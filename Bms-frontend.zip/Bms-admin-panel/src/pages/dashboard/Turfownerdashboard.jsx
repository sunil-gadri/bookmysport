import React, { useEffect, useState } from "react";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { PageHeader } from "../../components/UI.jsx";
import api from "../../api/axios.js";

const StatCard = ({ value, label, delta, deltaColor = "green", iconBg, iconColor, icon }) => (
  <div className="bg-bg-card border border-border rounded-lg p-4 flex flex-col gap-2">
    <div
      className="w-9 h-9 rounded-lg flex items-center justify-center"
      style={{ backgroundColor: iconBg }}
    >
      <i className={`ti ${icon}`} style={{ color: iconColor, fontSize: 16 }} />
    </div>
    <div className="text-t1 text-2xl font-bold font-poppins">{value}</div>
    <div className="text-t3 text-[11.5px]">{label}</div>
    {delta && (
      <div className={`text-[11px] font-semibold ${deltaColor === "green" ? "text-green" : "text-red"}`}>
        {delta}
      </div>
    )}
  </div>
);

const MiniStatCard = ({ label, value, sub }) => (
  <div className="bg-bg-card border border-border rounded-lg p-4 flex items-center justify-between">
    <div>
      <p className="text-t3 text-[11.5px] mb-1">{label}</p>
      <p className="text-t1 text-xl font-bold font-poppins">{value}</p>
    </div>
    <span className="text-t4 text-[10.5px]">{sub}</span>
  </div>
);

const ChartCard = ({ title, children, className = "" }) => (
  <div className={`bg-bg-card border border-border rounded-lg p-4 ${className}`}>
    <h3 className="text-t1 text-[13px] font-semibold mb-4">{title}</h3>
    {children}
  </div>
);

const STATUS_COLORS = {
  confirmed: "#2979FF",
  completed: "#22C55E",
  cancelled: "#EF4444",
};

const CustomTooltip = ({ active, payload, label, prefix = "" }) => {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="bg-bg-card border border-border rounded-md px-3 py-2 text-[11px]">
      <p className="text-t3 mb-1">{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color || p.fill }}>
          {p.name}: {prefix}
          {p.value?.toLocaleString?.() ?? p.value}
        </p>
      ))}
    </div>
  );
};

const TurfOwnerDashboard = () => {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState(null);
  const [charts, setCharts] = useState(null);

  const fetchDashboard = async () => {
    try {
      setLoading(true);
      const response = await api.get("/turf-owner/dashboard");
      setStats(response.data.data.stats);
      setCharts(response.data.data.charts);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  if (loading || !stats || !charts) {
    return (
      <div className="w-full p-2 lg:px-4 lg:py-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-32 rounded-lg bg-bg-card border border-border animate-pulse" />
          ))}
        </div>
        <div className="h-72 rounded-lg bg-bg-card border border-border animate-pulse" />
      </div>
    );
  }

  // If they have zero turfs yet, nudge them to add one instead of
  // showing a wall of empty charts.
  if (stats.total_turfs === 0) {
    return (
      <div className="w-full p-2 lg:px-4 lg:py-3">
        <PageHeader title="Dashboard" subtitle="Welcome!" />
        <div className="bg-bg-card border border-border rounded-lg p-10 text-center mt-4">
          <i className="ti ti-map-pin-plus text-t4" style={{ fontSize: 40 }} />
          <p className="text-t1 text-[15px] font-semibold mt-3">No turfs yet</p>
          <p className="text-t3 text-[12px] mt-1">
            Add your first turf to start seeing bookings and revenue here.
          </p>
        </div>
      </div>
    );
  }

  const todayLabel = new Date().toLocaleDateString("en-GB", {
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric",
  });

  return (
    <div className="w-full p-2 lg:px-4 lg:py-3 animate-fade-in">
      <PageHeader title="Dashboard" subtitle={todayLabel} />

      {/* Top stat cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-3 mt-3">
        <StatCard
          value={stats.total_bookings.toLocaleString()}
          label="Total Bookings"
          delta={`+${stats.bookings_today} today`}
          icon="ti-calendar-check"
          iconBg="rgba(41,121,255,.15)"
          iconColor="#2979FF"
        />
        <StatCard
          value={`₹${(stats.revenue_this_month / 1000).toFixed(1)}k`}
          label="Revenue (This Month)"
          delta={
            stats.revenue_change_percent === null
              ? null
              : `${stats.revenue_change_percent >= 0 ? "+" : ""}${stats.revenue_change_percent}% vs last month`
          }
          deltaColor={stats.revenue_change_percent >= 0 ? "green" : "red"}
          icon="ti-currency-rupee"
          iconBg="rgba(245,158,11,.15)"
          iconColor="#F59E0B"
        />
        <StatCard
          value={stats.checked_in_today.toLocaleString()}
          label="Checked In Today"
          delta={`of ${stats.bookings_today} today's bookings`}
          icon="ti-checkbox"
          iconBg="rgba(34,197,94,.15)"
          iconColor="#22C55E"
        />
        <StatCard
          value={stats.active_turfs.toLocaleString()}
          label="Active Turfs"
          delta={stats.pending_turfs > 0 ? `${stats.pending_turfs} pending review` : null}
          deltaColor="red"
          icon="ti-map-pin"
          iconBg="rgba(139,92,246,.15)"
          iconColor="#8B5CF6"
        />
      </div>

      {/* Secondary mini stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-4">
        <MiniStatCard
          label="Today's Occupancy"
          value={`${stats.occupancy_rate_today}%`}
          sub="Of today's active slots"
        />
        <MiniStatCard
          label="Avg Booking Value"
          value={`₹${stats.avg_booking_value}`}
          sub="Per transaction"
        />
        <MiniStatCard
          label="Cancellation Rate"
          value={`${stats.cancellation_rate}%`}
          sub="All time"
        />
      </div>

      {/* Charts grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 mb-3">
        <ChartCard title="Revenue Trend (Last 30 Days)" className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={charts.revenue_trend}>
              <defs>
                <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2979FF" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#2979FF" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
              <XAxis dataKey="label" tick={{ fill: "#8a8a99", fontSize: 10 }} interval={4} />
              <YAxis tick={{ fill: "#8a8a99", fontSize: 10 }} />
              <Tooltip content={<CustomTooltip prefix="₹" />} />
              <Area
                type="monotone"
                dataKey="revenue"
                name="Revenue"
                stroke="#2979FF"
                fill="url(#revenueGradient)"
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Booking Status">
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie
                data={charts.booking_status_breakdown}
                dataKey="total"
                nameKey="label"
                innerRadius={55}
                outerRadius={85}
                paddingAngle={3}
              >
                {charts.booking_status_breakdown.map((entry, i) => (
                  <Cell key={i} fill={STATUS_COLORS[entry.status] || "#888"} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
              <Legend
                verticalAlign="bottom"
                height={30}
                formatter={(value) => <span style={{ color: "#8a8a99", fontSize: 11 }}>{value}</span>}
              />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        <ChartCard title="Bookings (Last 14 Days)">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={charts.bookings_trend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
              <XAxis dataKey="label" tick={{ fill: "#8a8a99", fontSize: 10 }} interval={1} />
              <YAxis tick={{ fill: "#8a8a99", fontSize: 10 }} allowDecimals={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="bookings" name="Bookings" fill="#22C55E" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Only really useful when the owner has more than 1 turf, but
            harmless to always show — a single bar isn't confusing. */}
        <ChartCard title="Bookings By Turf">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={charts.bookings_by_turf} layout="vertical" margin={{ left: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" horizontal={false} />
              <XAxis type="number" tick={{ fill: "#8a8a99", fontSize: 10 }} allowDecimals={false} />
              <YAxis
                type="category"
                dataKey="turf_name"
                tick={{ fill: "#8a8a99", fontSize: 10 }}
                width={110}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="total_bookings" name="Bookings" fill="#F59E0B" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
};

export default TurfOwnerDashboard;