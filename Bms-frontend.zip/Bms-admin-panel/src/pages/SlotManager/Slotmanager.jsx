import React, { useEffect, useState } from "react";
import {
  StatCard,
  PageHeader,
  SearchBar,
  FilterChip,
  Pagination,
  EmptyState,
  Modal,
} from "../../components/UI.jsx";
import api from "../../api/axios.js";
import ListPageSkeleton from "../../components/skeletons/ListPageSkeleton.jsx";

// ── Status badge ──
const StatusBadge = ({ status }) =>
  status ? (
    <span className="px-2 py-0.5 rounded-[5px] text-[10px] font-bold bg-green/10 text-green">
      Active
    </span>
  ) : (
    <span className="px-2 py-0.5 rounded-[5px] text-[10px] font-bold bg-bg-input text-t3">
      Inactive
    </span>
  );

const SlotManager = () => {
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tableLoading, setTableLoading] = useState(false);

  const [currentPage, setCurrentPage] = useState(1);
  const [lastPage, setLastPage] = useState(1);
  const [totalSlots, setTotalSlots] = useState(0);

  const [searchText, setSearchText] = useState("");
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState(""); // "", "1", "0"
  const [day, setDay] = useState(""); // "", "monday", ...

  const [counts, setCounts] = useState({
    total_slots: 0,
    active_slots: 0,
    inactive_slots: 0,
  });

  const [actionLoading, setActionLoading] = useState(null); // slot id being toggled/deleted
  const [deleteSlot, setDeleteSlot] = useState(null); // slot pending delete confirmation

  const fetchSlots = async (page = 1) => {
    try {
      if (loading) {
        setLoading(true);
      } else {
        setTableLoading(true);
      }

      const response = await api.get("/admin/slots", {
        params: { page, search, status, day },
      });

      const res = response.data;

      setSlots(res.data);
      setCurrentPage(res.pagination.current_page);
      setLastPage(res.pagination.last_page);
      setTotalSlots(res.pagination.total);
      setCounts(res.counts);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
      setTableLoading(false);
    }
  };

  useEffect(() => {
    fetchSlots(currentPage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage, search, status, day]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchText.length >= 3 || searchText.length === 0) {
        setSearch(searchText);
        setCurrentPage(1);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [searchText]);

  const handleToggleStatus = async (slot) => {
    try {
      setActionLoading(slot.id);
      const response = await api.patch(`/admin/slots/${slot.id}/status`);
      const updated = response.data.data;
      setSlots((prev) =>
        prev.map((s) => (s.id === slot.id ? { ...s, status: updated.status } : s)),
      );
      setCounts((prev) => ({
        ...prev,
        active_slots: updated.status
          ? prev.active_slots + 1
          : prev.active_slots - 1,
        inactive_slots: updated.status
          ? prev.inactive_slots - 1
          : prev.inactive_slots + 1,
      }));
    } catch (error) {
      console.log(error);
    } finally {
      setActionLoading(null);
    }
  };

  const confirmDelete = async () => {
    if (!deleteSlot) return;
    try {
      setActionLoading(deleteSlot.id);
      await api.delete(`/admin/slots/${deleteSlot.id}`);
      setSlots((prev) => prev.filter((s) => s.id !== deleteSlot.id));
      setTotalSlots((prev) => prev - 1);
      setCounts((prev) => ({
        ...prev,
        total_slots: prev.total_slots - 1,
        active_slots: deleteSlot.status
          ? prev.active_slots - 1
          : prev.active_slots,
        inactive_slots: !deleteSlot.status
          ? prev.inactive_slots - 1
          : prev.inactive_slots,
      }));
      setDeleteSlot(null);
    } catch (error) {
      console.log(error);
    } finally {
      setActionLoading(null);
    }
  };

  const statusFilters = [
    { label: "All", value: "" },
    { label: "Active", value: "1" },
    { label: "Inactive", value: "0" },
  ];

  const dayFilters = [
    { label: "All Days", value: "" },
    { label: "Mon", value: "monday" },
    { label: "Tue", value: "tuesday" },
    { label: "Wed", value: "wednesday" },
    { label: "Thu", value: "thursday" },
    { label: "Fri", value: "friday" },
    { label: "Sat", value: "saturday" },
    { label: "Sun", value: "sunday" },
  ];

  const quickStats = [
    {
      icon: "ti-clock",
      value: counts.total_slots,
      label: "Total Slots",
      iconBg: "rgba(41,121,255,.15)",
      iconColor: "#2979FF",
    },
    {
      icon: "ti-circle-check",
      value: counts.active_slots,
      label: "Active Slots",
      iconBg: "rgba(34,197,94,.15)",
      iconColor: "#22C55E",
    },
    {
      icon: "ti-circle-x",
      value: counts.inactive_slots,
      label: "Inactive Slots",
      iconBg: "rgba(239,68,68,.15)",
      iconColor: "#EF4444",
    },
  ];

  if (loading) {
    return <ListPageSkeleton statsCount={3} tableRows={8} tableColumns={7} />;
  }

  return (
    <div className="w-full p-2 lg:px-4 lg:py-3 animate-fade-in">
      <PageHeader title="Slot Manager" subtitle={`${totalSlots} Total Slots`} />

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 mb-4">
        {quickStats.map((s, i) => (
          <StatCard key={i} {...s} />
        ))}
      </div>

      {/* Search + Filters */}
      <div className="flex flex-col gap-2 mb-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <SearchBar
            placeholder="Search by turf name or owner..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
          />
          <div className="flex items-center gap-2 overflow-x-auto">
            {statusFilters.map((item) => (
              <FilterChip
                key={item.label}
                label={item.label}
                active={status === item.value}
                onClick={() => {
                  setStatus(item.value);
                  setCurrentPage(1);
                }}
              />
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto">
          {dayFilters.map((item) => (
            <FilterChip
              key={item.label}
              label={item.label}
              active={day === item.value}
              onClick={() => {
                setDay(item.value);
                setCurrentPage(1);
              }}
            />
          ))}
        </div>
      </div>

      {/* Table */}
      {tableLoading ? (
        <div className="bg-bg-card border border-border rounded-lg p-4 space-y-2">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-10 rounded-md bg-bg-input animate-pulse" />
          ))}
        </div>
      ) : slots.length === 0 ? (
        <div className="bg-bg-card border border-border rounded-lg">
          <EmptyState
            icon="ti-clock-off"
            title="No slots found"
            sub="Try adjusting your search or filters to find what you're looking for."
          />
        </div>
      ) : (
        <div className="bg-bg-card border border-border rounded-lg overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-border">
                <th className="px-4 py-3 text-t3 text-[10px] uppercase tracking-wide font-semibold">
                  Turf
                </th>
                <th className="px-4 py-3 text-t3 text-[10px] uppercase tracking-wide font-semibold">
                  Sport / Event
                </th>
                <th className="px-4 py-3 text-t3 text-[10px] uppercase tracking-wide font-semibold">
                  Day
                </th>
                <th className="px-4 py-3 text-t3 text-[10px] uppercase tracking-wide font-semibold">
                  Time
                </th>
                <th className="px-4 py-3 text-t3 text-[10px] uppercase tracking-wide font-semibold">
                  Price
                </th>
                <th className="px-4 py-3 text-t3 text-[10px] uppercase tracking-wide font-semibold">
                  Status
                </th>
                <th className="px-4 py-3 text-t3 text-[10px] uppercase tracking-wide font-semibold text-right">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {slots.map((slot) => (
                <tr key={slot.id} className="border-b border-border last:border-0">
                  <td className="px-4 py-3">
                    <p className="text-t1 text-[12px] font-medium">{slot.turf_name}</p>
                    <p className="text-t4 text-[10px]">{slot.turf_owner_name}</p>
                  </td>
                  <td className="px-4 py-3 text-t2 text-[11.5px]">
                    {slot.booking_name}
                  </td>
                  <td className="px-4 py-3 text-t2 text-[11.5px]">{slot.day}</td>
                  <td className="px-4 py-3 text-t2 text-[11.5px]">
                    {slot.start_time} – {slot.end_time}
                  </td>
                  <td className="px-4 py-3 text-t2 text-[11.5px]">₹{slot.price}</td>
                  <td className="px-4 py-3">
                    <StatusBadge status={slot.status} />
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        disabled={actionLoading === slot.id}
                        onClick={() => handleToggleStatus(slot)}
                        className={`btn btn-sm disabled:opacity-50 ${
                          slot.status ? "btn-outline" : "btn-success"
                        }`}
                      >
                        {slot.status ? (
                          // "ban" icon — deactivate
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <circle cx="12" cy="12" r="9" />
                            <line x1="5.7" y1="5.7" x2="18.3" y2="18.3" />
                          </svg>
                        ) : (
                          // "check circle" icon — activate
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <circle cx="12" cy="12" r="9" />
                            <path d="M8.5 12.5l2.5 2.5 5-5" />
                          </svg>
                        )}
                        {slot.status ? "Deactivate" : "Activate"}
                      </button>
                      <button
                        disabled={actionLoading === slot.id}
                        onClick={() => setDeleteSlot(slot)}
                        className="btn btn-danger btn-sm disabled:opacity-50"
                        title="Delete slot"
                      >
                        {/* trash icon */}
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <line x1="4" y1="7" x2="20" y2="7" />
                          <path d="M6 7l1 13a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-13" />
                          <path d="M10 7V4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3" />
                          <line x1="10" y1="11" x2="10" y2="17" />
                          <line x1="14" y1="11" x2="14" y2="17" />
                        </svg>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination */}
      {!tableLoading && slots.length > 0 && lastPage > 1 && (
        <div className="mt-4 bg-bg-card border border-border rounded-lg">
          <Pagination
            info={`Page ${currentPage} of ${lastPage}`}
            pages={Array.from({ length: lastPage }, (_, i) => i + 1)}
            current={currentPage}
            onChange={setCurrentPage}
          />
        </div>
      )}

      {/* Delete confirmation modal */}
      {deleteSlot && (
        <Modal
          title="Delete Slot?"
          onClose={() => setDeleteSlot(null)}
          footer={
            <>
              <button
                className="btn btn-outline btn-sm"
                onClick={() => setDeleteSlot(null)}
              >
                Cancel
              </button>
              <button
                className="btn btn-danger btn-sm disabled:opacity-50"
                disabled={actionLoading === deleteSlot.id}
                onClick={confirmDelete}
              >
                Confirm Delete
              </button>
            </>
          }
        >
          <p className="text-[12px] text-t2">
            Are you sure you want to delete the{" "}
            <span className="font-semibold text-t1">
              {deleteSlot.day} {deleteSlot.start_time}–{deleteSlot.end_time}
            </span>{" "}
            slot for <span className="font-semibold text-t1">{deleteSlot.turf_name}</span>?
            This cannot be undone.
          </p>
        </Modal>
      )}
    </div>
  );
};

export default SlotManager; 