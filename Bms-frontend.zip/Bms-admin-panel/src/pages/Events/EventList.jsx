import React, { useEffect, useRef, useState } from "react";
import {
  Search,
  Plus,
  X,
  Pencil,
  Trash2,
  ImagePlus,
  Loader2,
  AlertTriangle,
} from "lucide-react";

import api from "../../api/axios";
import { PageHeader, StatCard } from "../../components/UI";
import ListPageSkeleton from "../../components/skeletons/ListPageSkeleton";
import { formatSportName } from "../../helpers/formatters";

const emptyForm = {
  name: "",
  status: 1,
};

const EventList = () => {
  const [events, setEvents] = useState([]);

  const [loading, setLoading] = useState(true);
  const [tableLoading, setTableLoading] = useState(false);

  const [currentPage, setCurrentPage] = useState(1);
  const [lastPage, setLastPage] = useState(1);
  const [perPage, setPerPage] = useState(10);

  const [totalEvents, setTotalEvents] = useState(0);
  const [activeEvents, setActiveEvents] = useState(0);
  const [inactiveEvents, setInactiveEvents] = useState(0);

  const [searchText, setSearchText] = useState("");
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");

  // Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState("add");
  const [editingId, setEditingId] = useState(null);

  const [modalLoading, setModalLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState(emptyForm);
  const [formErrors, setFormErrors] = useState({});

  const [selectedIconFile, setSelectedIconFile] = useState(null);
  const [unselectedIconFile, setUnselectedIconFile] = useState(null);

  const [selectedIconPreview, setSelectedIconPreview] = useState(null);
  const [unselectedIconPreview, setUnselectedIconPreview] = useState(null);

  const selectedIconInputRef = useRef(null);
  const unselectedIconInputRef = useRef(null);

  // Delete
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  // Status
  const [statusUpdatingId, setStatusUpdatingId] = useState(null);

  // ==============================
  // Fetch Events
  // ==============================

  const fetchEvents = async (page = 1) => {
    try {
      loading ? setLoading(true) : setTableLoading(true);

      const res = await api.get("/admin/events", {
        params: {
          page,
          search,
          status,
        },
      });

      const data = res.data;

      setEvents(data.data || []);

      setCurrentPage(data.pagination?.current_page || 1);
      setLastPage(data.pagination?.last_page || 1);
      setPerPage(data.pagination?.per_page || 10);

      setTotalEvents(data.counts?.total_events || 0);
      setActiveEvents(data.counts?.active_events || 0);
      setInactiveEvents(data.counts?.inactive_events || 0);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
      setTableLoading(false);
    }
  };

  // ==============================
  // Effects
  // ==============================

  useEffect(() => {
    fetchEvents(currentPage);

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage, search, status]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchText.length >= 3 || searchText.length === 0) {
        setSearch(searchText);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [searchText]);

  useEffect(() => {
    return () => {
      if (selectedIconPreview?.startsWith("blob:")) {
        URL.revokeObjectURL(selectedIconPreview);
      }

      if (unselectedIconPreview?.startsWith("blob:")) {
        URL.revokeObjectURL(unselectedIconPreview);
      }
    };

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedIconPreview, unselectedIconPreview]);

  // ==============================
  // Dashboard Stats
  // ==============================

  const stats = [
    {
      icon: "ti-calendar-event",
      value: totalEvents,
      label: "Total Events",
      iconBg: "rgba(41,121,255,.15)",
      iconColor: "#2979FF",
    },
    {
      icon: "ti-check",
      value: activeEvents,
      label: "Active Events",
      iconBg: "rgba(34,197,94,.15)",
      iconColor: "#22C55E",
    },
    {
      icon: "ti-ban",
      value: inactiveEvents,
      label: "Inactive Events",
      iconBg: "rgba(239,68,68,.15)",
      iconColor: "#EF4444",
    },
  ];

  const filters = ["All", "Active", "Inactive"];

  // ==============================
  // Reset Form
  // ==============================

  const resetForm = () => {
    setFormData(emptyForm);
    setFormErrors({});

    setSelectedIconFile(null);
    setUnselectedIconFile(null);

    setSelectedIconPreview(null);
    setUnselectedIconPreview(null);

    if (selectedIconInputRef.current) {
      selectedIconInputRef.current.value = "";
    }

    if (unselectedIconInputRef.current) {
      unselectedIconInputRef.current.value = "";
    }
  };

  // ==============================
  // Open Add Modal
  // ==============================

  const openAddModal = () => {
    resetForm();

    setModalMode("add");
    setEditingId(null);
    setModalOpen(true);
  };

  // ==============================
  // Open Edit Modal
  // ==============================

  const openEditModal = async (event) => {
    resetForm();

    setModalMode("edit");
    setEditingId(event.id);

    setModalOpen(true);
    setModalLoading(true);

    try {
      const res = await api.get(`/admin/events/${event.id}`);

      const data = res.data?.data || event;

      setFormData({
        name: data.name || "",
        status: data.status?.value ? 1 : 0,
      });

      setSelectedIconPreview(data.selected_icon || null);
      setUnselectedIconPreview(data.unselected_icon || null);
    } catch (error) {
      setFormData({
        name: event.name || "",
        status: event.status?.value ? 1 : 0,
      });

      setSelectedIconPreview(event.selected_icon || null);
      setUnselectedIconPreview(event.unselected_icon || null);
    } finally {
      setModalLoading(false);
    }
  };

  // ==============================
  // Close Modal
  // ==============================

  const closeModal = () => {
    if (submitting) return;

    setModalOpen(false);
    resetForm();
  };

  // ======================================
  // File Upload Validation
  // ======================================

  const handleFileChange = (e, type) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validTypes = [
      "image/png",
      "image/jpeg",
      "image/jpg",
      "image/svg+xml",
      "image/webp",
    ];

    if (!validTypes.includes(file.type)) {
      setFormErrors((prev) => ({
        ...prev,
        [type]: "Please upload a PNG, JPG, SVG or WEBP image.",
      }));
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      setFormErrors((prev) => ({
        ...prev,
        [type]: "Image must be under 2MB.",
      }));
      return;
    }

    const img = new Image();

    img.onload = () => {
      const { width, height } = img;

      if (width < 45 || height < 45) {
        setFormErrors((prev) => ({
          ...prev,
          [type]: "Image must be at least 45 × 45 pixels.",
        }));
        return;
      }

      if (width > 100 || height > 100) {
        setFormErrors((prev) => ({
          ...prev,
          [type]: "Image must not exceed 100 × 100 pixels.",
        }));
        return;
      }

      setFormErrors((prev) => ({
        ...prev,
        [type]: undefined,
      }));

      const preview = URL.createObjectURL(file);

      if (type === "selected_icon") {
        setSelectedIconFile(file);
        setSelectedIconPreview(preview);
      } else {
        setUnselectedIconFile(file);
        setUnselectedIconPreview(preview);
      }
    };

    img.onerror = () => {
      setFormErrors((prev) => ({
        ...prev,
        [type]: "Invalid image.",
      }));
    };

    img.src = URL.createObjectURL(file);
  };

  // ======================================
  // Form Validation
  // ======================================

  const validateForm = () => {
    const errors = {};

    if (!formData.name.trim()) {
      errors.name = "Event name is required.";
    } else if (formData.name.trim().length < 2) {
      errors.name = "Event name must be at least 2 characters.";
    } else if (formData.name.trim().length > 50) {
      errors.name = "Event name must be under 50 characters.";
    }

    if (modalMode === "add") {
      if (!selectedIconFile)
        errors.selected_icon = "Selected icon is required.";

      if (!unselectedIconFile)
        errors.unselected_icon = "Unselected icon is required.";
    }

    setFormErrors(errors);

    return Object.keys(errors).length === 0;
  };

  // ======================================
  // Submit
  // ======================================

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    setSubmitting(true);

    try {
      const payload = new FormData();

      payload.append("name", formatSportName(formData.name.trim()));
      payload.append("status", formData.status);

      if (selectedIconFile) payload.append("selected_icon", selectedIconFile);

      if (unselectedIconFile)
        payload.append("unselected_icon", unselectedIconFile);

      if (modalMode === "add") {
        await api.post("/admin/events", payload, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
      } else {
        payload.append("_method", "POST");

        await api.post(`/admin/events/${editingId}`, payload, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
      }

      closeModal();

      if (modalMode === "add") {
        setCurrentPage(1);
        fetchEvents(1);
      } else {
        fetchEvents(currentPage);
      }
    } catch (err) {
      const apiErrors = err?.response?.data?.errors;

      if (apiErrors) {
        const mapped = {};

        Object.entries(apiErrors).forEach(([key, value]) => {
          mapped[key] = Array.isArray(value) ? value[0] : value;
        });

        setFormErrors(mapped);
      } else {
        setFormErrors({
          form:
            err?.response?.data?.message ||
            "Something went wrong. Please try again.",
        });
      }
    } finally {
      setSubmitting(false);
    }
  };

  // ======================================
  // Delete
  // ======================================

  const confirmDelete = (event) => {
    setDeleteTarget(event);
  };

  const cancelDelete = () => {
    if (!deleting) {
      setDeleteTarget(null);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;

    setDeleting(true);

    try {
      await api.delete(`/admin/events/${deleteTarget.id}`);

      setDeleteTarget(null);

      const nextPage =
        events.length === 1 && currentPage > 1 ? currentPage - 1 : currentPage;

      setCurrentPage(nextPage);

      fetchEvents(nextPage);
    } catch (err) {
      setDeleteTarget((prev) => ({
        ...prev,
        _error: err?.response?.data?.message || "Failed to delete event.",
      }));
    } finally {
      setDeleting(false);
    }
  };

  // ======================================
  // Toggle Status
  // ======================================

  const handleToggleStatus = async (event) => {
    const nextStatus = event.status?.value ? 0 : 1;

    setStatusUpdatingId(event.id);

    setEvents((prev) =>
      prev.map((item) =>
        item.id === event.id
          ? {
              ...item,
              status: {
                value: !!nextStatus,
                label: nextStatus ? "Active" : "Inactive",
              },
            }
          : item,
      ),
    );

    try {
      await api.patch(`/admin/events/${event.id}/status`, {
        status: nextStatus,
      });

      fetchEvents(currentPage);
    } catch {
      setEvents((prev) =>
        prev.map((item) => (item.id === event.id ? event : item)),
      );
    } finally {
      setStatusUpdatingId(null);
    }
  };

  // ======================================
  // Skeleton
  // ======================================

  if (loading) {
    return <ListPageSkeleton statsCount={3} tableRows={8} tableColumns={8} />;
  }

  return (
    <div className="w-full p-2 lg:px-4 lg:py-3">
      <PageHeader
        title="Events Management"
        subtitle={`${totalEvents} Total Events`}
      >
        <button
          onClick={openAddModal}
          className="flex items-center gap-1.5 px-3 py-2 text-[11px] rounded-sm bg-blue-600 text-white font-semibold hover:bg-blue-500 transition-colors cursor-pointer"
        >
          <Plus size={13} />
          Add Event
        </button>
      </PageHeader>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-2 mb-4">
        {stats.map((item, index) => (
          <StatCard key={index} {...item} />
        ))}
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col xl:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search
            size={14}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6b7280]"
          />

          <input
            value={searchText}
            onChange={(e) => {
              setSearchText(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Search events..."
            className="w-full h-8 pl-9 pr-3 rounded-[8px] text-[11px] bg-[#14141A] border border-[#1F1F27] text-[#a0a0a0] outline-none"
          />
        </div>

        <div className="flex flex-wrap gap-2 mt-1">
          {filters.map((item) => (
            <button
              key={item}
              onClick={() => {
                setCurrentPage(1);

                if (item === "All") {
                  setStatus("");
                } else if (item === "Active") {
                  setStatus(1);
                } else {
                  setStatus(0);
                }
              }}
              className={`h-6 px-3 rounded-sm text-[10px] border cursor-pointer
              ${
                (item === "All" && status === "") ||
                (item === "Active" && status === 1) ||
                (item === "Inactive" && status === 0)
                  ? "bg-blue-600/10 border-blue-600 text-blue-400"
                  : "bg-[#11131d] border-[#1f2333] text-[#a0a0a0]"
              }`}
            >
              {item}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
        <div className="flex justify-between items-center px-6 py-2 border-b border-[#1f2333]">
          <h2 className="text-sm font-bold text-white">All Events</h2>

          <span className="text-gray-400 text-[10px]">
            Showing {totalEvents === 0 ? 0 : (currentPage - 1) * perPage + 1}-
            {Math.min(currentPage * perPage, totalEvents)}
            of {totalEvents}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[980px]">
            <thead>
              <tr className="border-b border-[#1f2333] text-gray-500 text-[8px]">
                <th className="text-left px-4 py-2">Sr No</th>
                <th className="text-left">Selected Icon</th>
                <th className="text-left">Unselected Icon</th>
                <th className="text-left">Event Name</th>
                <th className="text-left">Slug</th>
                <th className="text-left">Status</th>
                <th className="text-left">Created At</th>
                <th className="text-left">Action</th>
              </tr>
            </thead>

            <tbody>
              {tableLoading ? (
                <tr>
                  <td colSpan="8" className="text-center py-10 text-white">
                    Loading...
                  </td>
                </tr>
              ) : events.length === 0 ? (
                <tr>
                  <td colSpan="8" className="text-center py-10 text-gray-400">
                    No events found
                  </td>
                </tr>
              ) : (
                events.map((event, index) => (
                  <tr
                    key={event.id}
                    className="border-b border-[#1f2333] hover:bg-[#161926]"
                  >
                    <td className="pl-8 text-[11px] text-[#C0C0C0]">
                      {(currentPage - 1) * perPage + index + 1}
                    </td>

                    <td>
                      <img
                        src={event.selected_icon}
                        alt=""
                        className="w-8 h-8 object-contain"
                      />
                    </td>

                    <td>
                      <img
                        src={event.unselected_icon}
                        alt=""
                        className="w-8 h-8 object-contain"
                      />
                    </td>

                    <td className="text-white text-[11px]">{event.name}</td>

                    <td className="text-[#C0C0C0] text-[11px]">{event.slug}</td>

                    <td>
                      <button
                        onClick={() => handleToggleStatus(event)}
                        disabled={statusUpdatingId === event.id}
                        className={`flex items-center gap-1 px-2 py-1 rounded-[6px] text-[9px] font-semibold cursor-pointer transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                          event.status?.label === "Active"
                            ? "bg-green-500/15 text-green-400 hover:bg-green-500/25"
                            : "bg-yellow-500/15 text-yellow-400 hover:bg-yellow-500/25"
                        }`}
                      >
                        {statusUpdatingId === event.id && (
                          <Loader2 size={10} className="animate-spin" />
                        )}

                        {event.status?.label}
                      </button>
                    </td>

                    <td className="text-[#C0C0C0] text-[11px]">
                      {event.created_at}
                    </td>

                    <td>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => openEditModal(event)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-[6px] text-[9px] font-semibold bg-blue-600/10 border border-blue-600/40 text-blue-400 hover:bg-blue-600/20 cursor-pointer"
                        >
                          <Pencil size={11} />
                          Edit
                        </button>

                        <button
                          onClick={() => confirmDelete(event)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-[6px] text-[9px] font-semibold bg-red-500/10 border border-red-500/40 text-red-400 hover:bg-red-500/20 cursor-pointer"
                        >
                          <Trash2 size={11} />
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex justify-between items-center px-4 py-2">
          <span className="text-gray-400 text-[10px]">
            Page {currentPage} of {lastPage}
          </span>

          <div className="flex gap-2">
            <button
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(currentPage - 1)}
              className="w-7 h-7 rounded-[7px] bg-[#161926] disabled:opacity-40"
            >
              ←
            </button>

            <button className="w-7 h-7 rounded-[7px] bg-blue-600 text-white">
              {currentPage}
            </button>

            <button
              disabled={currentPage === lastPage}
              onClick={() => setCurrentPage(currentPage + 1)}
              className="w-7 h-7 rounded-[7px] bg-[#161926] disabled:opacity-40"
            >
              →
            </button>
          </div>
        </div>
      </div>

      {/* ================= Add / Edit Modal ================= */}

      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
          onClick={closeModal}
        >
          <div
            className="w-full max-w-md bg-[#14141A] border border-[#1F1F27] rounded-[14px] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#1F1F27]">
              <h3 className="text-[13px] font-bold text-white">
                {modalMode === "add" ? "Add Event" : "Edit Event"}
              </h3>

              <button
                onClick={closeModal}
                disabled={submitting}
                className="w-7 h-7 rounded-full bg-[#1F1F27] flex items-center justify-center text-[#A0A0A0] hover:text-white disabled:opacity-50"
              >
                <X size={14} />
              </button>
            </div>

            {modalLoading ? (
              <div className="flex items-center justify-center py-16">
                <Loader2 size={22} className="animate-spin text-blue-500" />
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="px-5 py-4">
                {formErrors.form && (
                  <div className="mb-3 flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-[8px] px-3 py-2 text-[10px] text-red-400">
                    <AlertTriangle size={13} />
                    {formErrors.form}
                  </div>
                )}

                {/* Event Name */}

                <div className="mb-4">
                  <label className="block text-[9px] text-[#A0A0A0] uppercase tracking-wide font-semibold mb-1.5">
                    Event Name
                  </label>

                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        name: formatSportName(e.target.value),
                      }))
                    }
                    placeholder="Enter Event Name"
                    className={`w-full h-9 px-3 rounded-[8px] text-[11px] bg-[#1F1F27] border text-white placeholder:text-[#555] outline-none ${
                      formErrors.name
                        ? "border-red-500"
                        : "border-[#2a2a35] focus:border-blue-600"
                    }`}
                  />

                  {formErrors.name && (
                    <p className="text-[9px] text-red-400 mt-1">
                      {formErrors.name}
                    </p>
                  )}
                </div>

                {/* Icons */}

                <div className="grid grid-cols-2 gap-3 mb-4">
                  {/* Selected */}

                  <div>
                    <label className="block text-[9px] text-[#A0A0A0] uppercase tracking-wide font-semibold mb-1.5">
                      Selected Icon
                    </label>

                    <input
                      ref={selectedIconInputRef}
                      id="selected_icon"
                      type="file"
                      className="hidden"
                      accept="image/png,image/jpeg,image/svg+xml,image/webp"
                      onChange={(e) => handleFileChange(e, "selected_icon")}
                    />

                    <label
                      htmlFor="selected_icon"
                      className={`flex flex-col items-center justify-center gap-2 h-24 rounded-[10px] border border-dashed cursor-pointer ${
                        formErrors.selected_icon
                          ? "border-red-500"
                          : "border-[#2a2a35] hover:border-blue-600"
                      }`}
                    >
                      {selectedIconPreview ? (
                        <img
                          src={selectedIconPreview}
                          className="w-10 h-10 object-contain"
                          alt=""
                        />
                      ) : (
                        <ImagePlus size={18} className="text-[#555]" />
                      )}

                      <span className="text-[8px] text-[#A0A0A0]">
                        {selectedIconFile
                          ? selectedIconFile.name
                          : "Upload PNG/SVG"}
                      </span>
                    </label>

                    {formErrors.selected_icon && (
                      <p className="text-[9px] text-red-400 mt-1">
                        {formErrors.selected_icon}
                      </p>
                    )}
                  </div>

                  {/* Unselected */}

                  <div>
                    <label className="block text-[9px] text-[#A0A0A0] uppercase tracking-wide font-semibold mb-1.5">
                      Unselected Icon
                    </label>

                    <input
                      ref={unselectedIconInputRef}
                      id="unselected_icon"
                      type="file"
                      className="hidden"
                      accept="image/png,image/jpeg,image/svg+xml,image/webp"
                      onChange={(e) => handleFileChange(e, "unselected_icon")}
                    />

                    <label
                      htmlFor="unselected_icon"
                      className={`flex flex-col items-center justify-center gap-2 h-24 rounded-[10px] border border-dashed cursor-pointer ${
                        formErrors.unselected_icon
                          ? "border-red-500"
                          : "border-[#2a2a35] hover:border-blue-600"
                      }`}
                    >
                      {unselectedIconPreview ? (
                        <img
                          src={unselectedIconPreview}
                          className="w-10 h-10 object-contain"
                          alt=""
                        />
                      ) : (
                        <ImagePlus size={18} className="text-[#555]" />
                      )}

                      <span className="text-[8px] text-[#A0A0A0]">
                        {unselectedIconFile
                          ? unselectedIconFile.name
                          : "Upload PNG/SVG"}
                      </span>
                    </label>

                    {formErrors.unselected_icon && (
                      <p className="text-[9px] text-red-400 mt-1">
                        {formErrors.unselected_icon}
                      </p>
                    )}
                  </div>
                </div>

              {/* Status */}
              <div className="mb-5">     
                           <label className="block text-[9px] text-[#A0A0A0] uppercase tracking-wide font-semibold mb-1.5">
                  Status
                </label>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      setFormData((prev) => ({
                        ...prev,
                        status: 1,
                      }))
                    }
                    className={`flex-1 h-8 rounded-[8px] text-[10px] font-semibold cursor-pointer ${
                      formData.status === 1
                        ? "bg-green-500/15 border border-green-500/50 text-green-400"
                        : "bg-[#1F1F27] border border-[#2a2a35] text-[#A0A0A0]"
                    }`}
                  >
                    Active
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      setFormData((prev) => ({
                        ...prev,
                        status: 0,
                      }))
                    }
                    className={`flex-1 h-8 rounded-[8px] text-[10px] font-semibold cursor-pointer ${
                      formData.status === 0
                        ? "bg-yellow-500/15 border border-yellow-500/50 text-yellow-400"
                        : "bg-[#1F1F27] border border-[#2a2a35] text-[#A0A0A0]"
                    }`}
                  >
                    Inactive
                  </button>
                </div>
              </div>

              {/* Footer */}
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={closeModal}
                  disabled={submitting}
                  className="px-4 py-2 rounded-[8px] bg-[#1F1F27] text-[#A0A0A0] text-[11px] font-semibold hover:bg-[#2A2A35] disabled:opacity-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={submitting}
                  className="flex items-center gap-2 px-4 py-2 rounded-[8px] bg-blue-600 text-white text-[11px] font-semibold hover:bg-blue-500 disabled:opacity-60"
                >
                  {submitting && (
                    <Loader2
                      size={13}
                      className="animate-spin"
                    />
                  )}

                  {modalMode === "add"
                    ? "Add Event"
                    : "Update Event"}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    )}

    {/* ================= Delete Modal ================= */}

    {deleteTarget && (
      <div
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
        onClick={cancelDelete}
      >
        <div
          className="w-full max-w-sm bg-[#14141A] border border-[#1F1F27] rounded-[14px] p-5"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="w-11 h-11 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center mb-3">
            <AlertTriangle
              size={20}
              className="text-red-400"
            />
          </div>

          <h3 className="text-[13px] font-bold text-white mb-1.5">
            Delete "{deleteTarget.name}"?
          </h3>

          <p className="text-[10px] text-[#A0A0A0] mb-2">
            This will permanently remove this event.
            This action cannot be undone.
          </p>

          {deleteTarget._error && (
            <p className="text-[10px] text-red-400 mb-3">
              {deleteTarget._error}
            </p>
          )}

          <div className="flex justify-end gap-2">
            <button
              onClick={cancelDelete}
              disabled={deleting}
              className="px-4 py-2 rounded-[8px] bg-[#1F1F27] text-[#A0A0A0] text-[11px] font-semibold disabled:opacity-50"
            >
              Cancel
            </button>

            <button
              onClick={handleDelete}
              disabled={deleting}
              className="flex items-center gap-2 px-4 py-2 rounded-[8px] bg-red-500 text-white text-[11px] font-semibold hover:bg-red-400 disabled:opacity-60"
            >
              {deleting && (
                <Loader2
                  size={13}
                  className="animate-spin"
                />
              )}

              Delete
            </button>
          </div>
        </div>
      </div>
    )}
  </div>
);
};


export default EventList;