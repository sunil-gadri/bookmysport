import React, { useEffect, useState, useMemo } from "react";
import {
  ArrowLeft,
  MapPin,
  Phone,
  Mail,
  Clock,
  LayoutGrid,
  Star,
  ShieldCheck,
  Edit3,
  Calendar,
  ImageOff,
  ExternalLink,
  AlertTriangle,
  Sparkles,
  RefreshCw,
  Hash,
} from "lucide-react";
import api from "../../../api/axios";
import { PageHeader } from "../../../components/UI";
import { useNavigate, useParams } from "react-router-dom";
import TurfViewSkeleton from "../../../components/skeletons/TurfViewSkeleton";

const StatusBadge = ({ status, approvalStatus }) => {
  if (approvalStatus === "pending") {
    return (
      <span className="px-2.5 py-1 rounded-[6px] text-[10px] font-semibold bg-amber-500/15 text-amber-400">
        Pending
      </span>
    );
  }
  if (approvalStatus === "rejected") {
    return (
      <span className="px-2.5 py-1 rounded-[6px] text-[10px] font-semibold bg-red-500/15 text-red-400">
        Rejected
      </span>
    );
  }
  if (approvalStatus === "approved") {
    return (
      <span className="px-2.5 py-1 rounded-[6px] text-[10px] font-semibold bg-red-500/15 text-green-400">
        Approved
      </span>
    );
  }

  return status ? (
    <span className="px-2.5 py-1 rounded-[6px] text-[10px] font-semibold bg-green-500/15 text-green-400">
      Active
    </span>
  ) : (
    <span className="px-2.5 py-1 rounded-[6px] text-[10px] font-semibold bg-gray-500/15 text-gray-400">
      Inactive
    </span>
  );
};

const StatCard = ({ icon, label, value }) => (
  <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] p-4 flex items-center gap-3">
    <div className="w-9 h-9 rounded-[8px] bg-blue-600/10 border border-blue-600/30 flex items-center justify-center text-blue-400 shrink-0">
      {icon}
    </div>
    <div>
      <p className="text-gray-500 text-[9px] uppercase tracking-wide">
        {label}
      </p>
      <p className="text-white text-[13px] font-bold mt-0.5">{value}</p>
    </div>
  </div>
);

const InfoRow = ({ icon, label, value }) => (
  <div className="flex items-start gap-3">
    <div className="w-7 h-7 rounded-[6px] bg-blue-600/10 border border-blue-600/30 flex items-center justify-center text-blue-400 shrink-0">
      {icon}
    </div>
    <div>
      <p className="text-gray-500 text-[9px] uppercase tracking-wide">
        {label}
      </p>
      <p className="text-[#C0C0C0] text-[11px] mt-0.5">{value || "-"}</p>
    </div>
  </div>
);

const SectionCard = ({ title, action, children }) => (
  <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
    <div className="px-6 py-3 border-b border-[#1f2333] flex items-center justify-between">
      <h3 className="text-white text-[12px] font-bold">{title}</h3>
      {action}
    </div>
    <div className="p-6">{children}</div>
  </div>
);

const TurfView = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [turf, setTurf] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [activeImage, setActiveImage] = useState(null);

  const fetchTurf = async () => {
    try {
      setLoading(true);
      setError("");

      const res = await api.get(`/turf-owner/turfs/${id}`);

      if (res.data.success) {
        setTurf(res.data.data);
        const gallery = buildGallery(res.data.data);
        setActiveImage(gallery[0] || null);
      } else {
        setError(res.data.message || "Failed to load turf details.");
      }
    } catch (err) {
      setError(
        err?.response?.data?.message ||
          "Something went wrong while fetching this turf.",
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTurf();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  function buildGallery(t) {
    if (!t) return [];
    const galleryImages = [...(t.images || [])]
      .sort((a, b) => a.sort_order - b.sort_order)
      .map((img) => img.image);
    if (t.cover_image && !galleryImages.includes(t.cover_image)) {
      return [t.cover_image, ...galleryImages];
    }
    return galleryImages;
  }

  const gallery = useMemo(() => buildGallery(turf), [turf]);
  const rating = parseFloat(turf?.average_rating || "0");
  const hasReviews = turf?.total_reviews > 0;
  const mapUrl =
    turf?.latitude && turf?.longitude
      ? `https://www.google.com/maps?q=${turf.latitude},${turf.longitude}`
      : null;

  const formatDate = (dateStr) => {
    if (!dateStr) return "-";
    return new Date(dateStr).toLocaleString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (loading) {
    return <TurfViewSkeleton />;
  }

  if (error) {
    return (
      <div className="w-full p-2 lg:px-4 lg:py-3">
        <button
          onClick={() => navigate("/my-turfs")}
          className="inline-flex cursor-pointer items-center gap-1.5 text-gray-500 text-[11px] font-semibold mb-4 hover:text-white transition-colors"
        >
          <ArrowLeft size={13} />
          Back to My Turfs
        </button>
        <div className="bg-[#14141a] border border-red-500/30 rounded-[10px] p-6 text-center">
          <p className="text-red-400 text-[12px] mb-3">{error}</p>
          <button
            onClick={fetchTurf}
            className="inline-flex cursor-pointer items-center gap-1.5 px-3 py-2 rounded-sm bg-blue-600 text-white text-[11px] font-semibold"
          >
            <RefreshCw size={12} />
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!turf) return null;

  return (
    <div className="w-full p-2 lg:px-4 lg:py-3">
      <button
        onClick={() => navigate("/my-turfs")}
        className="inline-flex cursor-pointer items-center gap-1.5 text-gray-500 text-[11px] font-semibold mb-4 hover:text-white transition-colors"
      >
        <ArrowLeft size={13} />
        Back to My Turfs
      </button>

      <PageHeader title={turf.name} subtitle={turf.address}>
        <button
          onClick={() => navigate(`/my-turfs/${turf.id}/edit`)}
          className="flex cursor-pointer items-center gap-1.5 px-3 py-2 text-[11px] rounded-sm bg-blue-600 text-white font-semibold"
        >
          <Edit3 size={12} />
          Edit Turf
        </button>
      </PageHeader>

      {turf.approval_status === "rejected" && turf.rejection_reason && (
        <div className="bg-red-500/10 border border-red-500/30 rounded-[10px] p-4 mb-3 flex items-start gap-3">
          <AlertTriangle size={16} className="text-red-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-red-400 text-[11px] font-semibold">
              This turf was rejected
            </p>
            <p className="text-red-300/80 text-[11px] mt-1">
              {turf.rejection_reason}
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">
        {/* Left column */}
        <div className="xl:col-span-2 flex flex-col gap-3">
          {/* Gallery */}
          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
            <div className="relative h-72 sm:h-96 bg-[#161926]">
              {activeImage ? (
                <img
                  src={activeImage}
                  alt={turf.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-gray-600 gap-2">
                  <ImageOff size={28} />
                  <span className="text-[11px]">No images uploaded</span>
                </div>
              )}
              <div className="absolute top-3 right-3 flex gap-2">
                {turf.is_featured && (
                  <span className="px-2.5 py-1 rounded-[6px] text-[10px] font-semibold bg-blue-600/20 text-blue-400 flex items-center gap-1">
                    <Sparkles size={10} />
                    Featured
                  </span>
                )}
                <StatusBadge
                  status={turf.status}
                  approvalStatus={turf.approval_status}
                />
              </div>
            </div>

            {gallery.length > 1 && (
              <div className="flex gap-2 p-3 overflow-x-auto">
                {gallery.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(img)}
                    className={`w-16 h-16 rounded-[8px] overflow-hidden border shrink-0 transition-colors ${
                      activeImage === img
                        ? "border-blue-600"
                        : "border-[#1F1F27]"
                    }`}
                  >
                    <img
                      src={img}
                      alt=""
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Quick stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <StatCard
              icon={<Star size={15} />}
              label="Rating"
              value={hasReviews ? rating.toFixed(1) : "New"}
            />
            <StatCard
              icon={<Hash size={15} />}
              label="Reviews"
              value={turf.total_reviews ?? 0}
            />
            <StatCard
              icon={<LayoutGrid size={15} />}
              label="Sports"
              value={turf.sports?.length ?? 0}
            />
            <StatCard
              icon={<ShieldCheck size={15} />}
              label="Amenities"
              value={turf.amenities?.length ?? 0}
            />
          </div>

          {/* About */}
          <SectionCard title="About">
            <p className="text-[#8b8b93] text-[11px] leading-relaxed">
              {turf.description || "No description added yet."}
            </p>
          </SectionCard>

          {/* Sports & Amenities */}
          <SectionCard title="Sports & Amenities">
            <div className="flex flex-col gap-4">
              <div>
                <p className="text-gray-500 text-[9px] uppercase tracking-wide mb-2">
                  Sports Available
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {turf.sports?.length > 0 ? (
                    turf.sports.map((sport) => (
                      <span
                        key={sport.id}
                        className="px-2.5 py-1 rounded-full text-[10px] bg-blue-600/10 text-blue-400 border border-blue-600/30"
                      >
                        {sport.name}
                      </span>
                    ))
                  ) : (
                    <span className="text-gray-500 text-[11px]">
                      No sports added
                    </span>
                  )}
                </div>
              </div>

              <div>
                <p className="text-gray-500 text-[9px] uppercase tracking-wide mb-2">
                  Events
                </p>

                <div className="flex flex-wrap gap-1.5">
                  {turf.events?.length > 0 ? (
                    turf.events.map((event) => (
                      <span
                        key={event.id}
                        className="px-2.5 py-1 rounded-full text-[10px]
          bg-purple-600/10
          text-purple-400
          border border-purple-600/30"
                      >
                        {event.name}
                      </span>
                    ))
                  ) : (
                    <span className="text-gray-500 text-[11px]">
                      No events added
                    </span>
                  )}
                </div>
              </div>

              <div>
                <p className="text-gray-500 text-[9px] uppercase tracking-wide mb-2">
                  Amenities
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {turf.amenities?.length > 0 ? (
                    turf.amenities.map((amenity) => (
                      <span
                        key={amenity.id}
                        className="px-2.5 py-1 rounded-full text-[10px] bg-[#161926] text-[#C0C0C0] border border-[#1f2333]"
                      >
                        {amenity.name}
                      </span>
                    ))
                  ) : (
                    <span className="text-gray-500 text-[11px]">
                      No amenities added
                    </span>
                  )}
                </div>
              </div>
            </div>
          </SectionCard>
        </div>

        {/* Right column */}
        <div className="flex flex-col gap-3">
          {/* Business info */}
          <SectionCard title="Business Information">
            <div className="flex flex-col gap-4">
              <InfoRow
                icon={<Phone size={13} />}
                label="Contact Number"
                value={turf.contact_number}
              />
              <InfoRow
                icon={<Mail size={13} />}
                label="Email"
                value={turf.email}
              />
              <InfoRow
                icon={<MapPin size={13} />}
                label="Landmark"
                value={turf.landmark}
              />
              <InfoRow
                icon={<Hash size={13} />}
                label="Pincode"
                value={turf.pincode}
              />
            </div>
          </SectionCard>

          {/* Timing & ground */}
          <SectionCard title="Timing & Ground">
            <div className="flex flex-col gap-4">
              <InfoRow
                icon={<Clock size={13} />}
                label="Operating Hours"
                value={`${turf.opening_time} – ${turf.closing_time}`}
              />
              <InfoRow
                icon={<LayoutGrid size={13} />}
                label="Ground Type"
                value={turf.ground_type}
              />
            </div>
          </SectionCard>

          {/* Location */}
          <SectionCard
            title="Location"
            action={
              mapUrl && (
                <a
                  href={mapUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1 text-blue-400 text-[10px] font-semibold hover:text-blue-300"
                >
                  View on Map
                  <ExternalLink size={10} />
                </a>
              )
            }
          >
            <div className="flex flex-col gap-4">
              <InfoRow
                icon={<MapPin size={13} />}
                label="Country"
                value={turf.country?.name}
              />

              <InfoRow
                icon={<MapPin size={13} />}
                label="State"
                value={turf.state?.name}
              />

              <InfoRow
                icon={<MapPin size={13} />}
                label="City"
                value={turf.city?.name}
              />

              <InfoRow
                icon={<MapPin size={13} />}
                label="Address"
                value={turf.address}
              />

              <InfoRow
                icon={<MapPin size={13} />}
                label="Area"
                value={turf.area}
              />

              <InfoRow
                icon={<Hash size={13} />}
                label="Latitude"
                value={turf.latitude}
              />

              <InfoRow
                icon={<Hash size={13} />}
                label="Longitude"
                value={turf.longitude}
              />
            </div>
          </SectionCard>

          {/* Timeline */}
          <SectionCard title="Account Timeline">
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-[6px] bg-[#161926] border border-[#1f2333] flex items-center justify-center text-gray-400 shrink-0">
                  <Calendar size={13} />
                </div>
                <div>
                  <p className="text-gray-500 text-[9px] uppercase tracking-wide">
                    Created At
                  </p>
                  <p className="text-[#C0C0C0] text-[11px] mt-0.5">
                    {formatDate(turf.created_at)}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-[6px] bg-[#161926] border border-[#1f2333] flex items-center justify-center text-gray-400 shrink-0">
                  <Calendar size={13} />
                </div>
                <div>
                  <p className="text-gray-500 text-[9px] uppercase tracking-wide">
                    Last Updated
                  </p>
                  <p className="text-[#C0C0C0] text-[11px] mt-0.5">
                    {formatDate(turf.updated_at)}
                  </p>
                </div>
              </div>
            </div>
          </SectionCard>
        </div>
      </div>
    </div>
  );
};

export default TurfView;
