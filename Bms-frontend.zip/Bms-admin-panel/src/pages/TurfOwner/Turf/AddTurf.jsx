import React, { useEffect, useRef, useState } from "react";
import {
  Building2,
  MapPin,
  Phone,
  Mail,
  Clock,
  Image as ImageIcon,
  ImagePlus,
  X,
  Loader2,
  AlertTriangle,
  Dumbbell,
  Sparkles,
  LocateFixed,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

import {
  MapContainer,
  TileLayer,
  Marker,
  useMap,
  useMapEvents,
} from "react-leaflet";

import L from "leaflet";
import "leaflet/dist/leaflet.css";

import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";

import api from "../../../api/axios";

import {
  formatTitleCase,
  formatAddress,
  formatDescription,
} from "../../../helpers/formatters";

import { PageHeader } from "../../../components/UI";

/* =========================================================
   LEAFLET MARKER FIX
========================================================= */

delete L.Icon.Default.prototype._getIconUrl;

L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

/* =========================================================
   ENDPOINTS
========================================================= */

const ENDPOINTS = {
  ADD_TURF: "/turf-owner/turfs",
  COUNTRIES: "masters/countries",
  STATES: (countryId) =>
    `masters/states?country_id=${countryId}`,
  CITIES: (stateId) =>
    `masters/cities?state_id=${stateId}`,
  SPORTS: "/sports",
  EVENTS: "/events",
  AMENITIES: "/amenities",
};

const MAX_GALLERY_IMAGES = 20;

const VALID_IMAGE_TYPES = [
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp",
];

/* =========================================================
   EMPTY FORM
========================================================= */

const emptyForm = {
  name: "",
  description: "",
  contact_number: "",
  email: "",
  address: "",
  area: "",
  landmark: "",
  country_id: "",
  state_id: "",
  city_id: "",
  pincode: "",

  latitude: "",
  longitude: "",

  opening_time: "",
  closing_time: "",
  ground_type: "single",
};

/* =========================================================
   LOCATION MARKER
========================================================= */

const LocationMarker = ({
  position,
  onLocationSelect,
}) => {
  const map = useMap();

  const selectLocation = (lat, lng) => {
    const newPosition = [lat, lng];

    onLocationSelect(lat, lng);

    map.flyTo(newPosition, Math.max(map.getZoom(), 15), {
      animate: true,
    });
  };

  /* Map par click */
  useMapEvents({
    click(e) {
      selectLocation(
        e.latlng.lat,
        e.latlng.lng
      );
    },
  });

  if (!position) {
    return null;
  }

  return (
    <Marker
      position={position}
      draggable={true}
      eventHandlers={{
        dragend: (e) => {
          const marker = e.target;

          const latLng = marker.getLatLng();

          selectLocation(
            latLng.lat,
            latLng.lng
          );
        },
      }}
    />
  );
};

/* =========================================================
   MAP VIEW CONTROLLER
========================================================= */

const MapController = ({ position }) => {
  const map = useMap();

  useEffect(() => {
    if (!position) return;

    map.flyTo(position, 15, {
      animate: true,
    });
  }, [position, map]);

  return null;
};

/* =========================================================
   MAIN COMPONENT
========================================================= */

const AddTurf = () => {
  const navigate = useNavigate();

  const [formData, setFormData] =
    useState(emptyForm);

  const [errors, setErrors] = useState({});

  const [submitting, setSubmitting] =
    useState(false);

  const [formError, setFormError] =
    useState("");

  /* =====================================================
     LOCATION STATE
  ===================================================== */

  const [mapPosition, setMapPosition] =
    useState(null);

  const [locationLoading, setLocationLoading] =
    useState(false);

  /* =====================================================
     COVER IMAGE
  ===================================================== */

  const [coverFile, setCoverFile] =
    useState(null);

  const [coverPreview, setCoverPreview] =
    useState(null);

  const coverInputRef =
    useRef(null);

  /* =====================================================
     GALLERY
  ===================================================== */

  const [galleryFiles, setGalleryFiles] =
    useState([]);

  const galleryInputRef =
    useRef(null);

  /* =====================================================
     LOOKUPS
  ===================================================== */

  const [countries, setCountries] =
    useState([]);

  const [states, setStates] =
    useState([]);

  const [cities, setCities] =
    useState([]);

  const [loadingStates, setLoadingStates] =
    useState(false);

  const [loadingCities, setLoadingCities] =
    useState(false);

  /* =====================================================
     SPORTS / EVENTS / AMENITIES
  ===================================================== */

  const [sports, setSports] =
    useState([]);

  const [events, setEvents] =
    useState([]);

  const [amenities, setAmenities] =
    useState([]);

  const [selectedSports, setSelectedSports] =
    useState([]);

  const [selectedAmenities, setSelectedAmenities] =
    useState([]);

  const [selectedEvents, setSelectedEvents] =
    useState([]);

  const [loadingLists, setLoadingLists] =
    useState(true);

  const [is24Hours, setIs24Hours] =
    useState(false);

  /* =====================================================
     INITIAL DATA
  ===================================================== */

  useEffect(() => {
    const loadData = async () => {
      try {
        const [
          countriesRes,
          sportsRes,
          eventsRes,
          amenitiesRes,
        ] = await Promise.all([
          api.get(ENDPOINTS.COUNTRIES),
          api.get(ENDPOINTS.SPORTS),
          api.get(ENDPOINTS.EVENTS),
          api.get(ENDPOINTS.AMENITIES),
        ]);

        setCountries(
          countriesRes.data?.data ||
            countriesRes.data ||
            []
        );

        setSports(
          sportsRes.data?.data ||
            sportsRes.data ||
            []
        );

        setEvents(
          eventsRes.data?.data ||
            eventsRes.data ||
            []
        );

        setAmenities(
          amenitiesRes.data?.data ||
            amenitiesRes.data ||
            []
        );
      } catch (err) {
        console.error(
          "Initial data error:",
          err
        );
      } finally {
        setLoadingLists(false);
      }
    };

    loadData();
  }, []);

  /* =====================================================
     STATES
  ===================================================== */

  useEffect(() => {
    if (!formData.country_id) {
      setStates([]);

      setFormData((prev) => ({
        ...prev,
        state_id: "",
        city_id: "",
      }));

      return;
    }

    const loadStates = async () => {
      setLoadingStates(true);

      try {
        const res = await api.get(
          ENDPOINTS.STATES(
            formData.country_id
          )
        );

        setStates(
          res.data?.data ||
            res.data ||
            []
        );
      } catch (err) {
        console.error(
          "States error:",
          err
        );
      } finally {
        setLoadingStates(false);
      }
    };

    loadStates();
  }, [formData.country_id]);

  /* =====================================================
     CITIES
  ===================================================== */

  useEffect(() => {
    if (!formData.state_id) {
      setCities([]);

      setFormData((prev) => ({
        ...prev,
        city_id: "",
      }));

      return;
    }

    const loadCities = async () => {
      setLoadingCities(true);

      try {
        const res = await api.get(
          ENDPOINTS.CITIES(
            formData.state_id
          )
        );

        setCities(
          res.data?.data ||
            res.data ||
            []
        );
      } catch (err) {
        console.error(
          "Cities error:",
          err
        );
      } finally {
        setLoadingCities(false);
      }
    };

    loadCities();
  }, [formData.state_id]);

  /* =====================================================
     CLEAN OBJECT URLS
  ===================================================== */

  useEffect(() => {
    return () => {
      if (
        coverPreview?.startsWith("blob:")
      ) {
        URL.revokeObjectURL(
          coverPreview
        );
      }

      galleryFiles.forEach((g) => {
        if (
          g.preview?.startsWith("blob:")
        ) {
          URL.revokeObjectURL(
            g.preview
          );
        }
      });
    };
  }, []);

  /* =====================================================
     FIELD HELPER
  ===================================================== */

  const setField = (key, value) => {
    setFormData((prev) => ({
      ...prev,
      [key]: value,
    }));

    setErrors((prev) => ({
      ...prev,
      [key]: undefined,
    }));
  };

  /* =====================================================
     SELECT LOCATION FROM MAP
  ===================================================== */

  const handleLocationSelect = (
    latitude,
    longitude
  ) => {
    const lat = Number(latitude).toFixed(7);
    const lng = Number(longitude).toFixed(7);

    setMapPosition([
      Number(latitude),
      Number(longitude),
    ]);

    setFormData((prev) => ({
      ...prev,
      latitude: lat,
      longitude: lng,
    }));

    setErrors((prev) => ({
      ...prev,
      latitude: undefined,
      longitude: undefined,
    }));
  };

  /* =====================================================
     CURRENT LOCATION
  ===================================================== */

  const useCurrentLocation = () => {
    if (!navigator.geolocation) {
      setErrors((prev) => ({
        ...prev,
        latitude:
          "Geolocation is not supported by your browser.",
      }));

      return;
    }

    setLocationLoading(true);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const latitude =
          position.coords.latitude;

        const longitude =
          position.coords.longitude;

        handleLocationSelect(
          latitude,
          longitude
        );

        setLocationLoading(false);
      },
      (error) => {
        console.error(
          "Location error:",
          error
        );

        let message =
          "Unable to get your current location.";

        if (error.code === 1) {
          message =
            "Location permission denied. Please allow location permission.";
        }

        if (error.code === 2) {
          message =
            "Location information is unavailable.";
        }

        if (error.code === 3) {
          message =
            "Location request timed out.";
        }

        setErrors((prev) => ({
          ...prev,
          latitude: message,
        }));

        setLocationLoading(false);
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 0,
      }
    );
  };

  /* =====================================================
     IMAGE VALIDATION
  ===================================================== */

  const validateImageFile = (file) => {
    if (
      !VALID_IMAGE_TYPES.includes(
        file.type
      )
    ) {
      return "Please upload a PNG, JPG or WEBP image.";
    }

    if (file.size > 5 * 1024 * 1024) {
      return "Image must be under 5MB.";
    }

    return null;
  };

  /* =====================================================
     COVER IMAGE
  ===================================================== */

  const handleCoverChange = (e) => {
    const file =
      e.target.files?.[0];

    if (!file) return;

    const error =
      validateImageFile(file);

    if (error) {
      setErrors((prev) => ({
        ...prev,
        cover_image: error,
      }));

      return;
    }

    setErrors((prev) => ({
      ...prev,
      cover_image: undefined,
    }));

    setCoverFile(file);

    setCoverPreview(
      URL.createObjectURL(file)
    );
  };

  const removeCover = () => {
    setCoverFile(null);

    setCoverPreview(null);

    if (coverInputRef.current) {
      coverInputRef.current.value = "";
    }
  };

  /* =====================================================
     GALLERY
  ===================================================== */

  const handleGalleryChange = (e) => {
    const files = Array.from(
      e.target.files || []
    );

    if (!files.length) return;

    if (
      galleryFiles.length +
        files.length >
      MAX_GALLERY_IMAGES
    ) {
      setErrors((prev) => ({
        ...prev,
        gallery_images: `You can upload up to ${MAX_GALLERY_IMAGES} gallery images.`,
      }));

      return;
    }

    const validated = [];

    for (const file of files) {
      const error =
        validateImageFile(file);

      if (error) {
        setErrors((prev) => ({
          ...prev,
          gallery_images: error,
        }));

        return;
      }

      validated.push({
        file,
        preview:
          URL.createObjectURL(file),
      });
    }

    setErrors((prev) => ({
      ...prev,
      gallery_images: undefined,
    }));

    setGalleryFiles((prev) => [
      ...prev,
      ...validated,
    ]);

    if (galleryInputRef.current) {
      galleryInputRef.current.value =
        "";
    }
  };

  const removeGalleryImage = (
    index
  ) => {
    setGalleryFiles((prev) => {
      const copy = [...prev];

      if (
        copy[index]?.preview?.startsWith(
          "blob:"
        )
      ) {
        URL.revokeObjectURL(
          copy[index].preview
        );
      }

      copy.splice(index, 1);

      return copy;
    });
  };

  /* =====================================================
     SPORTS
  ===================================================== */

  const toggleSport = (id) => {
    setSelectedSports((prev) =>
      prev.includes(id)
        ? prev.filter(
            (sportId) =>
              sportId !== id
          )
        : [...prev, id]
    );

    setErrors((prev) => ({
      ...prev,
      sport_ids: undefined,
    }));
  };

  /* =====================================================
     EVENTS
  ===================================================== */

  const toggleEvent = (id) => {
    setSelectedEvents((prev) =>
      prev.includes(id)
        ? prev.filter(
            (eventId) =>
              eventId !== id
          )
        : [...prev, id]
    );

    setErrors((prev) => ({
      ...prev,
      event_ids: undefined,
    }));
  };

  /* =====================================================
     AMENITIES
  ===================================================== */

  const toggleAmenity = (id) => {
    setSelectedAmenities((prev) =>
      prev.includes(id)
        ? prev.filter(
            (amenityId) =>
              amenityId !== id
          )
        : [...prev, id]
    );
  };

  /* =====================================================
     24 HOURS
  ===================================================== */

  const handle24Hours = (
    checked
  ) => {
    setIs24Hours(checked);

    if (checked) {
      setFormData((prev) => ({
        ...prev,
        opening_time: "00:00",
        closing_time: "23:59",
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        opening_time: "",
        closing_time: "",
      }));
    }
  };

  /* =====================================================
     VALIDATION
  ===================================================== */

  const validate = () => {
    const e = {};

    if (!formData.name.trim()) {
      e.name =
        "Turf name is required.";
    } else if (
      formData.name.trim()
        .length < 3
    ) {
      e.name =
        "Turf name must be at least 3 characters.";
    } else if (
      formData.name.trim()
        .length > 100
    ) {
      e.name =
        "Turf name must be under 100 characters.";
    }

    if (
      !formData.description.trim()
    ) {
      e.description =
        "Description is required.";
    } else if (
      formData.description.trim()
        .length > 500
    ) {
      e.description =
        "Description must be under 500 characters.";
    }

    if (!coverFile) {
      e.cover_image =
        "Cover image is required.";
    }

    if (
      !formData.contact_number.trim()
    ) {
      e.contact_number =
        "Contact number is required.";
    } else if (
      !/^[6-9]\d{9}$/.test(
        formData.contact_number.trim()
      )
    ) {
      e.contact_number =
        "Enter a valid 10-digit mobile number.";
    }

    if (!formData.email.trim()) {
      e.email =
        "Email is required.";
    } else if (
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
        formData.email.trim()
      )
    ) {
      e.email =
        "Enter a valid email address.";
    }

    if (!formData.address.trim()) {
      e.address =
        "Address is required.";
    }

    if (!formData.area.trim()) {
      e.area =
        "Area is required.";
    } else if (
      formData.area.trim()
        .length > 150
    ) {
      e.area =
        "Area must be under 150 characters.";
    }

    if (!formData.country_id) {
      e.country_id =
        "Please select a country.";
    }

    if (!formData.state_id) {
      e.state_id =
        "Please select a state.";
    }

    if (!formData.city_id) {
      e.city_id =
        "Please select a city.";
    }

    if (!formData.pincode.trim()) {
      e.pincode =
        "Pincode is required.";
    } else if (
      !/^\d{6}$/.test(
        formData.pincode.trim()
      )
    ) {
      e.pincode =
        "Pincode must be 6 digits.";
    }

    /* ================================================
       LOCATION REQUIRED
    ================================================= */

    if (
      !formData.latitude ||
      !formData.longitude
    ) {
      e.latitude =
        "Please select turf location from the map.";

      e.longitude =
        "Please select turf location from the map.";
    }

    if (
      formData.latitude &&
      (
        Number(formData.latitude) <
          -90 ||
        Number(formData.latitude) >
          90
      )
    ) {
      e.latitude =
        "Latitude must be between -90 and 90.";
    }

    if (
      formData.longitude &&
      (
        Number(formData.longitude) <
          -180 ||
        Number(formData.longitude) >
          180
      )
    ) {
      e.longitude =
        "Longitude must be between -180 and 180.";
    }

    if (!formData.ground_type) {
      e.ground_type =
        "Please select ground type.";
    }

    if (!formData.opening_time) {
      e.opening_time =
        "Opening time is required.";
    }

    if (!formData.closing_time) {
      e.closing_time =
        "Closing time is required.";
    }

    if (
      formData.opening_time &&
      formData.closing_time &&
      formData.opening_time ===
        formData.closing_time
    ) {
      e.closing_time =
        "Closing time cannot be the same as opening time.";
    }

    if (
      selectedSports.length === 0
    ) {
      e.sport_ids =
        "Select at least one sport.";
    }

    setErrors(e);

    return (
      Object.keys(e).length === 0
    );
  };

  /* =====================================================
     SUBMIT
  ===================================================== */

  const handleSubmit = async (
    e
  ) => {
    e.preventDefault();

    setFormError("");

    if (!validate()) {
      const firstErrorEl =
        document.querySelector(
          "[data-error='true']"
        );

      firstErrorEl?.scrollIntoView({
        behavior: "smooth",
        block: "center",
      });

      return;
    }

    setSubmitting(true);

    try {
      const payload =
        new FormData();

      payload.append(
        "name",
        formData.name.trim()
      );

      payload.append(
        "description",
        formData.description.trim()
      );

      payload.append(
        "cover_image",
        coverFile
      );

      galleryFiles.forEach((g) => {
        payload.append(
          "gallery_images[]",
          g.file
        );
      });

      payload.append(
        "contact_number",
        formData.contact_number.trim()
      );

      payload.append(
        "email",
        formData.email.trim()
      );

      payload.append(
        "address",
        formData.address.trim()
      );

      payload.append(
        "area",
        formData.area.trim()
      );

      payload.append(
        "landmark",
        formData.landmark.trim()
      );

      payload.append(
        "country_id",
        formData.country_id
      );

      payload.append(
        "state_id",
        formData.state_id
      );

      payload.append(
        "city_id",
        formData.city_id
      );

      payload.append(
        "pincode",
        formData.pincode.trim()
      );

      /* LOCATION */

      payload.append(
        "latitude",
        formData.latitude
      );

      payload.append(
        "longitude",
        formData.longitude
      );

      payload.append(
        "opening_time",
        formData.opening_time
      );

      payload.append(
        "closing_time",
        formData.closing_time
      );

      payload.append(
        "ground_type",
        formData.ground_type
      );

      selectedSports.forEach(
        (id) => {
          payload.append(
            "sport_ids[]",
            id
          );
        }
      );

      selectedEvents.forEach(
        (id) => {
          payload.append(
            "event_ids[]",
            id
          );
        }
      );

      selectedAmenities.forEach(
        (id) => {
          payload.append(
            "amenity_ids[]",
            id
          );
        }
      );

      await api.post(
        ENDPOINTS.ADD_TURF,
        payload,
        {
          headers: {
            "Content-Type":
              "multipart/form-data",
          },
        }
      );

      navigate("/my-turfs");
    } catch (err) {
      console.error(
        "Add turf error:",
        err
      );

      const apiErrors =
        err?.response?.data?.errors;

      const apiMessage =
        err?.response?.data?.message;

      if (apiErrors) {
        const mapped = {};

        Object.entries(
          apiErrors
        ).forEach(
          ([key, val]) => {
            mapped[key] =
              Array.isArray(val)
                ? val[0]
                : val;
          }
        );

        setErrors((prev) => ({
          ...prev,
          ...mapped,
        }));
      } else {
        setFormError(
          apiMessage ||
            "Something went wrong. Please try again."
        );
      }
    } finally {
      setSubmitting(false);
    }
  };

  /* =====================================================
     UI HELPERS
  ===================================================== */

  const Label = ({
    children,
    required,
  }) => (
    <label className="block text-[9px] text-[#A0A0A0] uppercase tracking-wide font-semibold mb-1.5">
      {children}{" "}
      {required && (
        <span className="text-red-400">
          *
        </span>
      )}
    </label>
  );

  const FieldError = ({
    msg,
  }) =>
    msg ? (
      <p
        data-error="true"
        className="text-[9px] text-red-400 mt-1"
      >
        {msg}
      </p>
    ) : null;

  const inputClass = (
    hasError
  ) =>
    `w-full h-9 px-3 rounded-[8px] text-[11px] bg-[#1F1F27] border text-white placeholder:text-[#555] outline-none ${
      hasError
        ? "border-red-500"
        : "border-[#2a2a35] focus:border-blue-600"
    }`;

  /* =====================================================
     RETURN
  ===================================================== */

  return (
    <div className="w-full p-2 lg:px-4 lg:py-3">

      <PageHeader
        title="Add New Turf"
        subtitle="List a new turf for players to discover and book"
      />

      <form
        onSubmit={handleSubmit}
        className="flex flex-col gap-3 mt-3"
      >

        {/* FORM ERROR */}

        {formError && (
          <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-[10px] px-4 py-3 text-[11px] text-red-400">
            <AlertTriangle
              size={14}
            />
            {formError}
          </div>
        )}

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">

          {/* =================================================
              LEFT COLUMN
          ================================================= */}

          <div className="flex flex-col gap-3">

            {/* COVER */}

            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">

              <div className="px-5 py-3 border-b border-[#1f2333] flex items-center gap-2">

                <ImageIcon
                  size={14}
                  className="text-blue-400"
                />

                <h3 className="text-white text-[12px] font-bold">
                  Cover Image
                </h3>

              </div>

              <div className="p-5">

                <input
                  ref={
                    coverInputRef
                  }
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={
                    handleCoverChange
                  }
                  className="hidden"
                  id="cover_image_input"
                />

                {coverPreview ? (
                  <div className="relative">

                    <img
                      src={
                        coverPreview
                      }
                      alt="Cover preview"
                      className="w-full h-40 object-cover rounded-[10px] border border-[#1F1F27]"
                    />

                    <button
                      type="button"
                      onClick={
                        removeCover
                      }
                      className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/60 flex items-center justify-center text-white cursor-pointer"
                    >
                      <X
                        size={13}
                      />
                    </button>

                  </div>
                ) : (
                  <label
                    htmlFor="cover_image_input"
                    className={`flex flex-col items-center justify-center gap-2 h-40 rounded-[10px] border border-dashed cursor-pointer ${
                      errors.cover_image
                        ? "border-red-500"
                        : "border-[#2a2a35] hover:border-blue-600"
                    }`}
                  >

                    <ImagePlus
                      size={22}
                      className="text-[#555]"
                    />

                    <span className="text-[9px] text-[#A0A0A0]">
                      Click to upload cover image
                    </span>

                    <span className="text-[8px] text-[#555]">
                      PNG, JPG or WEBP · up to 5MB
                    </span>

                  </label>
                )}

                <FieldError
                  msg={
                    errors.cover_image
                  }
                />

              </div>
            </div>

            {/* GALLERY */}

            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">

              <div className="px-5 py-3 border-b border-[#1f2333] flex items-center justify-between">

                <div className="flex items-center gap-2">

                  <ImagePlus
                    size={14}
                    className="text-blue-400"
                  />

                  <h3 className="text-white text-[12px] font-bold">
                    Gallery Images
                  </h3>

                </div>

                <span className="text-[9px] text-[#A0A0A0]">
                  {galleryFiles.length}/
                  {MAX_GALLERY_IMAGES}
                </span>

              </div>

              <div className="p-5">

                <input
                  ref={
                    galleryInputRef
                  }
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  multiple
                  onChange={
                    handleGalleryChange
                  }
                  className="hidden"
                  id="gallery_images_input"
                />

                <div className="grid grid-cols-3 gap-2 mb-3">

                  {galleryFiles.map(
                    (g, i) => (
                      <div
                        key={i}
                        className="relative"
                      >

                        <img
                          src={g.preview}
                          alt={`Gallery ${
                            i + 1
                          }`}
                          className="w-full h-16 object-cover rounded-[8px] border border-[#1F1F27]"
                        />

                        <button
                          type="button"
                          onClick={() =>
                            removeGalleryImage(
                              i
                            )
                          }
                          className="absolute top-1 right-1 w-5 h-5 rounded-full bg-black/60 flex items-center justify-center text-white cursor-pointer"
                        >
                          <X
                            size={10}
                          />
                        </button>

                      </div>
                    )
                  )}

                  {galleryFiles.length <
                    MAX_GALLERY_IMAGES && (
                    <label
                      htmlFor="gallery_images_input"
                      className="flex flex-col items-center justify-center gap-1 h-16 rounded-[8px] border border-dashed border-[#2a2a35] hover:border-blue-600 cursor-pointer"
                    >

                      <ImagePlus
                        size={15}
                        className="text-[#555]"
                      />

                      <span className="text-[7px] text-[#A0A0A0]">
                        Add
                      </span>

                    </label>
                  )}

                </div>

                <FieldError
                  msg={
                    errors.gallery_images
                  }
                />

              </div>
            </div>

          </div>

          {/* =================================================
              RIGHT COLUMN
          ================================================= */}

          <div className="xl:col-span-2 flex flex-col gap-3">

            {/* BASIC INFORMATION */}

            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">

              <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">

                <Building2
                  size={14}
                  className="text-blue-400"
                />

                <h3 className="text-white text-[12px] font-bold">
                  Basic Information
                </h3>

              </div>

              <div className="p-6 grid grid-cols-1 gap-4">

                <div>

                  <Label required>
                    Turf Name
                  </Label>

                  <input
                    type="text"
                    value={
                      formData.name
                    }
                    onChange={(e) =>
                      setField(
                        "name",
                        formatTitleCase(
                          e.target.value
                        )
                      )
                    }
                    placeholder="e.g. Elite Sports Arena"
                    className={inputClass(
                      errors.name
                    )}
                  />

                  <FieldError
                    msg={
                      errors.name
                    }
                  />

                </div>

                <div>

                  <Label required>
                    About
                  </Label>

                  <textarea
                    rows={3}
                    value={
                      formData.description
                    }
                    onChange={(e) =>
                      setField(
                        "description",
                        formatDescription(
                          e.target.value
                        )
                      )
                    }
                    placeholder="Premium sports arena with cricket and football grounds."
                    className={`w-full px-3 py-2 rounded-[8px] text-[11px] bg-[#1F1F27] border text-white placeholder:text-[#555] outline-none resize-none ${
                      errors.description
                        ? "border-red-500"
                        : "border-[#2a2a35] focus:border-blue-600"
                    }`}
                  />

                  <FieldError
                    msg={
                      errors.description
                    }
                  />

                </div>

              </div>
            </div>

            {/* CONTACT */}

            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">

              <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">

                <Phone
                  size={14}
                  className="text-blue-400"
                />

                <h3 className="text-white text-[12px] font-bold">
                  Contact Information
                </h3>

              </div>

              <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">

                <div>

                  <Label required>
                    Contact Number
                  </Label>

                  <input
                    type="text"
                    value={
                      formData.contact_number
                    }
                    onChange={(e) =>
                      setField(
                        "contact_number",
                        e.target.value
                          .replace(
                            /\D/g,
                            ""
                          )
                          .slice(
                            0,
                            10
                          )
                      )
                    }
                    placeholder="9876543210"
                    className={inputClass(
                      errors.contact_number
                    )}
                  />

                  <FieldError
                    msg={
                      errors.contact_number
                    }
                  />

                </div>

                <div>

                  <Label required>
                    Email
                  </Label>

                  <input
                    type="email"
                    value={
                      formData.email
                    }
                    onChange={(e) =>
                      setField(
                        "email",
                        e.target.value
                      )
                    }
                    placeholder="elite@example.com"
                    className={inputClass(
                      errors.email
                    )}
                  />

                  <FieldError
                    msg={
                      errors.email
                    }
                  />

                </div>

              </div>
            </div>

            {/* =================================================
                LOCATION
            ================================================= */}

            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">

              <div className="px-6 py-3 border-b border-[#1f2333] flex items-center justify-between">

                <div className="flex items-center gap-2">

                  <MapPin
                    size={14}
                    className="text-blue-400"
                  />

                  <h3 className="text-white text-[12px] font-bold">
                    Turf Location
                  </h3>

                </div>

                <button
                  type="button"
                  onClick={
                    useCurrentLocation
                  }
                  disabled={
                    locationLoading
                  }
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-[7px] bg-blue-600/10 border border-blue-600/30 text-[9px] text-blue-400 font-semibold hover:bg-blue-600/20 disabled:opacity-50 cursor-pointer"
                >

                  {locationLoading ? (
                    <Loader2
                      size={11}
                      className="animate-spin"
                    />
                  ) : (
                    <LocateFixed
                      size={11}
                    />
                  )}

                  {locationLoading
                    ? "Getting location..."
                    : "Use current location"}

                </button>

              </div>

              <div className="p-6">

                {/* ADDRESS */}

                <div className="mb-4">

                  <Label required>
                    Address
                  </Label>

                  <input
                    type="text"
                    value={
                      formData.address
                    }
                    onChange={(e) =>
                      setField(
                        "address",
                        formatAddress(
                          e.target.value
                        )
                      )
                    }
                    placeholder="Vaishali Nagar, Jaipur"
                    className={inputClass(
                      errors.address
                    )}
                  />

                  <FieldError
                    msg={
                      errors.address
                    }
                  />

                </div>

                {/* AREA + LANDMARK */}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">

                  <div>

                    <Label required>
                      Area
                    </Label>

                    <input
                      type="text"
                      value={
                        formData.area
                      }
                      onChange={(e) =>
                        setField(
                          "area",
                          formatAddress(
                            e.target.value
                          )
                        )
                      }
                      placeholder="Vaishali Nagar"
                      className={inputClass(
                        errors.area
                      )}
                    />

                    <FieldError
                      msg={
                        errors.area
                      }
                    />

                  </div>

                  <div>

                    <Label>
                      Landmark
                    </Label>

                    <input
                      type="text"
                      value={
                        formData.landmark
                      }
                      onChange={(e) =>
                        setField(
                          "landmark",
                          formatAddress(
                            e.target.value
                          )
                        )
                      }
                      placeholder="Near National Handloom"
                      className={inputClass(
                        errors.landmark
                      )}
                    />

                  </div>

                </div>

                {/* =================================================
                    MAP
                ================================================= */}

                <div className="mb-4">

                  <div className="flex items-center justify-between mb-2">

                    <Label required>
                      Select Turf Location
                    </Label>

                    {mapPosition && (
                      <span className="text-[9px] text-green-400">
                        ✓ Location selected
                      </span>
                    )}

                  </div>

                  <div
                    className={`relative w-full h-[400px] rounded-[10px] overflow-hidden border ${
                      errors.latitude ||
                      errors.longitude
                        ? "border-red-500"
                        : "border-[#2a2a35]"
                    }`}
                  >

                    <MapContainer
                      center={
                        mapPosition ||
                        [
                          26.9124,
                          75.7873,
                        ]
                      }
                      zoom={13}
                      scrollWheelZoom={
                        true
                      }
                      style={{
                        width:
                          "100%",
                        height:
                          "100%",
                      }}
                    >

                      <TileLayer
                        attribution='&copy; OpenStreetMap contributors'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                      />

                      <LocationMarker
                        position={
                          mapPosition
                        }
                        onLocationSelect={
                          handleLocationSelect
                        }
                      />

                      <MapController
                        position={
                          mapPosition
                        }
                      />

                    </MapContainer>

                    {/* MAP INSTRUCTION */}

                    {!mapPosition && (
                      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-[1000] bg-black/80 px-4 py-2 rounded-[8px] text-[9px] text-white pointer-events-none whitespace-nowrap">
                        📍 Click anywhere on the map to select turf location
                      </div>
                    )}

                  </div>

                  <div className="mt-2 flex items-center justify-between">

                    <p className="text-[9px] text-[#777]">
                      Click on map to select location
                      or drag the marker to exact location.
                    </p>

                    {!mapPosition && (
                      <p className="text-[9px] text-red-400">
                        Location required
                      </p>
                    )}

                  </div>

                  <FieldError
                    msg={
                      errors.latitude
                    }
                  />

                </div>

                {/* =================================================
                    PINCODE + COUNTRY
                ================================================= */}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">

                  <div>

                    <Label required>
                      Pincode
                    </Label>

                    <input
                      type="text"
                      value={
                        formData.pincode
                      }
                      onChange={(e) =>
                        setField(
                          "pincode",
                          e.target.value
                            .replace(
                              /\D/g,
                              ""
                            )
                            .slice(
                              0,
                              6
                            )
                        )
                      }
                      placeholder="302021"
                      className={inputClass(
                        errors.pincode
                      )}
                    />

                    <FieldError
                      msg={
                        errors.pincode
                      }
                    />

                  </div>

                  <div>

                    <Label required>
                      Country
                    </Label>

                    <select
                      value={
                        formData.country_id
                      }
                      onChange={(e) =>
                        setField(
                          "country_id",
                          e.target.value
                        )
                      }
                      className={
                        inputClass(
                          errors.country_id
                        ) +
                        " cursor-pointer"
                      }
                    >

                      <option value="">
                        Select country
                      </option>

                      {countries.map(
                        (country) => (
                          <option
                            key={
                              country.id
                            }
                            value={
                              country.id
                            }
                          >
                            {
                              country.name
                            }
                          </option>
                        )
                      )}

                    </select>

                    <FieldError
                      msg={
                        errors.country_id
                      }
                    />

                  </div>

                </div>

                {/* STATE + CITY */}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">

                  <div>

                    <Label required>
                      State
                    </Label>

                    <select
                      value={
                        formData.state_id
                      }
                      onChange={(e) =>
                        setField(
                          "state_id",
                          e.target.value
                        )
                      }
                      disabled={
                        !formData.country_id ||
                        loadingStates
                      }
                      className={
                        inputClass(
                          errors.state_id
                        ) +
                        " cursor-pointer disabled:opacity-50"
                      }
                    >

                      <option value="">
                        {loadingStates
                          ? "Loading..."
                          : "Select state"}
                      </option>

                      {states.map(
                        (state) => (
                          <option
                            key={
                              state.id
                            }
                            value={
                              state.id
                            }
                          >
                            {
                              state.name
                            }
                          </option>
                        )
                      )}

                    </select>

                    <FieldError
                      msg={
                        errors.state_id
                      }
                    />

                  </div>

                  <div>

                    <Label required>
                      City
                    </Label>

                    <select
                      value={
                        formData.city_id
                      }
                      onChange={(e) =>
                        setField(
                          "city_id",
                          e.target.value
                        )
                      }
                      disabled={
                        !formData.state_id ||
                        loadingCities
                      }
                      className={
                        inputClass(
                          errors.city_id
                        ) +
                        " cursor-pointer disabled:opacity-50"
                      }
                    >

                      <option value="">
                        {loadingCities
                          ? "Loading..."
                          : "Select city"}
                      </option>

                      {cities.map(
                        (city) => (
                          <option
                            key={
                              city.id
                            }
                            value={
                              city.id
                            }
                          >
                            {
                              city.name
                            }
                          </option>
                        )
                      )}

                    </select>

                    <FieldError
                      msg={
                        errors.city_id
                      }
                    />

                  </div>

                </div>

                {/* LATITUDE LONGITUDE */}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

                  <div>

                    <Label required>
                      Latitude
                    </Label>

                    <input
                      type="text"
                      value={
                        formData.latitude
                      }
                      readOnly
                      placeholder="Select from map"
                      className={`${inputClass(
                        errors.latitude
                      )} cursor-not-allowed opacity-80`}
                    />

                  </div>

                  <div>

                    <Label required>
                      Longitude
                    </Label>

                    <input
                      type="text"
                      value={
                        formData.longitude
                      }
                      readOnly
                      placeholder="Select from map"
                      className={`${inputClass(
                        errors.longitude
                      )} cursor-not-allowed opacity-80`}
                    />

                  </div>

                </div>

                {/* SELECTED LOCATION */}

                {mapPosition && (
                  <div className="mt-4 p-3 rounded-[8px] bg-green-500/10 border border-green-500/20">

                    <div className="flex items-center gap-2">

                      <MapPin
                        size={14}
                        className="text-green-400"
                      />

                      <span className="text-[10px] text-green-400 font-semibold">
                        Turf location selected successfully
                      </span>

                    </div>

                    <p className="text-[9px] text-[#A0A0A0] mt-1">
                      Latitude:{" "}
                      <span className="text-white">
                        {
                          formData.latitude
                        }
                      </span>

                      {" | "}

                      Longitude:{" "}
                      <span className="text-white">
                        {
                          formData.longitude
                        }
                      </span>
                    </p>

                  </div>
                )}

              </div>
            </div>

            {/* =================================================
                GROUND TYPE
            ================================================= */}

            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">

              <div className="px-6 py-3 border-b border-[#1f2333]">

                <h3 className="text-white text-[12px] font-bold">
                  Ground Type
                </h3>

              </div>

              <div className="p-6 flex gap-6">

                <div className="flex gap-2">

                  {[
                    "single",
                    "multiple",
                  ].map((type) => {

                    const active =
                      formData.ground_type ===
                      type;

                    return (
                      <button
                        key={type}
                        type="button"
                        onClick={() =>
                          setField(
                            "ground_type",
                            type
                          )
                        }
                        className={`px-4 py-2 rounded-[8px] text-[10px] font-semibold border cursor-pointer ${
                          active
                            ? "bg-blue-600/15 border-blue-600 text-blue-400"
                            : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                        }`}
                      >

                        {type ===
                        "single"
                          ? "Single Ground"
                          : "Multiple Ground"}

                      </button>
                    );
                  })}

                </div>

                <FieldError
                  msg={
                    errors.ground_type
                  }
                />

              </div>
            </div>

            {/* =================================================
                OPERATING HOURS
            ================================================= */}

            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">

              <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">

                <Clock
                  size={14}
                  className="text-blue-400"
                />

                <h3 className="text-white text-[12px] font-bold">
                  Operating Hours
                </h3>

              </div>

              <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">

                <div className="md:col-span-2">

                  <div className="flex gap-2">

                    {[true, false].map(
                      (value) => {

                        const active =
                          is24Hours ===
                          value;

                        return (
                          <button
                            key={value.toString()}
                            type="button"
                            onClick={() =>
                              handle24Hours(
                                value
                              )
                            }
                            className={`px-4 py-2 rounded-[8px] text-[10px] font-semibold border cursor-pointer ${
                              active
                                ? "bg-green-500/15 border-green-500 text-green-400"
                                : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                            }`}
                          >

                            {value
                              ? "24 Hours Open"
                              : "Custom Hours"}

                          </button>
                        );
                      }
                    )}

                  </div>

                </div>

                <div>

                  <Label required>
                    Opening Time
                  </Label>

                  <input
                    type="time"
                    value={
                      formData.opening_time
                    }
                    disabled={
                      is24Hours
                    }
                    onChange={(e) =>
                      setField(
                        "opening_time",
                        e.target.value
                      )
                    }
                    className={inputClass(
                      errors.opening_time
                    )}
                  />

                  <FieldError
                    msg={
                      errors.opening_time
                    }
                  />

                </div>

                <div>

                  <Label required>
                    Closing Time
                  </Label>

                  <input
                    type="time"
                    value={
                      formData.closing_time
                    }
                    disabled={
                      is24Hours
                    }
                    onChange={(e) =>
                      setField(
                        "closing_time",
                        e.target.value
                      )
                    }
                    className={inputClass(
                      errors.closing_time
                    )}
                  />

                  <FieldError
                    msg={
                      errors.closing_time
                    }
                  />

                </div>

              </div>
            </div>

            {/* =================================================
                SPORTS
            ================================================= */}

            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">

              <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">

                <Dumbbell
                  size={14}
                  className="text-blue-400"
                />

                <h3 className="text-white text-[12px] font-bold">
                  Sports Available{" "}
                  <span className="text-red-400">
                    *
                  </span>
                </h3>

              </div>

              <div className="p-6">

                {loadingLists ? (
                  <p className="text-[10px] text-[#A0A0A0]">
                    Loading sports...
                  </p>
                ) : sports.length ===
                  0 ? (
                  <p className="text-[10px] text-[#A0A0A0]">
                    No sports found.
                  </p>
                ) : (
                  <div className="flex flex-wrap gap-2">

                    {sports.map(
                      (sport) => {

                        const active =
                          selectedSports.includes(
                            sport.id
                          );

                        return (
                          <button
                            type="button"
                            key={
                              sport.id
                            }
                            onClick={() =>
                              toggleSport(
                                sport.id
                              )
                            }
                            className={`px-3 py-1.5 rounded-[8px] text-[10px] font-semibold cursor-pointer border ${
                              active
                                ? "bg-blue-600/15 border-blue-600 text-blue-400"
                                : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                            }`}
                          >
                            {
                              sport.name
                            }
                          </button>
                        );
                      }
                    )}

                  </div>
                )}

                <FieldError
                  msg={
                    errors.sport_ids
                  }
                />

              </div>
            </div>

            {/* =================================================
                EVENTS
            ================================================= */}

            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">

              <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">

                <Sparkles
                  size={14}
                  className="text-blue-400"
                />

                <h3 className="text-white text-[12px] font-bold">
                  Events
                </h3>

              </div>

              <div className="p-6">

                {loadingLists ? (
                  <p className="text-[10px] text-[#A0A0A0]">
                    Loading events...
                  </p>
                ) : events.length ===
                  0 ? (
                  <p className="text-[10px] text-[#A0A0A0]">
                    No events found.
                  </p>
                ) : (
                  <div className="flex flex-wrap gap-2">

                    {events.map(
                      (event) => {

                        const active =
                          selectedEvents.includes(
                            event.id
                          );

                        return (
                          <button
                            key={
                              event.id
                            }
                            type="button"
                            onClick={() =>
                              toggleEvent(
                                event.id
                              )
                            }
                            className={`px-3 py-1.5 rounded-[8px] text-[10px] font-semibold cursor-pointer border ${
                              active
                                ? "bg-purple-600/15 border-purple-600 text-purple-400"
                                : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                            }`}
                          >
                            {
                              event.name
                            }
                          </button>
                        );
                      }
                    )}

                  </div>
                )}

              </div>
            </div>

            {/* =================================================
                AMENITIES
            ================================================= */}

            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">

              <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">

                <Sparkles
                  size={14}
                  className="text-blue-400"
                />

                <h3 className="text-white text-[12px] font-bold">
                  Amenities
                </h3>

              </div>

              <div className="p-6">

                {loadingLists ? (
                  <p className="text-[10px] text-[#A0A0A0]">
                    Loading amenities...
                  </p>
                ) : amenities.length ===
                  0 ? (
                  <p className="text-[10px] text-[#A0A0A0]">
                    No amenities found.
                  </p>
                ) : (
                  <div className="flex flex-wrap gap-2">

                    {amenities.map(
                      (amenity) => {

                        const active =
                          selectedAmenities.includes(
                            amenity.id
                          );

                        return (
                          <button
                            type="button"
                            key={
                              amenity.id
                            }
                            onClick={() =>
                              toggleAmenity(
                                amenity.id
                              )
                            }
                            className={`px-3 py-1.5 rounded-[8px] text-[10px] font-semibold cursor-pointer border ${
                              active
                                ? "bg-green-500/15 border-green-500 text-green-400"
                                : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                            }`}
                          >
                            {
                              amenity.name
                            }
                          </button>
                        );
                      }
                    )}

                  </div>
                )}

              </div>
            </div>

            {/* =================================================
                SUBMIT
            ================================================= */}

            <div className="flex justify-end gap-2 pb-4">

              <button
                type="button"
                onClick={() =>
                  navigate(-1)
                }
                disabled={
                  submitting
                }
                className="px-5 py-2.5 rounded-[8px] text-[11px] font-semibold bg-[#1F1F27] text-[#A0A0A0] cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={
                  submitting
                }
                className="flex items-center gap-1.5 px-5 py-2.5 rounded-[8px] text-[11px] font-semibold bg-blue-600 text-white hover:bg-blue-500 cursor-pointer disabled:opacity-60"
              >

                {submitting && (
                  <Loader2
                    size={13}
                    className="animate-spin"
                  />
                )}

                {submitting
                  ? "Adding Turf..."
                  : "Add Turf"}

              </button>

            </div>

          </div>
        </div>
      </form>
    </div>
  );
};

export default AddTurf;