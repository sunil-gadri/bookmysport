import React, { useEffect, useState, useMemo } from "react";
import {
  MapPin,
  Star,
  Clock,
  LayoutGrid,
  ShieldCheck,
  Plus,
  RefreshCw,
  Search,
  Trash2,
} from "lucide-react";
import api from "../../../api/axios";
import { PageHeader, Modal } from "../../../components/UI";
import { useNavigate } from "react-router-dom";
import TurfListSkeleton from "../../../components/skeletons/TurfListSkeleton";

const FILTERS = [
  { key: "all", label: "All" },
  { key: "approved", label: "Approved" },
  { key: "pending", label: "Pending" },
  { key: "inactive", label: "Inactive" },
];

const StatusBadge = ({ status, approvalStatus }) => {
  if (approvalStatus === "pending") {
    return (
      <span className="px-2 py-1 rounded-[6px] text-[9px] font-semibold bg-amber-500/15 text-amber-400">
        Pending
      </span>
    );
  }
  if (approvalStatus === "rejected") {
    return (
      <span className="px-2 py-1 rounded-[6px] text-[9px] font-semibold bg-red-500/15 text-red-400">
        Rejected
      </span>
    );
  }
  return status ? (
    <span className="px-2 py-1 rounded-[6px] text-[9px] font-semibold bg-green-500/15 text-green-400">
      Active
    </span>
  ) : (
    <span className="px-2 py-1 rounded-[6px] text-[9px] font-semibold bg-gray-500/15 text-gray-400">
      Inactive
    </span>
  );
};

const TurfCard = ({ turf, onView, onEdit, onDelete, deleting }) => {
  const cityLine = [turf.city?.name, turf.state?.name]
    .filter(Boolean)
    .join(", ");
  const rating = parseFloat(turf.average_rating || "0");
  const hasReviews = turf.total_reviews > 0;

  return (
    <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden flex flex-col">
      {/* Cover */}
      <div className="relative h-36 bg-[#161926]">
        {turf.cover_image ? (
          <img
            src={turf.cover_image}
            alt={turf.name}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-600 text-2xl font-bold">
            {turf.sports?.[0]?.name?.[0] || "?"}
          </div>
        )}
        <div className="absolute top-2 right-2">
          <StatusBadge
            status={turf.status}
            approvalStatus={turf.approval_status}
          />
        </div>
      </div>

      {/* Body */}
      <div className="p-4 flex flex-col gap-3 flex-1">
        <div className="flex items-start justify-between gap-2">
          <h3 className="text-white text-[12px] font-bold leading-snug">
            {turf.name}
          </h3>
          <div className="flex items-center gap-1 shrink-0 text-[11px] text-[#C0C0C0]">
            <Star size={11} className="text-amber-400 fill-amber-400" />
            <span>{hasReviews ? rating.toFixed(1) : "New"}</span>
            {hasReviews && (
              <span className="text-gray-500">({turf.total_reviews})</span>
            )}
          </div>
        </div>

        <p className="text-gray-500 text-[10px] flex items-center gap-1">
          <MapPin size={10} className="shrink-0" />
          <span className="truncate">{cityLine || turf.address}</span>
        </p>

        {turf.sports?.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {turf.sports.map((sport) => (
              <span
                key={sport.id}
                className="px-2 py-0.5 rounded-full text-[9px] bg-blue-600/10 text-blue-400 border border-blue-600/30"
              >
                {sport.name}
              </span>
            ))}
          </div>
        )}

        {turf.events?.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-2">
            {turf.events.map((event) => (
              <span
                key={event.id}
                className="px-2 py-0.5 rounded-full text-[9px]
                bg-purple-600/10
                text-purple-400
                border border-purple-600/30"
              >
                {event.name}
              </span>
            ))}
          </div>
        )}

        <div className="grid grid-cols-3 gap-2 py-3 border-t border-b border-[#1f2333]">
          <div className="flex flex-col gap-1">
            <span className="text-gray-500 text-[9px] uppercase tracking-wide flex items-center gap-1">
              <Clock size={10} /> Hours
            </span>
            <span className="text-[#C0C0C0] text-[10px] font-medium">
              {turf.opening_time}–{turf.closing_time}
            </span>
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-gray-500 text-[9px] uppercase tracking-wide flex items-center gap-1">
              <LayoutGrid size={10} /> Ground
            </span>
            <span className="text-[#C0C0C0] text-[10px] font-medium capitalize">
              {turf.ground_type || "-"}
            </span>
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-gray-500 text-[9px] uppercase tracking-wide flex items-center gap-1">
              <ShieldCheck size={10} /> Amenities
            </span>
            <span className="text-[#C0C0C0] text-[10px] font-medium">
              {turf.amenities?.length ?? 0}
            </span>
          </div>
        </div>

        <div className="flex gap-2 mt-auto">
          <button
            onClick={() => onView(turf)}
            className="flex-1 cursor-pointer px-3 py-2 rounded-sm border border-[#1F1F27] text-[#C0C0C0] text-[11px] font-semibold hover:border-blue-600/50 hover:text-blue-400 transition-colors"
          >
            View
          </button>
          <button
            onClick={() => onEdit(turf)}
            className="flex-1 cursor-pointer px-3 py-2 rounded-sm bg-blue-600 text-white text-[11px] font-semibold hover:bg-blue-700 transition-colors"
          >
            Edit
          </button>
          <button
            onClick={() => onDelete(turf)}
            disabled={deleting}
            title="Delete turf"
            className="cursor-pointer px-3 py-2 rounded-sm border border-red-500/30 text-red-400 hover:bg-red-500/10 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>
    </div>
  );
};

const MyTurfs = () => {
  const [turfs, setTurfs] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [activeFilter, setActiveFilter] = useState("all");
  const navigate = useNavigate();

  // Delete flow state
  const [deleteTurf, setDeleteTurf] = useState(null); // turf pending delete confirmation
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState("");

  const fetchTurfs = async (pageNum = page) => {
    try {
      setLoading(true);
      setError("");

      const res = await api.get("/turf-owner/turfs", {
        params: { page: pageNum, per_page: 10 },
      });

      if (res.data.success) {
        setTurfs(res.data.data || []);
        setPagination(res.data.pagination || null);
      } else {
        setError(res.data.message || "Failed to load turfs.");
      }
    } catch (err) {
      setError(
        err?.response?.data?.message ||
          "Something went wrong while fetching your turfs.",
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTurfs(page);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page]);

  const filteredTurfs = useMemo(() => {
    return turfs.filter((turf) => {
      const q = search.toLowerCase();
      const matchesSearch =
        !search ||
        turf.name.toLowerCase().includes(q) ||
        turf.address.toLowerCase().includes(q);

      const matchesFilter =
        activeFilter === "all" ||
        (activeFilter === "approved" &&
          turf.approval_status === "approved" &&
          turf.status) ||
        (activeFilter === "pending" && turf.approval_status === "pending") ||
        (activeFilter === "inactive" && !turf.status);

      return matchesSearch && matchesFilter;
    });
  }, [turfs, search, activeFilter]);

  const handleView = (turf) => {
    navigate(`/view-turf/${turf.id}`);
  };
  const handleEdit = (turf) => navigate(`/my-turfs/${turf.id}/edit`);
  const handleAddNew = () => navigate("/my-turfs/new");

  const handleDeleteClick = (turf) => {
    setDeleteError("");
    setDeleteTurf(turf);
  };

  const confirmDelete = async () => {
    if (!deleteTurf) return;

    try {
      setDeleting(true);
      setDeleteError("");

      const res = await api.delete(`/turf-owner/turfs/${deleteTurf.id}`);

      if (res.data.success) {
        // Remove it from the list locally instead of refetching the
        // whole page — feels instant, and pagination total stays honest.
        setTurfs((prev) => prev.filter((t) => t.id !== deleteTurf.id));
        setPagination((prev) =>
          prev ? { ...prev, total: Math.max(0, prev.total - 1) } : prev,
        );
        setDeleteTurf(null);
      } else {
        setDeleteError(res.data.message || "Could not delete this turf.");
      }
    } catch (err) {
      // The API returns 422 with a clear message when there are
      // upcoming confirmed bookings blocking the delete — show it
      // right in the modal instead of a generic toast.
      setDeleteError(
        err?.response?.data?.message ||
          "Something went wrong while deleting this turf.",
      );
    } finally {
      setDeleting(false);
    }
  };

  if (loading) {
    return <TurfListSkeleton />;
  }

  if (error) {
    return (
      <div className="w-full p-2 lg:px-4 lg:py-3">
        <div className="bg-[#14141a] border border-red-500/30 rounded-[10px] p-6 text-center">
          <p className="text-red-400 text-[12px] mb-3">{error}</p>
          <button
            onClick={() => fetchTurfs(page)}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-sm bg-blue-600 text-white text-[11px] font-semibold"
          >
            <RefreshCw size={12} />
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full p-2 lg:px-4 lg:py-3">
      <PageHeader
        title="My Turfs"
        subtitle={`${pagination?.total ?? turfs.length} turf${
          (pagination?.total ?? turfs.length) === 1 ? "" : "s"
        } listed`}
      >
        <button
          onClick={handleAddNew}
          className="flex cursor-pointer items-center gap-1.5 px-3 py-2 text-[11px] rounded-sm bg-blue-600 text-white font-semibold"
        >
          <Plus size={12} />
          Add New Turf
        </button>
      </PageHeader>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search
            size={13}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500"
          />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search turf name, location…"
            className="w-full bg-[#14141a] border border-[#1F1F27] rounded-[10px] pl-8 pr-3 py-2 text-[11px] text-white placeholder:text-gray-500 focus:outline-none focus:border-blue-600/50"
          />
        </div>

        <div className="flex items-center gap-1 bg-[#14141a] border border-[#1F1F27] rounded-[10px] p-1">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              onClick={() => setActiveFilter(f.key)}
              className={`px-3 py-1.5 cursor-pointer rounded-[8px] text-[10px] font-semibold transition-colors ${
                activeFilter === f.key
                  ? "bg-blue-600 text-white"
                  : "text-gray-400 hover:text-white"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Grid / empty state */}
      {filteredTurfs.length === 0 ? (
        <div className="bg-[#14141a] border border-dashed border-[#1F1F27] rounded-[10px] p-12 text-center">
          <p className="text-gray-500 text-[12px] mb-2">
            No turfs match this view yet.
          </p>
          {/* <button
            onClick={handleAddNew}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-sm bg-blue-600 text-white text-[11px] font-semibold"
          >
            <Plus size={12} />
            Add your first turf
          </button> */}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
          {filteredTurfs.map((turf) => (
            <TurfCard
              key={turf.id}
              turf={turf}
              onView={handleView}
              onEdit={handleEdit}
              onDelete={handleDeleteClick}
              deleting={deleting && deleteTurf?.id === turf.id}
            />
          ))}
        </div>
      )}

      {/* Pagination */}
      {pagination && pagination.last_page > 1 && (
        <div className="flex items-center justify-center gap-4 mt-6">
          <button
            disabled={page <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="px-3 py-2 rounded-sm border border-[#1F1F27] text-[#C0C0C0] text-[11px] font-semibold disabled:opacity-40 disabled:cursor-not-allowed hover:border-blue-600/50 hover:text-blue-400 transition-colors"
          >
            Previous
          </button>
          <span className="text-gray-500 text-[11px]">
            Page {pagination.current_page} of {pagination.last_page}
          </span>
          <button
            disabled={page >= pagination.last_page}
            onClick={() =>
              setPage((p) => Math.min(pagination.last_page, p + 1))
            }
            className="px-3 py-2 rounded-sm border border-[#1F1F27] text-[#C0C0C0] text-[11px] font-semibold disabled:opacity-40 disabled:cursor-not-allowed hover:border-blue-600/50 hover:text-blue-400 transition-colors"
          >
            Next
          </button>
        </div>
      )}

      {/* Delete confirmation modal */}
      {deleteTurf && (
        <Modal
          title={`Delete "${deleteTurf.name}"?`}
          onClose={() => {
            if (!deleting) {
              setDeleteTurf(null);
              setDeleteError("");
            }
          }}
          footer={
            <>
              <button
                onClick={() => {
                  setDeleteTurf(null);
                  setDeleteError("");
                }}
                disabled={deleting}
                className="px-3 py-2 rounded-sm border border-[#1F1F27] text-[#C0C0C0] text-[11px] font-semibold disabled:opacity-40"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                disabled={deleting}
                className="px-3 py-2 rounded-sm bg-red-600 text-white text-[11px] font-semibold hover:bg-red-700 transition-colors disabled:opacity-50"
              >
                {deleting ? "Deleting…" : "Confirm Delete"}
              </button>
            </>
          }
        >
          <p className="text-[12px] text-[#C0C0C0] leading-relaxed">
            This turf will be removed from listings. This can't be undone
            from here.
          </p>

          {deleteError && (
            <p className="mt-3 text-[11px] text-red-400 bg-red-500/10 border border-red-500/30 rounded-md px-3 py-2">
              {deleteError}
            </p>
          )}
        </Modal>
      )}
    </div>
  );
};

export default MyTurfs;