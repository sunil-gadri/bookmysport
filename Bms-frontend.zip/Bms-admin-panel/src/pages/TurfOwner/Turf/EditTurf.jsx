import React, { useEffect, useRef, useState } from "react";
import {
  Building2,
  MapPin,
  Phone,
  Clock,
  Image as ImageIcon,
  ImagePlus,
  X,
  Loader2,
  AlertTriangle,
  Dumbbell,
  Sparkles,
  LocateFixed,
  ArrowLeft,
  RefreshCw,
} from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import api from "../../../api/axios";
import { PageHeader } from "../../../components/UI";
import {
  formatTitleCase,
  formatAddress,
  formatDescription,
} from "../../../helpers/formatters";
import EditTurfSkeleton from "../../../components/skeletons/EditTurfSkeleton";

const ENDPOINTS = {
  TURF_DETAIL: (id) => `/turf-owner/turfs/${id}`,
  TURF_UPDATE: (id) => `/turf-owner/turfs/${id}`,
  COUNTRIES: "masters/countries",
  STATES: (countryId) => `masters/states?country_id=${countryId}`,
  CITIES: (stateId) => `masters/cities?state_id=${stateId}`,
  SPORTS: "/sports",
  EVENTS: "/events",
  AMENITIES: "/amenities",
};

const MAX_GALLERY_IMAGES = 20;
const VALID_IMAGE_TYPES = [
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp",
];

const emptyForm = {
  name: "",
  description: "",
  contact_number: "",
  email: "",
  address: "",
  area: "",
  landmark: "",
  country_id: "",
  state_id: "",
  city_id: "",
  pincode: "",
  latitude: "",
  longitude: "",
  opening_time: "",
  closing_time: "",
  ground_type: "single",
};

const EditTurf = () => {
  const navigate = useNavigate();
  const { id } = useParams(); // numeric turf id — see integration guide note on id vs slug

  // ── Page load state ──
  const [pageLoading, setPageLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [approvalStatus, setApprovalStatus] = useState(null);
  const [rejectionReason, setRejectionReason] = useState(null);

  // ── Form state ──
  const [formData, setFormData] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState("");

  // ── Cover image (existing url OR new file) ──
  const [existingCover, setExistingCover] = useState(null); // url string from API
  const [coverFile, setCoverFile] = useState(null); // new File, if replaced
  const [coverPreview, setCoverPreview] = useState(null); // blob url for new file
  const coverInputRef = useRef(null);

  // ── Gallery images (existing from API + newly added files) ──
  const [existingGallery, setExistingGallery] = useState([]); // [{id, image, sort_order}]
  const [removedGalleryIds, setRemovedGalleryIds] = useState([]);
  const [newGalleryFiles, setNewGalleryFiles] = useState([]); // [{file, preview}]
  const galleryInputRef = useRef(null);

  // ── Lookups ──
  const [countries, setCountries] = useState([]);
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);
  const [loadingStates, setLoadingStates] = useState(false);
  const [loadingCities, setLoadingCities] = useState(false);
  const hydratingRef = useRef(false); // true while pre-filling from API, so the
  // country/state cascade effects below don't wipe out the values we just set

  // ── Sports & Amenities ──
  const [sports, setSports] = useState([]);
  const [events, setEvents] = useState([]);
  const [amenities, setAmenities] = useState([]);
  const [selectedSports, setSelectedSports] = useState([]);
  const [selectedAmenities, setSelectedAmenities] = useState([]);
  const [selectedEvents, setSelectedEvents] = useState([]);
  const [loadingLists, setLoadingLists] = useState(true);
  const [is24Hours, setIs24Hours] = useState(false);

  // ───────────────────────────────────────────────
  // Static lookup lists (countries, sports, events, amenities)
  // ───────────────────────────────────────────────

  useEffect(() => {
    (async () => {
      try {
        const [countriesRes, sportsRes, eventsRes, amenitiesRes] =
          await Promise.all([
            api.get(ENDPOINTS.COUNTRIES),
            api.get(ENDPOINTS.SPORTS),
            api.get(ENDPOINTS.EVENTS),
            api.get(ENDPOINTS.AMENITIES),
          ]);

        setCountries(countriesRes.data?.data || countriesRes.data || []);
        setSports(sportsRes.data?.data || sportsRes.data || []);
        setEvents(eventsRes.data?.data || eventsRes.data || []);
        setAmenities(amenitiesRes.data?.data || amenitiesRes.data || []);
      } catch (err) {
        // Non-fatal — the form can still be used without these resolving.
      } finally {
        setLoadingLists(false);
      }
    })();
  }, []);

  // ───────────────────────────────────────────────
  // Fetch the turf being edited and hydrate the form
  // ───────────────────────────────────────────────

  const hydrateLocation = async (turf) => {
    if (turf.country_id) {
      setLoadingStates(true);
      try {
        const res = await api.get(ENDPOINTS.STATES(turf.country_id));
        setStates(res.data?.data || res.data || []);
      } finally {
        setLoadingStates(false);
      }
    }
    if (turf.state_id) {
      setLoadingCities(true);
      try {
        const res = await api.get(ENDPOINTS.CITIES(turf.state_id));
        setCities(res.data?.data || res.data || []);
      } finally {
        setLoadingCities(false);
      }
    }
  };

  const fetchTurf = async () => {
    setPageLoading(true);
    setLoadError("");
    try {
      const res = await api.get(ENDPOINTS.TURF_DETAIL(id));
      if (!res.data.success) {
        setLoadError(res.data.message || "Failed to load this turf.");
        return;
      }
      const t = res.data.data;

      hydratingRef.current = true;

      setFormData({
        name: t.name || "",
        description: t.description || "",
        contact_number: t.contact_number || "",
        email: t.email || "",
        address: t.address || "",
        area: t.area || "",
        landmark: t.landmark || "",
        country_id: t.country_id ? String(t.country_id) : "",
        state_id: t.state_id ? String(t.state_id) : "",
        city_id: t.city_id ? String(t.city_id) : "",
        pincode: t.pincode || "",
        latitude: t.latitude ? String(parseFloat(t.latitude)) : "",
        longitude: t.longitude ? String(parseFloat(t.longitude)) : "",
        opening_time: t.opening_time || "",
        closing_time: t.closing_time || "",
        ground_type: t.ground_type || "single",
      });

      setIs24Hours(t.opening_time === "00:00" && t.closing_time === "23:59");
      setSelectedSports((t.sports || []).map((s) => s.id));
      setSelectedEvents((t.events || []).map((ev) => ev.id));
      setSelectedAmenities((t.amenities || []).map((a) => a.id));
      setExistingCover(t.cover_image || null);
      setExistingGallery(
        [...(t.images || [])].sort((a, b) => a.sort_order - b.sort_order),
      );
      setApprovalStatus(t.approval_status);
      setRejectionReason(t.rejection_reason);

      await hydrateLocation(t);
    } catch (err) {
      setLoadError(
        err?.response?.data?.message ||
          "Something went wrong while loading this turf.",
      );
    } finally {
      hydratingRef.current = false;
      setPageLoading(false);
    }
  };

  useEffect(() => {
    fetchTurf();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  // Country → States cascade (skipped while hydrating; hydrateLocation handles that case)
  useEffect(() => {
    if (hydratingRef.current) return;
    if (!formData.country_id) {
      setStates([]);
      setFormData((prev) => ({ ...prev, state_id: "", city_id: "" }));
      return;
    }
    (async () => {
      setLoadingStates(true);
      try {
        const res = await api.get(ENDPOINTS.STATES(formData.country_id));
        setStates(res.data?.data || res.data || []);
      } finally {
        setLoadingStates(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [formData.country_id]);

  // State → Cities cascade (skipped while hydrating)
  useEffect(() => {
    if (hydratingRef.current) return;
    if (!formData.state_id) {
      setCities([]);
      setFormData((prev) => ({ ...prev, city_id: "" }));
      return;
    }
    (async () => {
      setLoadingCities(true);
      try {
        const res = await api.get(ENDPOINTS.CITIES(formData.state_id));
        setCities(res.data?.data || res.data || []);
      } finally {
        setLoadingCities(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [formData.state_id]);

  // Clean up blob previews
  useEffect(() => {
    return () => {
      if (coverPreview?.startsWith("blob:")) URL.revokeObjectURL(coverPreview);
      newGalleryFiles.forEach((g) => {
        if (g.preview?.startsWith("blob:")) URL.revokeObjectURL(g.preview);
      });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ───────────────────────────────────────────────
  // Field helpers
  // ───────────────────────────────────────────────

  const setField = (key, value) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const validateImageFile = (file) => {
    if (!VALID_IMAGE_TYPES.includes(file.type)) {
      return "Please upload a PNG, JPG or WEBP image.";
    }
    if (file.size > 5 * 1024 * 1024) {
      return "Image must be under 5MB.";
    }
    return null;
  };

  const handleCoverChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const err = validateImageFile(file);
    if (err) {
      setErrors((prev) => ({ ...prev, cover_image: err }));
      return;
    }
    setErrors((prev) => ({ ...prev, cover_image: undefined }));
    setCoverFile(file);
    setCoverPreview(URL.createObjectURL(file));
  };

  const removeCover = () => {
    // Clears whichever cover is currently shown (existing or newly picked).
    // If nothing else is picked afterwards, validation will require a new one.
    setCoverFile(null);
    setCoverPreview(null);
    setExistingCover(null);
    if (coverInputRef.current) coverInputRef.current.value = "";
  };

  const totalGalleryCount = () =>
    existingGallery.filter((img) => !removedGalleryIds.includes(img.id))
      .length + newGalleryFiles.length;

  const handleGalleryChange = (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;

    if (totalGalleryCount() + files.length > MAX_GALLERY_IMAGES) {
      setErrors((prev) => ({
        ...prev,
        gallery_images: `You can upload up to ${MAX_GALLERY_IMAGES} gallery images.`,
      }));
      return;
    }

    const validated = [];
    for (const file of files) {
      const err = validateImageFile(file);
      if (err) {
        setErrors((prev) => ({ ...prev, gallery_images: err }));
        return;
      }
      validated.push({ file, preview: URL.createObjectURL(file) });
    }

    setErrors((prev) => ({ ...prev, gallery_images: undefined }));
    setNewGalleryFiles((prev) => [...prev, ...validated]);
    if (galleryInputRef.current) galleryInputRef.current.value = "";
  };

  const removeExistingGalleryImage = (imgId) => {
    setRemovedGalleryIds((prev) => [...prev, imgId]);
  };

  const removeNewGalleryImage = (index) => {
    setNewGalleryFiles((prev) => {
      const copy = [...prev];
      if (copy[index]?.preview?.startsWith("blob:")) {
        URL.revokeObjectURL(copy[index].preview);
      }
      copy.splice(index, 1);
      return copy;
    });
  };

  const toggleSport = (sportId) => {
    setSelectedSports((prev) =>
      prev.includes(sportId)
        ? prev.filter((s) => s !== sportId)
        : [...prev, sportId],
    );
    setErrors((prev) => ({ ...prev, sport_ids: undefined }));
  };

  const toggleEvent = (eventId) => {
    setSelectedEvents((prev) =>
      prev.includes(eventId)
        ? prev.filter((e) => e !== eventId)
        : [...prev, eventId],
    );
    setErrors((prev) => ({ ...prev, event_ids: undefined }));
  };

  const toggleAmenity = (amenityId) => {
    setSelectedAmenities((prev) =>
      prev.includes(amenityId)
        ? prev.filter((a) => a !== amenityId)
        : [...prev, amenityId],
    );
  };

  const useCurrentLocation = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setField("latitude", pos.coords.latitude.toFixed(6));
        setField("longitude", pos.coords.longitude.toFixed(6));
      },
      () => {
        setErrors((prev) => ({
          ...prev,
          latitude: "Couldn't fetch location. Enter it manually.",
        }));
      },
    );
  };

  const handle24Hours = (checked) => {
    setIs24Hours(checked);
    if (checked) {
      setFormData((prev) => ({
        ...prev,
        opening_time: "00:00",
        closing_time: "23:59",
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        opening_time: "",
        closing_time: "",
      }));
    }
  };

  // ───────────────────────────────────────────────
  // Validation
  // ───────────────────────────────────────────────

  const validate = () => {
    const e = {};

    if (!formData.name.trim()) e.name = "Turf name is required.";
    else if (formData.name.trim().length < 3)
      e.name = "Turf name must be at least 3 characters.";
    else if (formData.name.trim().length > 100)
      e.name = "Turf name must be under 100 characters.";

    if (!formData.description.trim())
      e.description = "Description is required.";
    else if (formData.description.trim().length > 500)
      e.description = "Description must be under 500 characters.";

    if (!coverFile && !existingCover)
      e.cover_image = "Cover image is required.";

    if (!formData.contact_number.trim()) {
      e.contact_number = "Contact number is required.";
    } else if (!/^[6-9]\d{9}$/.test(formData.contact_number.trim())) {
      e.contact_number = "Enter a valid 10-digit mobile number.";
    }

    if (!formData.email.trim()) {
      e.email = "Email is required.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      e.email = "Enter a valid email address.";
    }

    if (!formData.address.trim()) e.address = "Address is required.";
    if (!formData.area.trim()) {
      e.area = "Area is required.";
    } else if (formData.area.trim().length > 150) {
      e.area = "Area must be under 150 characters.";
    }
    if (!formData.country_id) e.country_id = "Please select a country.";
    if (!formData.state_id) e.state_id = "Please select a state.";
    if (!formData.city_id) e.city_id = "Please select a city.";

    if (!formData.pincode.trim()) {
      e.pincode = "Pincode is required.";
    } else if (!/^\d{6}$/.test(formData.pincode.trim())) {
      e.pincode = "Pincode must be 6 digits.";
    }

    if (
      formData.latitude &&
      (formData.latitude < -90 || formData.latitude > 90)
    ) {
      e.latitude = "Latitude must be between -90 and 90.";
    }
    if (
      formData.longitude &&
      (formData.longitude < -180 || formData.longitude > 180)
    ) {
      e.longitude = "Longitude must be between -180 and 180.";
    }

    if (!formData.ground_type) {
      e.ground_type = "Please select ground type.";
    }

    if (!formData.opening_time) e.opening_time = "Opening time is required.";
    if (!formData.closing_time) e.closing_time = "Closing time is required.";
    if (
      formData.opening_time &&
      formData.closing_time &&
      formData.opening_time === formData.closing_time
    ) {
      e.closing_time =
        "Closing time cannot be the same as opening time.";
    }

    if (selectedSports.length === 0) e.sport_ids = "Select at least one sport.";

    setErrors(e);
    return Object.keys(e).length === 0;
  };

  // ───────────────────────────────────────────────
  // Submit
  // ───────────────────────────────────────────────

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError("");
    if (!validate()) {
      const firstErrorEl = document.querySelector("[data-error='true']");
      firstErrorEl?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }

    setSubmitting(true);
    try {
      const payload = new FormData();
      payload.append("name", formData.name.trim());
      payload.append("description", formData.description.trim());
      if (coverFile) payload.append("cover_image", coverFile);
      newGalleryFiles.forEach((g) =>
        payload.append("gallery_images[]", g.file),
      );
      // NOTE: confirm this field name with backend — see integration guide.
      removedGalleryIds.forEach((imgId) =>
        payload.append("remove_gallery_image_ids[]", imgId),
      );
      payload.append("contact_number", formData.contact_number.trim());
      payload.append("email", formData.email.trim());
      payload.append("address", formData.address.trim());
      payload.append("area", formData.area.trim());
      payload.append("landmark", formData.landmark.trim());
      payload.append("country_id", formData.country_id);
      payload.append("state_id", formData.state_id);
      payload.append("city_id", formData.city_id);
      payload.append("pincode", formData.pincode.trim());
      if (formData.latitude) payload.append("latitude", formData.latitude);
      if (formData.longitude) payload.append("longitude", formData.longitude);
      payload.append("opening_time", formData.opening_time);
      payload.append("closing_time", formData.closing_time);
      payload.append("ground_type", formData.ground_type);
      selectedSports.forEach((sid) => payload.append("sport_ids[]", sid));
      selectedEvents.forEach((eid) => payload.append("event_ids[]", eid));
      selectedAmenities.forEach((aid) => payload.append("amenity_ids[]", aid));

      await api.post(ENDPOINTS.TURF_UPDATE(id), payload, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      navigate(`/view-turf/${id}`);
    } catch (err) {
      const apiErrors = err?.response?.data?.errors;
      const apiMessage = err?.response?.data?.message;
      if (apiErrors) {
        const mapped = {};
        Object.entries(apiErrors).forEach(([key, val]) => {
          mapped[key] = Array.isArray(val) ? val[0] : val;
        });
        setErrors((prev) => ({ ...prev, ...mapped }));
      } else {
        setFormError(apiMessage || "Something went wrong. Please try again.");
      }
    } finally {
      setSubmitting(false);
    }
  };

  // ───────────────────────────────────────────────
  // Small reusable bits
  // ───────────────────────────────────────────────

  const Label = ({ children, required }) => (
    <label className="block text-[9px] text-[#A0A0A0] uppercase tracking-wide font-semibold mb-1.5">
      {children} {required && <span className="text-red-400">*</span>}
    </label>
  );

  const FieldError = ({ msg }) =>
    msg ? (
      <p data-error="true" className="text-[9px] text-red-400 mt-1">
        {msg}
      </p>
    ) : null;

  const inputClass = (hasError) =>
    `w-full h-9 px-3 rounded-[8px] text-[11px] bg-[#1F1F27] border text-white placeholder:text-[#555] outline-none ${
      hasError ? "border-red-500" : "border-[#2a2a35] focus:border-blue-600"
    }`;

  // ───────────────────────────────────────────────
  // Render
  // ───────────────────────────────────────────────

  if (pageLoading) {
    return <EditTurfSkeleton />;
  }

  if (loadError) {
    return (
      <div className="w-full p-2 lg:px-4 lg:py-3">
        <button
          onClick={() => navigate("/my-turfs")}
          className="inline-flex cursor-pointer items-center gap-1.5 text-gray-500 text-[11px] font-semibold mb-4 hover:text-white transition-colors"
        >
          <ArrowLeft size={13} />
          Back to My Turfs
        </button>
        <div className="bg-[#14141a] border border-red-500/30 rounded-[10px] p-6 text-center">
          <p className="text-red-400 text-[12px] mb-3">{loadError}</p>
          <button
            onClick={fetchTurf}
            className="inline-flex cursor-pointer items-center gap-1.5 px-3 py-2 rounded-sm bg-blue-600 text-white text-[11px] font-semibold"
          >
            <RefreshCw size={12} />
            Retry
          </button>
        </div>
      </div>
    );
  }

  const coverToShow = coverPreview || existingCover;
  const visibleExistingGallery = existingGallery.filter(
    (img) => !removedGalleryIds.includes(img.id),
  );

  return (
    <div className="w-full p-2 lg:px-4 lg:py-3">
      <button
        onClick={() => navigate(-1)}
        className="inline-flex cursor-pointer items-center gap-1.5 text-gray-500 text-[11px] font-semibold mb-4 hover:text-white transition-colors"
      >
        <ArrowLeft size={13} />
        Back
      </button>

      <PageHeader
        title="Edit Turf"
        subtitle="Update your turf's details, media, and availability"
      />

      {approvalStatus === "rejected" && rejectionReason && (
        <div className="bg-red-500/10 border border-red-500/30 rounded-[10px] p-4 mt-3 flex items-start gap-3">
          <AlertTriangle size={16} className="text-red-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-red-400 text-[11px] font-semibold">
              This turf was rejected
            </p>
            <p className="text-red-300/80 text-[11px] mt-1">
              {rejectionReason}
            </p>
          </div>
        </div>
      )}

      {approvalStatus === "approved" && (
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-[10px] p-4 mt-3 flex items-start gap-3">
          <AlertTriangle size={16} className="text-amber-400 shrink-0 mt-0.5" />
          <p className="text-amber-300/90 text-[11px]">
            This turf is already approved. Saving changes may send it back for
            re-approval — confirm this behavior with the backend team.
          </p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex flex-col gap-3 mt-3">
        {formError && (
          <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-[10px] px-4 py-3 text-[11px] text-red-400">
            <AlertTriangle size={14} className="shrink-0" />
            {formError}
          </div>
        )}

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">
          {/* LEFT COLUMN — media */}
          <div className="flex flex-col gap-3">
            {/* Cover image */}
            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
              <div className="px-5 py-3 border-b border-[#1f2333] flex items-center gap-2">
                <ImageIcon size={14} className="text-blue-400" />
                <h3 className="text-white text-[12px] font-bold">
                  Cover Image
                </h3>
              </div>
              <div className="p-5">
                <input
                  ref={coverInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={handleCoverChange}
                  className="hidden"
                  id="cover_image_input"
                />
                {coverToShow ? (
                  <div className="relative">
                    <img
                      src={coverToShow}
                      alt="Cover preview"
                      className="w-full h-40 object-cover rounded-[10px] border border-[#1F1F27]"
                    />
                    <button
                      type="button"
                      onClick={removeCover}
                      className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/60 flex items-center justify-center text-white cursor-pointer"
                    >
                      <X size={13} />
                    </button>
                    <label
                      htmlFor="cover_image_input"
                      className="absolute bottom-2 right-2 px-2.5 py-1.5 rounded-[6px] bg-black/60 text-white text-[9px] font-semibold cursor-pointer"
                    >
                      Replace
                    </label>
                  </div>
                ) : (
                  <label
                    htmlFor="cover_image_input"
                    className={`flex flex-col items-center justify-center gap-2 h-40 rounded-[10px] border border-dashed cursor-pointer ${
                      errors.cover_image
                        ? "border-red-500"
                        : "border-[#2a2a35] hover:border-blue-600"
                    }`}
                  >
                    <ImagePlus size={22} className="text-[#555]" />
                    <span className="text-[9px] text-[#A0A0A0]">
                      Click to upload cover image
                    </span>
                    <span className="text-[8px] text-[#555]">
                      PNG, JPG or WEBP · up to 5MB
                    </span>
                  </label>
                )}
                <FieldError msg={errors.cover_image} />
              </div>
            </div>

            {/* Gallery images */}
            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
              <div className="px-5 py-3 border-b border-[#1f2333] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ImagePlus size={14} className="text-blue-400" />
                  <h3 className="text-white text-[12px] font-bold">
                    Gallery Images
                  </h3>
                </div>
                <span className="text-[9px] text-[#A0A0A0]">
                  {totalGalleryCount()}/{MAX_GALLERY_IMAGES}
                </span>
              </div>
              <div className="p-5">
                <input
                  ref={galleryInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  multiple
                  onChange={handleGalleryChange}
                  className="hidden"
                  id="gallery_images_input"
                />

                <div className="grid grid-cols-3 gap-2 mb-3">
                  {/* Existing images already on the turf */}
                  {visibleExistingGallery.map((img) => (
                    <div key={`existing-${img.id}`} className="relative">
                      <img
                        src={img.image}
                        alt="Gallery"
                        className="w-full h-16 object-cover rounded-[8px] border border-[#1F1F27]"
                      />
                      <button
                        type="button"
                        onClick={() => removeExistingGalleryImage(img.id)}
                        className="absolute top-1 right-1 w-5 h-5 rounded-full bg-black/60 flex items-center justify-center text-white cursor-pointer"
                      >
                        <X size={10} />
                      </button>
                    </div>
                  ))}

                  {/* Newly added images, not yet saved */}
                  {newGalleryFiles.map((g, i) => (
                    <div key={`new-${i}`} className="relative">
                      <img
                        src={g.preview}
                        alt={`New gallery ${i + 1}`}
                        className="w-full h-16 object-cover rounded-[8px] border border-blue-600/50"
                      />
                      <button
                        type="button"
                        onClick={() => removeNewGalleryImage(i)}
                        className="absolute top-1 right-1 w-5 h-5 rounded-full bg-black/60 flex items-center justify-center text-white cursor-pointer"
                      >
                        <X size={10} />
                      </button>
                    </div>
                  ))}

                  {totalGalleryCount() < MAX_GALLERY_IMAGES && (
                    <label
                      htmlFor="gallery_images_input"
                      className="flex flex-col items-center justify-center gap-1 h-16 rounded-[8px] border border-dashed border-[#2a2a35] hover:border-blue-600 cursor-pointer"
                    >
                      <ImagePlus size={15} className="text-[#555]" />
                      <span className="text-[7px] text-[#A0A0A0]">Add</span>
                    </label>
                  )}
                </div>
                <FieldError msg={errors.gallery_images} />
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN — details */}
          <div className="xl:col-span-2 flex flex-col gap-3">
            {/* Basic info */}
            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
              <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">
                <Building2 size={14} className="text-blue-400" />
                <h3 className="text-white text-[12px] font-bold">
                  Basic Information
                </h3>
              </div>
              <div className="p-6 grid grid-cols-1 gap-4">
                <div>
                  <Label required>Turf Name</Label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) =>
                      setField("name", formatTitleCase(e.target.value))
                    }
                    placeholder="e.g. Elite Sports Arena"
                    className={inputClass(errors.name)}
                  />
                  <FieldError msg={errors.name} />
                </div>

                <div>
                  <Label required>About</Label>
                  <textarea
                    rows={3}
                    value={formData.description}
                    onChange={(e) =>
                      setField("description", formatDescription(e.target.value))
                    }
                    placeholder="Premium sports arena with cricket and football grounds."
                    className={`w-full px-3 py-2 rounded-[8px] text-[11px] bg-[#1F1F27] border text-white placeholder:text-[#555] outline-none resize-none ${
                      errors.description
                        ? "border-red-500"
                        : "border-[#2a2a35] focus:border-blue-600"
                    }`}
                  />
                  <FieldError msg={errors.description} />
                </div>
              </div>
            </div>

            {/* Contact info */}
            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
              <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">
                <Phone size={14} className="text-blue-400" />
                <h3 className="text-white text-[12px] font-bold">
                  Contact Information
                </h3>
              </div>
              <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label required>Contact Number</Label>
                  <input
                    type="text"
                    value={formData.contact_number}
                    onChange={(e) =>
                      setField(
                        "contact_number",
                        e.target.value.replace(/\D/g, "").slice(0, 10),
                      )
                    }
                    placeholder="9876543210"
                    className={inputClass(errors.contact_number)}
                  />
                  <FieldError msg={errors.contact_number} />
                </div>

                <div>
                  <Label required>Email</Label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setField("email", e.target.value)}
                    placeholder="elite@example.com"
                    className={inputClass(errors.email)}
                  />
                  <FieldError msg={errors.email} />
                </div>
              </div>
            </div>

            {/* Location */}
            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
              <div className="px-6 py-3 border-b border-[#1f2333] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MapPin size={14} className="text-blue-400" />
                  <h3 className="text-white text-[12px] font-bold">Location</h3>
                </div>
                <button
                  type="button"
                  onClick={useCurrentLocation}
                  className="flex items-center gap-1 text-[9px] text-blue-400 font-semibold cursor-pointer"
                >
                  <LocateFixed size={11} />
                  Use current location
                </button>
              </div>
              <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <Label required>Address</Label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) =>
                      setField("address", formatAddress(e.target.value))
                    }
                    placeholder="Vaishali Nagar, Jaipur"
                    className={inputClass(errors.address)}
                  />
                  <FieldError msg={errors.address} />
                </div>
                <div>
                  <Label required>Area</Label>

                  <input
                    type="text"
                    value={formData.area}
                    onChange={(e) =>
                      setField("area", formatAddress(e.target.value))
                    }
                    placeholder="Vaishali Nagar"
                    className={inputClass(errors.area)}
                  />

                  <FieldError msg={errors.area} />
                </div>
                <div>
                  <Label>Landmark</Label>
                  <input
                    type="text"
                    value={formData.landmark}
                    onChange={(e) =>
                      setField("landmark", formatAddress(e.target.value))
                    }
                    placeholder="Near National Handloom"
                    className={inputClass(errors.landmark)}
                  />
                  <FieldError msg={errors.landmark} />
                </div>

                <div>
                  <Label required>Pincode</Label>
                  <input
                    type="text"
                    value={formData.pincode}
                    onChange={(e) =>
                      setField(
                        "pincode",
                        e.target.value.replace(/\D/g, "").slice(0, 6),
                      )
                    }
                    placeholder="302021"
                    className={inputClass(errors.pincode)}
                  />
                  <FieldError msg={errors.pincode} />
                </div>

                <div>
                  <Label required>Country</Label>
                  <select
                    value={formData.country_id}
                    onChange={(e) => setField("country_id", e.target.value)}
                    className={
                      inputClass(errors.country_id) + " cursor-pointer"
                    }
                  >
                    <option value="">Select country</option>
                    {countries.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                  <FieldError msg={errors.country_id} />
                </div>

                <div>
                  <Label required>State</Label>
                  <select
                    value={formData.state_id}
                    onChange={(e) => setField("state_id", e.target.value)}
                    disabled={!formData.country_id || loadingStates}
                    className={
                      inputClass(errors.state_id) +
                      " cursor-pointer disabled:opacity-50"
                    }
                  >
                    <option value="">
                      {loadingStates ? "Loading..." : "Select state"}
                    </option>
                    {states.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                  <FieldError msg={errors.state_id} />
                </div>

                <div>
                  <Label required>City</Label>
                  <select
                    value={formData.city_id}
                    onChange={(e) => setField("city_id", e.target.value)}
                    disabled={!formData.state_id || loadingCities}
                    className={
                      inputClass(errors.city_id) +
                      " cursor-pointer disabled:opacity-50"
                    }
                  >
                    <option value="">
                      {loadingCities ? "Loading..." : "Select city"}
                    </option>
                    {cities.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                  <FieldError msg={errors.city_id} />
                </div>

                <div>
                  <Label>Latitude</Label>
                  <input
                    type="text"
                    value={formData.latitude}
                    onChange={(e) => setField("latitude", e.target.value)}
                    placeholder="26.912434"
                    className={inputClass(errors.latitude)}
                  />
                  <FieldError msg={errors.latitude} />
                </div>

                <div>
                  <Label>Longitude</Label>
                  <input
                    type="text"
                    value={formData.longitude}
                    onChange={(e) => setField("longitude", e.target.value)}
                    placeholder="75.787271"
                    className={inputClass(errors.longitude)}
                  />
                  <FieldError msg={errors.longitude} />
                </div>
              </div>
            </div>

            {/* Ground Type */}
            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
              <div className="px-6 py-3 border-b border-[#1f2333]">
                <h3 className="text-white text-[12px] font-bold">
                  Ground Type
                </h3>
              </div>
              <div className="p-6 flex gap-6">
                <div className="flex gap-2">
                  {["single", "multiple"].map((type) => {
                    const active = formData.ground_type === type;
                    return (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setField("ground_type", type)}
                        className={`px-4 py-2 rounded-[8px] text-[10px] font-semibold border cursor-pointer transition-all ${
                          active
                            ? "bg-blue-600/15 border-blue-600 text-blue-400"
                            : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                        }`}
                      >
                        {type === "single"
                          ? "Single Ground"
                          : "Multiple Ground"}
                      </button>
                    );
                  })}
                </div>
                <FieldError msg={errors.ground_type} />
              </div>
            </div>

            {/* Timing */}
            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
              <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">
                <Clock size={14} className="text-blue-400" />
                <h3 className="text-white text-[12px] font-bold">
                  Operating Hours
                </h3>
              </div>
              <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <div className="flex gap-2">
                    {[true, false].map((value) => {
                      const active = is24Hours === value;
                      return (
                        <button
                          key={value.toString()}
                          type="button"
                          onClick={() => handle24Hours(value)}
                          className={`px-4 py-2 rounded-[8px] text-[10px] font-semibold border cursor-pointer ${
                            active
                              ? "bg-green-500/15 border-green-500 text-green-400"
                              : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                          }`}
                        >
                          {value ? "24 Hours Open" : "Custom Hours"}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <Label required>Opening Time</Label>
                  <input
                    type="time"
                    value={formData.opening_time}
                    disabled={is24Hours}
                    onChange={(e) => setField("opening_time", e.target.value)}
                    className={inputClass(errors.opening_time)}
                  />
                  <FieldError msg={errors.opening_time} />
                </div>

                <div>
                  <Label required>Closing Time</Label>
                  <input
                    type="time"
                    value={formData.closing_time}
                    disabled={is24Hours}
                    onChange={(e) => setField("closing_time", e.target.value)}
                    className={inputClass(errors.closing_time)}
                  />
                  <FieldError msg={errors.closing_time} />
                </div>
              </div>
            </div>

            {/* Sports */}
            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
              <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">
                <Dumbbell size={14} className="text-blue-400" />
                <h3 className="text-white text-[12px] font-bold">
                  Sports Available <span className="text-red-400">*</span>
                </h3>
              </div>
              <div className="p-6">
                {loadingLists ? (
                  <p className="text-[10px] text-[#A0A0A0]">
                    Loading sports...
                  </p>
                ) : sports.length === 0 ? (
                  <p className="text-[10px] text-[#A0A0A0]">
                    No sports found. Confirm the sports-list endpoint in the
                    ENDPOINTS config at the top of this file.
                  </p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {sports.map((s) => {
                      const active = selectedSports.includes(s.id);
                      return (
                        <button
                          type="button"
                          key={s.id}
                          onClick={() => toggleSport(s.id)}
                          className={`px-3 py-1.5 rounded-[8px] text-[10px] font-semibold cursor-pointer border ${
                            active
                              ? "bg-blue-600/15 border-blue-600 text-blue-400"
                              : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                          }`}
                        >
                          {s.name}
                        </button>
                      );
                    })}
                  </div>
                )}
                <FieldError msg={errors.sport_ids} />
              </div>
            </div>

            {/* Events */}
            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
              <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">
                <Sparkles size={14} className="text-blue-400" />
                <h3 className="text-white text-[12px] font-bold">Events</h3>
              </div>
              <div className="p-6">
                {loadingLists ? (
                  <p className="text-[10px] text-[#A0A0A0]">
                    Loading events...
                  </p>
                ) : events.length === 0 ? (
                  <p className="text-[10px] text-[#A0A0A0]">No events found.</p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {events.map((event) => {
                      const active = selectedEvents.includes(event.id);
                      return (
                        <button
                          key={event.id}
                          type="button"
                          onClick={() => toggleEvent(event.id)}
                          className={`px-3 py-1.5 rounded-[8px] text-[10px] font-semibold cursor-pointer border ${
                            active
                              ? "bg-purple-600/15 border-purple-600 text-purple-400"
                              : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                          }`}
                        >
                          {event.name}
                        </button>
                      );
                    })}
                  </div>
                )}
                <FieldError msg={errors.event_ids} />
              </div>
            </div>

            {/* Amenities */}
            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
              <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">
                <Sparkles size={14} className="text-blue-400" />
                <h3 className="text-white text-[12px] font-bold">Amenities</h3>
              </div>
              <div className="p-6">
                {loadingLists ? (
                  <p className="text-[10px] text-[#A0A0A0]">
                    Loading amenities...
                  </p>
                ) : amenities.length === 0 ? (
                  <p className="text-[10px] text-[#A0A0A0]">
                    No amenities found. Confirm the amenities-list endpoint in
                    the ENDPOINTS config at the top of this file.
                  </p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {amenities.map((a) => {
                      const active = selectedAmenities.includes(a.id);
                      return (
                        <button
                          type="button"
                          key={a.id}
                          onClick={() => toggleAmenity(a.id)}
                          className={`px-3 py-1.5 rounded-[8px] text-[10px] font-semibold cursor-pointer border ${
                            active
                              ? "bg-green-500/15 border-green-500 text-green-400"
                              : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                          }`}
                        >
                          {a.name}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Submit */}
            <div className="flex justify-end gap-2 pb-4">
              <button
                type="button"
                onClick={() => navigate(-1)}
                disabled={submitting}
                className="px-5 py-2.5 rounded-[8px] text-[11px] font-semibold bg-[#1F1F27] text-[#A0A0A0] cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="flex items-center gap-1.5 px-5 py-2.5 rounded-[8px] text-[11px] font-semibold bg-blue-600 text-white hover:bg-blue-500 cursor-pointer disabled:opacity-60"
              >
                {submitting && <Loader2 size={13} className="animate-spin" />}
                {submitting ? "Saving Changes..." : "Save Changes"}
              </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};

export default EditTurf;
