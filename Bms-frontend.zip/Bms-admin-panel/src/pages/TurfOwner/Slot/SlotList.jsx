import React, { useEffect, useState } from "react";
import {
  Search,
  Plus,
  RefreshCw,
  Clock,
  IndianRupee,
  Building2,
  Trash2,
  Loader2,
  AlertTriangle,
  CalendarClock,
  Pencil,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import api from "../../../api/axios";
import { PageHeader, StatCard } from "../../../components/UI";
import ListPageSkeleton from "../../../components/skeletons/ListPageSkeleton";
import { toast } from "sonner";

const ENDPOINTS = {
  DROPDOWN_DATA: "/turf-owner/slot-masters/dropdown-data",
  LIST: "/turf-owner/slot-masters",
  UPDATE_STATUS: (id) => `/turf-owner/slot-masters/${id}/status`,
  DELETE: (id) => `/turf-owner/slot-masters/${id}`,
};

const TYPE_FILTERS = [
  { key: "", label: "All Types" },
  { key: "sport", label: "Sport" },
  { key: "event", label: "Event" },
];

const StatusBadge = ({ active }) =>
  active ? (
    <span className="px-2 py-1 rounded-[6px] text-[9px] font-semibold bg-green-500/15 text-green-400 hover:bg-green-500/25">
      Active
    </span>
  ) : (
    <span className="px-2 py-1 rounded-[6px] text-[9px] font-semibold bg-yellow-500/15 text-yellow-400 hover:bg-yellow-500/25">
      Inactive
    </span>
  );

const BookingTypeTag = ({ type, name }) => (
  <span
    className={`px-2.5 py-1 rounded-full text-[9px] font-semibold border ${
      type === "event"
        ? "bg-purple-600/10 text-purple-400 border-purple-600/30"
        : "bg-blue-600/10 text-blue-400 border-blue-600/30"
    }`}
  >
    {name}
  </span>
);

const SlotList = () => {
  const navigate = useNavigate();

  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tableLoading, setTableLoading] = useState(false);
  const [error, setError] = useState("");

  const [currentPage, setCurrentPage] = useState(1);
  const [lastPage, setLastPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [totalSlots, setTotalSlots] = useState(0);
  const [activeSlots, setActiveSlots] = useState(0);
  const [inactiveSlots, setInactiveSlots] = useState(0);

  const [searchText, setSearchText] = useState("");
  const [search, setSearch] = useState("");
  const [turfFilter, setTurfFilter] = useState("");
  const [dayFilter, setDayFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");

  const [turfs, setTurfs] = useState([]);
  const [days, setDays] = useState([]);

  const [busyIds, setBusyIds] = useState([]);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    fetchFilters();
  }, []);

  useEffect(() => {
    fetchSlots(currentPage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage, search, turfFilter, dayFilter, typeFilter, statusFilter]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchText.length >= 3 || searchText.length === 0) {
        setSearch(searchText);
        setCurrentPage(1);
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [searchText]);

  const fetchFilters = async () => {
    try {
      const res = await api.get(ENDPOINTS.DROPDOWN_DATA);
      if (res.data.success) {
        setTurfs(res.data.data?.turfs || []);
        setDays(res.data.data?.days || []);
      }
    } catch (err) {
      toast.error("Unable to load filters.");
    }
  };

  const fetchSlots = async (pageNum = currentPage) => {
    try {
      loading ? setLoading(true) : setTableLoading(true);
      setError("");

      const res = await api.get(ENDPOINTS.LIST, {
        params: {
          page: pageNum,
          per_page: perPage,
          search: search || undefined,
          turf_id: turfFilter || undefined,
          day: dayFilter || undefined,
          booking_type: typeFilter || undefined,
          status: statusFilter,
        },
      });

      if (res.data.success) {
        setSlots(res.data.data || []);
        setCurrentPage(res.data.pagination?.current_page || 1);
        setLastPage(res.data.pagination?.last_page || 1);
        setPerPage(res.data.pagination?.per_page || 10);
        setTotalSlots(res.data.counts?.total_slots || 0);
        setActiveSlots(res.data.counts?.active_slots || 0);
        setInactiveSlots(res.data.counts?.inactive_slots || 0);
      } else {
        setError(res.data.message || "Failed to load slots.");
      }
    } catch (err) {
      const message =
        err?.response?.data?.message ||
        "Something went wrong while fetching slots.";

      toast.error(message);

      setError(message);
    } finally {
      setLoading(false);
      setTableLoading(false);
    }
  };

  const stats = [
    {
      icon: "ti-calendar-time",
      value: totalSlots,
      label: "Total Slots",
      iconBg: "rgba(41,121,255,.15)",
      iconColor: "#2979FF",
    },
    {
      icon: "ti-check",
      value: activeSlots,
      label: "Active Slots",
      iconBg: "rgba(34,197,94,.15)",
      iconColor: "#22C55E",
    },
    {
      icon: "ti-ban",
      value: inactiveSlots,
      label: "Inactive Slots",
      iconBg: "rgba(239,68,68,.15)",
      iconColor: "#EF4444",
    },
  ];

  const statusFilters = [
    { label: "All", value: "" },
    { label: "Active", value: 1 },
    { label: "Inactive", value: 0 },
  ];

  const handleAddNew = () => navigate("/slot-masters/new");

  const toggleStatus = async (slot) => {
    setBusyIds((prev) => [...prev, slot.id]);
    const nextStatus = !slot.status;
    setSlots((prev) =>
      prev.map((s) => (s.id === slot.id ? { ...s, status: nextStatus } : s)),
    );
    try {
      await api.patch(ENDPOINTS.UPDATE_STATUS(slot.id), {
        status: nextStatus,
      });
      toast.success(
        `Slot ${nextStatus ? "activated" : "deactivated"} successfully.`,
      );

      // Refresh counts from server truth
      fetchSlots(currentPage);
    } catch (err) {
      setSlots((prev) =>
        prev.map((s) => (s.id === slot.id ? { ...s, status: slot.status } : s)),
      );
      const message =
        err?.response?.data?.message || "Couldn't update slot status.";

      toast.error(message);

      setError(message);
    } finally {
      setBusyIds((prev) => prev.filter((id) => id !== slot.id));
    }
  };

  const confirmDelete = (slot) => setDeleteTarget(slot);
  const cancelDelete = () => {
    if (deleting) return;
    setDeleteTarget(null);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await api.delete(ENDPOINTS.DELETE(deleteTarget.id));
      toast.success("Slot deleted successfully.");
      setDeleteTarget(null);

      // If we deleted the last row on a page beyond page 1, step back a page
      const isLastRowOnPage = slots.length === 1 && currentPage > 1;
      const nextPage = isLastRowOnPage ? currentPage - 1 : currentPage;
      setCurrentPage(nextPage);
      fetchSlots(nextPage);
    } catch (err) {
      const message = err?.response?.data?.message || "Failed to delete slot.";

      toast.error(message);

      setDeleteTarget((prev) =>
        prev
          ? {
              ...prev,
              _error: message,
            }
          : prev,
      );
    } finally {
      setDeleting(false);
    }
  };

  if (loading) {
    return <ListPageSkeleton statsCount={3} tableRows={8} tableColumns={7} />;
  }

  return (
    <div className="w-full p-2 lg:px-4 lg:py-3">
      <PageHeader title="Slot Masters" subtitle={`${totalSlots} Total Slots`}>
        <button
          onClick={handleAddNew}
          className="flex items-center gap-1.5 px-3 py-2 text-[11px] rounded-sm bg-blue-600 text-white font-semibold hover:bg-blue-500 transition-colors cursor-pointer"
        >
          <Plus size={13} />
          Add New Slot
        </button>
      </PageHeader>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-2 mb-4">
        {stats.map((item, index) => (
          <StatCard key={index} {...item} />
        ))}
      </div>

      {error && (
        <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-[10px] px-4 py-3 text-[11px] text-red-400 mb-3">
          <AlertTriangle size={14} className="shrink-0" />
          {error}
          <button
            onClick={() => fetchSlots(currentPage)}
            className="ml-auto underline shrink-0 cursor-pointer"
          >
            <RefreshCw size={12} className="inline mr-1" />
            Retry
          </button>
        </div>
      )}

      {/* Search + Filters */}
      <div className="flex flex-col xl:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search
            size={14}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6b7280]"
          />
          <input
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            placeholder="Search by turf name…"
            className="w-full h-8 pl-9 pr-3 rounded-[8px] text-[11px] bg-[#14141A] border border-[#1F1F27] text-[#a0a0a0] outline-none"
          />
        </div>

        <select
          value={turfFilter}
          onChange={(e) => {
            setTurfFilter(e.target.value);
            setCurrentPage(1);
          }}
          className="h-8 bg-[#14141a] border border-[#1F1F27] rounded-[8px] px-3 text-[11px] text-white cursor-pointer outline-none"
        >
          <option value="">All Turfs</option>
          {turfs.map((t) => (
            <option key={t.id} value={t.id}>
              {t.name}
            </option>
          ))}
        </select>

        <select
          value={dayFilter}
          onChange={(e) => {
            setDayFilter(e.target.value);
            setCurrentPage(1);
          }}
          className="h-8 bg-[#14141a] border border-[#1F1F27] rounded-[8px] px-3 text-[11px] text-white capitalize cursor-pointer outline-none"
        >
          <option value="">All Days</option>
          {days.map((d) => (
            <option key={d} value={d} className="capitalize">
              {d}
            </option>
          ))}
        </select>

        <div className="flex flex-wrap gap-2">
          {TYPE_FILTERS.map((f) => (
            <button
              key={f.key || "all-types"}
              onClick={() => {
                setTypeFilter(f.key);
                setCurrentPage(1);
              }}
              className={`h-8 px-3 rounded-[8px] text-[10px] font-semibold border cursor-pointer ${
                typeFilter === f.key
                  ? "bg-blue-600/10 border-blue-600 text-blue-400"
                  : "bg-[#11131d] border-[#1f2333] text-[#a0a0a0]"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap gap-2">
          {statusFilters.map((f) => (
            <button
              key={f.label}
              onClick={() => {
                setStatusFilter(f.value);
                setCurrentPage(1);
              }}
              className={`h-8 px-3 rounded-[8px] text-[10px] font-semibold border cursor-pointer ${
                statusFilter === f.value
                  ? "bg-blue-600/10 border-blue-600 text-blue-400"
                  : "bg-[#11131d] border-[#1f2333] text-[#a0a0a0]"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
        <div className="flex justify-between items-center px-6 py-2 border-b border-[#1f2333]">
          <h2 className="text-sm font-bold text-white">All Slots</h2>
          <span className="text-gray-400 text-[10px]">
            Showing {totalSlots === 0 ? 0 : (currentPage - 1) * perPage + 1}-
            {Math.min(currentPage * perPage, totalSlots)} of {totalSlots}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px]">
            <thead>
              <tr className="border-b border-[#1f2333] text-gray-500 text-[8px]">
                <th className="text-left px-4 py-2">Sr No</th>
                <th className="text-left">Turf</th>
                <th className="text-left">Sport / Event</th>
                <th className="text-left">Day</th>
                <th className="text-left">Time</th>
                <th className="text-left">Price</th>
                <th className="text-left">Status</th>
                <th className="text-left">Action</th>
              </tr>
            </thead>

            <tbody>
              {tableLoading ? (
                <tr>
                  <td colSpan="8" className="text-center py-10 text-white">
                    Loading...
                  </td>
                </tr>
              ) : slots.length === 0 ? (
                <tr>
                  <td colSpan="8" className="text-center py-10 text-gray-400">
                    No slots match this view yet.
                  </td>
                </tr>
              ) : (
                slots.map((slot, index) => {
                  const isBusy = busyIds.includes(slot.id);
                  return (
                    <tr
                      key={slot.id}
                      className="border-b border-[#1f2333] hover:bg-[#161926]"
                    >
                      <td className="pl-8 text-[11px] text-[#C0C0C0]">
                        {(currentPage - 1) * perPage + index + 1}
                      </td>

                      <td>
                        <div className="flex items-center gap-2 text-[#C0C0C0] text-[11px]">
                          <Building2 size={12} className="text-gray-500" />
                          {slot.turf_name || "-"}
                        </div>
                      </td>

                      <td>
                        <BookingTypeTag
                          type={slot.booking_type}
                          name={slot.booking_name}
                        />
                      </td>

                      <td>
                        <div className="flex items-center gap-1.5 text-[#C0C0C0] text-[11px] capitalize">
                          <CalendarClock size={12} className="text-gray-500" />
                          {slot.day}
                        </div>
                      </td>

                      <td>
                        <div className="flex items-center gap-1.5 text-[#C0C0C0] text-[11px] whitespace-nowrap">
                          <Clock size={12} className="text-gray-500" />
                          {slot.start_time} – {slot.end_time}
                        </div>
                      </td>

                      <td>
                        <div className="flex items-center gap-1 text-[#C0C0C0] text-[11px] font-semibold">
                          <IndianRupee size={11} className="text-gray-500" />
                          {parseFloat(slot.price).toFixed(0)}
                        </div>
                      </td>

                      <td>
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => toggleStatus(slot)}
                          className="cursor-pointer disabled:opacity-50"
                          title="Click to toggle status"
                        >
                          {isBusy ? (
                            <Loader2
                              size={12}
                              className="animate-spin text-gray-400"
                            />
                          ) : (
                            <StatusBadge active={slot.status} />
                          )}
                        </button>
                      </td>

                      <td>
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => confirmDelete(slot)}
                            className="flex items-center gap-1 px-2.5 py-1.5 rounded-[6px] text-[9px] font-semibold bg-red-500/10 border border-red-500/40 text-red-400 hover:bg-red-500/20 cursor-pointer disabled:opacity-50"
                          >
                            <Trash2 size={11} />
                            Delete
                          </button>

                          <button
                            type="button"
                            onClick={() =>
                              navigate(`/slot-masters/${slot.id}/edit`)
                            }
                            className="flex items-center gap-1 px-2.5 py-1.5 rounded-[6px] text-[9px] font-semibold bg-blue-600/10 border border-blue-600/40 text-blue-400 hover:bg-blue-600/20 cursor-pointer"
                          >
                            <Pencil size={11} />
                            Edit
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        <div className="flex justify-between items-center px-4 py-2">
          <span className="text-gray-400 text-[10px]">
            Page {currentPage} of {lastPage}
          </span>

          <div className="flex gap-2">
            <button
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(currentPage - 1)}
              className="w-7 h-7 rounded-[7px] bg-[#161926] disabled:opacity-40"
            >
              ←
            </button>

            <button className="w-7 h-7 rounded-[7px] bg-blue-600 text-white">
              {currentPage}
            </button>

            <button
              disabled={currentPage === lastPage}
              onClick={() => setCurrentPage(currentPage + 1)}
              className="w-7 h-7 rounded-[7px] bg-[#161926] disabled:opacity-40"
            >
              →
            </button>
          </div>
        </div>
      </div>

      {/* Delete confirm */}
      {deleteTarget && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
          onClick={cancelDelete}
        >
          <div
            className="w-full max-w-sm bg-[#14141A] border border-[#1F1F27] rounded-[14px] p-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-11 h-11 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center mb-3">
              <AlertTriangle size={20} className="text-red-400" />
            </div>
            <h3 className="text-[13px] font-bold text-white mb-1.5">
              Delete this slot?
            </h3>
            <p className="text-[10px] text-[#A0A0A0] mb-1">
              {deleteTarget.booking_name} on{" "}
              <span className="capitalize">{deleteTarget.day}</span>,{" "}
              {deleteTarget.start_time}–{deleteTarget.end_time} will be
              permanently removed. This can't be undone.
            </p>
            {deleteTarget._error && (
              <p className="text-[10px] text-red-400 mt-2">
                {deleteTarget._error}
              </p>
            )}
            <div className="flex gap-2 justify-end mt-4">
              <button
                onClick={cancelDelete}
                disabled={deleting}
                className="px-4 py-2 rounded-[8px] text-[11px] font-semibold bg-[#1F1F27] text-[#A0A0A0] cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                disabled={deleting}
                className="flex items-center gap-1.5 px-4 py-2 rounded-[8px] text-[11px] font-semibold bg-red-500 text-white hover:bg-red-400 cursor-pointer disabled:opacity-60"
              >
                {deleting && <Loader2 size={13} className="animate-spin" />}
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SlotList;
