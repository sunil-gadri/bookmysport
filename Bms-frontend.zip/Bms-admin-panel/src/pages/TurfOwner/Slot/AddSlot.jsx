import React, { useEffect, useState } from "react";
import {
  CalendarClock,
  Building2,
  Dumbbell,
  Sparkles,
  Clock,
  IndianRupee,
  Loader2,
  AlertTriangle,
  CheckCircle2,
  Plus,
  List,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import api from "../../../api/axios";
import { PageHeader } from "../../../components/UI";
import { toast } from "sonner";

const ENDPOINTS = {
  DROPDOWN_DATA: "/turf-owner/slot-masters/dropdown-data",
  TURF_DETAILS: "/turf-owner/slot-masters/turf-details",
  ADD_SLOT: "/turf-owner/slot-masters",
  AUTO_GENERATE: "/turf-owner/slot-masters/auto-generate",
};

const emptyForm = {
  turf_id: "",
  booking_type: "sport", // "sport" | "event"
  booking_type_id: "",
  day: "", // manual mode
  days: [], // auto mode
  start_time: "", // manual mode
  end_time: "", // manual mode
  slot_duration: "", // auto mode
  price: "",
};

const AddSlot = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState("");
  const [successInfo, setSuccessInfo] = useState(null); // { booking_name, day, ... }

  // ── Dropdown data ──
  const [turfs, setTurfs] = useState([]);
  const [sports, setSports] = useState([]);
  const [events, setEvents] = useState([]);
  const [days, setDays] = useState([]);
  const [loadingDropdowns, setLoadingDropdowns] = useState(true);
  const [dropdownError, setDropdownError] = useState("");
  const [mode, setMode] = useState("manual"); // "manual" | "auto"
  const [turfTimings, setTurfTimings] = useState({
    opening_time: "",
    closing_time: "",
  });

  useEffect(() => {
    fetchDropdownData();
  }, []);

  const fetchDropdownData = async () => {
    setLoadingDropdowns(true);
    setDropdownError("");
    try {
      const res = await api.get(ENDPOINTS.DROPDOWN_DATA);
      if (res.data.success) {
        const turfList = res.data.data?.turfs || [];

        setTurfs(turfList);
        setDays(res.data.data?.days || []);

        if (turfList.length > 0) {
          const firstTurf = turfList[0];

          setFormData((prev) => ({
            ...prev,
            turf_id: firstTurf.id,
          }));

          fetchTurfDetails(firstTurf.id);
        } else {
          setSports([]);
          setEvents([]);
        }
      } else {
        setDropdownError(res.data.message || "Failed to load form options.");
      }
    } catch (err) {
      setDropdownError(
        err?.response?.data?.message ||
          "Something went wrong while loading form options.",
      );
    } finally {
      setLoadingDropdowns(false);
    }
  };

  const fetchTurfDetails = async (turfId) => {
    try {
      const res = await api.get(`${ENDPOINTS.TURF_DETAILS}/${turfId}`);
      if (res.data.success) {
        setSports(res.data.data?.sports || []);
        setEvents(res.data.data?.events || []);
        setTurfTimings({
          opening_time: res.data.data?.opening_time || "",
          closing_time: res.data.data?.closing_time || "",
        });
      }
    } catch (error) {
      setSports([]);
      setEvents([]);
      setTurfTimings({ opening_time: "", closing_time: "" });
    }
  };

  const toggleDay = (day) => {
    setFormData((prev) => {
      const already = prev.days.includes(day);
      return {
        ...prev,
        days: already
          ? prev.days.filter((d) => d !== day)
          : [...prev.days, day],
      };
    });
    setErrors((prev) => ({ ...prev, days: undefined }));
  };

  const setField = (key, value) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const handleBookingTypeChange = (type) => {
    // booking_type_id options change depending on sport vs event, so reset it
    setFormData((prev) => ({
      ...prev,
      booking_type: type,
      booking_type_id: "",
    }));
    setErrors((prev) => ({ ...prev, booking_type_id: undefined }));
  };

  const bookingTypeOptions =
    formData.booking_type === "event" ? events : sports;

  // ───────────────────────────────────────────────
  // Validation
  // ───────────────────────────────────────────────

  const validateManual = () => {
    const e = {};
    if (!formData.turf_id) e.turf_id = "Please select a turf.";
    if (!formData.booking_type_id) {
      e.booking_type_id =
        formData.booking_type === "event"
          ? "Please select an event."
          : "Please select a sport.";
    }
    if (!formData.day) e.day = "Please select a day.";
    if (!formData.start_time) e.start_time = "Start time is required.";
    if (!formData.end_time) e.end_time = "End time is required.";
    if (
      formData.start_time &&
      formData.end_time &&
      formData.start_time >= formData.end_time
    ) {
      e.end_time = "End time must be after start time.";
    }
    if (!formData.price.toString().trim()) e.price = "Price is required.";
    else if (Number(formData.price) <= 0)
      e.price = "Price must be greater than 0.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const validateAuto = () => {
    const e = {};
    if (!formData.turf_id) e.turf_id = "Please select a turf.";
    if (!formData.booking_type_id) {
      e.booking_type_id =
        formData.booking_type === "event"
          ? "Please select an event."
          : "Please select a sport.";
    }
    if (!formData.days.length) e.days = "Please select at least one day.";
    if (!turfTimings.opening_time || !turfTimings.closing_time) {
      e.turf_id =
        e.turf_id || "Selected turf has no operating hours configured.";
    }
    if (!formData.slot_duration || Number(formData.slot_duration) <= 0) {
      e.slot_duration = "Slot duration is required.";
    }
    if (!formData.price.toString().trim()) e.price = "Price is required.";
    else if (Number(formData.price) <= 0)
      e.price = "Price must be greater than 0.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  // ───────────────────────────────────────────────
  // Submit
  // ───────────────────────────────────────────────

  const resetForKeepingTurfAndDay = () => {
    // Keep turf + booking type selected since owners usually add several
    // slots for the same turf/sport back to back — only clear time & price.
    setFormData((prev) => ({
      ...prev,
      day: prev.day,
      start_time: "",
      end_time: "",
      price: "",
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError("");
    setSuccessInfo(null);

    const isValid = mode === "auto" ? validateAuto() : validateManual();
    if (!isValid) {
      const firstErrorEl = document.querySelector("[data-error='true']");
      firstErrorEl?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }

    setSubmitting(true);
    try {
      if (mode === "auto") {
        const payload = {
          turf_id: Number(formData.turf_id),
          booking_type: formData.booking_type,
          booking_type_id: Number(formData.booking_type_id),
          days: formData.days,
          opening_time: turfTimings.opening_time,
          closing_time: turfTimings.closing_time,
          slot_duration: Number(formData.slot_duration),
          price: Number(formData.price),
        };

        const res = await api.post(ENDPOINTS.AUTO_GENERATE, payload);
        const count = res.data?.data?.length || 0;

        toast.success(
          res.data.message || `${count} slots generated successfully.`,
        );
        setSuccessInfo({ generatedCount: count, days: formData.days });
        setFormData((prev) => ({
          ...prev,
          days: [],
          slot_duration: "",
          price: "",
        }));
      } else {
        const payload = {
          turf_id: Number(formData.turf_id),
          booking_type: formData.booking_type,
          booking_type_id: Number(formData.booking_type_id),
          day: formData.day,
          start_time: formData.start_time,
          end_time: formData.end_time,
          price: Number(formData.price),
        };

        const res = await api.post(ENDPOINTS.ADD_SLOT, payload);

        toast.success(res.data.message || "Slot created successfully.");
        setSuccessInfo({
          booking_name: res.data?.data?.booking_name,
          day: res.data?.data?.day,
          start_time: formData.start_time,
          end_time: formData.end_time,
        });
        resetForKeepingTurfAndDay();
      }
    } catch (err) {
      const apiErrors = err?.response?.data?.errors;
      const apiMessage = err?.response?.data?.message;
      if (apiErrors) {
        const mapped = {};
        Object.entries(apiErrors).forEach(([key, val]) => {
          mapped[key] = Array.isArray(val) ? val[0] : val;
        });
        setErrors((prev) => ({ ...prev, ...mapped }));
      } else {
        toast.error(apiMessage || "Something went wrong.");
        setFormError(apiMessage || "Something went wrong. Please try again.");
      }
    } finally {
      setSubmitting(false);
    }
  };

  // ───────────────────────────────────────────────
  // Small reusable bits
  // ───────────────────────────────────────────────

  const Label = ({ children, required }) => (
    <label className="block text-[9px] text-[#A0A0A0] uppercase tracking-wide font-semibold mb-1.5">
      {children} {required && <span className="text-red-400">*</span>}
    </label>
  );

  const FieldError = ({ msg }) =>
    msg ? (
      <p data-error="true" className="text-[9px] text-red-400 mt-1">
        {msg}
      </p>
    ) : null;

  const inputClass = (hasError) =>
    `w-full h-9 px-3 rounded-[8px] text-[11px] bg-[#1F1F27] border text-white placeholder:text-[#555] outline-none ${
      hasError ? "border-red-500" : "border-[#2a2a35] focus:border-blue-600"
    }`;

  if (!loadingDropdowns && turfs.length === 0) {
    return (
      <div className="w-full h-[70vh] flex items-center justify-center">
        <div className="bg-[#14141a] border border-[#1F1F27] rounded-xl p-10 text-center max-w-md">
          <Building2 size={48} className="mx-auto text-blue-500 mb-4" />

          <h2 className="text-white text-xl font-bold">No Turf Found</h2>

          <p className="text-[#A0A0A0] text-sm mt-3">
            You need to create your first turf before adding slots.
          </p>

          <button
            onClick={() => navigate("/turfs/new")}
            className="mt-6 px-6 py-3 bg-blue-600 rounded-lg text-white font-semibold hover:bg-blue-500"
          >
            Add Turf
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full p-2 lg:px-4 lg:py-3">
      <PageHeader
        title="Add New Slot"
        subtitle="Create a bookable time slot for a turf's sport or event"
      >
        <button
          onClick={() => navigate("/slots")}
          className="flex cursor-pointer items-center gap-1.5 px-3 py-2 text-[11px] rounded-sm bg-[#1F1F27] text-[#C0C0C0] font-semibold hover:text-white transition-colors"
        >
          <List size={12} />
          View All Slots
        </button>
      </PageHeader>

      <div className="max-w-2xl mt-3">
        {dropdownError && (
          <div className="flex items-center justify-between gap-2 bg-red-500/10 border border-red-500/30 rounded-[10px] px-4 py-3 text-[11px] text-red-400 mb-3">
            <span className="flex items-center gap-2">
              <AlertTriangle size={14} className="shrink-0" />
              {dropdownError}
            </span>
            <button
              type="button"
              onClick={fetchDropdownData}
              className="underline shrink-0 cursor-pointer"
            >
              Retry
            </button>
          </div>
        )}

        {/* {successInfo && (
          <div className="flex items-start gap-2 bg-green-500/10 border border-green-500/30 rounded-[10px] px-4 py-3 text-[11px] text-green-400 mb-3">
            <CheckCircle2 size={14} className="shrink-0 mt-0.5" />
            <span>
              Slot created for <strong>{successInfo.booking_name}</strong> on{" "}
              <strong className="capitalize">{successInfo.day}</strong>,{" "}
              {successInfo.start_time}–{successInfo.end_time}. Add another
              below, or head to the slot list.
            </span>
          </div>
        )} */}

        {successInfo && mode === "auto" && (
          <div className="flex items-start gap-2 bg-green-500/10 border border-green-500/30 rounded-[10px] px-4 py-3 text-[11px] text-green-400 mb-3">
            <CheckCircle2 size={14} className="shrink-0 mt-0.5" />
            <span>
              Generated <strong>{successInfo.generatedCount}</strong> slots
              across{" "}
              <strong className="capitalize">
                {successInfo.days?.join(", ")}
              </strong>
              .
            </span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-3">
          {formError && (
            <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-[10px] px-4 py-3 text-[11px] text-red-400">
              <AlertTriangle size={14} className="shrink-0" />
              {formError}
            </div>
          )}

          <div className="flex gap-2 mb-1">
            {[
              { key: "manual", label: "Manual" },
              { key: "auto", label: "Auto Generate" },
            ].map((opt) => {
              const active = mode === opt.key;
              return (
                <button
                  key={opt.key}
                  type="button"
                  onClick={() => {
                    setMode(opt.key);
                    setErrors({});
                    setSuccessInfo(null);
                  }}
                  className={`px-4 py-2 rounded-[8px] text-[10px] font-semibold border cursor-pointer transition-all ${
                    active
                      ? "bg-blue-600/15 border-blue-600 text-blue-400"
                      : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>

          {/* Turf */}
          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
            <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">
              <Building2 size={14} className="text-blue-400" />
              <h3 className="text-white text-[12px] font-bold">Turf</h3>
            </div>
            <div className="p-6">
              <Label required>Select Turf</Label>
              <select
                value={formData.turf_id}
                onChange={(e) => {
                  const turfId = e.target.value;

                  setField("turf_id", turfId);

                  setField("booking_type_id", "");

                  setSports([]);

                  setEvents([]);

                  if (turfId) {
                    fetchTurfDetails(turfId);
                  }
                }}
                disabled={loadingDropdowns}
                className={
                  inputClass(errors.turf_id) +
                  " cursor-pointer disabled:opacity-50"
                }
              >
                <option value="">
                  {loadingDropdowns ? "Loading..." : "Select turf"}
                </option>
                {turfs.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>
              <FieldError msg={errors.turf_id} />
            </div>
          </div>

          {/* Booking type */}
          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
            <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">
              <Dumbbell size={14} className="text-blue-400" />
              <h3 className="text-white text-[12px] font-bold">Booking Type</h3>
            </div>
            <div className="p-6 flex flex-col gap-4">
              <div className="flex gap-2">
                {[
                  { key: "sport", label: "Sport" },
                  { key: "event", label: "Event" },
                ].map((opt) => {
                  const active = formData.booking_type === opt.key;
                  return (
                    <button
                      key={opt.key}
                      type="button"
                      onClick={() => handleBookingTypeChange(opt.key)}
                      className={`px-4 py-2 rounded-[8px] text-[10px] font-semibold border cursor-pointer transition-all ${
                        active
                          ? "bg-blue-600/15 border-blue-600 text-blue-400"
                          : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                      }`}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>

              <div>
                <Label required>
                  {formData.booking_type === "event" ? "Event" : "Sport"}
                </Label>
                {loadingDropdowns ? (
                  <p className="text-[10px] text-[#A0A0A0]">
                    Loading options...
                  </p>
                ) : bookingTypeOptions.length === 0 ? (
                  <p className="text-[10px] text-[#A0A0A0]">
                    {formData.turf_id ? (
                      <p className="text-[10px] text-[#A0A0A0]">
                        No{" "}
                        {formData.booking_type === "event"
                          ? "events"
                          : "sports"}{" "}
                        are available for the selected turf.
                      </p>
                    ) : (
                      <p className="text-[10px] text-[#A0A0A0]">
                        Please select a turf first.
                      </p>
                    )}
                  </p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {bookingTypeOptions.map((opt) => {
                      const active =
                        String(formData.booking_type_id) === String(opt.id);
                      return (
                        <button
                          type="button"
                          key={opt.id}
                          onClick={() => setField("booking_type_id", opt.id)}
                          className={`px-3 py-1.5 rounded-[8px] text-[10px] font-semibold cursor-pointer border ${
                            active
                              ? formData.booking_type === "event"
                                ? "bg-purple-600/15 border-purple-600 text-purple-400"
                                : "bg-blue-600/15 border-blue-600 text-blue-400"
                              : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                          }`}
                        >
                          {opt.name}
                        </button>
                      );
                    })}
                  </div>
                )}
                <FieldError msg={errors.booking_type_id} />
              </div>
            </div>
          </div>

          {/* Day */}
          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
            <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">
              <CalendarClock size={14} className="text-blue-400" />
              <h3 className="text-white text-[12px] font-bold">
                {mode === "auto" ? "Days" : "Day"}
              </h3>
            </div>
            <div className="p-6">
              <Label required>
                {mode === "auto" ? "Select Days" : "Select Day"}
              </Label>
              {loadingDropdowns ? (
                <p className="text-[10px] text-[#A0A0A0]">Loading days...</p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {days.map((d) => {
                    const active =
                      mode === "auto"
                        ? formData.days.includes(d)
                        : formData.day === d;
                    return (
                      <button
                        type="button"
                        key={d}
                        onClick={() =>
                          mode === "auto" ? toggleDay(d) : setField("day", d)
                        }
                        className={`px-3 py-1.5 rounded-[8px] text-[10px] font-semibold capitalize cursor-pointer border ${
                          active
                            ? "bg-blue-600/15 border-blue-600 text-blue-400"
                            : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                        }`}
                      >
                        {d}
                      </button>
                    );
                  })}
                </div>
              )}
              <FieldError msg={mode === "auto" ? errors.days : errors.day} />
            </div>
          </div>

          {/* Timing & price */}
          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
            <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">
              <Clock size={14} className="text-blue-400" />
              <h3 className="text-white text-[12px] font-bold">
                {mode === "auto"
                  ? "Timing, Duration & Price"
                  : "Timing & Price"}
              </h3>
            </div>

            {mode === "auto" ? (
              <div className="p-6 grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <Label>Opening Time</Label>
                  <input
                    type="time"
                    value={turfTimings.opening_time}
                    disabled
                    className={
                      inputClass(false) + " opacity-60 cursor-not-allowed"
                    }
                  />
                </div>

                <div>
                  <Label>Closing Time</Label>
                  <input
                    type="time"
                    value={turfTimings.closing_time}
                    disabled
                    className={
                      inputClass(false) + " opacity-60 cursor-not-allowed"
                    }
                  />
                </div>

                <div>
                  <Label required>Slot Duration (min)</Label>
                  <input
                    type="number"
                    min="5"
                    step="5"
                    value={formData.slot_duration}
                    onChange={(e) =>
                      setField(
                        "slot_duration",
                        e.target.value.replace(/[^\d]/g, ""),
                      )
                    }
                    placeholder="60"
                    className={inputClass(errors.slot_duration)}
                  />
                  <FieldError msg={errors.slot_duration} />
                </div>

                <div>
                  <Label required>Price (₹)</Label>
                  <div className="relative">
                    <IndianRupee
                      size={11}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-[#555]"
                    />
                    <input
                      type="number"
                      min="0"
                      step="1"
                      value={formData.price}
                      onChange={(e) =>
                        setField("price", e.target.value.replace(/[^\d.]/g, ""))
                      }
                      placeholder="800"
                      className={inputClass(errors.price) + " pl-7"}
                    />
                  </div>
                  <FieldError msg={errors.price} />
                </div>
              </div>
            ) : (
              <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label required>Start Time</Label>
                  <input
                    type="time"
                    value={formData.start_time}
                    onChange={(e) => setField("start_time", e.target.value)}
                    className={inputClass(errors.start_time)}
                  />
                  <FieldError msg={errors.start_time} />
                </div>

                <div>
                  <Label required>End Time</Label>
                  <input
                    type="time"
                    value={formData.end_time}
                    onChange={(e) => setField("end_time", e.target.value)}
                    className={inputClass(errors.end_time)}
                  />
                  <FieldError msg={errors.end_time} />
                </div>

                <div>
                  <Label required>Price (₹)</Label>
                  <div className="relative">
                    <IndianRupee
                      size={11}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-[#555]"
                    />
                    <input
                      type="number"
                      min="0"
                      step="1"
                      value={formData.price}
                      onChange={(e) =>
                        setField("price", e.target.value.replace(/[^\d.]/g, ""))
                      }
                      placeholder="800"
                      className={inputClass(errors.price) + " pl-7"}
                    />
                  </div>
                  <FieldError msg={errors.price} />
                </div>
              </div>
            )}
          </div>

          {/* Submit */}
          <div className="flex justify-end gap-2 pb-4">
            <button
              type="button"
              onClick={() => navigate("/slots")}
              disabled={submitting}
              className="px-5 py-2.5 rounded-[8px] text-[11px] font-semibold bg-[#1F1F27] text-[#A0A0A0] cursor-pointer disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || loadingDropdowns}
              className="flex items-center gap-1.5 px-5 py-2.5 rounded-[8px] text-[11px] font-semibold bg-blue-600 text-white hover:bg-blue-500 cursor-pointer disabled:opacity-60"
            >
              {submitting ? (
                <Loader2 size={13} className="animate-spin" />
              ) : (
                <Plus size={13} />
              )}
              {submitting
                ? mode === "auto"
                  ? "Generating Slots..."
                  : "Adding Slot..."
                : mode === "auto"
                  ? "Generate Slots"
                  : "Add Slot"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddSlot;
