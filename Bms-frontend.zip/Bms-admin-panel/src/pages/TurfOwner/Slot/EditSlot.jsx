import React, { useEffect, useState } from "react";
import {
  CalendarClock,
  Building2,
  Dumbbell,
  Clock,
  IndianRupee,
  Loader2,
  AlertTriangle,
  CheckCircle2,
  Save,
  List,
} from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import api from "../../../api/axios";
import { PageHeader } from "../../../components/UI";
import { toast } from "sonner";

const ENDPOINTS = {
  DROPDOWN_DATA: "/turf-owner/slot-masters/dropdown-data",
  TURF_DETAILS: "/turf-owner/slot-masters/turf-details",
  SLOT_DETAILS: (id) => `/turf-owner/slot-masters/${id}`,
  UPDATE_SLOT: (id) => `/turf-owner/slot-masters/${id}`,
};

const emptyForm = {
  turf_id: "",
  booking_type: "sport",
  booking_type_id: "",
  day: "",
  start_time: "",
  end_time: "",
  price: "",
};

// API returns "12:00 AM" style strings for display; <input type="time">
// and the update endpoint both need "HH:mm" 24-hour format. Convert on load.
const to24Hour = (timeStr) => {
  if (!timeStr) return "";
  const trimmed = timeStr.trim();
  const match = trimmed.match(/^(\d{1,2}):(\d{2})\s?(AM|PM)$/i);
  if (!match) return trimmed; // already "HH:mm"
  let [, hours, minutes, modifier] = match;
  hours = parseInt(hours, 10);
  modifier = modifier.toUpperCase();
  if (modifier === "PM" && hours !== 12) hours += 12;
  if (modifier === "AM" && hours === 12) hours = 0;
  return `${String(hours).padStart(2, "0")}:${minutes}`;
};

const EditSlot = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const [formData, setFormData] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState("");
  const [successInfo, setSuccessInfo] = useState(null);

  const [turfs, setTurfs] = useState([]);
  const [sports, setSports] = useState([]);
  const [events, setEvents] = useState([]);
  const [days, setDays] = useState([]);

  const [loadingSlot, setLoadingSlot] = useState(true);
  const [loadingDropdowns, setLoadingDropdowns] = useState(true);
  const [loadingError, setLoadingError] = useState("");

  useEffect(() => {
    initialize();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const initialize = async () => {
    setLoadingSlot(true);
    setLoadingDropdowns(true);
    setLoadingError("");

    try {
      const [slotRes, dropdownRes] = await Promise.all([
        api.get(ENDPOINTS.SLOT_DETAILS(id)),
        api.get(ENDPOINTS.DROPDOWN_DATA),
      ]);

      if (!slotRes.data.success) {
        setLoadingError(slotRes.data.message || "Failed to load slot.");
        return;
      }

      const slot = slotRes.data.data;

      setTurfs(dropdownRes.data.data?.turfs || []);
      setDays(dropdownRes.data.data?.days || []);

      setFormData({
        turf_id: slot.turf_id,
        booking_type: slot.booking_type,
        booking_type_id: slot.booking_type_id,
        day: (slot.day || "").toLowerCase(),
        start_time: to24Hour(slot.start_time),
        end_time: to24Hour(slot.end_time),
        price: slot.price ? String(parseFloat(slot.price)) : "",
      });

      // Load sports/events available for this slot's own turf
      await fetchTurfDetails(slot.turf_id);
    } catch (err) {
      setLoadingError(
        err?.response?.data?.message ||
          "Something went wrong while loading the slot.",
      );
    } finally {
      setLoadingSlot(false);
      setLoadingDropdowns(false);
    }
  };

  const fetchTurfDetails = async (turfId) => {
    try {
      const res = await api.get(`${ENDPOINTS.TURF_DETAILS}/${turfId}`);
      if (res.data.success) {
        setSports(res.data.data?.sports || []);
        setEvents(res.data.data?.events || []);
      }
    } catch (err) {
      setSports([]);
      setEvents([]);
    }
  };

  const setField = (key, value) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const handleBookingTypeChange = (type) => {
    // booking_type_id options change depending on sport vs event, so reset it
    setFormData((prev) => ({
      ...prev,
      booking_type: type,
      booking_type_id: "",
    }));
    setErrors((prev) => ({ ...prev, booking_type_id: undefined }));
  };

  const bookingTypeOptions =
    formData.booking_type === "event" ? events : sports;

  const validate = () => {
    const e = {};
    if (!formData.turf_id) e.turf_id = "Please select a turf.";
    if (!formData.booking_type_id) {
      e.booking_type_id =
        formData.booking_type === "event"
          ? "Please select an event."
          : "Please select a sport.";
    }
    if (!formData.day) e.day = "Please select a day.";
    if (!formData.start_time) e.start_time = "Start time is required.";
    if (!formData.end_time) e.end_time = "End time is required.";
    if (
      formData.start_time &&
      formData.end_time &&
      formData.start_time >= formData.end_time
    ) {
      e.end_time = "End time must be after start time.";
    }
    if (!formData.price.toString().trim()) e.price = "Price is required.";
    else if (Number(formData.price) <= 0)
      e.price = "Price must be greater than 0.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError("");
    setSuccessInfo(null);

    if (!validate()) {
      const firstErrorEl = document.querySelector("[data-error='true']");
      firstErrorEl?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        turf_id: Number(formData.turf_id),
        booking_type: formData.booking_type,
        booking_type_id: Number(formData.booking_type_id),
        day: formData.day,
        start_time: formData.start_time,
        end_time: formData.end_time,
        price: Number(formData.price),
      };

      const res = await api.put(ENDPOINTS.UPDATE_SLOT(id), payload);

      toast.success(res.data.message || "Slot updated successfully.");
      setSuccessInfo({
        booking_name: res.data?.data?.booking_name,
        day: res.data?.data?.day,
        start_time: formData.start_time,
        end_time: formData.end_time,
      });
    } catch (err) {
      const apiErrors = err?.response?.data?.errors;
      const apiMessage = err?.response?.data?.message;
      if (apiErrors) {
        const mapped = {};
        Object.entries(apiErrors).forEach(([key, val]) => {
          mapped[key] = Array.isArray(val) ? val[0] : val;
        });
        setErrors((prev) => ({ ...prev, ...mapped }));
      } else {
        toast.error(apiMessage || "Something went wrong.");
        setFormError(apiMessage || "Something went wrong. Please try again.");
      }
    } finally {
      setSubmitting(false);
    }
  };

  const Label = ({ children, required }) => (
    <label className="block text-[9px] text-[#A0A0A0] uppercase tracking-wide font-semibold mb-1.5">
      {children} {required && <span className="text-red-400">*</span>}
    </label>
  );

  const FieldError = ({ msg }) =>
    msg ? (
      <p data-error="true" className="text-[9px] text-red-400 mt-1">
        {msg}
      </p>
    ) : null;

  const inputClass = (hasError) =>
    `w-full h-9 px-3 rounded-[8px] text-[11px] bg-[#1F1F27] border text-white placeholder:text-[#555] outline-none ${
      hasError ? "border-red-500" : "border-[#2a2a35] focus:border-blue-600"
    }`;

  if (loadingSlot || loadingDropdowns) {
    return (
      <div className="w-full h-[70vh] flex items-center justify-center">
        <Loader2 size={28} className="animate-spin text-blue-500" />
      </div>
    );
  }

  if (loadingError) {
    return (
      <div className="w-full h-[70vh] flex items-center justify-center">
        <div className="bg-[#14141a] border border-red-500/30 rounded-xl p-10 text-center max-w-md">
          <AlertTriangle size={40} className="mx-auto text-red-400 mb-4" />
          <h2 className="text-white text-lg font-bold">Couldn't load slot</h2>
          <p className="text-[#A0A0A0] text-sm mt-2">{loadingError}</p>
          <button
            onClick={() => navigate("/slots")}
            className="mt-6 px-6 py-3 bg-blue-600 rounded-lg text-white font-semibold hover:bg-blue-500"
          >
            Back to Slot List
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full p-2 lg:px-4 lg:py-3">
      <PageHeader
        title="Edit Slot"
        subtitle="Update timing, price, or booking details for this slot"
      >
        <button
          onClick={() => navigate("/slots")}
          className="flex cursor-pointer items-center gap-1.5 px-3 py-2 text-[11px] rounded-sm bg-[#1F1F27] text-[#C0C0C0] font-semibold hover:text-white transition-colors"
        >
          <List size={12} />
          View All Slots
        </button>
      </PageHeader>

      <div className="max-w-2xl mt-3">
        {successInfo && (
          <div className="flex items-start gap-2 bg-green-500/10 border border-green-500/30 rounded-[10px] px-4 py-3 text-[11px] text-green-400 mb-3">
            <CheckCircle2 size={14} className="shrink-0 mt-0.5" />
            <span>
              Slot updated for <strong>{successInfo.booking_name}</strong> on{" "}
              <strong className="capitalize">{successInfo.day}</strong>,{" "}
              {successInfo.start_time}–{successInfo.end_time}.
            </span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-3">
          {formError && (
            <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-[10px] px-4 py-3 text-[11px] text-red-400">
              <AlertTriangle size={14} className="shrink-0" />
              {formError}
            </div>
          )}

          {/* Turf */}
          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
            <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">
              <Building2 size={14} className="text-blue-400" />
              <h3 className="text-white text-[12px] font-bold">Turf</h3>
            </div>
            <div className="p-6">
              <Label required>Select Turf</Label>
              <select
                value={formData.turf_id}
                onChange={(e) => {
                  const turfId = e.target.value;
                  setField("turf_id", turfId);
                  setField("booking_type_id", "");
                  setSports([]);
                  setEvents([]);
                  if (turfId) fetchTurfDetails(turfId);
                }}
                className={inputClass(errors.turf_id) + " cursor-pointer"}
              >
                <option value="">Select turf</option>
                {turfs.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>
              <FieldError msg={errors.turf_id} />
            </div>
          </div>

          {/* Booking type */}
          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
            <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">
              <Dumbbell size={14} className="text-blue-400" />
              <h3 className="text-white text-[12px] font-bold">
                Booking Type
              </h3>
            </div>
            <div className="p-6 flex flex-col gap-4">
              <div className="flex gap-2">
                {[
                  { key: "sport", label: "Sport" },
                  { key: "event", label: "Event" },
                ].map((opt) => {
                  const active = formData.booking_type === opt.key;
                  return (
                    <button
                      key={opt.key}
                      type="button"
                      onClick={() => handleBookingTypeChange(opt.key)}
                      className={`px-4 py-2 rounded-[8px] text-[10px] font-semibold border cursor-pointer transition-all ${
                        active
                          ? "bg-blue-600/15 border-blue-600 text-blue-400"
                          : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                      }`}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>

              <div>
                <Label required>
                  {formData.booking_type === "event" ? "Event" : "Sport"}
                </Label>
                {bookingTypeOptions.length === 0 ? (
                  <p className="text-[10px] text-[#A0A0A0]">
                    {formData.turf_id
                      ? `No ${
                          formData.booking_type === "event"
                            ? "events"
                            : "sports"
                        } are available for the selected turf.`
                      : "Please select a turf first."}
                  </p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {bookingTypeOptions.map((opt) => {
                      const active =
                        String(formData.booking_type_id) === String(opt.id);
                      return (
                        <button
                          type="button"
                          key={opt.id}
                          onClick={() => setField("booking_type_id", opt.id)}
                          className={`px-3 py-1.5 rounded-[8px] text-[10px] font-semibold cursor-pointer border ${
                            active
                              ? formData.booking_type === "event"
                                ? "bg-purple-600/15 border-purple-600 text-purple-400"
                                : "bg-blue-600/15 border-blue-600 text-blue-400"
                              : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                          }`}
                        >
                          {opt.name}
                        </button>
                      );
                    })}
                  </div>
                )}
                <FieldError msg={errors.booking_type_id} />
              </div>
            </div>
          </div>

          {/* Day */}
          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
            <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">
              <CalendarClock size={14} className="text-blue-400" />
              <h3 className="text-white text-[12px] font-bold">Day</h3>
            </div>
            <div className="p-6">
              <Label required>Select Day</Label>
              <div className="flex flex-wrap gap-2">
                {days.map((d) => {
                  const active = formData.day === d;
                  return (
                    <button
                      type="button"
                      key={d}
                      onClick={() => setField("day", d)}
                      className={`px-3 py-1.5 rounded-[8px] text-[10px] font-semibold capitalize cursor-pointer border ${
                        active
                          ? "bg-blue-600/15 border-blue-600 text-blue-400"
                          : "bg-[#1F1F27] border-[#2a2a35] text-[#A0A0A0]"
                      }`}
                    >
                      {d}
                    </button>
                  );
                })}
              </div>
              <FieldError msg={errors.day} />
            </div>
          </div>

          {/* Timing & price */}
          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
            <div className="px-6 py-3 border-b border-[#1f2333] flex items-center gap-2">
              <Clock size={14} className="text-blue-400" />
              <h3 className="text-white text-[12px] font-bold">
                Timing & Price
              </h3>
            </div>
            <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label required>Start Time</Label>
                <input
                  type="time"
                  value={formData.start_time}
                  onChange={(e) => setField("start_time", e.target.value)}
                  className={inputClass(errors.start_time)}
                />
                <FieldError msg={errors.start_time} />
              </div>

              <div>
                <Label required>End Time</Label>
                <input
                  type="time"
                  value={formData.end_time}
                  onChange={(e) => setField("end_time", e.target.value)}
                  className={inputClass(errors.end_time)}
                />
                <FieldError msg={errors.end_time} />
              </div>

              <div>
                <Label required>Price (₹)</Label>
                <div className="relative">
                  <IndianRupee
                    size={11}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-[#555]"
                  />
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={formData.price}
                    onChange={(e) =>
                      setField("price", e.target.value.replace(/[^\d.]/g, ""))
                    }
                    placeholder="800"
                    className={inputClass(errors.price) + " pl-7"}
                  />
                </div>
                <FieldError msg={errors.price} />
              </div>
            </div>
          </div>

          {/* Submit */}
          <div className="flex justify-end gap-2 pb-4">
            <button
              type="button"
              onClick={() => navigate("/slots")}
              disabled={submitting}
              className="px-5 py-2.5 rounded-[8px] text-[11px] font-semibold bg-[#1F1F27] text-[#A0A0A0] cursor-pointer disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="flex items-center gap-1.5 px-5 py-2.5 rounded-[8px] text-[11px] font-semibold bg-blue-600 text-white hover:bg-blue-500 cursor-pointer disabled:opacity-60"
            >
              {submitting ? (
                <Loader2 size={13} className="animate-spin" />
              ) : (
                <Save size={13} />
              )}
              {submitting ? "Saving..." : "Save Changes"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditSlot;