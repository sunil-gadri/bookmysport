import React, { useEffect, useState } from "react";
import {
  Building2,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Edit3,
  RefreshCw,
  User,
} from "lucide-react";
import api from "../../../api/axios";
import { PageHeader } from "../../../components/UI";
import { useNavigate } from "react-router-dom";
import ProfileSkeleton from "../../../components/skeletons/ProfileSkeleton";

const TurfOwnerProfile = () => {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const fetchProfile = async () => {
    try {
      setLoading(true);
      setError("");

      const res = await api.get("/turf-owner/profile");

      if (res.data.status) {
        setProfile(res.data.data);
      } else {
        setError(res.data.message || "Failed to load profile.");
      }
    } catch (err) {
      // Redirect to Complete Profile if profile doesn't exist
      if (
        err.response?.status === 404 ||
        err.response?.data?.message === "Turf owner profile not found."
      ) {
        navigate("/complete-profile", { replace: true });
        return;
      }

      setError(
        err?.response?.data?.message ||
          "Something went wrong while fetching profile.",
      );
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => {
    fetchProfile();
  }, []);

  const formatDate = (dateStr) => {
    if (!dateStr) return "-";
    return new Date(dateStr).toLocaleString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getInitials = (name = "") =>
    name
      .split(" ")
      .map((w) => w[0])
      .join("")
      .slice(0, 2)
      .toUpperCase();

  if (loading) {
    return <ProfileSkeleton />;
  }

  if (error) {
    return (
      <div className="w-full p-2 lg:px-4 lg:py-3">
        <div className="bg-[#14141a] border border-red-500/30 rounded-[10px] p-6 text-center">
          <p className="text-red-400 text-[12px] mb-3">{error}</p>
          <button
            onClick={fetchProfile}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-sm bg-blue-600 text-white text-[11px] font-semibold"
          >
            <RefreshCw size={12} />
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!profile) return null;

  const infoRows = [
    {
      icon: <User size={13} />,
      label: "Owner Name",
      value: profile.full_name,
    },
    {
      icon: <Mail size={13} />,
      label: "Business Email",
      value: profile.business_email,
    },
    {
      icon: <Phone size={13} />,
      label: "Business Phone",
      value: profile.business_phone,
    },
    {
      icon: <MapPin size={13} />,
      label: "Address",
      value: profile.address,
    },
    {
      icon: <MapPin size={13} />,
      label: "Pincode",
      value: profile.pincode,
    },
  ];

  const locationRows = [
    { label: "Country", value: profile.country?.name },
    { label: "State", value: profile.state?.name },
    { label: "City", value: profile.city?.name },
  ];

  return (
    <div className="w-full p-2 lg:px-4 lg:py-3">
      <PageHeader title="Turf Owner Profile" subtitle={profile.business_name}>
        <button
          onClick={() => navigate("/update-profile")}
          className="flex cursor-pointer items-center gap-1.5 px-3 py-2 text-[11px] rounded-sm bg-blue-600 text-white font-semibold"
        >
          <Edit3 size={12} />
          Edit Profile
        </button>
      </PageHeader>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">
        {/* Left: avatar / summary card */}
        <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] p-6 flex flex-col items-center text-center">
          {profile.profile_image ? (
            <img
              src={profile.profile_image}
              alt={profile.business_name}
              className="w-20 h-20 rounded-full object-cover border border-[#1f2333]"
            />
          ) : (
            <div className="w-20 h-20 rounded-full bg-blue-600/15 border border-blue-600/40 flex items-center justify-center text-blue-400 text-lg font-bold">
              {getInitials(profile.full_name)}
            </div>
          )}

          <h2 className="text-white text-sm font-bold mt-4">
            {profile.business_name}
          </h2>

          {profile.full_name && (
            <p className="text-gray-500 text-[10px] mt-1 flex items-center gap-1">
              <User size={10} />
              {profile.full_name}
            </p>
          )}

          <span className="mt-2 px-2 py-1 rounded-[6px] text-[9px] font-semibold bg-green-500/15 text-green-400 flex items-center gap-1">
            <Building2 size={10} />
            Turf Owner
          </span>

          <div className="w-full border-t border-[#1f2333] my-4" />

          <p className="text-[#8b8b93] text-[11px] leading-relaxed">
            {profile.description || "No description added yet."}
          </p>
        </div>

        {/* Right: details */}
        <div className="xl:col-span-2 flex flex-col gap-3">
          {/* Contact info card */}
          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
            <div className="px-6 py-3 border-b border-[#1f2333]">
              <h3 className="text-white text-[12px] font-bold">
                Business Information
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-6">
              {infoRows.map((row, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-7 h-7 rounded-[6px] bg-blue-600/10 border border-blue-600/30 flex items-center justify-center text-blue-400 shrink-0">
                    {row.icon}
                  </div>
                  <div>
                    <p className="text-gray-500 text-[9px] uppercase tracking-wide">
                      {row.label}
                    </p>
                    <p className="text-[#C0C0C0] text-[11px] mt-0.5">
                      {row.value || "-"}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Location card */}
          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
            <div className="px-6 py-3 border-b border-[#1f2333]">
              <h3 className="text-white text-[12px] font-bold">Location</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-6">
              {locationRows.map((row, i) => (
                <div key={i}>
                  <p className="text-gray-500 text-[9px] uppercase tracking-wide">
                    {row.label}
                  </p>
                  <p className="text-white text-[11px] mt-1 font-medium">
                    {row.value || "-"}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Meta card */}
          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
            <div className="px-6 py-3 border-b border-[#1f2333]">
              <h3 className="text-white text-[12px] font-bold">
                Account Timeline
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-6">
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-[6px] bg-[#161926] border border-[#1f2333] flex items-center justify-center text-gray-400 shrink-0">
                  <Calendar size={13} />
                </div>
                <div>
                  <p className="text-gray-500 text-[9px] uppercase tracking-wide">
                    Created At
                  </p>
                  <p className="text-[#C0C0C0] text-[11px] mt-0.5">
                    {formatDate(profile.created_at)}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-[6px] bg-[#161926] border border-[#1f2333] flex items-center justify-center text-gray-400 shrink-0">
                  <Calendar size={13} />
                </div>
                <div>
                  <p className="text-gray-500 text-[9px] uppercase tracking-wide">
                    Last Updated
                  </p>
                  <p className="text-[#C0C0C0] text-[11px] mt-0.5">
                    {formatDate(profile.updated_at)}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TurfOwnerProfile;
