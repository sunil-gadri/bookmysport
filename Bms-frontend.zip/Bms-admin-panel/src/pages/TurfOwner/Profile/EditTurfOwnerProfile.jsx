import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Building2,
  Mail,
  Phone,
  MapPin,
  FileText,
  Camera,
  Save,
  X,
  Loader2,
  User,
} from "lucide-react";
import api from "../../../api/axios";
import { PageHeader } from "../../../components/UI";
import { validateProfile } from "../../../validations/profileValidation";
import {
  formatTitleCase,
  formatAddress,
  formatDescription,
  formatNumber,
} from "../../../helpers/formatters";
import { useAuth } from "../../../context/AuthContext";
import { toast } from "sonner";
import FormSkeleton from "../../../components/skeletons/FormSkeleton";

const EditTurfOwnerProfile = () => {
  const navigate = useNavigate();
  const { updateUser } = useAuth();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState({});

  const [countries, setCountries] = useState([]);
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);

  const [imagePreview, setImagePreview] = useState(null);
  const [imageFile, setImageFile] = useState(null);

  const [form, setForm] = useState({
    name: "",
    business_name: "",
    business_email: "",
    business_phone: "",
    description: "",
    address: "",
    country_id: "",
    state_id: "",
    city_id: "",
    pincode: "",
  });

  // ---------- Step 1: Load current profile to prefill the form ----------
  const fetchProfile = async () => {
    try {
      setLoading(true);
      const res = await api.get("/turf-owner/profile");
      const data = res.data;

      if (data.status) {
        const p = data.data;
        setForm({
          name: p.full_name || "",
          business_name: p.business_name || "",
          business_email: p.business_email || "",
          business_phone: p.business_phone || "",
          description: p.description || "",
          address: p.address || "",
          country_id: p.country?.id || "",
          state_id: p.state?.id || "",
          city_id: p.city?.id || "",
          pincode: p.pincode || "",
        });
        setImagePreview(p.profile_image || null);

        // preload states/cities for the saved country/state so dropdowns aren't empty
        if (p.country?.id) await fetchStates(p.country.id);
        if (p.state?.id) await fetchCities(p.state.id);
      } else {
        setError(data.message || "Failed to load profile.");
      }
    } catch (err) {
      setError(err?.response?.data?.message || "Failed to load profile.");
    } finally {
      setLoading(false);
    }
  };

  // ---------- Step 2: Location dropdown helpers ----------
  const fetchCountries = async () => {
    try {
      const res = await api.get("/masters/countries");
      setCountries(res.data.data || []);
    } catch {
      setCountries([]);
    }
  };

  const fetchStates = async (countryId) => {
    if (!countryId) {
      setStates([]);
      return;
    }

    try {
      const res = await api.get(`/masters/states?country_id=${countryId}`);
      setStates(res.data.data || []);
    } catch {
      setStates([]);
    }
  };

  const fetchCities = async (stateId) => {
    if (!stateId) {
      setCities([]);
      return;
    }

    try {
      const res = await api.get(`/masters/cities?state_id=${stateId}`);
      setCities(res.data.data || []);
    } catch {
      setCities([]);
    }
  };
  useEffect(() => {
    fetchCountries();
    fetchProfile();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---------- Step 3: Form field handlers ----------
  const handleChange = (e) => {
    let { name, value } = e.target;

    switch (name) {
      case "name":
      case "business_name":
        value = formatTitleCase(value);
        break;

      case "address":
        value = formatAddress(value);
        break;

      case "description":
        value = formatDescription(value);
        break;

      case "business_phone":
        value = formatNumber(value, 10);
        break;

      case "pincode":
        value = formatNumber(value, 6);
        break;

      default:
        break;
    }

    const updatedForm = {
      ...form,
      [name]: value,
    };

    setForm(updatedForm);

    if (fieldErrors[name]) {
      const errors = validateProfile(updatedForm, {
        requireName: true,
      });

      setFieldErrors((prev) => ({
        ...prev,
        [name]: errors[name],
      }));
    }
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;

    const updatedForm = {
      ...form,
      [name]: value,
    };

    const errors = validateProfile(updatedForm, {
      requireName: true,
    });

    setFieldErrors((prev) => ({
      ...prev,
      [name]: errors[name],
    }));
  };

  const handleCountryChange = (e) => {
    const countryId = e.target.value;
    setForm((prev) => ({
      ...prev,
      country_id: countryId,
      state_id: "",
      city_id: "",
    }));
    setStates([]);
    setCities([]);
    fetchStates(countryId);
  };

  const handleStateChange = (e) => {
    const stateId = e.target.value;
    setForm((prev) => ({ ...prev, state_id: stateId, city_id: "" }));
    setCities([]);
    fetchCities(stateId);
  };

  const handleImageChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const allowedTypes = ["image/jpeg", "image/jpg", "image/png", "image/webp"];

    // File type validation
    if (!allowedTypes.includes(file.type)) {
      setFieldErrors((prev) => ({
        ...prev,
        profile_image: "Only JPG, JPEG, PNG and WEBP images are allowed.",
      }));
      return;
    }

    // File size validation (2MB)
    const maxSize = 2 * 1024 * 1024;

    if (file.size > maxSize) {
      setFieldErrors((prev) => ({
        ...prev,
        profile_image: "Image size must not exceed 2 MB.",
      }));
      return;
    }

    const img = new Image();

    img.onload = () => {
      const width = img.width;
      const height = img.height;

      // Minimum dimensions
      if (width < 200 || height < 200) {
        setFieldErrors((prev) => ({
          ...prev,
          profile_image: "Image must be at least 200 × 200 pixels.",
        }));
        return;
      }

      // Maximum dimensions
      if (width > 2000 || height > 2000) {
        setFieldErrors((prev) => ({
          ...prev,
          profile_image: "Image must not exceed 2000 × 2000 pixels.",
        }));
        return;
      }

      // Clear previous error
      setFieldErrors((prev) => ({
        ...prev,
        profile_image: "",
      }));

      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
    };

    img.onerror = () => {
      setFieldErrors((prev) => ({
        ...prev,
        profile_image: "Invalid image file.",
      }));
    };

    img.src = URL.createObjectURL(file);
  };
  // ---------- Step 4: Submit update ----------
  const handleSubmit = async (e) => {
    e.preventDefault();

    // requireName: true — /turf-owner/profile/update requires `name`
    // and uses it to update the user's account name.

    const errors = validateProfile(form, { requireName: true });

    setFieldErrors(errors);

    if (Object.values(errors).some((error) => error)) {
      return;
    }

    try {
      setSaving(true);

      const payload = new FormData();
      payload.append("name", form.name);
      payload.append("business_name", form.business_name);
      payload.append("business_email", form.business_email);
      payload.append("business_phone", form.business_phone);
      payload.append("description", form.description);
      payload.append("address", form.address);
      payload.append("country_id", form.country_id);
      payload.append("state_id", form.state_id);
      payload.append("city_id", form.city_id);
      payload.append("pincode", form.pincode);

      if (imageFile) {
        payload.append("profile_image", imageFile);
      }

      const res = await api.post("/turf-owner/profile/update", payload, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      if (res.data.status) {
        updateUser({
          name: res.data.data.full_name,
        });
        toast.success("Profile updated successfully.");
        navigate("/turfowner-profile");
      } else {
        toast.error(res?.message || "Something went wrong.");
      }
    } catch (err) {
      const res = err?.response?.data;
      if (res?.errors) {
        // Laravel-style validation error bag: { field: ["message"] }
        const mapped = {};
        Object.keys(res.errors).forEach((key) => {
          mapped[key] = res.errors[key][0];
        });
        setFieldErrors(mapped);
      }
      setError(res?.message || "Something went wrong while updating profile.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <FormSkeleton />;
  }

  const inputClass =
    "w-full h-9 px-3 rounded-[8px] text-[11px] bg-[#0f0f14] border border-[#1F1F27] text-white outline-none focus:border-blue-600/60";
  const labelClass =
    "text-gray-500 text-[9px] uppercase tracking-wide mb-1.5 flex items-center gap-1.5";
  const errorClass = "text-red-400 text-[9px] mt-1";

  return (
    <div className="w-full p-2 lg:px-4 lg:py-3">
      <PageHeader title="Edit Turf Owner Profile" subtitle={form.business_name}>
        <button
          onClick={() => navigate("/turfowner-profile")}
          className="flex cursor-pointer items-center gap-1.5 px-3 py-2 text-[11px] rounded-sm bg-[#11131d] border border-[#1f2333] text-white"
        >
          <X size={12} />
          Cancel
        </button>
      </PageHeader>

      {error && (
        <div className="mb-4 px-4 py-2.5 rounded-[8px] bg-red-500/10 border border-red-500/30 text-red-400 text-[11px]">
          {error}
        </div>
      )}

      <form
        onSubmit={handleSubmit}
        className="grid grid-cols-1 xl:grid-cols-3 gap-3"
      >
        {/* Left: avatar upload */}
        <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] p-6 flex flex-col items-center text-center">
          <div className="relative">
            {imagePreview ? (
              <img
                src={imagePreview}
                alt="profile"
                className="w-20 h-20 rounded-full object-cover border border-[#1f2333]"
              />
            ) : (
              <div className="w-20 h-20 rounded-full bg-blue-600/15 border border-blue-600/40 flex items-center justify-center text-blue-400 text-lg font-bold">
                {form.name
                    ? form.name
                        .split(" ")
                        .map((word) => word[0])
                        .join("")
                        .slice(0, 2)
                        .toUpperCase()
                    : form.business_name
                        ?.split(" ")
                        .map((word) => word[0])
                        .join("")
                        .slice(0, 2)
                        .toUpperCase()}
              </div>
            )}

            <label className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center cursor-pointer border-2 border-[#14141a]">
              <Camera size={12} className="text-white" />
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
              />
            </label>
          </div>

          {fieldErrors.profile_image && (
            <p className="text-red-400 text-[9px] mt-3 text-center">
              {fieldErrors.profile_image}
            </p>
          )}

          <span className="mt-4 px-2 py-1 rounded-[6px] text-[9px] font-semibold bg-green-500/15 text-green-400 flex items-center gap-1">
            <Building2 size={10} />
            Turf Owner
          </span>

          <div className="w-full border-t border-[#1f2333] my-4" />

          <div className="w-full text-left">
            <label className={labelClass}>
              <FileText size={11} /> Description
            </label>
            <textarea
              name="description"
              value={form.description}
              onChange={handleChange}
              onBlur={handleBlur}
              rows={5}
              className="w-full px-3 py-2 rounded-[8px] text-[11px] bg-[#0f0f14] border border-[#1F1F27] text-white outline-none focus:border-blue-600/60 resize-none"
              placeholder="Tell customers about your business..."
            />
          </div>
        </div>

        {/* Right: form fields */}
        <div className="xl:col-span-2 flex flex-col gap-3">
          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
            <div className="px-6 py-3 border-b border-[#1f2333]">
              <h3 className="text-white text-[12px] font-bold">
                Business Information
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-6">
              <div>
                <label className={labelClass}>
                  <User size={11} /> Full Name
                </label>
                <input
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className={inputClass}
                  placeholder="Full Name"
                />
                {fieldErrors.name && (
                  <p className={errorClass}>{fieldErrors.name}</p>
                )}
              </div>

              <div>
                <label className={labelClass}>
                  <Building2 size={11} /> Business Name
                </label>
                <input
                  name="business_name"
                  value={form.business_name}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className={inputClass}
                  placeholder="Enter your business name"
                />
                {fieldErrors.business_name && (
                  <p className={errorClass}>{fieldErrors.business_name}</p>
                )}
              </div>

              <div>
                <label className={labelClass}>
                  <Mail size={11} /> Business Email
                </label>
                <input
                  type="email"
                  name="business_email"
                  value={form.business_email}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className={inputClass}
                  placeholder="Enter your business email"
                />
                {fieldErrors.business_email && (
                  <p className={errorClass}>{fieldErrors.business_email}</p>
                )}
              </div>

              <div>
                <label className={labelClass}>
                  <Phone size={11} /> Mobile Number
                </label>

                <input
                  name="business_phone"
                  value={form.business_phone}
                  disabled
                  className={`${inputClass} bg-[#11131d] text-gray-400 cursor-not-allowed`}
                />
              </div>
              <div>
                <label className={labelClass}>
                  <MapPin size={11} /> Pincode
                </label>
                <input
                  name="pincode"
                  value={form.pincode}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className={inputClass}
                  placeholder=""
                />
                {fieldErrors.pincode && (
                  <p className={errorClass}>{fieldErrors.pincode}</p>
                )}
              </div>

              <div className="md:col-span-2">
                <label className={labelClass}>
                  <MapPin size={11} /> Address
                </label>
                <input
                  name="address"
                  value={form.address}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className={inputClass}
                  placeholder="Mansarovar, Jaipur"
                />
                {fieldErrors.address && (
                  <p className={errorClass}>{fieldErrors.address}</p>
                )}
              </div>
            </div>
          </div>

          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
            <div className="px-6 py-3 border-b border-[#1f2333]">
              <h3 className="text-white text-[12px] font-bold">Location</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-6">
              <div>
                <label className={labelClass}>Country</label>
                <select
                  name="country_id"
                  value={form.country_id}
                  onChange={handleCountryChange}
                  onBlur={handleBlur}
                  className={inputClass}
                >
                  <option value="">Select country</option>
                  {countries.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
                {fieldErrors.country_id && (
                  <p className={errorClass}>{fieldErrors.country_id}</p>
                )}
              </div>

              <div>
                <label className={labelClass}>State</label>
                <select
                  name="state_id"
                  value={form.state_id}
                  onChange={handleStateChange}
                  onBlur={handleBlur}
                  className={inputClass}
                  disabled={!form.country_id}
                >
                  <option value="">Select state</option>
                  {states.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
                {fieldErrors.state_id && (
                  <p className={errorClass}>{fieldErrors.state_id}</p>
                )}
              </div>

              <div>
                <label className={labelClass}>City</label>
                <select
                  name="city_id"
                  value={form.city_id}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className={inputClass}
                  disabled={!form.state_id}
                >
                  <option value="">Select city</option>
                  {cities.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
                {fieldErrors.city_id && (
                  <p className={errorClass}>{fieldErrors.city_id}</p>
                )}
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => navigate("/turfowner-profile")}
              className="px-4 cursor-pointer py-2 text-[11px] rounded-sm bg-[#11131d] border border-[#1f2333] text-white"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={saving}
              className="flex cursor-pointer items-center gap-1.5 px-4 py-2 text-[11px] rounded-sm bg-blue-600 text-white font-semibold disabled:opacity-60"
            >
              {saving ? (
                <>
                  <Loader2 size={12} className="animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save size={12} />
                  Save Changes
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default EditTurfOwnerProfile;
