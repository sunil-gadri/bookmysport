import React from "react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  StatCard,
  CardBox,
  BarChart,
  DonutChart,
  ActionBtn,
  PageHeader,
  Badge,
  Avatar,
} from "../../components/UI.jsx";
import {
  BOOKINGS,
  ACTIVITIES,
  REVENUE_CHART,
} from "../../components/mockData.js";
import { Search } from "lucide-react";
import { useEffect } from "react";
import api from "../../api/axios.js";
import {
  formatFullName,
  getInitials,
  getAvatarColor,
} from "../../helpers/formatters.js";
import UserListSkeleton from "../../components/skeletons/UserListSkeleton.jsx";
import UserTableSkeleton from "../../components/skeletons/UserTableSkeleton";
import { Eye } from "lucide-react";
import UserDetailsModal from "./UserDetailsModal.jsx";

const UserList = () => {
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [lastPage, setLastPage] = useState(1);
  const [perPage, setPerPage] = useState(3);
  const [totalUsers, setTotalUsers] = useState(0);
  const [period, setPeriod] = useState("This Month");
  const [searchText, setSearchText] = useState("");
  const [search, setSearch] = useState("");
  const [tableLoading, setTableLoading] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [status, setStatus] = useState("");
  const [activeUsers, setActiveUsers] = useState(0);
  const [inactiveUsers, setInactiveUsers] = useState(0);
  const [viewLoading, setViewLoading] = useState(false);

  // list users api

  const fetchUsers = async (page = 1) => {
    try {
      if (loading) {
        setLoading(true);
      } else {
        setTableLoading(true);
      }

      const response = await api.get("/admin/users", {
        params: {
          page,
          search,
          status,
        },
      });

      const res = response.data;

      console.log(res, "response");

      setUsers(res.data);

      setCurrentPage(res.pagination.current_page);
      setLastPage(res.pagination.last_page);
      setPerPage(res.pagination.per_page);
      setTotalUsers(res.counts.total_users);
      setActiveUsers(res.counts.active_users);
      setInactiveUsers(res.counts.inactive_users);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
      setTableLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers(currentPage);
  }, [currentPage, search, status]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchText.length >= 3 || searchText.length === 0) {
        setSearch(searchText);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [searchText]);

  //user details modal api

  const handleViewUser = async (userId, index) => {
    try {
      setViewLoading(true);

      const response = await api.get(`/admin/users/${userId}`);

      setSelectedUser(response.data.data);
      setSelectedIndex(index);
    } catch (error) {
      console.log(error);
    } finally {
      setViewLoading(false);
    }
  };

  const quickStats = [
    {
      icon: "ti-users",
      value: totalUsers,
      label: "Total Users",
      change: "+124 This week",
      up: true,
      iconBg: "rgba(41,121,255,.15)",
      iconColor: "#2979FF",
    },
    {
      icon: "ti-user-check",
      value: activeUsers,
      label: "Active Users",
      iconBg: "rgba(0,230,118,.12)",
      iconColor: "#00E676",
    },

    {
      icon: "ti-user-x",
      value: inactiveUsers,
      label: "Inactive Users",
      iconBg: "rgba(255,82,82,.12)",
      iconColor: "#FF5252",
    },
    // {
    //   icon: "ti-calendar-check",
    //   value: "847",
    //   label: "Total Bookings",
    //   change: "+38 Today",
    //   up: true,
    //   iconBg: "rgba(0,230,118,.12)",
    //   iconColor: "#00E676",
    // },
    // {
    //   icon: "ti-currency-rupee",
    //   value: "₹4.2L",
    //   label: "Revenue (Jun)",
    //   change: "+18% vs May",
    //   up: true,
    //   iconBg: "rgba(255,179,0,.12)",
    //   iconColor: "#FFB300",
    // },
    // {
    //   icon: "ti-map-pin",
    //   value: "36",
    //   label: "Active Turfs",
    //   change: "2 Pending Review",
    //   iconBg: "rgba(255,82,82,.12)",
    //   iconColor: "#FF5252",
    // },
  ];

  const sportSegments = [
    { pct: 40, color: "#2979FF" },
    { pct: 24, color: "#00E676" },
    { pct: 12, color: "#FFB300" },
    { pct: 24, color: "#FF5252" },
  ];

  const sportLegend = [
    { c: "#2979FF", l: "Football", p: "40%" },
    { c: "#00E676", l: "Cricket", p: "24%" },
    { c: "#FFB300", l: "Badminton", p: "12%" },
    { c: "#FF5252", l: "Others", p: "24%" },
  ];

  const kpiRow = [
    { label: "Avg Booking Value", value: "₹685", sub: "Per transaction" },
    { label: "Cancellation Rate", value: "5.8%", sub: "This month" },
    { label: "Wallet Balance", value: "₹82.4k", sub: "All users" },
    { label: "Peak Hour", value: "6–9 PM", sub: "Most bookings" },
  ];

  if (loading) {
    return <UserListSkeleton />;
  }

  const filters = [
    "All",
    "Active",
    "Inactive",
    // "Premium",
    // "New (7d)",
    // "Turf Owners",
  ];

  return (
    <>
      <div className="w-full p-2 lg:px-4 lg:py-3 animate-fade-in">
        <PageHeader
          title="User Management"
          subtitle={`${totalUsers} Total Users · 124 new this week`}
        >
          <button className="px-3 text-[11px] py-2 rounded-sm bg-[#11131d] border border-[#1f2333] text-white">
            Export CSV
          </button>

          {/* <button className="px-3 py-2 text-[11px]  rounded-sm bg-blue-600 text-white font-semibold">
            Add User
          </button> */}
        </PageHeader>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-2 mb-4">
          {quickStats.map((s, i) => (
            <StatCard key={i} {...s} />
          ))}
        </div>

        {/* Search + Filters */}
        <div className="flex flex-col xl:flex-row gap-3 mb-4">
          <div className="relative flex-1">
            <Search
              size={14}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6b7280]"
            />

            <input
              type="text"
              value={searchText}
              onChange={(e) => {
                setSearchText(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search by name, phone, email..."
              className="w-full h-8 pl-9 pr-3 rounded-[8px] text-[11px] bg-[#14141A] border border-[#1F1F27] text-[#a0a0a0] outline-none"
            />
          </div>

          <div className="flex flex-wrap gap-2 mt-1">
            {filters.map((item, i) => (
              <button
                key={item}
                onClick={() => {
                  setCurrentPage(1);

                  if (item === "All") {
                    setStatus("");
                  } else if (item === "Active") {
                    setStatus(1);
                  } else if (item === "Inactive") {
                    setStatus(0);
                  }
                }}
                className={`h-6 px-3 rounded-sm text-[10px] border cursor-pointer
                    ${
                      (item === "All" && status === "") ||
                      (item === "Active" && status === 1) ||
                      (item === "Inactive" && status === 0)
                        ? "bg-blue-600/10 border-blue-600 text-blue-400"
                        : "bg-[#11131d] border-[#1f2333] text-[#a0a0a0]"
                    }`}
              >
                {item}
              </button>
            ))}
          </div>
        </div>

        <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
          <div className="flex justify-between items-center px-6 py-2 border-b border-[#1f2333]">
            <h2 className="text-sm font-bold text-white">All Users</h2>
            <span className="text-gray-400 text-[10px]">
              Showing {totalUsers === 0 ? 0 : (currentPage - 1) * perPage + 1}-
              {Math.min(currentPage * perPage, totalUsers)}
              of {totalUsers}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full min-w-[1000px]">
              <thead>
                <tr className="border-b border-[#1f2333] text-gray-500 text-[8px]">
                  <th className="text-left px-4 py-2">Sr No</th>
                  <th className="text-left px-4 py-2">USER</th>
                  <th className="text-left">PHONE</th>
                  {/* <th className="text-left">ROLE</th> */}
                  <th className="text-left">Gender</th>
                  <th className="text-left">Country</th>
                  <th className="text-left">State</th>
                  <th className="text-left">City</th>
                  <th className="text-left">Status</th>
                  <th className="text-left">Created At</th>
                  <th className="text-left pr-4">Action</th>
                </tr>
              </thead>

              <tbody>
                {tableLoading ? (
                  <UserTableSkeleton rows={8} />
                ) : users.length === 0 ? (
                  <tr>
                    <td
                      colSpan={10}
                      className="py-10 text-center text-gray-400"
                    >
                      No data found
                    </td>
                  </tr>
                ) : (
                  users.map((user, index) => {
                    const avatarColor = getAvatarColor(index);

                    return (
                      <tr
                        key={user.id}
                        className="border-b border-[#1f2333] hover:bg-[#161926] whitespace-nowrap"
                      >
                        <td className="text-[#C0C0C0] text-[11px] pl-8">
                          {(currentPage - 1) * perPage + index + 1}
                        </td>

                        <td className="px-4 py-2">
                          <div className="flex items-center gap-2">
                            <div
                              className={`w-7 h-7 rounded-full overflow-hidden flex items-center justify-center text-[9px] font-bold ${!user.profile_image ? `${avatarColor.bg} ${avatarColor.text}` : ""}`}
                            >
                              {user.profile_image ? (
                                <img
                                  src={user.profile_image}
                                  alt={user.full_name}
                                  className="w-full h-full object-cover"
                                  onError={(e) => {
                                    e.target.style.display = "none";
                                    e.target.nextSibling.style.display = "flex";
                                  }}
                                />
                              ) : null}

                              <span
                                className={`w-full h-full items-center justify-center ${
                                  user.profile_image ? "hidden" : "flex"
                                }`}
                              >
                                {getInitials(user.full_name)}
                              </span>
                            </div>
                            <div>
                              <p className="text-white font-medium text-[10px]">
                                {user.full_name
                                  ? formatFullName(user.full_name)
                                  : "-"}
                              </p>

                              <p className="text-[9px] text-gray-500">
                                {user.email || "-"}
                              </p>
                            </div>
                          </div>
                        </td>

                        <td className="text-[#C0C0C0] text-[11px]">
                          {user.mobile}
                        </td>
                        <td className="text-[#C0C0C0] text-[11px]">
                          {user.gender}
                        </td>
                        <td className="text-[#C0C0C0] text-[11px]">
                          {user.country.name}
                        </td>
                        <td className="text-[#C0C0C0] text-[11px]">
                          {user.state.name}
                        </td>
                        <td className="text-[#C0C0C0] text-[11px]">
                          {user.city.name}
                        </td>

                        {/* <td>
                        <span
                          className={`px-2 py-1 rounded-[6px] text-[9px] font-semibold ${
                            user.role === "Owner"
                              ? "bg-yellow-500/15 text-yellow-400"
                              : "bg-blue-500/15 text-[#2979FF]"
                          }`}
                        >
                          {user.role}
                        </span>
                      </td> */}

                        {/* <td className="font-semibold text-white">{user.bookings}</td> */}
                        {/* <td className="font-semibold text-green-400">{user.spent}</td> */}

                        <td>
                          <span
                            className={`px-2 py-1 rounded-[6px] text-[9px] font-semibold ${
                              user.status.label === "Active"
                                ? "bg-green-500/15 text-green-400"
                                : user.status.label === "Inactive"
                                  ? "bg-yellow-500/15 text-yellow-400"
                                  : "bg-red-500/15 text-red-400"
                            }`}
                          >
                            {user.status.label}
                          </span>
                        </td>

                        <td className="text-[#C0C0C0]">{user.created_at}</td>
                        <td className="pr-4">
                          <button
                            onClick={() => handleViewUser(user.id, index)}
                            className="flex items-center gap-1 px-2.5 py-1.5 rounded-[6px] text-[9px] font-semibold bg-blue-600/10 border border-blue-600/40 text-blue-400 hover:bg-blue-600/20 transition-colors cursor-pointer"
                          >
                            <Eye size={11} />
                            View
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          <div className="flex justify-between items-center px-4 py-2">
            <span className="text-gray-400 text-[10px]">
              Page {currentPage} of {lastPage}
            </span>

            <div className="flex gap-2">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(currentPage - 1)}
                className="w-7 h-7 cursor-pointer rounded-[7px] bg-[#161926] text-[12px] disabled:opacity-40"
              >
                ←
              </button>

              <button className="w-7 h-7 rounded-[7px] text-[12px] bg-blue-600 text-white">
                {currentPage}
              </button>
              <button
                disabled={currentPage === lastPage}
                onClick={() => setCurrentPage(currentPage + 1)}
                className="w-7 h-7 cursor-pointer rounded-[7px] bg-[#161926] text-[12px] disabled:opacity-40"
              >
                →
              </button>
            </div>
          </div>
        </div>
      </div>

      {selectedUser && (
        <UserDetailsModal
          user={selectedUser}
          loading={viewLoading}
          index={selectedIndex}
          onClose={() => setSelectedUser(null)}
          onStatusUpdated={(userId, newStatus) => {
            setUsers((prev) =>
              prev.map((u) =>
                u.id === userId
                  ? {
                      ...u,
                      status: {
                        ...u.status,
                        label:
                          newStatus.charAt(0).toUpperCase() +
                          newStatus.slice(1),
                      },
                    }
                  : u,
              ),
            );
          }}
        />
      )}
    </>
  );
};

export default UserList;
