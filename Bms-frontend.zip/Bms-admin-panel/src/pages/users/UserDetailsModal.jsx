import React, { useState } from "react";
import {
  X,
  Phone,
  Mail,
  MapPin,
  Calendar,
  User as UserIcon,
} from "lucide-react";
import {
  formatFullName,
  getInitials,
  getAvatarColor,
} from "../../helpers/formatters.js";
import api from "../../api/axios.js";
import StatusDropdown from "../../components/StatusDropdown.jsx";

const InfoRow = ({ icon: Icon, label, value }) => (
  <div className="flex items-start gap-3 py-2.5 border-b border-[#1f2333] last:border-b-0">
    <div className="w-7 h-7 rounded-[7px] bg-[#11131d] border border-[#1f2333] flex items-center justify-center shrink-0 mt-0.5">
      <Icon size={13} className="text-[#6b7280]" />
    </div>
    <div className="flex-1 min-w-0">
      <p className="text-[9px] uppercase tracking-wide text-gray-500 mb-0.5">
        {label}
      </p>
      <p className="text-[12px] text-[#e5e5e5] font-medium truncate">
        {value || "-"}
      </p>
    </div>
  </div>
);

const UserDetailsModal = ({
  user,
  loading,
  index = 0,
  onClose,
  onStatusUpdated,
}) => {
  if (!user) return null;

  if (loading) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
        <div className="text-white text-sm">Loading...</div>
      </div>
    );
  }

  const avatarColor = getAvatarColor(index);

  const handleStatusChange = async (status) => {
    const response = await api.patch(`/admin/users/${user.id}/status`, {
      status,
    });

    onStatusUpdated?.(user.id, response.data.data.status.label);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-[#14141a] border border-[#1F1F27] rounded-[12px] shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[#1f2333]">
          {" "}
          <h2 className="text-sm font-bold text-white">User Details</h2>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-[7px] flex items-center justify-center text-gray-500 hover:text-white hover:bg-[#1f2333] transition-colors cursor-pointer"
          >
            <X size={15} />
          </button>
        </div>

        <div className="flex-1 h-[350px] overflow-y-auto scrollbar-thin scrollbar-thumb-[#2a2d3a] scrollbar-track-transparent">
          {/* Profile summary */}
          <div className="flex items-center gap-3 px-5 py-4 border-b border-[#1f2333]">
            <div
              className={`w-12 h-12 rounded-full overflow-hidden flex items-center justify-center text-[13px] font-bold ${
                !user.profile_image
                  ? `${avatarColor.bg} ${avatarColor.text}`
                  : ""
              }`}
            >
              {user.profile_image ? (
                <img
                  src={user.profile_image}
                  alt={user.full_name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.target.style.display = "none";
                    e.target.nextSibling.style.display = "flex";
                  }}
                />
              ) : null}

              <span
                className={`w-full h-full items-center justify-center ${
                  user.profile_image ? "hidden" : "flex"
                }`}
              >
                {getInitials(user.full_name)}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white font-semibold text-[13px] truncate">
                {user.full_name ? formatFullName(user.full_name) : "-"}
              </p>
              <p className="text-[10px] text-gray-500 truncate">
                {user.email || "-"}
              </p>
            </div>

            <StatusDropdown
              currentLabel={user.status?.label}
              onChange={handleStatusChange}
            />
          </div>

          {/* Details */}
          <div className="px-5 py-1">
            <InfoRow icon={Phone} label="Phone" value={user.mobile} />
            <InfoRow icon={UserIcon} label="Gender" value={user.gender} />
            <InfoRow
              icon={MapPin}
              label="Address"
              value={user.address || "-"}
            />

            <InfoRow
              icon={MapPin}
              label="City"
              value={user.city?.name || "-"}
            />

            <InfoRow
              icon={MapPin}
              label="State"
              value={user.state?.name || "-"}
            />

            <InfoRow
              icon={MapPin}
              label="Country"
              value={user.country?.name || "-"}
            />
            <InfoRow
              icon={Calendar}
              label="Created At"
              value={user.created_at}
            />
          </div>
        </div>
        {/* Footer */}
        <div className="flex justify-end gap-2 px-5 py-3 border-t border-[#1f2333]">
          {" "}
          <button
            onClick={onClose}
            className="px-3 py-2 text-[11px] rounded-sm bg-[#11131d] border border-[#1f2333] text-white cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default UserDetailsModal;
