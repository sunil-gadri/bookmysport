import React, { useEffect, useState, useCallback } from "react";
import { Trash2 } from "lucide-react";
import {
  StatCard,
  PageHeader,
  SearchBar,
  FilterChip,
  Pagination,
  EmptyState,
  Modal,
} from "../../components/UI.jsx";
import api from "../../api/axios.js";
import ListPageSkeleton from "../../components/skeletons/ListPageSkeleton.jsx";
import { toast } from "sonner";

// ── Status badge ──
const StatusBadge = ({ status, approvalStatus }) => {
  if (approvalStatus === "pending") {
    return (
      <span className="px-2 py-0.5 rounded-[5px] text-[10px] font-bold bg-amber/10 text-amber">
        Pending Review
      </span>
    );
  }
  if (approvalStatus === "rejected") {
    return (
      <span className="px-2 py-0.5 rounded-[5px] text-[10px] font-bold bg-red/10 text-red">
        Rejected
      </span>
    );
  }
  if (approvalStatus === "draft") {
    return (
      <span className="px-2 py-0.5 rounded-[5px] text-[10px] font-bold bg-bg-input text-t3">
        Draft
      </span>
    );
  }
  return status ? (
    <span className="px-2 py-0.5 rounded-[5px] text-[10px] font-bold bg-green/10 text-green">
      Active
    </span>
  ) : (
    <span className="px-2 py-0.5 rounded-[5px] text-[10px] font-bold bg-bg-input text-t3">
      Inactive
    </span>
  );
};

// ── Turf card ──
const TurfCard = ({
  turf,
  onView,
  onApprove,
  onReject,
  onToggleStatus,
  onDelete,
  actionLoading,
}) => {
  const cityLine = [turf.city?.name, turf.state?.name]
    .filter(Boolean)
    .join(", ");
  const rating = parseFloat(turf.average_rating || "0");
  const hasReviews = (turf.total_reviews || 0) > 0;
  const isPending = turf.approval_status === "pending";
  const isBusy = actionLoading === turf.id;

  return (
    <div className="bg-bg-card border border-border rounded-lg overflow-hidden flex flex-col">
      {/* Cover */}
      <div className="relative h-36 bg-bg-input">
        {turf.cover_image ? (
          <img
            src={turf.cover_image}
            alt={turf.name}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-t4 text-2xl font-bold">
            {turf.sports?.[0]?.name?.[0] || "?"}
          </div>
        )}
        <div className="absolute top-2 right-2">
          <StatusBadge
            status={turf.status}
            approvalStatus={turf.approval_status}
          />
        </div>
      </div>

      {/* Body */}
      <div className="p-4 flex flex-col gap-3 flex-1">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-poppins text-t1 text-[12.5px] font-bold leading-snug">
            {turf.name}
          </h3>
          <div className="flex items-center gap-1 shrink-0 text-[11px] text-t2">
            <i className="ti ti-star-filled text-[11px] text-amber" />
            <span>{hasReviews ? rating.toFixed(1) : "New"}</span>
            {hasReviews && (
              <span className="text-t4">({turf.total_reviews})</span>
            )}
          </div>
        </div>

        <p className="text-t3 text-[10px] flex items-center gap-1">
          <i className="ti ti-map-pin text-[11px] shrink-0" />
          <span className="truncate">{cityLine || turf.address || "-"}</span>
        </p>

        <p className="text-t3 text-[10px] flex items-center gap-1">
          <i className="ti ti-user text-[11px] shrink-0" />
          <span className="truncate">
            {turf.owner?.name || "-"}
            {turf.owner?.mobile ? ` · ${turf.owner.mobile}` : ""}
          </span>
        </p>

        {turf.sports?.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {turf.sports.map((sport) => (
              <span
                key={sport.id}
                className="px-2 py-0.5 rounded-full text-[9px] bg-accent/10 text-accent border border-accent/30"
              >
                {sport.name}
              </span>
            ))}
          </div>
        )}

        <div className="grid grid-cols-3 gap-2 py-3 border-t border-b border-border">
          <div className="flex flex-col gap-1">
            <span className="text-t4 text-[9px] uppercase tracking-wide flex items-center gap-1">
              <i className="ti ti-clock text-[11px]" /> Hours
            </span>
            <span className="text-t2 text-[10px] font-medium">
              {turf.opening_time || "-"}–{turf.closing_time || "-"}
            </span>
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-t4 text-[9px] uppercase tracking-wide flex items-center gap-1">
              <i className="ti ti-layout-grid text-[11px]" /> Ground
            </span>
            <span className="text-t2 text-[10px] font-medium capitalize">
              {turf.ground_type || "-"}
            </span>
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-t4 text-[9px] uppercase tracking-wide flex items-center gap-1">
              <i className="ti ti-shield-check text-[11px]" /> Amenities
            </span>
            <span className="text-t2 text-[10px] font-medium">
              {turf.amenities?.length ?? 0}
            </span>
          </div>
        </div>

        {turf.approval_status === "rejected" && turf.rejection_reason && (
          <p className="text-[10px] text-red bg-red/5 border border-red/20 rounded-md px-2.5 py-1.5 leading-snug">
            <span className="font-semibold">Reason:</span>{" "}
            {turf.rejection_reason}
          </p>
        )}

        {/* Actions */}
        <div className="flex flex-wrap gap-2 mt-auto">
          <button
            type="button"
            onClick={() => onView(turf)}
            className="btn btn-outline btn-sm flex-1 justify-center min-w-[70px]"
          >
            <i className="ti ti-eye" />
            View
          </button>

          {isPending && (
            <>
              <button
                type="button"
                disabled={isBusy}
                onClick={() => onApprove(turf)}
                className="btn btn-success btn-sm flex-1 justify-center disabled:opacity-50 min-w-[70px]"
              >
                {isBusy ? (
                  <i className="ti ti-loader animate-spin" />
                ) : (
                  <i className="ti ti-check" />
                )}
                Approve
              </button>
              <button
                type="button"
                disabled={isBusy}
                onClick={() => onReject(turf)}
                className="btn btn-danger btn-sm flex-1 justify-center disabled:opacity-50 min-w-[70px]"
              >
                <i className="ti ti-x" />
                Reject
              </button>
            </>
          )}

          {turf.approval_status === "approved" && (
            <button
              type="button"
              disabled={isBusy}
              onClick={() => onToggleStatus(turf)}
              className={`btn btn-sm flex-1 justify-center disabled:opacity-50 min-w-[90px] ${
                turf.status ? "btn-danger" : "btn-success"
              }`}
            >
              <i
                className={`ti ${
                  turf.status ? "ti-player-pause" : "ti-player-play"
                }`}
              />
              {turf.status ? "Deactivate" : "Activate"}
            </button>
          )}

          <button
            type="button"
            disabled={isBusy}
            onClick={() => onDelete(turf)}
            className="btn btn-outline btn-sm justify-center disabled:opacity-50 text-red border-red/40 hover:bg-red/10 px-2.5"
            title="Delete turf"
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>
    </div>
  );
};

const TurfList = () => {
  const [turfs, setTurfs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [gridLoading, setGridLoading] = useState(false);

  const [currentPage, setCurrentPage] = useState(1);
  const [lastPage, setLastPage] = useState(1);
  const [totalTurfs, setTotalTurfs] = useState(0);

  const [searchText, setSearchText] = useState("");
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");

  const [counts, setCounts] = useState({
    total: 0,
    approved: 0,
    pending: 0,
    rejected: 0,
  });

  const [actionLoading, setActionLoading] = useState(null);
  const [rejectTurf, setRejectTurf] = useState(null);
  const [rejectReason, setRejectReason] = useState("");
  const [viewTurf, setViewTurf] = useState(null);
  const [deleteTurf, setDeleteTurf] = useState(null);

  // ── List ──
  const fetchTurfs = useCallback(
    async (page = 1) => {
      try {
        setGridLoading(true);

        const params = { page, per_page: 12 };
        if (search) params.search = search;
        if (status) params.approval_status = status;

        const response = await api.get("/admin/turfs", { params });
        const res = response.data;

        const items = Array.isArray(res.data) ? res.data : [];
        const pagination = res.pagination || {};

        setTurfs(items);
        setCurrentPage(pagination.current_page ?? page);
        setLastPage(pagination.last_page ?? 1);
        setTotalTurfs(pagination.total ?? items.length);
      } catch (error) {
        console.error(error);
        toast.error(error?.response?.data?.message || "Failed to load turfs.");
        setTurfs([]);
      } finally {
        setLoading(false);
        setGridLoading(false);
      }
    },
    [search, status]
  );

  // ── Counts ──
  const fetchCounts = useCallback(async () => {
    try {
      const base = { page: 1, per_page: 1 };
      const [allRes, approvedRes, pendingRes, rejectedRes] = await Promise.all([
        api.get("/admin/turfs", { params: base }),
        api.get("/admin/turfs", {
          params: { ...base, approval_status: "approved" },
        }),
        api.get("/admin/turfs", {
          params: { ...base, approval_status: "pending" },
        }),
        api.get("/admin/turfs", {
          params: { ...base, approval_status: "rejected" },
        }),
      ]);

      const getTotal = (r) => r?.data?.pagination?.total ?? 0;

      setCounts({
        total: getTotal(allRes),
        approved: getTotal(approvedRes),
        pending: getTotal(pendingRes),
        rejected: getTotal(rejectedRes),
      });
    } catch (error) {
      console.error(error);
    }
  }, []);

  useEffect(() => {
    fetchTurfs(currentPage);
  }, [currentPage, fetchTurfs]);

  useEffect(() => {
    fetchCounts();
  }, [fetchCounts]);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchText.length >= 3 || searchText.length === 0) {
        setSearch(searchText);
        setCurrentPage(1);
      }
    }, 400);
    return () => clearTimeout(timer);
  }, [searchText]);

  // ── View ──
  const handleView = (turf) => setViewTurf(turf);

  // ── Approve ──
  const handleApprove = async (turf) => {
    try {
      setActionLoading(turf.id);
      const res = await api.post(`/admin/turfs/${turf.id}/approve`);
      const updated = res.data?.data;

      setTurfs((prev) =>
        prev.map((t) =>
          t.id === turf.id
            ? {
                ...t,
                ...(updated || {}),
                approval_status: "approved",
                status: true,
                rejection_reason: null,
              }
            : t
        )
      );

      if (status === "pending") {
        setTurfs((prev) => prev.filter((t) => t.id !== turf.id));
      }

      toast.success(res.data?.message || `"${turf.name}" approved.`);
      fetchCounts();
    } catch (error) {
      toast.error(error?.response?.data?.message || "Failed to approve turf.");
    } finally {
      setActionLoading(null);
    }
  };

  // ── Reject ──
  const confirmReject = async () => {
    if (!rejectTurf) return;
    const reason = rejectReason.trim();
    if (!reason) {
      toast.error("Please enter a rejection reason.");
      return;
    }

    try {
      setActionLoading(rejectTurf.id);
      const res = await api.post(`/admin/turfs/${rejectTurf.id}/reject`, {
        reason,
      });
      const updated = res.data?.data;

      setTurfs((prev) =>
        prev.map((t) =>
          t.id === rejectTurf.id
            ? {
                ...t,
                ...(updated || {}),
                approval_status: "rejected",
                rejection_reason: reason,
              }
            : t
        )
      );

      if (status === "pending") {
        setTurfs((prev) => prev.filter((t) => t.id !== rejectTurf.id));
      }

      toast.success(res.data?.message || `"${rejectTurf.name}" rejected.`);
      setRejectTurf(null);
      setRejectReason("");
      fetchCounts();
    } catch (error) {
      toast.error(error?.response?.data?.message || "Failed to reject turf.");
    } finally {
      setActionLoading(null);
    }
  };

  // ── Toggle active/inactive ──
  const handleToggleStatus = async (turf) => {
    const nextStatus = !turf.status;
    try {
      setActionLoading(turf.id);
      await api.patch(`/admin/turfs/${turf.id}/status`, {
        status: nextStatus,
      });
      setTurfs((prev) =>
        prev.map((t) => (t.id === turf.id ? { ...t, status: nextStatus } : t))
      );
      toast.success(nextStatus ? "Turf activated." : "Turf deactivated.");
    } catch (error) {
      toast.error(
        error?.response?.data?.message || "Failed to update status."
      );
    } finally {
      setActionLoading(null);
    }
  };

  // ── Delete ──
  const confirmDelete = async () => {
    if (!deleteTurf) return;
    try {
      setActionLoading(deleteTurf.id);
      const res = await api.delete(`/admin/turfs/${deleteTurf.id}`);
      setTurfs((prev) => prev.filter((t) => t.id !== deleteTurf.id));
      toast.success(res.data?.message || `"${deleteTurf.name}" deleted.`);
      setDeleteTurf(null);
      fetchCounts();
      if (turfs.length <= 1 && currentPage > 1) {
        setCurrentPage((p) => p - 1);
      } else {
        fetchTurfs(currentPage);
      }
    } catch (error) {
      toast.error(error?.response?.data?.message || "Failed to delete turf.");
    } finally {
      setActionLoading(null);
    }
  };

  const filters = [
    { label: "All", value: "" },
    { label: "Pending Review", value: "pending" },
    { label: "Approved", value: "approved" },
    { label: "Rejected", value: "rejected" },
  ];

  const quickStats = [
    {
      icon: "ti-map-pin",
      value: counts.total,
      label: "Total Turfs",
      iconBg: "rgba(41,121,255,.15)",
      iconColor: "#2979FF",
    },
    {
      icon: "ti-circle-check",
      value: counts.approved,
      label: "Approved",
      iconBg: "rgba(0,230,118,.12)",
      iconColor: "#00E676",
    },
    {
      icon: "ti-clock",
      value: counts.pending,
      label: "Pending Review",
      iconBg: "rgba(255,179,0,.12)",
      iconColor: "#FFB300",
    },
    {
      icon: "ti-x",
      value: counts.rejected,
      label: "Rejected",
      iconBg: "rgba(255,82,82,.12)",
      iconColor: "#FF5252",
    },
  ];

  if (loading) {
    return <ListPageSkeleton statsCount={4} tableRows={0} tableColumns={0} />;
  }

  return (
    <div className="w-full p-2 lg:px-4 lg:py-3 animate-fade-in">
      <PageHeader
        title="Turf Management"
        subtitle={`${totalTurfs} Total Turfs · ${counts.pending} awaiting review`}
      />

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-2 mb-4">
        {quickStats.map((s, i) => (
          <StatCard key={i} {...s} />
        ))}
      </div>

      {/* Search + Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 mb-4">
        <SearchBar
          placeholder="Search by turf name, location or owner..."
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
        />
        <div className="flex items-center gap-2 overflow-x-auto">
          {filters.map((item) => (
            <FilterChip
              key={item.label}
              label={item.label}
              active={status === item.value}
              onClick={() => {
                setStatus(item.value);
                setCurrentPage(1);
              }}
            />
          ))}
        </div>
      </div>

      {/* Grid */}
      {gridLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="h-[330px] rounded-lg bg-bg-card border border-border animate-pulse"
            />
          ))}
        </div>
      ) : turfs.length === 0 ? (
        <div className="bg-bg-card border border-border rounded-lg">
          <EmptyState
            icon="ti-map-pin-off"
            title="No turfs found"
            sub="Try adjusting your search or filters to find what you're looking for."
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
          {turfs.map((turf) => (
            <TurfCard
              key={turf.id}
              turf={turf}
              onView={handleView}
              onApprove={handleApprove}
              onReject={(t) => {
                setRejectReason("");
                setRejectTurf(t);
              }}
              onToggleStatus={handleToggleStatus}
              onDelete={(t) => setDeleteTurf(t)}
              actionLoading={actionLoading}
            />
          ))}
        </div>
      )}

      {/* Pagination */}
      {!gridLoading && turfs.length > 0 && lastPage > 1 && (
        <div className="mt-4 bg-bg-card border border-border rounded-lg">
          <Pagination
            info={`Page ${currentPage} of ${lastPage}`}
            pages={Array.from({ length: lastPage }, (_, i) => i + 1)}
            current={currentPage}
            onChange={setCurrentPage}
          />
        </div>
      )}

      {/* ── View modal ── */}
      {viewTurf && (
        <Modal
          title={viewTurf.name}
          onClose={() => setViewTurf(null)}
          footer={
            <button
              type="button"
              className="btn btn-outline btn-sm"
              onClick={() => setViewTurf(null)}
            >
              Close
            </button>
          }
        >
          <div className="flex flex-col gap-3 max-h-[65vh] overflow-y-auto pr-1">
            {viewTurf.cover_image && (
              <img
                src={viewTurf.cover_image}
                alt={viewTurf.name}
                className="w-full h-40 object-cover rounded-md"
              />
            )}

            <div className="flex items-center justify-between">
              <StatusBadge
                status={viewTurf.status}
                approvalStatus={viewTurf.approval_status}
              />
              {parseFloat(viewTurf.average_rating || "0") > 0 && (
                <span className="text-[11px] text-t2 flex items-center gap-1">
                  <i className="ti ti-star-filled text-amber text-[11px]" />
                  {parseFloat(viewTurf.average_rating).toFixed(1)} (
                  {viewTurf.total_reviews})
                </span>
              )}
            </div>

            {viewTurf.approval_status === "rejected" &&
              viewTurf.rejection_reason && (
                <div className="bg-red/10 border border-red/30 rounded-md px-3 py-2">
                  <p className="text-[10px] text-red font-semibold mb-0.5">
                    Rejection reason
                  </p>
                  <p className="text-[11px] text-t2">
                    {viewTurf.rejection_reason}
                  </p>
                </div>
              )}

            {viewTurf.description && (
              <p className="text-[11.5px] text-t2 leading-relaxed">
                {viewTurf.description}
              </p>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-t4 text-[9px] uppercase tracking-wide mb-0.5">
                  Owner
                </p>
                <p className="text-t1 text-[11.5px] font-medium">
                  {viewTurf.owner?.name || "-"}
                </p>
                <p className="text-t3 text-[10px]">
                  {viewTurf.owner?.mobile || "-"}
                </p>
              </div>
              <div>
                <p className="text-t4 text-[9px] uppercase tracking-wide mb-0.5">
                  Contact
                </p>
                <p className="text-t1 text-[11.5px] font-medium">
                  {viewTurf.contact_number || "-"}
                </p>
              </div>
              <div>
                <p className="text-t4 text-[9px] uppercase tracking-wide mb-0.5">
                  Hours
                </p>
                <p className="text-t1 text-[11.5px] font-medium">
                  {viewTurf.opening_time || "-"}–{viewTurf.closing_time || "-"}
                </p>
              </div>
              <div>
                <p className="text-t4 text-[9px] uppercase tracking-wide mb-0.5">
                  Ground Type
                </p>
                <p className="text-t1 text-[11.5px] font-medium capitalize">
                  {viewTurf.ground_type || "-"}
                </p>
              </div>
            </div>

            <div>
              <p className="text-t4 text-[9px] uppercase tracking-wide mb-1">
                Address
              </p>
              <p className="text-t2 text-[11px]">
                {[
                  viewTurf.address,
                  viewTurf.area,
                  viewTurf.city?.name,
                  viewTurf.state?.name,
                  viewTurf.pincode,
                ]
                  .filter(Boolean)
                  .join(", ") || "-"}
              </p>
            </div>

            {viewTurf.sports?.length > 0 && (
              <div>
                <p className="text-t4 text-[9px] uppercase tracking-wide mb-1.5">
                  Sports
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {viewTurf.sports.map((s) => (
                    <span
                      key={s.id}
                      className="px-2 py-0.5 rounded-full text-[9px] bg-accent/10 text-accent border border-accent/30"
                    >
                      {s.name}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {viewTurf.amenities?.length > 0 && (
              <div>
                <p className="text-t4 text-[9px] uppercase tracking-wide mb-1.5">
                  Amenities
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {viewTurf.amenities.map((a) => (
                    <span
                      key={a.id}
                      className="px-2 py-0.5 rounded-full text-[9px] bg-bg-input text-t2 border border-border"
                    >
                      {a.name}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {viewTurf.events?.length > 0 && (
              <div>
                <p className="text-t4 text-[9px] uppercase tracking-wide mb-1.5">
                  Events Supported
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {viewTurf.events.map((e) => (
                    <span
                      key={e.id}
                      className="px-2 py-0.5 rounded-full text-[9px] bg-bg-input text-t2 border border-border"
                    >
                      {e.name}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </Modal>
      )}

      {/* ── Reject modal ── */}
      {rejectTurf && (
        <Modal
          title={`Reject "${rejectTurf.name}"`}
          onClose={() => {
            setRejectTurf(null);
            setRejectReason("");
          }}
          footer={
            <>
              <button
                type="button"
                className="btn btn-outline btn-sm"
                onClick={() => {
                  setRejectTurf(null);
                  setRejectReason("");
                }}
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-danger btn-sm disabled:opacity-50"
                disabled={
                  actionLoading === rejectTurf.id || !rejectReason.trim()
                }
                onClick={confirmReject}
              >
                {actionLoading === rejectTurf.id
                  ? "Rejecting..."
                  : "Confirm Reject"}
              </button>
            </>
          }
        >
          <label className="text-[11px] text-t3 mb-1.5 block">
            Reason for rejection <span className="text-red">*</span>
            <span className="text-t4"> (shown to the turf owner)</span>
          </label>
          <textarea
            value={rejectReason}
            onChange={(e) => setRejectReason(e.target.value)}
            rows={4}
            maxLength={500}
            placeholder="e.g. Photos don't match the listed facilities..."
            className="w-full bg-bg-input border border-border rounded-md px-3 py-2 text-[12px] text-t1 outline-none placeholder:text-t4 resize-none focus:border-accent/50"
          />
          <p className="text-[10px] text-t4 mt-1 text-right">
            {rejectReason.length}/500
          </p>
        </Modal>
      )}

      {/* ── Delete confirm modal ── */}
      {deleteTurf && (
        <Modal
          title="Delete Turf"
          onClose={() => setDeleteTurf(null)}
          footer={
            <>
              <button
                type="button"
                className="btn btn-outline btn-sm"
                onClick={() => setDeleteTurf(null)}
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-danger btn-sm disabled:opacity-50"
                disabled={actionLoading === deleteTurf.id}
                onClick={confirmDelete}
              >
                {actionLoading === deleteTurf.id ? (
                  <>
                    <i className="ti ti-loader animate-spin" /> Deleting...
                  </>
                ) : (
                  <>
                    <Trash2 size={14} /> Delete
                  </>
                )}
              </button>
            </>
          }
        >
          <p className="text-[12px] text-t2 leading-relaxed">
            Are you sure you want to delete{" "}
            <span className="font-semibold text-t1">"{deleteTurf.name}"</span>?
            This action cannot be undone.
          </p>
          {deleteTurf.approval_status === "approved" && deleteTurf.status && (
            <p className="text-[11px] text-amber mt-2 bg-amber/10 border border-amber/30 rounded-md px-3 py-2">
              This turf is currently active. Make sure there are no upcoming
              bookings before deleting.
            </p>
          )}
        </Modal>
      )}
    </div>
  );
};

export default TurfList;