import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { adminLogin, sendOtp, verifyOtp } from "../../services/authService";
import { toast } from "sonner";
import {
  validateAdminLogin,
  validateEmail,
  validatePassword,
  validateMobile,
  validateOtp,
  validateFullName,
} from "../../validations/authValidation";
import { getToken, getRole } from "../../utils/auth";
import { formatFullName } from "../../helpers/formatters";
import { Eye, EyeOff } from "lucide-react";
import { useAuth } from "../../context/AuthContext";

// ─── OTP Send / Verify sub-component ───────────────────────────────────────
const SendOtpFlow = ({
  mobile,
  otp,
  otpSent,
  fullName,
  sendOtpLoading,
  verifyOtpLoading,

  onEdit,

  setFullName,

  turfErrors,
  setTurfErrors,

  otpRefs,

  onChange,
  onOtpChange,
  onKeyDown,
  onSend,
  onResend,
  onVerify,
}) => {
  const [countdown, setCountdown] = useState(0);

  // Start 30-second countdown when OTP is sent
  useEffect(() => {
    if (otpSent) {
      setCountdown(60);
      const timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [otpSent]);

  const handleResend = () => {
    onResend();
    setCountdown(60);
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const otpFilled = otp.every((d) => d !== "");

  return (
    <div className="flex flex-col gap-1">
      <label className="text-[10px] font-semibold tracking-widest text-[#a0a0a0] uppercase">
        Full Name
      </label>

      <input
        type="text"
        placeholder="Enter full name"
        value={fullName}
        onChange={(e) => {
          if (otpSent) return;

          const formattedName = formatFullName(e.target.value);

          setFullName(formattedName);

          setTurfErrors((prev) => ({
            ...prev,
            fullName: "",
          }));
        }}
        onBlur={() => {
          setTurfErrors((prev) => ({
            ...prev,

            fullName: validateFullName(fullName),
          }));
        }}
        className={`w-full pl-5 pr-4 py-2.5 bg-[#1F1F27] border text-[12px] rounded-[10px] outline-none placeholder-[#555] transition-all ${
          otpSent
            ? "text-[#888] border-[#333] cursor-not-allowed"
            : turfErrors.fullName
              ? "text-white border-red-500"
              : "text-white border-[#555] focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
        }`}
      />

      {turfErrors.fullName && (
        <p className="text-red-500 text-xs">{turfErrors.fullName}</p>
      )}

      {/* Mobile field */}
      <label className="text-[10px] mt-2 font-semibold tracking-widest text-[#a0a0a0] uppercase">
        Mobile Number
      </label>

      <div className="relative mb-3">
        <span className="absolute left-3 top-5 -translate-y-1/2 text-[#555] text-[12px] select-none">
          +91
        </span>
        <span className="absolute left-9 top-5 -translate-y-1/2 text-[#333] text-[12px] select-none">
          |
        </span>
        <input
          type="tel"
          placeholder="Enter mobile number"
          value={mobile}
          readOnly={otpSent}
          onChange={(e) => {
            const value = e.target.value.replace(/\D/g, "");

            if (value.length <= 10) {
              onChange(value);

              setTurfErrors((prev) => ({
                ...prev,
                mobile: "",
              }));
            }
          }}
          onBlur={() => {
            setTurfErrors((prev) => ({
              ...prev,
              mobile: validateMobile(mobile),
            }));
          }}
          className={`w-full pl-12 pr-4 py-2.5 bg-[#1F1F27] border text-[12px] rounded-[10px] outline-none placeholder-[#555] transition-all ${
            otpSent
              ? "text-[#888] border-[#333] cursor-not-allowed"
              : turfErrors.mobile
                ? "text-white border-red-500"
                : "text-white border-[#555] focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
          }`}
        />
        {turfErrors.mobile && (
          <p className="text-red-500 text-xs mt-1">{turfErrors.mobile}</p>
        )}
        {/* Edit button when OTP is sent */}
        {otpSent && (
          <button
            onClick={onEdit}
            className="absolute cursor-pointer right-3 top-1/2 -translate-y-1/2 text-blue-500 text-[11px] font-semibold hover:text-blue-400 transition-colors"
          >
            Edit
          </button>
        )}
      </div>

      {/* ── OTP input section (visible after Send OTP) ── */}
      {otpSent && (
        <div className="mb-1">
          {/* Label row */}
          <div className="flex items-center justify-between mb-2">
            <label className="text-[10px] font-semibold tracking-widest text-[#a0a0a0] uppercase">
              Enter OTP
            </label>
            {/* Countdown / Resend */}
            {countdown > 0 ? (
              <span className="text-[11px] text-[#666]">
                Resend in{" "}
                <span className="text-blue-400 font-semibold ">
                  {countdown}s
                </span>
              </span>
            ) : (
              <button
                onClick={handleResend}
                className="text-[11px] cursor-pointer text-blue-500 font-semibold hover:text-blue-400 transition-colors"
              >
                Resend OTP
              </button>
            )}
          </div>

          {/* 6 OTP boxes */}
          <div className="flex gap-2">
            {otp.map((val, idx) => (
              <input
                key={idx}
                ref={(el) => (otpRefs.current[idx] = el)}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={val}
                placeholder="—"
                onChange={() => {}}
                onInput={(e) => {
                  const v = e.target.value.replace(/\D/g, "").slice(-1);
                  e.target.value = v;
                  onOtpChange(v, idx);
                }}
                onKeyDown={(e) => onKeyDown(e, idx)}
                className={`flex-1 min-w-0 text-center text-[15px] font-bold rounded-[10px] py-2.5 outline-none transition-all duration-150 border ${
                  val
                    ? "bg-[#162a4a] text-blue-400 border-blue-600 shadow-[0_0_8px_#2979ff40]"
                    : "bg-[#1F1F27] text-white border-[#333] placeholder-[#444]"
                } focus:border-blue-600`}
              />
            ))}
          </div>
          {turfErrors.otp && (
            <p className="text-red-500 text-xs mt-2 text-center">
              {turfErrors.otp}
            </p>
          )}

          {/* OTP sent notice */}
          <p className="text-[11px] text-[#555] mt-2 text-center">
            6-digit OTP sent to{" "}
            <span className="text-[#888] font-semibold">+91 {mobile}</span>
          </p>
        </div>
      )}

      {/* CTA Button */}
      {!otpSent ? (
        <button
          onClick={onSend}
          disabled={sendOtpLoading}
          //   disabled={mobile.length !== 10}
          className={`w-full cursor-pointer font-bold text-[12px] rounded-[12px] py-3 mt-2 mb-1 transition-all duration-150 active:scale-[0.98] 
          bg-blue-600 hover:bg-blue-700 text-white
          `}
        >
          {sendOtpLoading ? "Sending OTP..." : "Send OTP"}
        </button>
      ) : (
        <button
          onClick={onVerify}
          disabled={!otpFilled || verifyOtpLoading}
          className={`w-full font-bold text-[12px] rounded-[12px] py-3 mt-2 mb-1 transition-all duration-150 active:scale-[0.98] ${
            otpFilled
              ? "bg-blue-600 hover:bg-blue-700 text-white cursor-pointer"
              : "bg-[#1F1F27] text-[#444] cursor-not-allowed"
          }`}
        >
          {verifyOtpLoading ? "Verifying..." : "Verify & Sign In"}
        </button>
      )}

      {/* Progress dots */}
      <div className="flex items-center justify-center gap-2 mt-2 mb-1">
        <span
          className={`w-2 h-2 rounded-full transition-all ${!otpSent ? "bg-blue-500 w-4" : "bg-[#333]"}`}
        />
        <span
          className={`w-2 h-2 rounded-full transition-all ${otpSent ? "bg-blue-500 w-4" : "bg-[#333]"}`}
        />
      </div>
      <p className="text-center text-[10px] text-[#444] mb-1">
        {!otpSent
          ? "Step 1 of 2 — Enter your mobile number"
          : "Step 2 of 2 — Verify OTP"}
      </p>
    </div>
  );
};

// ─── Main Login Component ───────────────────────────────────────────────────
const Login = () => {
  const navigate = useNavigate();
  const [adminLoading, setAdminLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [sendOtpLoading, setSendOtpLoading] = useState(false);
  const { saveAuthData } = useAuth();

  const [verifyOtpLoading, setVerifyOtpLoading] = useState(false);
  const [errors, setErrors] = useState({
    email: "",
    password: "",
  });
  const [turfErrors, setTurfErrors] = useState({
    fullName: "",
    mobile: "",
    otp: "",
  });
  const [tab, setTab] = useState("admin");

  // Admin form
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Turf form
  const [fullName, setFullName] = useState("");

  const [mobile, setMobile] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [otpSent, setOtpSent] = useState(false);
  const otpRefs = useRef([]);

  const handleTabSwitch = (newTab) => {
    setTab(newTab);
    setOtp(["", "", "", "", "", ""]);
    setOtpSent(false);
    setMobile("");
    setFullName("");
    setTurfErrors({
      fullName: "",
      mobile: "",
      otp: "",
    });
    setEmail("");
    setPassword("");
    setAdminLoading(false);

    setSendOtpLoading(false);

    setVerifyOtpLoading(false);
  };

  const handleOtpInput = (val, idx) => {
    const newOtp = [...otp];
    newOtp[idx] = val;
    setOtp(newOtp);

    setTurfErrors((prev) => ({
      ...prev,
      otp: "",
    }));

    if (val && idx < 5) {
      otpRefs.current[idx + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (e, idx) => {
    if (e.key === "Backspace") {
      if (otp[idx]) {
        const newOtp = [...otp];
        newOtp[idx] = "";
        setOtp(newOtp);
      } else if (idx > 0) {
        otpRefs.current[idx - 1]?.focus();
      }
    }
  };

  const handleSendOtp = async () => {
    const fullNameError = validateFullName(fullName);
    const mobileError = validateMobile(mobile);

    setTurfErrors({
      fullName: fullNameError,
      mobile: mobileError,
      otp: "",
    });

    if (fullNameError || mobileError) {
      return;
    }

    try {
      setSendOtpLoading(true);

      const response = await sendOtp({
        name: fullName.trim(),
        mobile,
        role_id: 2,
      });

      if (response.data.status) {
        toast.success(response.data.message);

        setOtpSent(true);

        setTimeout(() => {
          otpRefs.current[0]?.focus();
        }, 100);
      }
    } catch (error) {
      setOtp(["", "", "", "", "", ""]);

      // Focus first box
      setTimeout(() => {
        otpRefs.current[0]?.focus();
      }, 100);

      toast.error(error.response?.data?.message || "Failed to send OTP.");
    } finally {
      setSendOtpLoading(false);
    }
  };

  const handleResendOtp = async () => {
    try {
      setSendOtpLoading(true);

      // Clear previous OTP
      setOtp(["", "", "", "", "", ""]);

      // Clear OTP validation error
      setTurfErrors((prev) => ({
        ...prev,
        otp: "",
      }));

      const response = await sendOtp({
        name: fullName.trim(),
        mobile,
        role_id: 2,
      });

      if (response.data.status) {
        toast.success(response.data.message);

        setTimeout(() => {
          otpRefs.current[0]?.focus();
        }, 100);
      } else {
        toast.error(response.data.message);
      }
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to resend OTP.");
    } finally {
      setSendOtpLoading(false);
    }
  };

  const handleTurfVerify = async () => {
    setVerifyOtpLoading(true);
    // Join all OTP digits
    const code = otp.join("");

    // Validate OTP
    const otpError = validateOtp(code);

    setTurfErrors((prev) => ({
      ...prev,
      otp: otpError,
    }));

    // Stop if validation fails
    if (otpError) {
      setVerifyOtpLoading(false);
      return;
    }

    try {
      // Show loading

      // Call Verify OTP API
      const response = await verifyOtp({
        mobile,
        otp: code,
      });

      // Check API response
      if (response.data.status) {
        // Save Token + User + Role
        saveAuthData(response.data);

        // Success Message
        toast.success(response.data.message);

        // Navigate according to role
        const role = response.data.login_role;
        const profileCompleted = response.data.is_profile_completed;

        if (role === "admin") {
          navigate("/dashboard", { replace: true });
        } else if (role === "turf_owner") {
          if (profileCompleted) {
            navigate("/dashboard", { replace: true });
          } else {
            navigate("/complete-profile", { replace: true });
          }
        }
      } else {
        toast.error(response.data.message || "OTP verification failed.");
      }
    } catch (error) {
      toast.error(
        error.response?.data?.message ||
          "Unable to verify OTP. Please try again.",
      );
    } finally {
      // Stop loading
      setVerifyOtpLoading(false);
    }
  };

  // admin login function
  const handleAdminLogin = async () => {
    const validationErrors = validateAdminLogin(email, password);

    setErrors(validationErrors);

    const hasErrors = Object.values(validationErrors).some(
      (error) => error !== "",
    );

    if (hasErrors) {
      return;
    }

    try {
      setAdminLoading(true);

      const response = await adminLogin({
        email,
        password,
      });

      if (response.data.status) {
        saveAuthData(response.data);

        toast.success(response.data.message);

        const role = response.data.login_role;

        if (role === "admin") {
          navigate("/dashboard");
        }
      } else {
        toast.error(response.data.message);
      }
    } catch (error) {
      toast.error(error.response?.data?.message || "Something went wrong.");
    } finally {
      setAdminLoading(false);
    }
  };

  // mobile edit function

  const handleEditMobile = () => {
    setOtpSent(false);

    setOtp(["", "", "", "", "", ""]);

    setVerifyOtpLoading(false);

    setTurfErrors((prev) => ({
      ...prev,
      otp: "",
    }));
  };

  useEffect(() => {
    const token = getToken();

    const role = getRole();

    if (token) {
      if (role === "admin") {
        navigate("/dashboard", { replace: true });
      } else if (role === "turf_owner") {
        navigate("/dashboard", { replace: true });
      }
    }
  }, [navigate]);

  return (
    <div className="min-h-screen bg-[#0B0B0F] flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-md bg-[#14141A] rounded-2xl p-8">
        {/* Logo */}
        <div className="w-12 h-12 bg-blue-600 rounded-xl mx-auto mb-2 flex items-center justify-center">
          <svg
            className="w-6 h-6 text-white"
            fill="none"
            stroke="currentColor"
            strokeWidth={2.5}
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M12 3v2m0 14v2M4.22 4.22l1.42 1.42m12.72 12.72 1.42 1.42M3 12H1m22 0h-2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"
            />
          </svg>
        </div>

        {/* Title */}
        <h1 className="text-center text-white text-lg font-bold mb-1">
          {tab === "admin" ? "Admin Login" : "Turf Owner Login"}
        </h1>
        <p className="text-center text-[#A0A0A0] text-[12px] mb-5">
          BookMySport Control Panel
        </p>

        {/* Tab Switcher */}
        <div className="grid grid-cols-2 gap-3 mb-5">
          <button
            onClick={() => handleTabSwitch("admin")}
            className={`h-10 text-[12px] rounded-lg font-semibold transition-all cursor-pointer ${
              tab === "admin"
                ? "bg-[#2979ff1f] text-[#2979FF] border border-[#2979FF50]"
                : "bg-[#1F1F27] text-slate-500 border border-transparent hover:border-[#333]"
            }`}
          >
            Admin
          </button>
          <button
            onClick={() => handleTabSwitch("turf")}
            className={`h-10 text-[12px] rounded-lg font-semibold transition-all cursor-pointer ${
              tab === "turf"
                ? "bg-[#2979ff1f] text-[#2979FF] border border-[#2979FF50]"
                : "bg-[#1F1F27] text-slate-500 border border-transparent hover:border-[#333]"
            }`}
          >
            Turf Owner
          </button>
        </div>

        {/* ── ADMIN FORM ── */}
        {tab === "admin" && (
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-semibold tracking-widest text-[#a0a0a0] uppercase">
              Email Address
            </label>
            <input
              type="email"
              placeholder="Enter email address"
              value={email}
              readOnly={otpSent}
              onChange={(e) => {
                setEmail(e.target.value);

                setErrors({
                  ...errors,
                  email: "",
                });
              }}
              onBlur={() => {
                setErrors((prev) => ({
                  ...prev,
                  email: validateEmail(email),
                }));
              }}
              className={`w-full bg-[#1F1F27]  placeholder-[#555] text-white border text-[12px] rounded-[10px] px-4 py-2.5 outline-none transition-all ${
                errors.email
                  ? "border-red-500"
                  : "border-[#333] focus:border-blue-600"
              }`}
            />
            {errors.email && (
              <p className="text-red-500 text-xs">{errors.email}</p>
            )}

            <label className="text-[10px] mt-2 font-semibold tracking-widest text-[#a0a0a0] uppercase">
              Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Enter password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setErrors({
                    ...errors,
                    password: "",
                  });
                }}
                onBlur={() => {
                  setErrors((prev) => ({
                    ...prev,
                    password: validatePassword(password),
                  }));
                }}
                className={`w-full bg-[#1F1F27] placeholder-[#555] text-white border border-[#333] text-[12px] rounded-[10px] px-4 py-2.5  outline-none placeholder-[#555] focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-all ${
                  errors.password ? "border-red-500" : "border-[#333]"
                }`}
              />

              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute cursor-pointer inset-y-0 right-3 flex items-center text-gray-400 hover:text-white transition-colors"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            {errors.password && (
              <p className="text-red-500 text-xs">{errors.password}</p>
            )}

            <button
              onClick={handleAdminLogin}
              disabled={adminLoading}
              className={`w-full font-bold text-[12px] mt-4 rounded-[12px] py-3 transition-all duration-150 active:scale-[0.98] mb-3
                   bg-blue-600 hover:bg-blue-700 text-white cursor-pointer
                  ${
                    adminLoading
                      ? "bg-blue-400 cursor-not-allowed"
                      : "bg-blue-600 hover:bg-blue-700 cursor-pointer"
                  }`}
            >
              {adminLoading ? "Signing In..." : "Sign In to Dashboard"}
            </button>

            <p className="text-center text-[11px] text-[#666] mb-3">
              Forgot password?{" "}
              <a href="#" className="text-blue-500 hover:underline">
                Reset via email
              </a>
            </p>
          </div>
        )}

        {/* ── TURF OWNER FORM ── */}
        {tab === "turf" && (
          <SendOtpFlow
            onEdit={handleEditMobile}
            sendOtpLoading={sendOtpLoading}
            verifyOtpLoading={verifyOtpLoading}
            mobile={mobile}
            otp={otp}
            fullName={fullName}
            setFullName={setFullName}
            otpSent={otpSent}
            otpRefs={otpRefs}
            turfErrors={turfErrors}
            setTurfErrors={setTurfErrors}
            onChange={setMobile}
            onOtpChange={handleOtpInput}
            onKeyDown={handleOtpKeyDown}
            onSend={handleSendOtp}
            onResend={handleResendOtp}
            onVerify={handleTurfVerify}
          />
        )}

        {/* Footer */}
        <div className="border-t border-[#1F1F27] mt-3 pt-3">
          <p className="text-center text-[11px] text-[#555]">
            Secured by{" "}
            <span className="text-blue-500 font-semibold">
              BookMySport Shield
            </span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
