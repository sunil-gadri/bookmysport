import React, { useEffect, useState } from "react";
import {
  StatCard,
  PageHeader,
  Badge,
  Avatar,
  ActionBtn,
  SearchBar,
  FilterChip,
  Pagination,
  EmptyState,
} from "../../components/UI.jsx";
import api from "../../api/axios.js";
import { getInitials, getAvatarColor } from "../../helpers/formatters.js";
import ListPageSkeleton from "../../components/skeletons/ListPageSkeleton.jsx";

const sportIcon = {
  Football: "ti-ball-football",
  Badminton: "ti-ball-tennis",
  Tennis: "ti-ball-tennis",
  Cricket: "ti-cricket",
  Swimming: "ti-swimming",
  Boxing: "ti-boxing-glove",
};

const statusLabel = (s) =>
  s ? s.charAt(0).toUpperCase() + s.slice(1) : "-";

const BookingList = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tableLoading, setTableLoading] = useState(false);

  const [currentPage, setCurrentPage] = useState(1);
  const [lastPage, setLastPage] = useState(1);
  const [perPage, setPerPage] = useState(15);
  const [totalBookings, setTotalBookings] = useState(0);

  const [searchText, setSearchText] = useState("");
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");

  const [counts, setCounts] = useState({
    total_bookings: 0,
    confirmed: 0,
    completed: 0,
    cancelled: 0,
    total_revenue: 0,
  });

  const fetchBookings = async (page = 1) => {
    try {
      if (loading) {
        setLoading(true);
      } else {
        setTableLoading(true);
      }

      const response = await api.get("/admin/bookings", {
        params: {
          page,
          search,
          status,
        },
      });

      const res = response.data;

      setBookings(res.data);
      setCounts(res.counts);
      setCurrentPage(res.pagination.current_page);
      setLastPage(res.pagination.last_page);
      setPerPage(res.pagination.per_page);
      setTotalBookings(res.pagination.total);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
      setTableLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings(currentPage);
  }, [currentPage, search, status]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchText.length >= 3 || searchText.length === 0) {
        setSearch(searchText);
        setCurrentPage(1);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [searchText]);

  const filters = [
    { label: "All", value: "" },
    { label: "Confirmed", value: "confirmed" },
    { label: "Pending", value: "pending" },
    { label: "Completed", value: "completed" },
    { label: "Cancelled", value: "cancelled" },
  ];

  const quickStats = [
    {
      icon: "ti-calendar-check",
      value: counts.total_bookings,
      label: "Total Bookings",
      iconBg: "rgba(41,121,255,.15)",
      iconColor: "#2979FF",
    },
    {
      icon: "ti-circle-check",
      value: counts.confirmed,
      label: "Confirmed",
      iconBg: "rgba(0,230,118,.12)",
      iconColor: "#00E676",
    },
    {
      icon: "ti-x",
      value: counts.cancelled,
      label: "Cancelled",
      iconBg: "rgba(255,82,82,.12)",
      iconColor: "#FF5252",
    },
    {
      icon: "ti-currency-rupee",
      value: `₹${Number(counts.total_revenue || 0).toLocaleString("en-IN")}`,
      label: "Total Revenue",
      iconBg: "rgba(255,179,0,.12)",
      iconColor: "#FFB300",
    },
  ];

  if (loading) {
    return <ListPageSkeleton statsCount={4} tableRows={8} tableColumns={8} />;
  }

  return (
    <div className="w-full p-2 lg:px-4 lg:py-3 animate-fade-in">
      <PageHeader
        title="Bookings"
        subtitle={`${totalBookings} Total Bookings`}
      >
        <button className="btn btn-outline btn-sm">
          <i className="ti ti-download" />
          Export CSV
        </button>
      </PageHeader>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-2 mb-4">
        {quickStats.map((s, i) => (
          <StatCard key={i} {...s} />
        ))}
      </div>

      {/* Search + Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 mb-4">
        <SearchBar
          placeholder="Search by customer, mobile or booking number..."
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
        />
        <div className="flex items-center gap-2 overflow-x-auto">
          {filters.map((item) => (
            <FilterChip
              key={item.label}
              label={item.label}
              active={status === item.value}
              onClick={() => {
                setStatus(item.value);
                setCurrentPage(1);
              }}
            />
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-bg-card border border-border rounded-lg overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <span className="font-poppins text-[13px] font-bold text-t1">
            All Bookings
          </span>
          <span className="text-[10px] text-t3">
            Showing{" "}
            {totalBookings === 0 ? 0 : (currentPage - 1) * perPage + 1}–
            {Math.min(currentPage * perPage, totalBookings)} of{" "}
            {totalBookings}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-[950px]">
            <thead>
              <tr>
                <th>Booking No.</th>
                <th>Customer</th>
                <th>Turf / Sport</th>
                <th>Date &amp; Slot</th>
                <th>Amount</th>
                <th>Payment</th>
                <th>Status</th>
                <th className="text-right pr-4">Action</th>
              </tr>
            </thead>
            <tbody>
              {tableLoading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    {Array.from({ length: 8 }).map((__, j) => (
                      <td key={j}>
                        <div className="h-3 w-full max-w-[110px] rounded bg-bg-input" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : bookings.length === 0 ? (
                <tr>
                  <td colSpan={8}>
                    <EmptyState
                      icon="ti-calendar-off"
                      title="No bookings found"
                      sub="Try adjusting your search or filters to find what you're looking for."
                    />
                  </td>
                </tr>
              ) : (
                bookings.map((b, index) => {
                  const avatarColor = getAvatarColor(index);
                  return (
                    <tr key={b.id}>
                      <td className="font-poppins font-semibold text-t1">
                        {b.booking_number}
                      </td>
                      <td>
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-[26px] h-[26px] rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0 ${avatarColor.bg} ${avatarColor.text}`}
                          >
                            {getInitials(b.customer?.name)}
                          </div>
                          <div>
                            <p className="text-t1 font-medium text-[11.5px]">
                              {b.customer?.name || "-"}
                            </p>
                            <p className="text-[9.5px] text-t4">
                              {b.customer?.mobile || "-"}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td>
                        <div className="flex items-center gap-1.5">
                          <i
                            className={`ti ${sportIcon[b.booking_name] ?? "ti-ball"} text-[13px] text-accent`}
                          />
                          <div>
                            <div className="text-t2">{b.turf?.name || "-"}</div>
                            <div className="text-[9.5px] text-t4">
                              {b.booking_name}
                              {b.checked_in && (
                                <span className="ml-1 text-green">
                                  · Checked in
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td>
                        <div className="text-t2">{b.booking_date}</div>
                        <div className="text-[9.5px] text-t4">
                          {b.time_range}
                        </div>
                      </td>
                      <td className="font-poppins font-semibold text-t1">
                        ₹{Number(b.total_amount).toLocaleString("en-IN")}
                      </td>
                      <td>
                        <Badge label={statusLabel(b.payment_status)} />
                      </td>
                      <td>
                        <Badge label={statusLabel(b.booking_status)} />
                      </td>
                      <td className="text-right pr-4">
                        <ActionBtn icon="ti-eye" title="View" />
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {!tableLoading && bookings.length > 0 && (
          <Pagination
            info={`Page ${currentPage} of ${lastPage}`}
            pages={Array.from({ length: lastPage }, (_, i) => i + 1)}
            current={currentPage}
            onChange={setCurrentPage}
          />
        )}
      </div>
    </div>
  );
};

export default BookingList;