import React, { useEffect, useState } from "react";
import {
  StatCard,
  PageHeader,
  SearchBar,
  FilterChip,
  Pagination,
  EmptyState,
  Modal,
} from "../../components/UI.jsx";
import api from "../../api/axios.js";
import ListPageSkeleton from "../../components/skeletons/ListPageSkeleton.jsx";

// ── Status badges ──
const BookingStatusBadge = ({ status }) => {
  const map = {
    confirmed: "bg-accent/10 text-accent",
    completed: "bg-green/10 text-green",
    cancelled: "bg-red/10 text-red",
  };
  return (
    <span className={`px-2 py-0.5 rounded-[5px] text-[10px] font-bold capitalize ${map[status] || "bg-bg-input text-t3"}`}>
      {status}
    </span>
  );
};

const PaymentStatusBadge = ({ status }) => {
  const map = {
    paid: "bg-green/10 text-green",
    failed: "bg-red/10 text-red",
    refunded: "bg-amber/10 text-amber",
    pending: "bg-bg-input text-t3",
  };
  return (
    <span className={`px-2 py-0.5 rounded-[5px] text-[10px] font-bold capitalize ${map[status] || "bg-bg-input text-t3"}`}>
      {status}
    </span>
  );
};

const CheckInBadge = ({ checkIn }) =>
  checkIn.checked_in ? (
    <span className="px-2 py-0.5 rounded-[5px] text-[10px] font-bold bg-green/10 text-green flex items-center gap-1 w-fit">
      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
        <path d="M8.5 12.5l2.5 2.5 5-5" />
      </svg>
      Checked In
    </span>
  ) : (
    <span className="px-2 py-0.5 rounded-[5px] text-[10px] font-bold bg-bg-input text-t3">
      Not Yet
    </span>
  );

const TurfOwnerBookings = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tableLoading, setTableLoading] = useState(false);

  const [currentPage, setCurrentPage] = useState(1);
  const [lastPage, setLastPage] = useState(1);
  const [totalBookings, setTotalBookings] = useState(0);

  const [searchText, setSearchText] = useState("");
  const [search, setSearch] = useState("");
  const [bookingStatus, setBookingStatus] = useState(""); // "", "confirmed", "completed", "cancelled"
  const [todayOnly, setTodayOnly] = useState(false);

  const [counts, setCounts] = useState({
    total_bookings: 0,
    today_bookings: 0,
    confirmed: 0,
    completed: 0,
    cancelled: 0,
    checked_in: 0,
    total_revenue: 0,
  });

  const [viewBooking, setViewBooking] = useState(null); // detail modal

  const fetchBookings = async (page = 1) => {
    try {
      if (loading) {
        setLoading(true);
      } else {
        setTableLoading(true);
      }

      const response = await api.get("/turf-owner/bookings", {
        params: {
          page,
          search,
          booking_status: bookingStatus,
          today: todayOnly ? 1 : undefined,
        },
      });

      const res = response.data;

      setBookings(res.data);
      setCurrentPage(res.pagination.current_page);
      setLastPage(res.pagination.last_page);
      setTotalBookings(res.pagination.total);
      setCounts(res.counts);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
      setTableLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings(currentPage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage, search, bookingStatus, todayOnly]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchText.length >= 3 || searchText.length === 0) {
        setSearch(searchText);
        setCurrentPage(1);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [searchText]);

  const handleView = async (booking) => {
    try {
      const response = await api.get(`/turf-owner/bookings/${booking.id}`);
      setViewBooking(response.data.data);
    } catch (error) {
      console.log(error);
    }
  };

  const statusFilters = [
    { label: "All", value: "" },
    { label: "Confirmed", value: "confirmed" },
    { label: "Completed", value: "completed" },
    { label: "Cancelled", value: "cancelled" },
  ];

  const quickStats = [
    {
      icon: "ti-calendar-check",
      value: counts.total_bookings,
      label: "Total Bookings",
      iconBg: "rgba(41,121,255,.15)",
      iconColor: "#2979FF",
    },
    {
      icon: "ti-calendar-event",
      value: counts.today_bookings,
      label: "Today's Bookings",
      iconBg: "rgba(245,158,11,.15)",
      iconColor: "#F59E0B",
    },
    {
      icon: "ti-checkbox",
      value: counts.checked_in,
      label: "Checked In",
      iconBg: "rgba(34,197,94,.15)",
      iconColor: "#22C55E",
    },
    {
      icon: "ti-currency-rupee",
      value: `₹${counts.total_revenue.toLocaleString()}`,
      label: "Total Revenue",
      iconBg: "rgba(139,92,246,.15)",
      iconColor: "#8B5CF6",
    },
  ];

  if (loading) {
    return <ListPageSkeleton statsCount={4} tableRows={8} tableColumns={8} />;
  }

  return (
    <div className="w-full p-2 lg:px-4 lg:py-3 animate-fade-in">
      <PageHeader title="Bookings" subtitle={`${totalBookings} Total Bookings`} />

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 mb-4 mt-3">
        {quickStats.map((s, i) => (
          <StatCard key={i} {...s} />
        ))}
      </div>

      {/* Search + Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 mb-4">
        <SearchBar
          placeholder="Search by booking number, customer name or mobile..."
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
        />
        <div className="flex items-center gap-2 overflow-x-auto">
          {statusFilters.map((item) => (
            <FilterChip
              key={item.label}
              label={item.label}
              active={bookingStatus === item.value}
              onClick={() => {
                setBookingStatus(item.value);
                setCurrentPage(1);
              }}
            />
          ))}
          <FilterChip
            label="Today Only"
            active={todayOnly}
            onClick={() => {
              setTodayOnly((prev) => !prev);
              setCurrentPage(1);
            }}
          />
        </div>
      </div>

      {/* Table */}
      {tableLoading ? (
        <div className="bg-bg-card border border-border rounded-lg p-4 space-y-2">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-10 rounded-md bg-bg-input animate-pulse" />
          ))}
        </div>
      ) : bookings.length === 0 ? (
        <div className="bg-bg-card border border-border rounded-lg">
          <EmptyState
            icon="ti-calendar-off"
            title="No bookings found"
            sub="Try adjusting your search or filters to find what you're looking for."
          />
        </div>
      ) : (
        <div className="bg-bg-card border border-border rounded-lg overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-border">
                <th className="px-4 py-3 text-t3 text-[10px] uppercase tracking-wide font-semibold">Booking #</th>
                <th className="px-4 py-3 text-t3 text-[10px] uppercase tracking-wide font-semibold">Customer</th>
                <th className="px-4 py-3 text-t3 text-[10px] uppercase tracking-wide font-semibold">Sport</th>
                <th className="px-4 py-3 text-t3 text-[10px] uppercase tracking-wide font-semibold">Date &amp; Time</th>
                <th className="px-4 py-3 text-t3 text-[10px] uppercase tracking-wide font-semibold">Amount</th>
                <th className="px-4 py-3 text-t3 text-[10px] uppercase tracking-wide font-semibold">Status</th>
                <th className="px-4 py-3 text-t3 text-[10px] uppercase tracking-wide font-semibold">Check-In</th>
                <th className="px-4 py-3 text-t3 text-[10px] uppercase tracking-wide font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((booking) => (
                <tr key={booking.id} className="border-b border-border last:border-0">
                  <td className="px-4 py-3">
                    <p className="text-t1 text-[12px] font-semibold">{booking.booking_number}</p>
                    <PaymentStatusBadge status={booking.payment_status} />
                  </td>
                  <td className="px-4 py-3">
                    <p className="text-t1 text-[12px] font-medium">{booking.customer.name || "-"}</p>
                    <p className="text-t4 text-[10px]">{booking.customer.mobile}</p>
                  </td>
                  <td className="px-4 py-3 text-t2 text-[11.5px]">{booking.booking_name}</td>
                  <td className="px-4 py-3">
                    <p className="text-t2 text-[11.5px]">{booking.booking_date}</p>
                    <p className="text-t4 text-[10.5px]">{booking.time_range}</p>
                  </td>
                  <td className="px-4 py-3 text-t1 text-[12px] font-semibold">₹{booking.total_amount}</td>
                  <td className="px-4 py-3">
                    <BookingStatusBadge status={booking.booking_status} />
                  </td>
                  <td className="px-4 py-3">
                    <CheckInBadge checkIn={booking.check_in} />
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => handleView(booking)}
                      className="btn btn-outline btn-sm"
                    >
                      <i className="ti ti-eye" />
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination */}
      {!tableLoading && bookings.length > 0 && lastPage > 1 && (
        <div className="mt-4 bg-bg-card border border-border rounded-lg">
          <Pagination
            info={`Page ${currentPage} of ${lastPage}`}
            pages={Array.from({ length: lastPage }, (_, i) => i + 1)}
            current={currentPage}
            onChange={setCurrentPage}
          />
        </div>
      )}

      {/* Booking detail modal */}
      {viewBooking && (
        <Modal
          title={`Booking ${viewBooking.booking_number}`}
          onClose={() => setViewBooking(null)}
          footer={
            <button className="btn btn-outline btn-sm" onClick={() => setViewBooking(null)}>
              Close
            </button>
          }
        >
          <div className="flex flex-col gap-3 max-h-[65vh] overflow-y-auto pr-1">
            <div className="flex items-center justify-between">
              <BookingStatusBadge status={viewBooking.booking_status} />
              <PaymentStatusBadge status={viewBooking.payment_status} />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-t4 text-[9px] uppercase tracking-wide mb-0.5">Customer</p>
                <p className="text-t1 text-[11.5px] font-medium">{viewBooking.customer.name || "-"}</p>
                <p className="text-t3 text-[10px]">{viewBooking.customer.mobile}</p>
              </div>
              <div>
                <p className="text-t4 text-[9px] uppercase tracking-wide mb-0.5">Sport / Event</p>
                <p className="text-t1 text-[11.5px] font-medium">{viewBooking.booking_name}</p>
              </div>
              <div>
                <p className="text-t4 text-[9px] uppercase tracking-wide mb-0.5">Date</p>
                <p className="text-t1 text-[11.5px] font-medium">{viewBooking.booking_date}</p>
              </div>
              <div>
                <p className="text-t4 text-[9px] uppercase tracking-wide mb-0.5">Amount</p>
                <p className="text-t1 text-[11.5px] font-medium">₹{viewBooking.total_amount}</p>
              </div>
            </div>

            <div>
              <p className="text-t4 text-[9px] uppercase tracking-wide mb-1.5">Slots</p>
              <div className="flex flex-col gap-1.5">
                {viewBooking.slots.map((slot) => (
                  <div
                    key={slot.id}
                    className="bg-bg-input rounded-md px-3 py-2 text-[11px] text-t2 flex justify-between"
                  >
                    <span>{slot.start_time} - {slot.end_time}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <p className="text-t4 text-[9px] uppercase tracking-wide mb-0.5">Check-In Status</p>
              <CheckInBadge checkIn={viewBooking.check_in} />
              {viewBooking.check_in.checked_in && (
                <p className="text-t3 text-[10.5px] mt-1">
                  Checked in at {viewBooking.check_in.checked_in_at}
                </p>
              )}
            </div>

            <div>
              <p className="text-t4 text-[9px] uppercase tracking-wide mb-0.5">Booked On</p>
              <p className="text-t2 text-[11px]">{viewBooking.created_at}</p>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

export default TurfOwnerBookings;