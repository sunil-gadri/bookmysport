import React, { useEffect, useRef, useState } from "react";
import {
  Search,
  Eye,
  Plus,
  X,
  Pencil,
  Trash2,
  ImagePlus,
  Loader2,
  AlertTriangle,
} from "lucide-react";
import api from "../../api/axios";
import { PageHeader, StatCard } from "../../components/UI";
import ListPageSkeleton from "../../components/skeletons/ListPageSkeleton";
import { formatSportName } from "../../helpers/formatters";

const emptyForm = { name: "", status: 1 };

const AmenitiesList = () => {
  const [amenities, setAmenities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tableLoading, setTableLoading] = useState(false);

  const [currentPage, setCurrentPage] = useState(1);
  const [lastPage, setLastPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [totalAmenities, setTotalAmenities] = useState(0);
  const [activeAmenities, setActiveAmenities] = useState(0);
  const [inactiveAmenities, setInactiveAmenities] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");

  // ── Add / Edit modal state ──
  const [modalOpen, setModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState("add"); // 'add' | 'edit'
  const [editingId, setEditingId] = useState(null);
  const [modalLoading, setModalLoading] = useState(false); // loading existing amenity for edit
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState(emptyForm);
  const [formErrors, setFormErrors] = useState({});
  const [iconFile, setIconFile] = useState(null);
  const [iconPreview, setIconPreview] = useState(null);
  const iconInputRef = useRef(null);

  // ── Delete confirm state ──
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  // ── Row-level status toggle loading ──
  const [statusUpdatingId, setStatusUpdatingId] = useState(null);

  const fetchAmenities = async (page = 1) => {
    try {
      loading ? setLoading(true) : setTableLoading(true);

      const res = await api.get("/admin/amenities", {
        params: {
          page,
          search,
          status,
        },
      });

      const data = res.data;

      setAmenities(data.data || []);
      setCurrentPage(data.pagination?.current_page || 1);
      setLastPage(data.pagination?.last_page || 1);
      setPerPage(data.pagination?.per_page || 10);
      setTotalAmenities(data.counts?.total_amenities || 0);
      setActiveAmenities(data.counts?.active_amenities || 0);
      setInactiveAmenities(data.counts?.inactive_amenities || 0);
    } finally {
      setLoading(false);
      setTableLoading(false);
    }
  };

  useEffect(() => {
    fetchAmenities(currentPage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage, search, status]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchText.length >= 3 || searchText.length === 0) {
        setSearch(searchText);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [searchText]);

  // Clean up object URLs when preview changes/unmounts
  useEffect(() => {
    return () => {
      if (iconPreview?.startsWith("blob:")) URL.revokeObjectURL(iconPreview);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [iconPreview]);

  const stats = [
    {
      icon: "ti-trophy",
      value: totalAmenities,
      label: "Total Amenities",
      iconBg: "rgba(41,121,255,.15)",
      iconColor: "#2979FF",
    },
    {
      icon: "ti-check",
      value: activeAmenities,
      label: "Active Amenities",
      iconBg: "rgba(34,197,94,.15)",
      iconColor: "#22C55E",
    },
    {
      icon: "ti-ban",
      value: inactiveAmenities,
      label: "Inactive Amenities",
      iconBg: "rgba(239,68,68,.15)",
      iconColor: "#EF4444",
    },
  ];

  const filters = ["All", "Active", "Inactive"];

  // ───────────────────────────────────────────────
  // Modal helpers
  // ───────────────────────────────────────────────

  const resetForm = () => {
    setFormData(emptyForm);
    setFormErrors({});
    setIconFile(null);
    setIconPreview(null);
    if (iconInputRef.current) iconInputRef.current.value = "";
  };

  const openAddModal = () => {
    resetForm();
    setModalMode("add");
    setEditingId(null);
    setModalOpen(true);
  };

  const openEditModal = async (amenity) => {
    resetForm();
    setModalMode("edit");
    setEditingId(amenity.id);
    setModalOpen(true);
    setModalLoading(true);

    try {
      // Pull fresh data for the amenity being edited
      const res = await api.get(`/admin/amenities/${amenity.id}`);
      const data = res.data?.data || amenity;

      setFormData({
        name: data.name || "",
        status: data.status?.value ? 1 : 0,
      });
      setIconPreview(data.icon || null);
    } catch (err) {
      // Fall back to the row data already in the table if the fetch fails
      setFormData({
        name: amenity.name || "",
        status: amenity.status?.value ? 1 : 0,
      });
      setIconPreview(amenity.icon || null);
    } finally {
      setModalLoading(false);
    }
  };

  const closeModal = () => {
    if (submitting) return;
    setModalOpen(false);
    resetForm();
  };

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validTypes = [
      "image/png",
      "image/jpeg",
      "image/jpg",
      "image/svg+xml",
      "image/webp",
    ];
    if (!validTypes.includes(file.type)) {
      setFormErrors((prev) => ({
        ...prev,
        icon: "Please upload a PNG, JPG, SVG or WEBP image.",
      }));
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setFormErrors((prev) => ({
        ...prev,
        icon: "Image must be under 2MB.",
      }));
      return;
    }

    const img = new Image();

    img.onload = () => {
      const { width, height } = img;

      if (width < 45 || height < 45) {
        setFormErrors((prev) => ({
          ...prev,
          icon: "Image must be at least 45 × 45 pixels.",
        }));
        return;
      }

      if (width > 100 || height > 100) {
        setFormErrors((prev) => ({
          ...prev,
          icon: "Image must not exceed 100 × 100 pixels.",
        }));
        return;
      }

      setFormErrors((prev) => ({
        ...prev,
        icon: undefined,
      }));

      const previewUrl = URL.createObjectURL(file);
      setIconFile(file);
      setIconPreview(previewUrl);
    };

    img.onerror = () => {
      setFormErrors((prev) => ({
        ...prev,
        icon: "Invalid image.",
      }));
    };

    img.src = URL.createObjectURL(file);
  };

  const validateForm = () => {
    const errors = {};

    if (!formData.name || !formData.name.trim()) {
      errors.name = "Amenity name is required.";
    } else if (formData.name.trim().length < 2) {
      errors.name = "Amenity name must be at least 2 characters.";
    } else if (formData.name.trim().length > 50) {
      errors.name = "Amenity name must be under 50 characters.";
    }



    // Icon is required when adding; optional when editing (existing one is kept)
    if (modalMode === "add" && !iconFile) {
      errors.icon = "Icon is required.";
    }

    if (formData.status !== 0 && formData.status !== 1) {
      errors.status = "Please choose a status.";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    setSubmitting(true);
    try {
      const payload = new FormData();
      payload.append("name", formatSportName(formData.name.trim()));
      payload.append("status", formData.status);
      if (iconFile) payload.append("icon", iconFile);

      if (modalMode === "add") {
        await api.post("/admin/amenities", payload, {
          headers: { "Content-Type": "multipart/form-data" },
        });
      } else {
        await api.post(`/admin/amenities/${editingId}`, payload, {
          headers: { "Content-Type": "multipart/form-data" },
        });
      }

      setModalOpen(false);
      resetForm();
      fetchAmenities(modalMode === "add" ? 1 : currentPage);
      if (modalMode === "add") setCurrentPage(1);
    } catch (err) {
      const apiErrors = err?.response?.data?.errors;
      const apiMessage = err?.response?.data?.message;
      if (apiErrors) {
        // Map backend validation errors (Laravel-style arrays) to our field keys
        const mapped = {};
        Object.entries(apiErrors).forEach(([key, val]) => {
          mapped[key] = Array.isArray(val) ? val[0] : val;
        });
        setFormErrors((prev) => ({ ...prev, ...mapped }));
      } else {
        setFormErrors((prev) => ({
          ...prev,
          form: apiMessage || "Something went wrong. Please try again.",
        }));
      }
    } finally {
      setSubmitting(false);
    }
  };

  // ───────────────────────────────────────────────
  // Delete
  // ───────────────────────────────────────────────

  const confirmDelete = (amenity) => setDeleteTarget(amenity);
  const cancelDelete = () => {
    if (deleting) return;
    setDeleteTarget(null);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await api.delete(`/admin/amenities/${deleteTarget.id}`);
      setDeleteTarget(null);

      // If we deleted the last row on a page beyond page 1, step back a page
      const isLastRowOnPage = amenities.length === 1 && currentPage > 1;
      const nextPage = isLastRowOnPage ? currentPage - 1 : currentPage;
      setCurrentPage(nextPage);
      fetchAmenities(nextPage);
    } catch (err) {
      // Surface delete failure inline without closing the confirm dialog
      setDeleteTarget((prev) =>
        prev
          ? {
              ...prev,
              _error:
                err?.response?.data?.message || "Failed to delete amenity.",
            }
          : prev,
      );
    } finally {
      setDeleting(false);
    }
  };

  // ───────────────────────────────────────────────
  // Status toggle (row-level, no modal)
  // ───────────────────────────────────────────────

  const handleToggleStatus = async (amenity) => {
    const nextStatus = amenity.status?.value ? 0 : 1;
    setStatusUpdatingId(amenity.id);

    // Optimistic update
    setAmenities((prev) =>
      prev.map((a) =>
        a.id === amenity.id
          ? {
              ...a,
              status: {
                value: !!nextStatus,
                label: nextStatus ? "Active" : "Inactive",
              },
            }
          : a,
      ),
    );

    try {
      await api.patch(`/admin/amenities/${amenity.id}/status`, {
        status: nextStatus,
      });
      // Refresh counts (Active/Inactive totals) from server truth
      fetchAmenities(currentPage);
    } catch (err) {
      // Revert on failure
      setAmenities((prev) =>
        prev.map((a) => (a.id === amenity.id ? amenity : a)),
      );
    } finally {
      setStatusUpdatingId(null);
    }
  };

  if (loading) {
    return <ListPageSkeleton statsCount={3} tableRows={8} tableColumns={7} />;
  }

  return (
    <div className="w-full p-2 lg:px-4 lg:py-3">
      <PageHeader
        title="Amenities Management"
        subtitle={`${totalAmenities} Total Amenities`}
      >
        <button
          onClick={openAddModal}
          className="flex items-center gap-1.5 px-3 py-2 text-[11px] rounded-sm bg-blue-600 text-white font-semibold hover:bg-blue-500 transition-colors cursor-pointer"
        >
          <Plus size={13} />
          Add Amenity
        </button>
      </PageHeader>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-2 mb-4">
        {stats.map((item, index) => (
          <StatCard key={index} {...item} />
        ))}
      </div>

      <div className="flex flex-col xl:flex-row gap-3 mb-4">
        {/* Search */}
        <div className="relative flex-1">
          <Search
            size={14}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6b7280]"
          />

          <input
            value={searchText}
            onChange={(e) => {
              setSearchText(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Search amenities..."
            className="w-full h-8 pl-9 pr-3 rounded-[8px] text-[11px] bg-[#14141A] border border-[#1F1F27] text-[#a0a0a0] outline-none"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 mt-1">
          {filters.map((item) => (
            <button
              key={item}
              onClick={() => {
                setCurrentPage(1);

                if (item === "All") {
                  setStatus("");
                } else if (item === "Active") {
                  setStatus(1);
                } else if (item === "Inactive") {
                  setStatus(0);
                }
              }}
              className={`h-6 px-3 rounded-sm text-[10px] border cursor-pointer
                ${
                  (item === "All" && status === "") ||
                  (item === "Active" && status === 1) ||
                  (item === "Inactive" && status === 0)
                    ? "bg-blue-600/10 border-blue-600 text-blue-400"
                    : "bg-[#11131d] border-[#1f2333] text-[#a0a0a0]"
                }`}
            >
              {item}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
        <div className="flex justify-between items-center px-6 py-2 border-b border-[#1f2333]">
          <h2 className="text-sm font-bold text-white">All Amenities</h2>

          <span className="text-gray-400 text-[10px]">
            Showing{" "}
            {totalAmenities === 0 ? 0 : (currentPage - 1) * perPage + 1}-
            {Math.min(currentPage * perPage, totalAmenities)}
            of {totalAmenities}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px]">
            <thead>
              <tr className="border-b border-[#1f2333] text-gray-500 text-[8px]">
                <th className="text-left px-4 py-2">Sr No</th>
                <th className="text-left">Icon</th>
                <th className="text-left">Amenity Name</th>
                <th className="text-left">Slug</th>
                <th className="text-left">Status</th>
                <th className="text-left">Created At</th>
                <th className="text-left">Action</th>
              </tr>
            </thead>

            <tbody>
              {tableLoading ? (
                <tr>
                  <td colSpan="7" className="text-center py-10 text-white">
                    Loading...
                  </td>
                </tr>
              ) : amenities.length === 0 ? (
                <tr>
                  <td colSpan="7" className="text-center py-10 text-gray-400">
                    No data found
                  </td>
                </tr>
              ) : (
                amenities.map((amenity, index) => (
                  <tr
                    key={amenity.id}
                    className="border-b border-[#1f2333] hover:bg-[#161926]"
                  >
                    <td className="pl-8 text-[11px] text-[#C0C0C0]">
                      {(currentPage - 1) * perPage + index + 1}
                    </td>

                    <td>
                      <img
                        src={amenity.icon}
                        className="w-8 h-8 object-contain"
                        alt=""
                      />
                    </td>

                    <td className="text-white text-[11px]">{amenity.name}</td>

                    <td className="text-[#C0C0C0] text-[11px]">
                      {amenity.slug}
                    </td>

                    <td>
                      <button
                        onClick={() => handleToggleStatus(amenity)}
                        disabled={statusUpdatingId === amenity.id}
                        className={`flex items-center gap-1 px-2 py-1 rounded-[6px] text-[9px] font-semibold cursor-pointer transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                          amenity.status?.label === "Active"
                            ? "bg-green-500/15 text-green-400 hover:bg-green-500/25"
                            : "bg-yellow-500/15 text-yellow-400 hover:bg-yellow-500/25"
                        }`}
                        title="Click to toggle status"
                      >
                        {statusUpdatingId === amenity.id && (
                          <Loader2 size={10} className="animate-spin" />
                        )}
                        {amenity.status?.label}
                      </button>
                    </td>

                    <td className="text-[#C0C0C0] text-[11px]">
                      {amenity.created_at}
                    </td>

                    <td>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => openEditModal(amenity)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-[6px] text-[9px] font-semibold bg-blue-600/10 border border-blue-600/40 text-blue-400 hover:bg-blue-600/20 cursor-pointer"
                        >
                          <Pencil size={11} />
                          Edit
                        </button>
                        <button
                          onClick={() => confirmDelete(amenity)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-[6px] text-[9px] font-semibold bg-red-500/10 border border-red-500/40 text-red-400 hover:bg-red-500/20 cursor-pointer"
                        >
                          <Trash2 size={11} />
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="flex justify-between items-center px-4 py-2">
          <span className="text-gray-400 text-[10px]">
            Page {currentPage} of {lastPage}
          </span>

          <div className="flex gap-2">
            <button
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(currentPage - 1)}
              className="w-7 h-7 rounded-[7px] bg-[#161926] disabled:opacity-40"
            >
              ←
            </button>

            <button className="w-7 h-7 rounded-[7px] bg-blue-600 text-white">
              {currentPage}
            </button>

            <button
              disabled={currentPage === lastPage}
              onClick={() => setCurrentPage(currentPage + 1)}
              className="w-7 h-7 rounded-[7px] bg-[#161926] disabled:opacity-40"
            >
              →
            </button>
          </div>
        </div>
      </div>

      {/* ═══════════════ ADD / EDIT MODAL ═══════════════ */}
      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
          onClick={closeModal}
        >
          <div
            className="w-full max-w-md bg-[#14141A] border border-[#1F1F27] rounded-[14px] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#1F1F27]">
              <h3 className="text-[13px] font-bold text-white font-['Poppins',sans-serif]">
                {modalMode === "add" ? "Add Amenity" : "Edit Amenity"}
              </h3>
              <button
                onClick={closeModal}
                disabled={submitting}
                className="w-7 h-7 rounded-full bg-[#1F1F27] flex items-center justify-center text-[#A0A0A0] hover:text-white cursor-pointer disabled:opacity-50"
              >
                <X size={14} />
              </button>
            </div>

            {modalLoading ? (
              <div className="flex items-center justify-center py-16">
                <Loader2 size={22} className="animate-spin text-blue-500" />
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="px-5 py-4">
                {formErrors.form && (
                  <div className="mb-3 flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-[8px] px-3 py-2 text-[10px] text-red-400">
                    <AlertTriangle size={13} className="shrink-0" />
                    {formErrors.form}
                  </div>
                )}

                {/* Amenity Name */}
                <div className="mb-4">
                  <label className="block text-[9px] text-[#A0A0A0] uppercase tracking-wide font-semibold mb-1.5">
                    Amenity Name
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        name: formatSportName(e.target.value),
                      }))
                    }
                    placeholder="e.g. Drinking Water"
                    className={`w-full h-9 px-3 rounded-[8px] text-[11px] bg-[#1F1F27] border text-white placeholder:text-[#555] outline-none ${
                      formErrors.name
                        ? "border-red-500"
                        : "border-[#2a2a35] focus:border-blue-600"
                    }`}
                  />
                  {formErrors.name && (
                    <p className="text-[9px] text-red-400 mt-1">
                      {formErrors.name}
                    </p>
                  )}
                </div>


                {/* Icon */}
                <div className="mb-4">
                  <label className="block text-[9px] text-[#A0A0A0] uppercase tracking-wide font-semibold mb-1.5">
                    Icon
                  </label>
                  <input
                    ref={iconInputRef}
                    type="file"
                    accept="image/png,image/jpeg,image/svg+xml,image/webp"
                    onChange={handleFileChange}
                    className="hidden"
                    id="icon_input"
                  />
                  <label
                    htmlFor="icon_input"
                    className={`flex flex-col items-center justify-center gap-1.5 h-24 rounded-[10px] border border-dashed cursor-pointer ${
                      formErrors.icon
                        ? "border-red-500"
                        : "border-[#2a2a35] hover:border-blue-600"
                    }`}
                  >
                    {iconPreview ? (
                      <img
                        src={iconPreview}
                        alt="Icon preview"
                        className="w-10 h-10 object-contain"
                      />
                    ) : (
                      <ImagePlus size={18} className="text-[#555]" />
                    )}
                    <span className="text-[8px] text-[#A0A0A0]">
                      {iconFile ? iconFile.name : "Upload PNG/SVG"}
                    </span>
                  </label>
                  {formErrors.icon && (
                    <p className="text-[9px] text-red-400 mt-1">
                      {formErrors.icon}
                    </p>
                  )}
                </div>

                {/* Status */}
                <div className="mb-5">
                  <label className="block text-[9px] text-[#A0A0A0] uppercase tracking-wide font-semibold mb-1.5">
                    Status
                  </label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        setFormData((prev) => ({ ...prev, status: 1 }))
                      }
                      className={`flex-1 h-8 rounded-[8px] text-[10px] font-semibold cursor-pointer ${
                        formData.status === 1
                          ? "bg-green-500/15 border border-green-500/50 text-green-400"
                          : "bg-[#1F1F27] border border-[#2a2a35] text-[#A0A0A0]"
                      }`}
                    >
                      Active
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setFormData((prev) => ({ ...prev, status: 0 }))
                      }
                      className={`flex-1 h-8 rounded-[8px] text-[10px] font-semibold cursor-pointer ${
                        formData.status === 0
                          ? "bg-yellow-500/15 border border-yellow-500/50 text-yellow-400"
                          : "bg-[#1F1F27] border border-[#2a2a35] text-[#A0A0A0]"
                      }`}
                    >
                      Inactive
                    </button>
                  </div>
                </div>

                <div className="flex gap-2 justify-end">
                  <button
                    type="button"
                    onClick={closeModal}
                    disabled={submitting}
                    className="px-4 py-2 rounded-[8px] text-[11px] font-semibold bg-[#1F1F27] text-[#A0A0A0] cursor-pointer disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-[8px] text-[11px] font-semibold bg-blue-600 text-white hover:bg-blue-500 cursor-pointer disabled:opacity-60"
                  >
                    {submitting && (
                      <Loader2 size={13} className="animate-spin" />
                    )}
                    {modalMode === "add" ? "Add Amenity" : "Save Changes"}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* ═══════════════ DELETE CONFIRM MODAL ═══════════════ */}
      {deleteTarget && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
          onClick={cancelDelete}
        >
          <div
            className="w-full max-w-sm bg-[#14141A] border border-[#1F1F27] rounded-[14px] p-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-11 h-11 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center mb-3">
              <AlertTriangle size={20} className="text-red-400" />
            </div>
            <h3 className="text-[13px] font-bold text-white mb-1.5">
              Delete “{deleteTarget.name}”?
            </h3>
            <p className="text-[10px] text-[#A0A0A0] mb-1">
              This will permanently remove this amenity. This action cannot
              be undone.
            </p>
            {deleteTarget._error && (
              <p className="text-[10px] text-red-400 mt-2">
                {deleteTarget._error}
              </p>
            )}
            <div className="flex gap-2 justify-end mt-4">
              <button
                onClick={cancelDelete}
                disabled={deleting}
                className="px-4 py-2 rounded-[8px] text-[11px] font-semibold bg-[#1F1F27] text-[#A0A0A0] cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                disabled={deleting}
                className="flex items-center gap-1.5 px-4 py-2 rounded-[8px] text-[11px] font-semibold bg-red-500 text-white hover:bg-red-400 cursor-pointer disabled:opacity-60"
              >
                {deleting && <Loader2 size={13} className="animate-spin" />}
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AmenitiesList;