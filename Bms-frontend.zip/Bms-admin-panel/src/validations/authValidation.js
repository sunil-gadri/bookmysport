// validations/authValidation.js

export const validateEmail = (email) => {

    if (!email.trim()) {
        return "Email is required";
    }

    const emailRegex =
        /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;

    if (!emailRegex.test(email)) {
        return "Please enter a valid email address";
    }

    return "";
};

export const validatePassword = (password) => {

    if (!password.trim()) {
        return "Password is required";
    }

    return "";
};

export const validateAdminLogin = (email, password) => {

    return {
        email: validateEmail(email),
        password: validatePassword(password),
    };

};


export const validateMobile = (mobile) => {
    if (!mobile.trim()) {
        return "Mobile number is required";
    }

    if (!/^[6-9]\d{9}$/.test(mobile)) {
        return "Please enter a valid mobile number";
    }

    return "";
};

export const validateOtp = (otp) => {
    if (!otp.trim()) {
        return "OTP is required";
    }

    if (otp.length !== 6) {
        return "OTP must be 6 digits";
    }

    return "";
};

export const validateFullName = (name) => {

    if (!name.trim()) {
        return "Full name is required";
    }

    if (name.trim().length < 3) {
        return "Please enter your full name";
    }

    return "";
};