
// profile validation file

export const validateProfile = (form, { requireName = false } = {}) => {
  const errors = {};

  // ---- Full name (Edit page only) ----
  if (requireName) {
    if (!form.name || !form.name.trim()) {
      errors.name = "Full name is required.";
    } else if (form.name.trim().length < 3) {
      errors.name = "Name must be at least 3 characters.";
    } else if (form.name.trim().length > 255) {
      errors.name = "Name is too long.";
    }
  }

  // ---- Business name ----
  if (!form.business_name || !form.business_name.trim()) {
    errors.business_name = "Business name is required.";
  } else if (form.business_name.trim().length < 3) {
    errors.business_name = "Business name must be at least 3 characters.";
  } else if (form.business_name.trim().length > 150) {
    errors.business_name = "Business name must be under 150 characters.";
  }

  // ---- Business email ----
  if (!form.business_email || !form.business_email.trim()) {
      errors.business_email = "Business email is required.";
  } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (!emailRegex.test(form.business_email.trim())) {
          errors.business_email = "Enter a valid email address.";
      }
  }

  // ---- Business phone (optional, but must look like a valid Indian mobile) ----
  if (form.business_phone && form.business_phone.trim()) {
    const phoneRegex = /^[6-9]\d{9}$/;
    if (!phoneRegex.test(form.business_phone.trim())) {
      errors.business_phone = "Enter a valid 10-digit phone number.";
    }
  }

  // ---- Address ----
  if (!form.address || !form.address.trim()) {
    errors.address = "Address is required.";
  }

  // ---- Location dropdowns ----
  if (!form.country_id) {
    errors.country_id = "Please select a country.";
  }
  if (!form.state_id) {
    errors.state_id = "Please select a state.";
  }
  if (!form.city_id) {
    errors.city_id = "Please select a city.";
  }

  // ---- Pincode ----
  if (!form.pincode || !form.pincode.trim()) {
    errors.pincode = "Pincode is required.";
  } else {
    const pinRegex = /^\d{6}$/;

    if (!pinRegex.test(form.pincode.trim())) {
      errors.pincode = "Enter a valid 6-digit pincode.";
    }
  }
  
  // ---- Description ----
  if (!form.description || !form.description.trim()) {
      errors.description = "Description is required.";
  } else if (form.description.trim().length < 10) {
      errors.description = "Description must be at least 10 characters.";
  }

  return errors;
};