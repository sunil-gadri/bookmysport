
// formatter file

export const formatFullName = (value) => {
  return value
    .replace(/[^a-zA-Z\s]/g, "") // Allow only letters and spaces
    .toLowerCase()
    .replace(/\b\w/g, (char) => char.toUpperCase());
};

export const getInitials = (fullName) => {
  if (!fullName || !fullName.trim()) return "";

  const words = fullName.trim().split(/\s+/);

  if (words.length === 1) {
    return words[0].charAt(0).toUpperCase();
  }

  return (
    words[0].charAt(0) +
    words[words.length - 1].charAt(0)
  ).toUpperCase();
};

export const getAvatarColor = (index) => {
  const colors = [
    {
      bg: "bg-[#2979ff20]",
      text: "text-[#2979FF]",
    },
    {
      bg: "bg-[#00E67615]",
      text: "text-[#00E676]",
    },
    {
      bg: "bg-[#FFB30015]",
      text: "text-[#FFB300]",
    },
    {
      bg: "bg-[#FF525215]",
      text: "text-[#FF5252]",
    },
  ];

  return colors[index % colors.length];
};

export const formatTitleCase = (value) => {
  return value
    .replace(/[^a-zA-Z\s]/g, "")
    .replace(/\s+/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());
};


export const formatAddress = (value) => {
  return value
    .replace(/[^a-zA-Z0-9\s,./-]/g, "")
    .replace(/\s+/g, " ")
    .trimStart()
    .replace(/\b[a-z]/g, (char) => char.toUpperCase());
};

export const formatDescription = (value) => {
  return value
    .replace(/\s+/g, " ")
    .replace(/(^\s*[a-z])|([.!?]\s+[a-z])/g, (match) =>
      match.toUpperCase()
    );
};


export const formatNumber = (value, maxLength = null) => {
  let numbers = value.replace(/\D/g, "");

  if (maxLength) {
    numbers = numbers.slice(0, maxLength);
  }

  return numbers;
};


export const formatSportName = (value) => {
  return value
    .replace(/[^a-zA-Z\s]/g, "") // Allow only letters and spaces
    .replace(/\s+/g, " ")        // Remove extra spaces
    .toLowerCase()               // Convert everything to lowercase first
    .replace(/\b\w/g, (char) => char.toUpperCase()); // Capitalize each word
};
