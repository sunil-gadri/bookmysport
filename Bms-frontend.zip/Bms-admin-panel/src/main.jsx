import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import { Toaster } from "sonner";
import "./index.css";
import "react-toastify/dist/ReactToastify.css";
import "react-loading-skeleton/dist/skeleton.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
      <Toaster
        position="top-right"
        richColors
        closeButton
        theme="dark"
        toastOptions={{
          duration: 2500,
          style: {
            fontSize: "12px",
            padding: "8px 12px",
            minHeight: "40px",
            borderRadius: "8px",
            width: "300px",
          },
        }}
      />
    </BrowserRouter>
  </React.StrictMode>,
);
