import { Routes, Route, Navigate } from "react-router-dom";

// Layout
import Layout from "../components/layout/Layout";

// Auth
import Login from "../pages/auth/Login";
import ProtectedRoute from "./ProtectedRoute";

// Admin Pages
import Dashboard from "../pages/dashboard/Dashboard";
import UserList from "../pages/users/UserList";
import SportList from "../pages/Sports/SportList";
import EventList from "../pages/Events/EventList";
import AmenitiesList from "../pages/Amenities/AmenitiesList";
import BookingList from "../pages/Bookings/BookingList";
import TurfList from "../pages/Turfs/TurfList";
import SlotManager from "../pages/SlotManager/Slotmanager";

// Turf Owner Pages
import TurfOwnerDashboard from "../pages/dashboard/Turfownerdashboard";
import TurfOwnerProfile from "../pages/TurfOwner/Profile/TurfOwnerProfile";
import EditTurfOwnerProfile from "../pages/TurfOwner/Profile/EditTurfOwnerProfile";

import AddTurf from "../pages/TurfOwner/Turf/AddTurf";
import MyTurfs from "../pages/TurfOwner/Turf/MyTurfs";
import TurfView from "../pages/TurfOwner/Turf/TurfView";
import EditTurf from "../pages/TurfOwner/Turf/EditTurf";

import AddSlot from "../pages/TurfOwner/Slot/AddSlot";
import SlotList from "../pages/TurfOwner/Slot/SlotList";
import EditSlot from "../pages/TurfOwner/Slot/EditSlot";

import TurfOwnerBookings from "../pages/Bookings/TurfOwnerBookings";


// =====================================================
// ROLE BASED REDIRECT
// =====================================================

function RoleBasedRedirect() {
  const user = JSON.parse(localStorage.getItem("user"));

  // User not logged in
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // Admin
  if (user.role === "admin") {
    return <Navigate to="/dashboard" replace />;
  }

  // Turf Owner
  if (user.role === "turf_owner") {
    return <Navigate to="/turfowner-dashboard" replace />;
  }

  // Unknown role
  return <Navigate to="/login" replace />;
}


// =====================================================
// APP ROUTES
// =====================================================

export default function AppRoutes() {
  return (
    <Routes>

      {/* =================================================
          LOGIN
      ================================================= */}

      <Route path="/login" element={<Login />} />


      {/* =================================================
          PROTECTED LAYOUT
      ================================================= */}

      <Route
        path="/"
        element={
          <ProtectedRoute allowedRoles={["admin", "turf_owner"]}>
            <Layout />
          </ProtectedRoute>
        }
      >

        {/* =================================================
            ROOT
        ================================================= */}

        <Route index element={<RoleBasedRedirect />} />


        {/* =================================================
            ADMIN DASHBOARD
        ================================================= */}

        <Route
          path="dashboard"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <Dashboard />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            ADMIN - USERS
        ================================================= */}

        <Route
          path="users"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <UserList />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            ADMIN - SPORTS
        ================================================= */}

        <Route
          path="sports"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <SportList />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            ADMIN - EVENTS
        ================================================= */}

        <Route
          path="events"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <EventList />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            ADMIN - AMENITIES
        ================================================= */}

        <Route
          path="amentities"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <AmenitiesList />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            ADMIN - BOOKINGS
        ================================================= */}

        <Route
          path="bookings"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <BookingList />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            ADMIN - TURFS
        ================================================= */}

        <Route
          path="turfs"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <TurfList />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            ADMIN - SLOT MANAGER
        ================================================= */}

        <Route
          path="slot-manager"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <SlotManager />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            TURF OWNER DASHBOARD
        ================================================= */}

        <Route
          path="turfowner-dashboard"
          element={
            <ProtectedRoute allowedRoles={["turf_owner"]}>
              <TurfOwnerDashboard />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            TURF OWNER PROFILE
        ================================================= */}

        <Route
          path="turfowner-profile"
          element={
            <ProtectedRoute allowedRoles={["turf_owner"]}>
              <TurfOwnerProfile />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            EDIT TURF OWNER PROFILE
        ================================================= */}

        <Route
          path="update-profile"
          element={
            <ProtectedRoute allowedRoles={["turf_owner"]}>
              <EditTurfOwnerProfile />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            TURF OWNER - ADD TURF
        ================================================= */}

        <Route
          path="my-turfs/new"
          element={
            <ProtectedRoute allowedRoles={["turf_owner"]}>
              <AddTurf />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            TURF OWNER - MY TURFS
        ================================================= */}

        <Route
          path="my-turfs"
          element={
            <ProtectedRoute allowedRoles={["turf_owner"]}>
              <MyTurfs />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            TURF OWNER - VIEW TURF
        ================================================= */}

        <Route
          path="view-turf/:id"
          element={
            <ProtectedRoute allowedRoles={["turf_owner"]}>
              <TurfView />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            TURF OWNER - EDIT TURF
        ================================================= */}

        <Route
          path="my-turfs/:id/edit"
          element={
            <ProtectedRoute allowedRoles={["turf_owner"]}>
              <EditTurf />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            TURF OWNER - ADD SLOT
        ================================================= */}

        <Route
          path="slot-masters/new"
          element={
            <ProtectedRoute allowedRoles={["turf_owner"]}>
              <AddSlot />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            TURF OWNER - SLOT LIST
        ================================================= */}

        <Route
          path="slots"
          element={
            <ProtectedRoute allowedRoles={["turf_owner"]}>
              <SlotList />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            TURF OWNER - EDIT SLOT
        ================================================= */}

        <Route
          path="slot-masters/:id/edit"
          element={
            <ProtectedRoute allowedRoles={["turf_owner"]}>
              <EditSlot />
            </ProtectedRoute>
          }
        />


        {/* =================================================
            TURF OWNER - BOOKINGS
        ================================================= */}

        <Route
          path="turf-bookings"
          element={
            <ProtectedRoute allowedRoles={["turf_owner"]}>
              <TurfOwnerBookings />
            </ProtectedRoute>
          }
        />

      </Route>


      {/* =================================================
          FALLBACK ROUTE
      ================================================= */}

      <Route path="*" element={<RoleBasedRedirect />} />

    </Routes>
  );
}