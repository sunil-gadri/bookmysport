import { Navigate } from "react-router-dom";
import { getToken, getRole } from "../utils/auth";

const ProtectedRoute = ({ children, allowedRoles }) => {
  const token = getToken();
  const role = getRole();

  // User login nahi hai
  if (!token) {
    return <Navigate to="/login" replace />;
  }

  // Agar role allowed nahi hai
  if (allowedRoles && !allowedRoles.includes(role)) {
    // Admin ko admin dashboard par bhejo
    if (role === "admin") {
      return <Navigate to="/dashboard" replace />;
    }

    // Turf Owner ko turf owner dashboard par bhejo
    if (role === "turf_owner") {
      return <Navigate to="/turfowner-dashboard" replace />;
    }

    // Unknown role
    return <Navigate to="/login" replace />;
  }

  // Authorized user
  return children;
};

export default ProtectedRoute;