import api from "../api/axios";

// Admin Login
export const adminLogin = async (data) => {
    return await api.post("/admin/login", data);
};

// Send OTP
export const sendOtp = async (data) => {
    return await api.post("/send-otp", data);
};

// Verify OTP
export const verifyOtp = async (data) => {
    return await api.post("/verify-otp", data);
};

export const logoutUser = async () => {
    return await api.post("/logout");
};