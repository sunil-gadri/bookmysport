// ── Mock Data ────────────────────────────────────────────────────────────────
export const USERS = [
  { id:1,  initials:"AS", name:"Arjun Sharma",   email:"arjun@gmail.com",   phone:"+91 98765 43210", role:"User",       bookings:24, spent:18400, status:"Active",    joined:"Mar 2024", color:"#2979FF", city:"Jaipur", dob:"15 Mar 1998", sports:["Football","Cricket"] },
  { id:2,  initials:"PM", name:"Priya Mehra",    email:"priya@gmail.com",   phone:"+91 99887 65432", role:"Owner",      bookings:8,  spent:6200,  status:"Active",    joined:"Jan 2024", color:"#00E676", city:"Jaipur", dob:"22 Jul 1995", sports:["Badminton"] },
  { id:3,  initials:"RK", name:"Rahul Kumar",    email:"rahul@email.com",   phone:"+91 97654 32109", role:"User",       bookings:16, spent:12800, status:"Suspended", joined:"May 2024", color:"#FFB300", city:"Jaipur", dob:"08 Nov 1992", sports:["Cricket","Football"] },
  { id:4,  initials:"SJ", name:"Simran Joshi",   email:"simran@yahoo.com",  phone:"+91 91234 56789", role:"User",       bookings:5,  spent:3500,  status:"Banned",    joined:"Jun 2024", color:"#FF5252", city:"Jaipur", dob:"14 Jan 2000", sports:["Swimming"] },
  { id:5,  initials:"MV", name:"Mohit Verma",    email:"mohit@hotmail.com", phone:"+91 88888 77777", role:"Owner",      bookings:42, spent:31000, status:"Active",    joined:"Dec 2023", color:"#2979FF", city:"Jaipur", dob:"03 Sep 1988", sports:["Football","Cricket"] },
  { id:6,  initials:"NK", name:"Neha Kapoor",    email:"neha@gmail.com",    phone:"+91 93456 78901", role:"User",       bookings:11, spent:8800,  status:"Active",    joined:"Apr 2024", color:"#00E676", city:"Jaipur", dob:"29 Feb 1996", sports:["Badminton","Tennis"] },
  { id:7,  initials:"VS", name:"Vikram Singh",   email:"vikram@email.com",  phone:"+91 94567 89012", role:"Owner",      bookings:7,  spent:5600,  status:"Active",    joined:"Feb 2024", color:"#FFB300", city:"Jaipur", dob:"17 Jun 1991", sports:["Swimming"] },
  { id:8,  initials:"AR", name:"Ananya Rao",     email:"ananya@gmail.com",  phone:"+91 95678 90123", role:"Owner",      bookings:19, spent:15200, status:"Active",    joined:"Nov 2023", color:"#FF5252", city:"Jaipur", dob:"05 Aug 1993", sports:["Tennis"] },
  { id:9,  initials:"RS", name:"Rohit Shah",     email:"rohit@gmail.com",   phone:"+91 96789 01234", role:"User",       bookings:3,  spent:2400,  status:"Active",    joined:"Jun 2024", color:"#2979FF", city:"Jaipur", dob:"12 Dec 1998", sports:["Football"] },
  { id:10, initials:"DG", name:"Deepa Gupta",    email:"deepa@email.com",   phone:"+91 97890 12345", role:"User",       bookings:9,  spent:7200,  status:"Active",    joined:"Mar 2024", color:"#00E676", city:"Jaipur", dob:"28 Oct 1994", sports:["Badminton"] },
];

export const TURFS = [
  { id:1, emoji:"🏟️", bg:"#0a2a1a", name:"Green Arena FC",   location:"Vaishali Nagar", city:"Jaipur", sport:"Football",  price:800,  rating:4.8, reviews:247, bookings:142, occupancy:92, revenue:110000, status:"Active",   owner:"Mohit Verma",  ownerId:5, facilities:["Parking","Flood Lights","Change Room","Drinking Water"], size:"5-a-side",   surface:"Synthetic Turf",  openTime:"06:00", closeTime:"23:00", description:"Premium 5-a-side football turf with synthetic grass, flood lighting, and professional goal posts." },
  { id:2, emoji:"🏸", bg:"#1a0a2a", name:"Shuttle Kings",    location:"Mansarovar",    city:"Jaipur", sport:"Badminton", price:350,  rating:4.7, reviews:183, bookings:98,  occupancy:87, revenue:34000,  status:"Active",   owner:"Priya Mehra",  ownerId:2, facilities:["Parking","Change Room","AC Hall"],                        size:"2 Courts",   surface:"Wooden Court",    openTime:"05:00", closeTime:"22:00", description:"Air-conditioned badminton courts with international-grade wooden flooring." },
  { id:3, emoji:"🎾", bg:"#2a1a0a", name:"Tennis Pro Court", location:"C-Scheme",      city:"Jaipur", sport:"Tennis",    price:500,  rating:4.5, reviews:62,  bookings:31,  occupancy:61, revenue:15000,  status:"Pending",  owner:"Ananya Rao",   ownerId:8, facilities:["Parking","Flood Lights"],                                  size:"2 Courts",   surface:"Hard Court",      openTime:"06:00", closeTime:"21:00", description:"Professional-grade hard courts for singles and doubles play." },
  { id:4, emoji:"🏊", bg:"#0a1a2a", name:"AquaZone Pool",    location:"Tonk Road",     city:"Jaipur", sport:"Swimming",  price:600,  rating:4.6, reviews:94,  bookings:67,  occupancy:72, revenue:40200,  status:"Active",   owner:"Vikram Singh", ownerId:7, facilities:["Change Room","Lockers","Cafeteria"],                       size:"Olympic",    surface:"Water",           openTime:"05:30", closeTime:"21:00", description:"Olympic-standard swimming pool with trained lifeguards and coaching available." },
  { id:5, emoji:"🏏", bg:"#1a1a0a", name:"Cricket Ground",   location:"Sitapura",      city:"Jaipur", sport:"Cricket",   price:1200, rating:4.9, reviews:312, bookings:156, occupancy:95, revenue:92000,  status:"Active",   owner:"Mohit Verma",  ownerId:5, facilities:["Parking","Flood Lights","Nets","Cafeteria"],               size:"Full Pitch", surface:"Natural Grass",   openTime:"05:00", closeTime:"22:00", description:"Full-size cricket ground with professionally maintained natural grass and batting nets." },
  { id:6, emoji:"🥊", bg:"#2a0a1a", name:"Fighter's Den",    location:"Malviya Nagar", city:"Jaipur", sport:"Boxing",    price:400,  rating:4.4, reviews:48,  bookings:22,  occupancy:44, revenue:8800,   status:"Inactive", owner:"Rahul Kumar",  ownerId:3, facilities:["Change Room","Bag Area"],                                  size:"Ring + Gym", surface:"Canvas Ring",     openTime:"06:00", closeTime:"20:00", description:"Professional boxing ring with heavy bags, speed bags, and full gym equipment." },
];

export const BOOKINGS = [
  { id:"#BMS2024891", userId:1, initials:"AS", color:"#2979FF", user:"Arjun Sharma",  turf:"Green Arena FC",   turfId:1, date:"20 Jun 2026", slot:"10:00 AM",  amount:800,  method:"UPI",    status:"Confirmed", sport:"Football"  },
  { id:"#BMS2024890", userId:2, initials:"PM", color:"#00E676", user:"Priya Mehra",   turf:"Shuttle Kings",    turfId:2, date:"20 Jun 2026", slot:"07:00 AM",  amount:350,  method:"Pending",status:"Pending",   sport:"Badminton" },
  { id:"#BMS2024885", userId:3, initials:"RK", color:"#FFB300", user:"Rahul Kumar",   turf:"Tennis Pro Court", turfId:3, date:"19 Jun 2026", slot:"06:00 PM",  amount:500,  method:"Card",   status:"Confirmed", sport:"Tennis"    },
  { id:"#BMS2024880", userId:4, initials:"SJ", color:"#FF5252", user:"Simran Joshi",  turf:"AquaZone Pool",    turfId:4, date:"19 Jun 2026", slot:"08:00 AM",  amount:600,  method:"Refund", status:"Cancelled", sport:"Swimming"  },
  { id:"#BMS2024877", userId:5, initials:"MV", color:"#2979FF", user:"Mohit Verma",   turf:"Cricket Ground",   turfId:5, date:"18 Jun 2026", slot:"05:00 PM",  amount:1200, method:"Wallet", status:"Confirmed", sport:"Cricket"   },
  { id:"#BMS2024871", userId:6, initials:"NK", color:"#00E676", user:"Neha Kapoor",   turf:"Green Arena FC",   turfId:1, date:"18 Jun 2026", slot:"07:00 AM",  amount:800,  method:"UPI",    status:"Confirmed", sport:"Football"  },
  { id:"#BMS2024866", userId:7, initials:"VS", color:"#FFB300", user:"Vikram Singh",  turf:"Shuttle Kings",    turfId:2, date:"17 Jun 2026", slot:"09:00 AM",  amount:350,  method:"Card",   status:"Confirmed", sport:"Badminton" },
  { id:"#BMS2024861", userId:8, initials:"AR", color:"#FF5252", user:"Ananya Rao",    turf:"Cricket Ground",   turfId:5, date:"17 Jun 2026", slot:"03:00 PM",  amount:1200, method:"UPI",    status:"Confirmed", sport:"Cricket"   },
  { id:"#BMS2024855", userId:9, initials:"RS", color:"#2979FF", user:"Rohit Shah",    turf:"Green Arena FC",   turfId:1, date:"16 Jun 2026", slot:"06:00 PM",  amount:800,  method:"Card",   status:"Cancelled", sport:"Football"  },
  { id:"#BMS2024850", userId:10,initials:"DG", color:"#00E676", user:"Deepa Gupta",   turf:"Shuttle Kings",    turfId:2, date:"15 Jun 2026", slot:"08:00 AM",  amount:350,  method:"Wallet", status:"Confirmed", sport:"Badminton" },
];

export const TRANSACTIONS = [
  { id:"TXN98712", userId:1, initials:"AS", color:"#2979FF", user:"Arjun Sharma",  booking:"#BMS2024891", method:"UPI",    amount:800,   type:"Payment", status:"Success",   time:"9:32 AM",   date:"20 Jun 2026" },
  { id:"TXN98709", userId:3, initials:"RK", color:"#FFB300", user:"Rahul Kumar",   booking:"#BMS2024885", method:"Card",   amount:500,   type:"Payment", status:"Success",   time:"8:10 AM",   date:"20 Jun 2026" },
  { id:"TXN98701", userId:4, initials:"SJ", color:"#FF5252", user:"Simran Joshi",  booking:"#BMS2024880", method:"Wallet", amount:-600,  type:"Refund",  status:"Processed", time:"7:45 AM",   date:"19 Jun 2026" },
  { id:"TXN98698", userId:5, initials:"MV", color:"#2979FF", user:"Mohit Verma",   booking:"#BMS2024877", method:"Wallet", amount:1200,  type:"Payment", status:"Success",   time:"5:12 PM",   date:"18 Jun 2026" },
  { id:"TXN98690", userId:6, initials:"NK", color:"#00E676", user:"Neha Kapoor",   booking:"#BMS2024871", method:"UPI",    amount:800,   type:"Payment", status:"Success",   time:"7:02 AM",   date:"18 Jun 2026" },
  { id:"TXN98681", userId:7, initials:"VS", color:"#FFB300", user:"Vikram Singh",  booking:"#BMS2024866", method:"Card",   amount:350,   type:"Payment", status:"Success",   time:"9:05 AM",   date:"17 Jun 2026" },
  { id:"TXN98670", userId:2, initials:"PM", color:"#00E676", user:"Priya Mehra",   booking:"#BMS2024855", method:"UPI",    amount:-800,  type:"Refund",  status:"Processed", time:"11:30 AM",  date:"16 Jun 2026" },
];

export const SLOTS_TEMPLATE = [
  {time:"6 AM",  type:"booked",    user:"Arjun"},
  {time:"7 AM",  type:"booked",    user:"Priya"},
  {time:"8 AM",  type:"available"},
  {time:"9 AM",  type:"available"},
  {time:"10 AM", type:"booked",    user:"Rahul"},
  {time:"11 AM", type:"available"},
  {time:"12 PM", type:"blocked"},
  {time:"1 PM",  type:"available"},
  {time:"2 PM",  type:"available"},
  {time:"3 PM",  type:"available"},
  {time:"4 PM",  type:"available"},
  {time:"5 PM",  type:"booked",    user:"Simran"},
  {time:"6 PM",  type:"booked",    user:"Mohit"},
  {time:"7 PM",  type:"available"},
  {time:"8 PM",  type:"available"},
  {time:"9 PM",  type:"available"},
  {time:"10 PM", type:"blocked"},
  {time:"11 PM", type:"blocked"},
];

export const ADMINS = [
  { initials:"SA", name:"Super Admin",      email:"admin@bookmysport.in",  role:"Super Admin", color:"#FF5252", permissions:"full" },
  { initials:"RJ", name:"Rajesh Sharma",    email:"rajesh@bookmysport.in", role:"Manager",     color:"#FFB300", permissions:"manage" },
  { initials:"PK", name:"Pooja Kapoor",     email:"pooja@bookmysport.in",  role:"Support",     color:"#2979FF", permissions:"view" },
];

export const ACTIVITIES = [
  { dot:"#00E676", text:"New booking confirmed — Arjun S. booked Green Arena FC",  time:"2 min ago" },
  { dot:"#2979FF", text:"New user registered — Rohit S. (+91 96789)",              time:"6 min ago" },
  { dot:"#FFB300", text:"Payment received — ₹1,600 via UPI by Neha K.",            time:"12 min ago" },
  { dot:"#FF5252", text:"Booking cancelled — Simran J. Refund ₹600 initiated",     time:"18 min ago" },
  { dot:"#2979FF", text:"Turf review posted — Green Arena FC rated ⭐ 4.9",         time:"25 min ago" },
  { dot:"#00E676", text:"New turf submitted — Fighter's Den by Rahul K.",           time:"1 hr ago" },
  { dot:"#FFB300", text:"Dispute raised — TXN98670 by Priya M. Under review",      time:"2 hr ago" },
];

export const REVENUE_CHART = [
  {v:38,l:"1"},{v:52,l:"2"},{v:44,l:"3"},{v:60,l:"4"},{v:72,l:"5",peak:true},
  {v:56,l:"6"},{v:80,l:"7",peak:true},{v:64,l:"8"},{v:48,l:"9"},{v:58,l:"10"},
  {v:76,l:"11",peak:true},{v:62,l:"12"},{v:50,l:"13"},{v:80,l:"14",peak:true},
  {v:54,l:"15"},{v:44,l:"16"},{v:58,l:"17"},{v:78,l:"18",peak:true},
  {v:52,l:"19"},{v:38,l:"20",dim:true},
];

export const MONTHLY_REVENUE = [
  {v:180,l:"Jan"},{v:220,l:"Feb"},{v:195,l:"Mar"},{v:260,l:"Apr"},{v:305,l:"May"},{v:420,l:"Jun",peak:true}
];

export const USER_GROWTH = [
  {v:120,l:"Jan"},{v:180,l:"Feb"},{v:210,l:"Mar"},{v:290,l:"Apr"},{v:350,l:"May"},{v:412,l:"Jun",peak:true}
];

export const TOP_TURFS = [
  {name:"Green Arena FC",   rev:110000, pct:92},
  {name:"Cricket Ground",   rev:92000,  pct:78},
  {name:"AquaZone Pool",    rev:40200,  pct:58},
  {name:"Shuttle Kings",    rev:34000,  pct:46},
  {name:"Tennis Pro Court", rev:15000,  pct:28},
  {name:"Fighter's Den",    rev:8800,   pct:18},
];

export const SPORT_COLORS = {
  Football:"#2979FF", Cricket:"#00E676", Badminton:"#FFB300", Swimming:"#00BCD4", Tennis:"#AB47BC", Boxing:"#FF5252",
};

export const NOTIF_TEMPLATES = [
  { key:"booking_confirm",  label:"Booking Confirmation",     channels:"SMS + Email + Push", on:true  },
  { key:"booking_reminder", label:"Booking Reminder (1hr)",   channels:"Push",               on:true  },
  { key:"cancel_alert",     label:"Cancellation Alert",       channels:"SMS + Email",        on:true  },
  { key:"payment_receipt",  label:"Payment Receipt",          channels:"Email",              on:true  },
  { key:"weekly_digest",    label:"Weekly Digest",            channels:"Email",              on:false },
  { key:"new_offers",       label:"New Offers & Deals",       channels:"Push + SMS",         on:true  },
];