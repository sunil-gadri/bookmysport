import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";

const STATUS_STYLES = {
  active: {
    text: "text-green-400",
    bg: "bg-green-500/10",
    border: "border-green-500/30",
    dot: "bg-green-400",
  },
  inactive: {
    text: "text-yellow-400",
    bg: "bg-yellow-500/10",
    border: "border-yellow-500/30",
    dot: "bg-yellow-400",
  },
};

const StatusDropdown = ({ currentLabel, onChange, size = "md" }) => {
  const [updating, setUpdating] = useState(false);
  const value = (currentLabel || "active").toLowerCase();
  const style = STATUS_STYLES[value] || STATUS_STYLES.active;
  const isSmall = size === "sm";
  const [selectedStatus, setSelectedStatus] = useState(
    (currentLabel || "active").toLowerCase(),
  );

  useEffect(() => {
    setSelectedStatus((currentLabel || "active").toLowerCase());
  }, [currentLabel]);

  const handleChange = async (e) => {
    const newStatus = e.target.value;

    if (newStatus === selectedStatus) return;

    // Update UI immediately
    setSelectedStatus(newStatus);

    setUpdating(true);

    try {
      const statusValue = newStatus === "active";

      await onChange(statusValue);

      toast.success("User status updated successfully.");
    } catch (error) {
      // Roll back if API fails
      setSelectedStatus(currentLabel.toLowerCase());

      toast.error(error?.response?.data?.message || "Failed to update status.");
    } finally {
      setUpdating(false);
    }
  };

  return (
    <div className="relative inline-flex items-center">
      <span
        className={`pointer-events-none absolute left-2.5 w-1.5 h-1.5 rounded-full ${style.dot} ${
          updating ? "animate-pulse" : ""
        }`}
      />

      <select
        value={selectedStatus}
        onChange={handleChange}
        disabled={updating}
        className={`appearance-none font-semibold rounded-[6px] border outline-none cursor-pointer transition-colors
          focus:ring-1 focus:ring-blue-600/60 disabled:opacity-50
          ${style.text} ${style.bg} ${style.border}
          ${isSmall ? "pl-6 pr-6 py-1 text-[9px]" : "pl-7 pr-7 py-1.5 text-[10.5px]"}
        `}
      >
        <option className="bg-[#11131d] text-green-400" value="active">
          Active
        </option>
        <option className="bg-[#11131d] text-yellow-400" value="inactive">
          Inactive
        </option>
      </select>

      <svg
        width="8"
        height="8"
        viewBox="0 0 10 6"
        fill="none"
        className={`pointer-events-none absolute ${isSmall ? "right-2" : "right-2.5"} ${style.text}`}
      >
        <path
          d="M1 1L5 5L9 1"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </div>
  );
};

export default StatusDropdown;
