import React from "react";

// Same visual language as ProfileSkeleton — pulse blocks on the
// #14141a / #1F1F27 card surfaces used across the turf-owner panel.

const TurfCardSkeleton = () => (
  <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden animate-pulse">
    <div className="h-36 bg-[#1a1a22]" />
    <div className="p-4 flex flex-col gap-3">
      <div className="h-3 w-3/4 bg-[#1f2333] rounded" />
      <div className="h-2.5 w-1/2 bg-[#1f2333] rounded" />
      <div className="flex gap-1.5">
        <div className="h-4 w-14 bg-[#1f2333] rounded-full" />
        <div className="h-4 w-14 bg-[#1f2333] rounded-full" />
      </div>
      <div className="grid grid-cols-3 gap-2 py-3 border-t border-b border-[#1f2333]">
        <div className="h-6 bg-[#1f2333] rounded" />
        <div className="h-6 bg-[#1f2333] rounded" />
        <div className="h-6 bg-[#1f2333] rounded" />
      </div>
      <div className="flex gap-2">
        <div className="h-8 flex-1 bg-[#1f2333] rounded-sm" />
        <div className="h-8 flex-1 bg-[#1f2333] rounded-sm" />
      </div>
    </div>
  </div>
);

const TurfListSkeleton = () => (
  <div className="w-full p-2 lg:px-4 lg:py-3">
    {/* Header row */}
    <div className="flex items-center justify-between mb-4">
      <div>
        <div className="h-5 w-32 bg-[#1f2333] rounded animate-pulse mb-2" />
        <div className="h-3 w-24 bg-[#1f2333] rounded animate-pulse" />
      </div>
      <div className="h-9 w-32 bg-[#1f2333] rounded-sm animate-pulse" />
    </div>

    {/* Toolbar row */}
    <div className="flex gap-3 mb-4">
      <div className="h-9 flex-1 bg-[#14141a] border border-[#1F1F27] rounded-[10px] animate-pulse" />
      <div className="h-9 w-64 bg-[#14141a] border border-[#1F1F27] rounded-[10px] animate-pulse" />
    </div>

    {/* Card grid */}
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <TurfCardSkeleton key={i} />
      ))}
    </div>
  </div>
);

export default TurfListSkeleton;
