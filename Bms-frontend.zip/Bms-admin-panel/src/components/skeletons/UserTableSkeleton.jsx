const UserTableSkeleton = ({ rows = 8 }) => {
  return (
    <>
      {Array.from({ length: rows }).map((_, index) => (
        <tr
          key={index}
          className="border-b border-[#1f2333] animate-pulse"
        >
          <td className="px-4 py-4">
            <div className="h-3 w-6 rounded bg-[#24242f]"></div>
          </td>

          <td className="px-4 py-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-[#24242f]"></div>

              <div>
                <div className="h-3 w-24 rounded bg-[#24242f] mb-2"></div>
                <div className="h-2 w-32 rounded bg-[#24242f]"></div>
              </div>
            </div>
          </td>

          <td><div className="h-3 w-24 rounded bg-[#24242f]"></div></td>
          <td><div className="h-3 w-16 rounded bg-[#24242f]"></div></td>
          <td><div className="h-3 w-24 rounded bg-[#24242f]"></div></td>
          <td><div className="h-3 w-24 rounded bg-[#24242f]"></div></td>
          <td><div className="h-3 w-24 rounded bg-[#24242f]"></div></td>
          <td><div className="h-6 w-16 rounded bg-[#24242f]"></div></td>
          <td><div className="h-3 w-24 rounded bg-[#24242f]"></div></td>
        </tr>
      ))}
    </>
  );
};

export default UserTableSkeleton;