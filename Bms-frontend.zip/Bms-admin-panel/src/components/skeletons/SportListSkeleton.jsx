import Skeleton from "react-loading-skeleton";

const SportListSkeleton = () => {
  return (
    <div className="w-full p-2 lg:px-4 lg:py-3">
      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <div>
          <Skeleton width={220} height={22} />
          <Skeleton width={140} height={12} className="mt-2" />
        </div>

        <Skeleton width={100} height={34} />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-2 mb-4">
        {[1, 2, 3].map((i) => (
          <div
            key={i}
            className="bg-[#14141A] rounded-[10px] border border-[#1F1F27] p-4"
          >
            <Skeleton circle width={40} height={40} />
            <Skeleton width={60} height={24} className="mt-4" />
            <Skeleton width={120} height={12} className="mt-2" />
          </div>
        ))}
      </div>

      {/* Search */}
      <div className="flex justify-between mb-4">
        <Skeleton width={300} height={32} />

        <div className="flex gap-2">
          <Skeleton width={70} height={28} />
          <Skeleton width={70} height={28} />
          <Skeleton width={70} height={28} />
        </div>
      </div>

      {/* Table */}
      <div className="bg-[#14141A] border border-[#1F1F27] rounded-[10px] p-4">
        {[1, 2, 3, 4, 5, 6, 7].map((row) => (
          <div
            key={row}
            className="grid grid-cols-8 gap-4 items-center py-4 border-b border-[#1F1F27]"
          >
            <Skeleton width={20} />
            <Skeleton circle width={32} height={32} />
            <Skeleton circle width={32} height={32} />
            <Skeleton width={120} />
            <Skeleton width={100} />
            <Skeleton width={60} />
            <Skeleton width={90} />
            <Skeleton width={55} height={24} />
          </div>
        ))}

        <div className="flex justify-between mt-5">
          <Skeleton width={90} />
          <div className="flex gap-2">
            <Skeleton width={30} height={30} />
            <Skeleton width={30} height={30} />
            <Skeleton width={30} height={30} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default SportListSkeleton;