import React from "react";

const Bar = ({ className = "" }) => (
  <div className={`bg-[#1F1F27] rounded-[6px] animate-pulse ${className}`} />
);

const SlotListSkeleton = () => {
  return (
    <div className="w-full p-2 lg:px-4 lg:py-3 animate-pulse">
      <div className="flex items-center justify-between mb-3">
        <div>
          <Bar className="h-5 w-32 mb-2" />
          <Bar className="h-3 w-40" />
        </div>
        <Bar className="h-9 w-32 rounded-sm" />
      </div>

      <div className="flex flex-col lg:flex-row gap-3 mb-4">
        <Bar className="h-9 flex-1 rounded-[10px]" />
        <Bar className="h-9 w-40 rounded-[10px]" />
        <Bar className="h-9 w-40 rounded-[10px]" />
        <Bar className="h-9 w-48 rounded-[10px]" />
      </div>

      <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
        <div className="px-4 py-3 border-b border-[#1f2333] flex gap-6">
          {Array.from({ length: 7 }).map((_, i) => (
            <Bar key={i} className="h-2.5 w-16" />
          ))}
        </div>
        {Array.from({ length: 6 }).map((_, i) => (
          <div
            key={i}
            className="px-4 py-4 border-b border-[#1f2333] last:border-b-0 flex items-center gap-6"
          >
            <Bar className="h-3 w-24" />
            <Bar className="h-5 w-20 rounded-full" />
            <Bar className="h-3 w-16" />
            <Bar className="h-3 w-28" />
            <Bar className="h-3 w-14" />
            <Bar className="h-5 w-16 rounded-[6px]" />
            <Bar className="h-6 w-6 rounded-[6px] ml-auto" />
          </div>
        ))}
      </div>
    </div>
  );
};

export default SlotListSkeleton;
