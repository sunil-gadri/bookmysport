import React from "react";

const Block = ({ className = "" }) => (
  <div className={`bg-[#1f2333] rounded animate-pulse ${className}`} />
);

const Card = ({ children, className = "" }) => (
  <div
    className={`bg-[#14141a] border border-[#1F1F27] rounded-[10px] p-6 ${className}`}
  >
    {children}
  </div>
);

const TurfViewSkeleton = () => (
  <div className="w-full p-2 lg:px-4 lg:py-3">
    <Block className="h-3 w-32 mb-4" />

    <div className="flex items-center justify-between mb-4">
      <div>
        <Block className="h-5 w-48 mb-2" />
        <Block className="h-3 w-64" />
      </div>
      <Block className="h-9 w-28 rounded-sm" />
    </div>

    <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">
      <div className="xl:col-span-2 flex flex-col gap-3">
        <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
          <div className="h-72 sm:h-96 bg-[#1a1a22] animate-pulse" />
          <div className="flex gap-2 p-3">
            <Block className="w-16 h-16 rounded-[8px]" />
            <Block className="w-16 h-16 rounded-[8px]" />
            <Block className="w-16 h-16 rounded-[8px]" />
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <div
              key={i}
              className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] p-4 flex items-center gap-3"
            >
              <Block className="w-9 h-9 rounded-[8px]" />
              <div className="flex-1">
                <Block className="h-2 w-10 mb-2" />
                <Block className="h-3 w-8" />
              </div>
            </div>
          ))}
        </div>

        <Card>
          <Block className="h-3 w-full mb-2" />
          <Block className="h-3 w-4/5" />
        </Card>

        <Card>
          <Block className="h-2 w-24 mb-3" />
          <div className="flex gap-2 mb-4">
            <Block className="h-5 w-16 rounded-full" />
            <Block className="h-5 w-16 rounded-full" />
          </div>
          <Block className="h-2 w-24 mb-3" />
          <div className="flex gap-2">
            <Block className="h-5 w-16 rounded-full" />
            <Block className="h-5 w-16 rounded-full" />
            <Block className="h-5 w-16 rounded-full" />
          </div>
        </Card>
      </div>

      <div className="flex flex-col gap-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i}>
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3">
                <Block className="w-7 h-7 rounded-[6px]" />
                <div className="flex-1">
                  <Block className="h-2 w-16 mb-2" />
                  <Block className="h-3 w-24" />
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Block className="w-7 h-7 rounded-[6px]" />
                <div className="flex-1">
                  <Block className="h-2 w-16 mb-2" />
                  <Block className="h-3 w-24" />
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  </div>
);

export default TurfViewSkeleton;
