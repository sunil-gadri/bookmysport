const UserListSkeleton = () => {
  return (
    <div className="w-full p-2 lg:px-4 lg:py-3 animate-pulse">

      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <div>
          <div className="h-6 w-40 bg-[#23232e] rounded mb-2"></div>
          <div className="h-3 w-56 bg-[#23232e] rounded"></div>
        </div>

        <div className="flex gap-2">
          <div className="h-8 w-24 rounded bg-[#23232e]"></div>
          <div className="h-8 w-24 rounded bg-[#23232e]"></div>
        </div>
      </div>

      {/* Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-2 mb-4">
        {Array.from({ length: 4 }).map((_, index) => (
          <div
            key={index}
            className="h-28 rounded-xl bg-[#23232e]"
          />
        ))}
      </div>

      {/* Search */}
      <div className="flex gap-3 mb-4">
        <div className="h-8 flex-1 rounded bg-[#23232e]" />

        <div className="h-8 w-20 rounded bg-[#23232e]" />
        <div className="h-8 w-20 rounded bg-[#23232e]" />
        <div className="h-8 w-20 rounded bg-[#23232e]" />
      </div>

      {/* Table */}
      <div className="rounded-xl border border-[#1f2333] overflow-hidden">

        <div className="h-10 bg-[#181821]" />

        {Array.from({ length: 8 }).map((_, index) => (

          <div
            key={index}
            className="grid grid-cols-9 gap-4 px-4 py-4 border-t border-[#1f2333]"
          >
            <div className="h-3 rounded bg-[#23232e]" />
            <div className="h-3 rounded bg-[#23232e]" />
            <div className="h-3 rounded bg-[#23232e]" />
            <div className="h-3 rounded bg-[#23232e]" />
            <div className="h-3 rounded bg-[#23232e]" />
            <div className="h-3 rounded bg-[#23232e]" />
            <div className="h-3 rounded bg-[#23232e]" />
            <div className="h-3 rounded bg-[#23232e]" />
            <div className="h-3 rounded bg-[#23232e]" />
          </div>

        ))}

      </div>

    </div>
  );
};

export default UserListSkeleton;