import Skeleton, { SkeletonTheme } from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

const ProfileSkeleton = () => {
  return (
    <SkeletonTheme
      baseColor="#1f1f27"
      highlightColor="#2a2a35"
    >
      <div className="w-full p-2 lg:px-4 lg:py-3">
        {/* ---------------- Header ---------------- */}
        <div className="flex items-center justify-between mb-3">
          <div>
            <Skeleton width={180} height={22} />
            <div className="mt-2">
              <Skeleton width={120} height={12} />
            </div>
          </div>

          <Skeleton
            width={110}
            height={36}
            borderRadius={6}
          />
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">

          {/* ---------------- Left Profile Card ---------------- */}
          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] p-6 flex flex-col items-center">

            <Skeleton
              circle
              width={80}
              height={80}
            />

            <div className="mt-4">
              <Skeleton width={170} height={18} />
            </div>

            <div className="mt-2">
              <Skeleton width={120} height={12} />
            </div>

            <div className="mt-3">
              <Skeleton
                width={90}
                height={24}
                borderRadius={6}
              />
            </div>

            <div className="w-full border-t border-[#1f2333] my-4" />

            <Skeleton count={5} />
          </div>

          {/* ---------------- Right Section ---------------- */}
          <div className="xl:col-span-2 flex flex-col gap-3">

            {/* Business Information */}
            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">

              <div className="px-6 py-3 border-b border-[#1f2333]">
                <Skeleton width={160} height={18} />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 p-6">

                {Array.from({ length: 5 }).map((_, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-3"
                  >
                    <Skeleton
                      width={28}
                      height={28}
                      borderRadius={6}
                    />

                    <div className="flex-1">
                      <Skeleton width={80} height={10} />
                      <div className="mt-2">
                        <Skeleton width="90%" height={14} />
                      </div>
                    </div>
                  </div>
                ))}

              </div>
            </div>

            {/* Location */}
            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">

              <div className="px-6 py-3 border-b border-[#1f2333]">
                <Skeleton width={90} height={18} />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5 p-6">

                {Array.from({ length: 3 }).map((_, index) => (
                  <div key={index}>
                    <Skeleton width={70} height={10} />
                    <div className="mt-2">
                      <Skeleton width={90} height={14} />
                    </div>
                  </div>
                ))}

              </div>
            </div>

            {/* Timeline */}
            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">

              <div className="px-6 py-3 border-b border-[#1f2333]">
                <Skeleton width={140} height={18} />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 p-6">

                {Array.from({ length: 2 }).map((_, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-3"
                  >
                    <Skeleton
                      width={28}
                      height={28}
                      borderRadius={6}
                    />

                    <div className="flex-1">
                      <Skeleton width={90} height={10} />
                      <div className="mt-2">
                        <Skeleton width={150} height={14} />
                      </div>
                    </div>
                  </div>
                ))}

              </div>
            </div>

          </div>
        </div>
      </div>
    </SkeletonTheme>
  );
};

export default ProfileSkeleton;