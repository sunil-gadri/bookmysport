import Skeleton, { SkeletonTheme } from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

const SkeletonInput = ({ fullWidth = false }) => (
  <div className={fullWidth ? "md:col-span-2" : ""}>
    <Skeleton width={90} height={10} />

    <div className="mt-2">
      <Skeleton height={36} borderRadius={8} />
    </div>
  </div>
);

const FormSkeleton = () => {
  return (
    <SkeletonTheme
      baseColor="#1f1f27"
      highlightColor="#2a2a35"
    >
      <div className="w-full p-2 lg:px-4 lg:py-3">

        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <div>
            <Skeleton width={220} height={22} />

            <div className="mt-2">
              <Skeleton width={160} height={12} />
            </div>
          </div>

          <Skeleton
            width={100}
            height={34}
            borderRadius={6}
          />
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">

          {/* Left Card */}
          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] p-6 flex flex-col items-center text-center">

            <Skeleton
              circle
              width={80}
              height={80}
            />

            <div className="mt-4">
              <Skeleton
                width={90}
                height={22}
                borderRadius={6}
              />
            </div>

            <div className="w-full border-t border-[#1f2333] my-4" />

            <div className="w-full text-left">
              <Skeleton width={100} height={10} />

              <div className="mt-3">
                <Skeleton
                  height={110}
                  borderRadius={8}
                />
              </div>
            </div>

          </div>

          {/* Right Side */}
          <div className="xl:col-span-2 flex flex-col gap-3">

            {/* Business Information */}
            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">

              <div className="px-6 py-3 border-b border-[#1f2333]">
                <Skeleton width={170} height={18} />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-6">

                <SkeletonInput />
                <SkeletonInput />
                <SkeletonInput />
                <SkeletonInput />
                <SkeletonInput />
                <SkeletonInput fullWidth />

              </div>

            </div>

            {/* Location */}
            <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">

              <div className="px-6 py-3 border-b border-[#1f2333]">
                <Skeleton width={90} height={18} />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-6">

                <SkeletonInput />
                <SkeletonInput />
                <SkeletonInput />

              </div>

            </div>

            {/* Bottom Buttons */}
            <div className="flex justify-end gap-2">

              <Skeleton
                width={90}
                height={36}
                borderRadius={6}
              />

              <Skeleton
                width={120}
                height={36}
                borderRadius={6}
              />

            </div>

          </div>

        </div>
      </div>
    </SkeletonTheme>
  );
};

export default FormSkeleton;