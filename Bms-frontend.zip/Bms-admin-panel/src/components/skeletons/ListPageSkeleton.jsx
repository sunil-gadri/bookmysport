import Skeleton, { SkeletonTheme } from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

const ListPageSkeleton = ({
  statsCount = 4,
  tableRows = 6,
  tableColumns = 8,
}) => {
  return (
    <SkeletonTheme
      baseColor="#1F1F27"
      highlightColor="#2A2A35"
    >
      <div className="w-full p-2 lg:px-4 lg:py-3">

        {/* Header */}
        <div className="flex justify-between items-start mb-5">
          <div>
            <Skeleton width={220} height={20} />
            <div className="mt-2">
              <Skeleton width={140} height={12} />
            </div>
          </div>

          <div className="flex gap-3">
            <Skeleton width={120} height={34} borderRadius={6} />
            <Skeleton width={120} height={34} borderRadius={6} />
          </div>
        </div>

        {/* Stats */}
        <div className={`grid grid-cols-1 md:grid-cols-2 xl:grid-cols-${statsCount} gap-2 mb-5`}>
          {Array.from({ length: statsCount }).map((_, index) => (
            <div
              key={index}
              className="bg-[#14141A] border border-[#1F1F27] rounded-[10px] h-[150px]"
            />
          ))}
        </div>

        {/* Search + Filters */}
        <div className="flex justify-between items-center mb-5 gap-4">
          <Skeleton height={38} className="flex-1 rounded-lg" />

          <div className="flex gap-3">
            <Skeleton width={110} height={38} borderRadius={8} />
            <Skeleton width={110} height={38} borderRadius={8} />
            <Skeleton width={110} height={38} borderRadius={8} />
          </div>
        </div>

        {/* Table */}
        <div className="bg-[#14141A] border border-[#1F1F27] rounded-[10px] overflow-hidden">

          <div className="h-12 border-b border-[#1F1F27]" />

          <div className="overflow-x-auto">

            <table className="w-full">

              <tbody>

                {Array.from({ length: tableRows }).map((_, row) => (

                  <tr
                    key={row}
                    className="border-b border-[#1F1F27]"
                  >
                    {Array.from({ length: tableColumns }).map((_, col) => (

                      <td
                        key={col}
                        className="px-6 py-5"
                      >
                        <Skeleton
                          height={14}
                          borderRadius={4}
                        />
                      </td>

                    ))}
                  </tr>

                ))}

              </tbody>

            </table>

          </div>

          <div className="flex justify-between items-center px-5 py-4">

            <Skeleton width={120} height={14} />

            <div className="flex gap-2">
              <Skeleton width={34} height={34} borderRadius={8} />
              <Skeleton width={34} height={34} borderRadius={8} />
              <Skeleton width={34} height={34} borderRadius={8} />
            </div>

          </div>

        </div>

      </div>
    </SkeletonTheme>
  );
};

export default ListPageSkeleton;