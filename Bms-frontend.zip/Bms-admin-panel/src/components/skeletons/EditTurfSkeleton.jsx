import React from "react";

const Bar = ({ className = "" }) => (
  <div className={`bg-[#1F1F27] rounded-[6px] animate-pulse ${className}`} />
);

const CardShell = ({ children, headerWidth = "w-32" }) => (
  <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
    <div className="px-6 py-3 border-b border-[#1f2333]">
      <Bar className={`h-3 ${headerWidth}`} />
    </div>
    <div className="p-6">{children}</div>
  </div>
);

const EditTurfSkeleton = () => {
  return (
    <div className="w-full p-2 lg:px-4 lg:py-3 animate-pulse">
      <Bar className="h-3 w-24 mb-4" />

      <div className="mb-3">
        <Bar className="h-5 w-48 mb-2" />
        <Bar className="h-3 w-72" />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-3 mt-3">
        {/* LEFT COLUMN — media */}
        <div className="flex flex-col gap-3">
          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
            <div className="px-5 py-3 border-b border-[#1f2333]">
              <Bar className="h-3 w-24" />
            </div>
            <div className="p-5">
              <Bar className="h-40 w-full rounded-[10px]" />
            </div>
          </div>

          <div className="bg-[#14141a] border border-[#1F1F27] rounded-[10px] overflow-hidden">
            <div className="px-5 py-3 border-b border-[#1f2333]">
              <Bar className="h-3 w-28" />
            </div>
            <div className="p-5 grid grid-cols-3 gap-2">
              {Array.from({ length: 6 }).map((_, i) => (
                <Bar key={i} className="h-16 w-full rounded-[8px]" />
              ))}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN — details */}
        <div className="xl:col-span-2 flex flex-col gap-3">
          <CardShell headerWidth="w-36">
            <div className="flex flex-col gap-4">
              <div>
                <Bar className="h-2 w-20 mb-2" />
                <Bar className="h-9 w-full" />
              </div>
              <div>
                <Bar className="h-2 w-16 mb-2" />
                <Bar className="h-16 w-full" />
              </div>
            </div>
          </CardShell>

          <CardShell headerWidth="w-40">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Bar className="h-2 w-24 mb-2" />
                <Bar className="h-9 w-full" />
              </div>
              <div>
                <Bar className="h-2 w-14 mb-2" />
                <Bar className="h-9 w-full" />
              </div>
            </div>
          </CardShell>

          <CardShell headerWidth="w-20">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i}>
                  <Bar className="h-2 w-16 mb-2" />
                  <Bar className="h-9 w-full" />
                </div>
              ))}
            </div>
          </CardShell>

          <CardShell headerWidth="w-24">
            <div className="flex gap-2">
              <Bar className="h-8 w-28 rounded-[8px]" />
              <Bar className="h-8 w-32 rounded-[8px]" />
            </div>
          </CardShell>

          <CardShell headerWidth="w-32">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Bar className="h-8 w-full md:col-span-2" />
              <Bar className="h-9 w-full" />
              <Bar className="h-9 w-full" />
            </div>
          </CardShell>

          {Array.from({ length: 3 }).map((_, i) => (
            <CardShell key={i} headerWidth="w-24">
              <div className="flex flex-wrap gap-2">
                {Array.from({ length: 5 }).map((_, j) => (
                  <Bar key={j} className="h-7 w-20 rounded-[8px]" />
                ))}
              </div>
            </CardShell>
          ))}

          <div className="flex justify-end gap-2 pb-4">
            <Bar className="h-10 w-24 rounded-[8px]" />
            <Bar className="h-10 w-32 rounded-[8px]" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditTurfSkeleton;
