import { useState } from "react";
import { Outlet } from "react-router-dom";
import Navbar from "./Navbar";
import Sidebar from "./Sidebar";

export default function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    /*
      Full-viewport column layout:
        Row 1 → Navbar  (fixed height, full width, z-30)
        Row 2 → Body row (fills remaining height)
                  ├─ Sidebar  (240px, desktop: static | mobile: fixed overlay)
                  └─ <main>   (flex-1, scrollable page content)
    */
    <div className="flex flex-col h-screen overflow-hidden bg-[#090d1a]">

      {/* ── Top Navbar ── */}
      <Navbar onMenuClick={() => setSidebarOpen(true)} />

      {/* ── Body: Sidebar + Page content ── */}
      <div className="flex flex-1 overflow-hidden">

        {/*
          Desktop  → sidebar in normal flow (relative), 240 px wide, always visible.
          Mobile   → sidebar is position:fixed, slides in from left via translate-x.
                     Backdrop rendered inside <Sidebar /> handles click-outside close.
        */}
        <Sidebar open={sidebarOpen} setOpen={setSidebarOpen} />

        {/* Scrollable page content */}
        <main className="flex-1 overflow-y-auto bg-[#0B0B0F]">
          <Outlet />
        </main>

      </div>
    </div>
  );
}