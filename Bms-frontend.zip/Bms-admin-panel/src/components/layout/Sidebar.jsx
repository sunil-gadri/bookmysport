import { NavLink } from "react-router-dom";
import { X } from "lucide-react";
import { isProfileCompleted } from "../../utils/auth";
import { useAuth } from "../../context/AuthContext";


const adminMenu = [
  {
    title: "MAIN",
    items: [
      { name: "Dashboard", path: "/dashboard" },
      { name: "Users", path: "/users" },
      { name: "Turf Management", path: "/turfs" },
      { name: "Bookings", path: "/bookings" },
      { name: "Slot Manager", path: "/slot-manager" },
    ],
  },
  {
    title: "MASTER",
    items: [
      { name: "Sports", path: "/sports" },
      { name: "Events", path: "/events" },
      { name: "Amenities", path: "/amentities" },
    ],
  },
  {
    title: "SYSTEM",
    items: [{ name: "Settings", path: "/settings" }],
  },
];

const turfOwnerMenu = [
  {
    title: "MAIN",
    items: [
      { name: "Dashboard", path: "/turfowner-dashboard" },
      { name: "My Turfs", path: "/my-turfs" },
      { name: "Bookings", path: "/turf-bookings" },
      { name: "Slot Manager", path: "/slots" },
    ],
  },
  {
    title: "SYSTEM",
    items: [
      {
        name: "Profile",
        path: "/profile",
        isProfile: true,
      },
    ],
  },
];

const badgeClass = {
  blue: "bg-blue-500 text-white px-1.5 py-0.4 rounded-full text-[8px] font-semibold",
  red: "bg-red-500 text-white w-4 h-4 rounded-full text-[8px] font-bold flex items-center justify-center shrink-0",
  green:
    "bg-green-500 text-white px-1.5 py-0.4 rounded-full text-[8px] font-semibold",
};

export default function Sidebar({ open, setOpen }) {
  const { user, role } = useAuth();

  const menuSections = role === "admin" ? adminMenu : turfOwnerMenu;

  return (
    <>
      {/* ── Mobile backdrop overlay ── */}
      {open && (
        <div
          className="fixed inset-0 bg-black/60 z-40 lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      {/* ── Sidebar panel ── */}
      <aside
        className={`
          fixed lg:relative
          top-0 left-0 lg:top-auto lg:left-auto
          h-full
          w-[220px]
          bg-[#0B0B0F]
          border-r border-[#1a1f2e]
          flex flex-col
          z-50 lg:z-auto
          transition-transform duration-300 ease-in-out
          ${open ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
          shrink-0
        `}
      >
        {/* Mobile close button (X) */}
        <button
          className="lg:hidden absolute right-4 top-4 text-gray-400 hover:text-white transition-colors"
          onClick={() => setOpen(false)}
          aria-label="Close sidebar"
        >
          <X size={18} />
        </button>

        {/* ── Navigation sections ── */}
        <nav className="flex-1 overflow-y-auto px-1 pt-4 pb-3 space-y-5">
          {menuSections.map((section) => (
            <div key={section.title}>
              {/* Section label — tiny uppercase spaced */}
              <p className="text-[9px] font-semibold tracking-[3px] text-gray-600 px-3 mb-1.5 uppercase">
                {section.title}
              </p>

              <ul className="space-y-0.5 p-2">
                {section.items.map((item, index) => {
                  const path = item.isProfile
                    ? isProfileCompleted()
                      ? "/turfowner-profile"
                      : "/complete-profile"
                    : item.path;

                  return (
                    <li key={item.path || index}>
                      <NavLink
                        to={path}
                        onClick={() => setOpen(false)}
                        className={({ isActive }) =>
                          `flex items-center justify-between px-5 py-1 rounded-sm transition-colors duration-150 group ${
                            isActive
                              ? "bg-[#111827] text-white font-semibold"
                              : "text-gray-400"
                          }`
                        }
                      >
                        <span className="text-[11px]">{item.name}</span>

                        {item.badge && (
                          <span className={badgeClass[item.badgeColor]}>
                            {item.badge}
                          </span>
                        )}
                      </NavLink>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </nav>

        {/* ── Bottom user card ── */}
        <div className="p-3 border-t border-[#1a1f2e] shrink-0">
          <div className="bg-[#111827] rounded-xl p-3 flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-blue-500 flex items-center justify-center font-bold text-white text-sm shrink-0 ring-2 ring-blue-500/30">
              {user?.name
                ?.split(" ")
                .map((word) => word[0])
                .join("")
                .substring(0, 2)
                .toUpperCase()}
            </div>{" "}
            <div className="min-w-0">
              <p className="text-sm font-semibold text-white leading-tight truncate">
                {user?.name}
              </p>
              <p className="text-xs text-gray-400 truncate">{user?.email}</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
