import { NavLink } from "react-router-dom";
import { Menu, Bell } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { logoutUser } from "../../services/authService";
import { logout } from "../../utils/auth";
import { toast } from "react-toastify";
import { useAuth } from "../../context/AuthContext";

export default function Navbar({ onMenuClick }) {
  const navigate = useNavigate();
  const { user, role, logout: contextLogout } = useAuth();

  const handleLogout = async () => {
    try {
      await logoutUser();
    } catch (error) {
      console.error(error);
    } finally {
      contextLogout();
      toast.success("Logged out successfully");
      navigate("/login", { replace: true });
    }
  };

  return (
    <header className="h-14 bg-[#0d1117] border-b border-[#1a1f2e] flex items-center px-4 gap-4 shrink-0 z-30">
      {/* ── Left: Logo + hamburger (mobile) ── */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Hamburger — visible on mobile & tablet, hidden on lg+ */}
        <button
          className="lg:hidden text-gray-400 hover:text-white p-1 rounded-md transition-colors"
          onClick={onMenuClick}
          aria-label="Open sidebar"
        >
          <Menu size={20} />
        </button>

        {/* Logo */}
        <div className="flex items-center gap-2.5">
          {/* Blue rounded square icon */}
          <div className="w-8 h-8 bg-blue-500 rounded-xl shrink-0 flex items-center justify-center">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <circle cx="8" cy="8" r="6" stroke="white" strokeWidth="1.5" />
              <path
                d="M8 2 Q11 5 8 8 Q5 11 8 14"
                stroke="white"
                strokeWidth="1.2"
                fill="none"
              />
              <path
                d="M2 8 Q5 5 8 8 Q11 11 14 8"
                stroke="white"
                strokeWidth="1.2"
                fill="none"
              />
            </svg>
          </div>
          <span className="font-bold text-[17px] text-white tracking-tight">
            BookMySport
          </span>
          {/* Admin pill badge */}
          <span className="text-[11px] text-gray-400 bg-[#1a1f2e] px-2 py-0.5 rounded-md font-medium hidden sm:inline">
              {role === "admin" ? "Admin" : "Turf Owner"}

          </span>
        </div>
      </div>

      {/* ── Right: Bell + Avatar ── */}
      <div className="ml-auto flex items-center gap-3 shrink-0">
        {/* Bell with red dot */}
        <button
          className="relative text-gray-400 hover:text-white p-1.5 rounded-lg hover:bg-[#1a1f2e] transition-colors"
          aria-label="Notifications"
        >
          <Bell size={18} />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full ring-2 ring-[#0d1117]" />
        </button>

        {/* Avatar + name */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center font-bold text-white text-xs shrink-0 ring-2 ring-blue-500/30">
            {user?.name
              ?.split(" ")
              .map((word) => word[0])
              .join("")
              .substring(0, 2)
              .toUpperCase()}
          </div>
          <span className="text-sm font-semibold text-white hidden sm:block">
            {user?.name}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleLogout}
            className="cursor-pointer rounded-[10px] bg-blue-500 flex items-center justify-center font-bold text-white text-[11px] shrink-0 ring-2 ring-blue-500/30 px-2 py-2"
          >
            Logout
          </button>
        </div>
      </div>
    </header>
  );
}
