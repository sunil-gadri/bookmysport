/* ─────────────────────────────────────────────
   UI.jsx  —  All BMS components (Tailwind v4)
   ───────────────────────────────────────────── */

// ── StatCard ──────────────────────────────────
export function StatCard({ icon, value, label, change, up, iconBg, iconColor }) {
  return (
    <div className="bg-bg-card border border-border rounded-lg p-4">
      <div
        className="w-[35px] h-[35px] rounded-[10px] flex items-center justify-center mb-3"
        style={{ background: iconBg }}
      >
        <i className={`ti ${icon} text-[18px]`} style={{ color: iconColor }} />
      </div>
      <div className="font-poppins text-[16px] font-bold text-t1 leading-none mb-1">
        {value}
      </div>
      <div className="text-[10px] text-t3 mb-1">{label}</div>
      {change && (
        <div
          className={`text-[9px] font-semibold flex items-center gap-1 ${
            up === false ? "text-red" : up ? "text-green" : "text-t3"
          }`}
        >
          {up !== undefined && (
            <i className={`ti ${up ? "ti-trending-up" : "ti-trending-down"} text-[12px]`} />
          )}
          {change}
        </div>
      )}
    </div>
  );
}

// ── CardBox ───────────────────────────────────
export function CardBox({ title, right, children }) {
  return (
    <div className="bg-bg-card border border-border rounded-lg overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <span className="font-poppins text-[13px] font-bold text-t1">{title}</span>
        {right && <div>{right}</div>}
      </div>
      {children}
    </div>
  );
}

// ── PageHeader ────────────────────────────────
export function PageHeader({ title, subtitle, children }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <div>
        <h2 className="font-poppins text-[16px] font-bold text-t1">{title}</h2>
        {subtitle && <p className="text-[11px] text-t3 mt-0.5">{subtitle}</p>}
      </div>
      {children && <div className="flex items-center gap-2">{children}</div>}
    </div>
  );
}

// ── Badge ─────────────────────────────────────
const badgeMap = {
  Confirmed: "bg-green/10 text-green",
  confirmed: "bg-green/10 text-green",
  Paid:      "bg-green/10 text-green",
  paid:      "bg-green/10 text-green",
  UPI:       "bg-accent/10 text-accent",
  upi:       "bg-accent/10 text-accent",
  Card:      "bg-accent/10 text-accent",
  card:      "bg-accent/10 text-accent",
  Pending:   "bg-amber/10 text-amber",
  pending:   "bg-amber/10 text-amber",
  Refund:    "bg-amber/10 text-amber",
  refund:    "bg-amber/10 text-amber",
  Cancelled: "bg-red/10 text-red",
  cancelled: "bg-red/10 text-red",
  Wallet:    "bg-[rgba(171,71,188,.15)] text-[#CE93D8]",
  wallet:    "bg-[rgba(171,71,188,.15)] text-[#CE93D8]",
};

export function Badge({ label }) {
  const cls = badgeMap[label] ?? "bg-bg-input text-t3";
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-[5px] text-[10px] font-bold whitespace-nowrap ${cls}`}>
      {label}
    </span>
  );
}

// ── Avatar ────────────────────────────────────
export function Avatar({ initials, color, size = 26 }) {
  return (
    <div
      className="rounded-full flex items-center justify-center font-poppins font-bold text-white flex-shrink-0"
      style={{ width: size, height: size, background: color, fontSize: size * 0.36 }}
    >
      {initials}
    </div>
  );
}

// ── ActionBtn ─────────────────────────────────
export function ActionBtn({ icon, title, onClick, danger }) {
  return (
    <button
      onClick={onClick}
      title={title}
      className={`
        w-[26px] h-[26px] rounded-[6px] inline-flex items-center justify-center
        border border-border bg-bg-input mr-1
        hover:bg-accent/10 hover:border-accent/40 transition-colors
        ${danger ? "hover:bg-red/10 hover:border-red/30" : ""}
      `}
    >
      <i className={`ti ${icon} text-[12px] ${danger ? "text-red" : "text-t3"}`} />
    </button>
  );
}

// ── BarChart ──────────────────────────────────
// mockData uses { v, l, peak } — supports both v and value, l and label
export function BarChart({ data, height = 80 }) {
  const max = Math.max(...data.map((d) => d.v ?? d.value ?? 0));
  return (
    <div className="flex items-end gap-[3px]" style={{ height }}>
      {data.map((d, i) => {
        const val = d.v ?? d.value ?? 0;
        const lbl = d.l ?? d.label ?? "";
        const isPeak = d.peak === true;
        const isDim  = d.dim  === true;
        return (
          <div key={i} className="flex-1 flex flex-col items-center gap-[3px]">
            <div
              className={`w-full rounded-t-[3px] transition-all ${
                isPeak ? "bg-green" : isDim ? "bg-bg-input" : "bg-accent"
              }`}
              style={{
                height: `${(val / max) * 100}%`,
                opacity: isDim ? 0.4 : isPeak ? 1 : 0.75,
              }}
            />
            {lbl && <span className="text-[8px] text-t4">{lbl}</span>}
          </div>
        );
      })}
    </div>
  );
}

// ── DonutChart ────────────────────────────────
export function DonutChart({ segments, label }) {
  let cumulative = 0;
  const stops = segments.map((s) => {
    const start = cumulative;
    cumulative += s.pct;
    return `${s.color} ${start}% ${cumulative}%`;
  });
  const gradient = `conic-gradient(${stops.join(", ")})`;

  return (
    <div className="relative w-[80px] h-[80px] flex-shrink-0">
      <div className="w-full h-full rounded-full" style={{ background: gradient }} />
      <div className="absolute inset-[14px] rounded-full bg-bg-card flex items-center justify-center">
        <span className="font-poppins text-[14px] font-bold text-t1">{label}</span>
      </div>
    </div>
  );
}

// ── Toggle ────────────────────────────────────
export function Toggle({ on, onChange }) {
  return (
    <div
      onClick={onChange}
      className={`toggle w-[36px] h-[20px] rounded-[10px] relative cursor-pointer flex-shrink-0 transition-colors duration-200 ${
        on ? "toggle-on bg-accent" : "toggle-off bg-border"
      }`}
    />
  );
}

// ── SearchBar ─────────────────────────────────
export function SearchBar({ placeholder = "Search...", value, onChange }) {
  return (
    <div className="flex items-center gap-2 bg-bg-card border border-border rounded-md px-3 py-2 flex-1 min-w-[200px]">
      <i className="ti ti-search text-[15px] text-t4 flex-shrink-0" />
      <input
        className="bg-transparent border-none p-0 text-[12px] text-t2 flex-1 outline-none placeholder:text-t4"
        placeholder={placeholder}
        value={value}
        onChange={onChange}
      />
    </div>
  );
}

// ── FilterChip ────────────────────────────────
export function FilterChip({ label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`px-3 py-1.5 rounded-[6px] text-[10px] whitespace-nowrap cursor-pointer transition-all border ${
        active
          ? "bg-accent/10 border-accent/40 text-accent"
          : "bg-bg-card border-border text-t3 hover:border-[#3a3a48] hover:text-t2"
      }`}
    >
      {label}
    </button>
  );
}

// ── Modal ─────────────────────────────────────
export function Modal({ title, onClose, children, footer }) {
  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[1000] p-5 backdrop-blur-sm">
      <div className="bg-bg-card border border-border rounded-xl w-full max-w-[540px] max-h-[90vh] overflow-y-auto shadow-card">
        <div className="flex items-center justify-between px-5 py-[18px] border-b border-border">
          <span className="font-poppins text-[15px] font-bold text-t1">{title}</span>
          <button onClick={onClose} className="text-t3 hover:text-t1 transition-colors">
            <i className="ti ti-x text-[18px]" />
          </button>
        </div>
        <div className="p-5">{children}</div>
        {footer && (
          <div className="px-5 py-3.5 border-t border-border flex justify-end gap-2">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Toast ─────────────────────────────────────
export function Toast({ message, type = "info" }) {
  const border = { success: "border-l-green", error: "border-l-red", info: "border-l-accent" };
  return (
    <div className={`flex items-center gap-2.5 bg-bg-card border border-border rounded-md px-4 py-3 shadow-card text-[12px] text-t1 min-w-[260px] animate-slide-in border-l-[3px] ${border[type] ?? border.info}`}>
      {message}
    </div>
  );
}

// ── EmptyState ────────────────────────────────
export function EmptyState({ icon = "ti-inbox", title = "Nothing here", sub }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-5 text-center">
      <div className="w-[72px] h-[72px] rounded-[20px] bg-bg-input flex items-center justify-center mb-4">
        <i className={`ti ${icon} text-[32px] text-border`} />
      </div>
      <p className="font-poppins text-[14px] font-bold text-t1 mb-1.5">{title}</p>
      {sub && <p className="text-[12px] text-t3 max-w-[280px] leading-relaxed">{sub}</p>}
    </div>
  );
}

// ── Pagination ────────────────────────────────
export function Pagination({ info, pages, current, onChange }) {
  return (
    <div className="flex items-center justify-between px-4 py-3 border-t border-border">
      <span className="text-[11px] text-t3">{info}</span>
      <div className="flex gap-1">
        {pages.map((p) => (
          <button
            key={p}
            onClick={() => onChange(p)}
            className={`w-7 h-7 flex items-center justify-center rounded-[6px] text-[11px] cursor-pointer border transition-colors ${
              p === current
                ? "bg-accent text-white border-accent"
                : "bg-bg-input border-border text-t3 hover:border-[#3a3a48] hover:text-t2"
            }`}
          >
            {p}
          </button>
        ))}
      </div>
    </div>
  );
}