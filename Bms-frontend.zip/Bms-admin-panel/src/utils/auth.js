export const saveAuthData = (response) => {

    localStorage.setItem("token", response.token);

    localStorage.setItem(
        "user",
        JSON.stringify(response.user)
    );

    localStorage.setItem(
        "role",
        response.login_role
    );

    localStorage.setItem(
        "is_profile_completed",
        response.is_profile_completed ?? true
    );


};

export const getToken = () => {
    return localStorage.getItem("token");
};

export const getUser = () => {

    const user = localStorage.getItem("user");

    return user ? JSON.parse(user) : null;

};

export const getRole = () => {
    return localStorage.getItem("role");
};

export const logout = () => {

    localStorage.removeItem("token");
    localStorage.removeItem("user");
    localStorage.removeItem("role");
    localStorage.removeItem("is_profile_completed");

};

export const isAuthenticated = () => {

    return !!localStorage.getItem("token");

};

export const isProfileCompleted = () => {
    return localStorage.getItem("is_profile_completed") === "true";
};

export const isAdmin = () => {
    return getRole() === "admin";
};

export const isTurfOwner = () => {
    return getRole() === "turf_owner";
};


export const updateUser = (updatedFields) => {
    const user = getUser();

    if (!user) return;

    localStorage.setItem(
        "user",
        JSON.stringify({
            ...user,
            ...updatedFields,
        })
    );
};
