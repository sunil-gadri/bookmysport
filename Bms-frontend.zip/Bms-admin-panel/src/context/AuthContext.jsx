import { createContext, useContext, useState, useCallback } from "react";
import {
  getUser,
  getRole,
  isProfileCompleted,
  saveAuthData as saveAuthDataUtil,
  updateUser as updateUserUtil,
  logout as logoutUtil,
} from "../utils/auth";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => getUser());
  const [role, setRole] = useState(() => getRole());
  const [profileCompleted, setProfileCompleted] = useState(() =>
    isProfileCompleted()
  );

  // Call this after login instead of saveAuthData directly
  const saveAuthData = useCallback((response) => {
    saveAuthDataUtil(response);
    setUser(getUser());
    setRole(getRole());
    setProfileCompleted(isProfileCompleted());
  }, []);

  // Call this instead of the raw updateUser from utils/auth
  const updateUser = useCallback((updatedFields) => {
    updateUserUtil(updatedFields);
    setUser(getUser());
  }, []);

  // Call this instead of logout from utils/auth
  const logout = useCallback(() => {
    logoutUtil();
    setUser(null);
    setRole(null);
    setProfileCompleted(false);
  }, []);

  // Call this after CompleteTurfOwnerProfile finishes, if it flips the flag
  const markProfileCompleted = useCallback(() => {
    localStorage.setItem("is_profile_completed", "true");
    setProfileCompleted(true);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        profileCompleted,
        saveAuthData,
        updateUser,
        logout,
        markProfileCompleted,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return ctx;
};