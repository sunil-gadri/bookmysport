import axios from "axios";
import { logout } from "../utils/auth";

const api = axios.create({
    baseURL: "http://192.168.0.9:8000/api",
    timeout: 10000,
    headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
    },
});

api.interceptors.request.use(
    (config) => {

        const token = localStorage.getItem("token");

        if (token) {                    
            config.headers.Authorization = `Bearer ${token}`;
        }

        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);


api.interceptors.response.use(
    (response) => response,

    (error) => {

        if (error.response?.status === 401) {

            logout();

            window.location.replace("/login");
        }

        return Promise.reject(error);
    }
);


export default api;