/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#07070C',
        surface: {
          1: '#0E0E16',
          2: '#13131C',
          3: '#1A1A26',
        },
        edge: {
          DEFAULT: '#1F1F2E',
          strong: '#2A2A3C',
        },
        brand: {
          blue: '#2979FF',
          blue2: '#1565C0',
          green: '#00E676',
          amber: '#FFB300',
          red: '#FF5252',
          cyan: '#00BCD4',
          purple: '#AB47BC',
        },
        ink: {
          1: '#FFFFFF',
          2: '#B8B8CC',
          3: '#707088',
          4: '#3A3A52',
        },
      },
      fontFamily: {
        heading: ['Poppins', 'sans-serif'],
        body: ['Inter', 'sans-serif'],
      },
      borderRadius: {
        r8: '8px',
        r12: '12px',
        r16: '16px',
      },
      boxShadow: {
        blueglow: '0 4px 20px rgba(41,121,255,0.35)',
        blueglowlg: '0 6px 28px rgba(41,121,255,0.5)',
        greenglow: '0 4px 20px rgba(0,230,118,0.3)',
        greenglowlg: '0 6px 28px rgba(0,230,118,0.45)',
      },
    },
  },
  plugins: [],
}
