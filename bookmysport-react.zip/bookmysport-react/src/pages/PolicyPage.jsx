import { Pill } from '../components/ui.jsx'

function ListItem({ item }) {
  if (typeof item === 'string') {
    return (
      <li className="text-[14.5px] text-ink-2 leading-[1.75] py-1.5 pl-[22px] relative border-b border-edge/50 last:border-b-0 before:content-['→'] before:absolute before:left-0 before:text-brand-blue before:text-[13px]">
        {item}
      </li>
    )
  }
  const colorClass = item.color || 'text-ink-1'
  return (
    <li className="text-[14.5px] text-ink-2 leading-[1.75] py-1.5 pl-[22px] relative border-b border-edge/50 last:border-b-0 before:content-['→'] before:absolute before:left-0 before:text-brand-blue before:text-[13px]">
      <strong className={colorClass}>{item.strong}</strong> — {item.text}
    </li>
  )
}

function Section({ section }) {
  return (
    <div className="mb-10">
      <h2 className="font-heading text-xl font-bold text-ink-1 mb-3.5 pb-2.5 border-b border-edge">
        {section.h2}
      </h2>

      {section.p?.map((para, i) => (
        <p
          key={i}
          className="text-[14.5px] text-ink-2 leading-[1.8] mb-3"
          dangerouslySetInnerHTML={{ __html: para }}
        />
      ))}

      {section.blocks?.map((block, i) => (
        <div key={i}>
          <h3 className="font-heading text-base font-semibold text-ink-1 mt-[18px] mb-2">{block.h3}</h3>
          <ul className="list-none mb-3">
            {block.ul.map((item, j) => (
              <ListItem key={j} item={item} />
            ))}
          </ul>
        </div>
      ))}

      {section.ul && (
        <ul className="list-none mb-3">
          {section.ul.map((item, i) => (
            <ListItem key={i} item={item} />
          ))}
        </ul>
      )}

      {section.pAfter?.map((para, i) => (
        <p key={i} className="text-[14.5px] text-ink-2 leading-[1.8] mb-3">
          {para}
        </p>
      ))}
    </div>
  )
}

export default function PolicyPage({ policy }) {
  return (
    <div className="min-h-screen pt-[68px]">
      <div className="bg-surface-1 border-b border-edge pt-14 pb-10">
        <div className="max-w-[1120px] mx-auto px-6">
          <Pill icon={policy.icon} className="mb-3">
            {policy.label}
          </Pill>
          <h1 className="text-[32px] font-heading font-extrabold text-ink-1 mb-2">{policy.title}</h1>
          <p className="text-sm text-ink-3">
            Effective: {policy.effective} · Last updated: {policy.updated}
          </p>
        </div>
      </div>
      <div className="max-w-[780px] mx-auto px-6 pt-12 pb-20">
        <div className="bg-surface-2 border border-edge rounded-r12 px-5 py-4 mb-8 text-[13px] text-ink-3 flex gap-6 flex-wrap">
          <span className="flex items-center gap-1.5">
            <i className="ti ti-calendar text-sm" aria-hidden="true" /> Effective: {policy.effective}
          </span>
          <span className="flex items-center gap-1.5">
            <i className="ti ti-refresh text-sm" aria-hidden="true" /> Updated: {policy.updated}
          </span>
          {policy.company && (
            <span className="flex items-center gap-1.5">
              <i className="ti ti-building text-sm" aria-hidden="true" /> {policy.company}
            </span>
          )}
        </div>
        {policy.sections.map((section, i) => (
          <Section key={i} section={section} />
        ))}
      </div>
    </div>
  )
}
