const NAV_LINKS = [
  { id: 'home', label: 'Home' },
  { id: 'how', label: 'How it Works' },
  { id: 'features', label: 'Features' },
  { id: 'sports', label: 'Sports' },
  { id: 'for-owners', label: 'For Turf Owners' },
  { id: 'testimonials', label: 'Reviews' },
  { id: 'contact', label: 'Contact Us' },
]

const LEGAL_LINKS = [
  { slug: 'terms', label: 'Terms & Conditions' },
  { slug: 'privacy', label: 'Privacy Policy' },
  { slug: 'refund', label: 'Refund & Cancellation' },
  { slug: 'cookie', label: 'Cookie Policy' },
  { slug: 'grievance', label: 'Grievance Policy' },
]

const SOCIALS = [
  { icon: 'ti-brand-instagram', label: 'Instagram' },
  { icon: 'ti-brand-whatsapp', label: 'WhatsApp' },
  { icon: 'ti-brand-x', label: 'Twitter/X' },
  { icon: 'ti-brand-youtube', label: 'YouTube' },
  { icon: 'ti-brand-linkedin', label: 'LinkedIn' },
]

export default function Footer({ onNavigate, onNavigatePolicy }) {
  return (
    <footer className="bg-surface-1 border-t border-edge pt-16 pb-8">
      <div className="max-w-[1120px] mx-auto px-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-[2fr_1fr_1fr_1fr] gap-12 mb-12">
          <div>
            <div className="flex items-center gap-2.5 font-heading font-extrabold text-[17px] mb-3.5">
              <div className="w-8 h-8 rounded-lg bg-brand-blue flex items-center justify-center">
                <i className="ti ti-bolt text-[17px] text-white" aria-hidden="true" />
              </div>
              BookMySport
            </div>
            <p className="text-[13.5px] text-ink-3 leading-[1.75] max-w-[280px] mb-[22px]">
              India's easiest sports turf booking platform. Find, book, and play at premium venues near you — in under
              60 seconds.
            </p>
            <div className="flex gap-2.5">
              {SOCIALS.map((s) => (
                <a
                  key={s.label}
                  href="#"
                  aria-label={s.label}
                  className="w-9 h-9 rounded-lg bg-surface-2 border border-edge flex items-center justify-center text-ink-3 text-base transition-all hover:bg-brand-blue/[0.12] hover:border-brand-blue/30 hover:text-brand-blue"
                >
                  <i className={`ti ${s.icon}`} aria-hidden="true" />
                </a>
              ))}
            </div>
            <div className="flex gap-2.5 flex-wrap mt-[18px]">
              {[
                ['ti-shield-check', 'Secure payments'],
                ['ti-brand-razorpay', 'Razorpay'],
                ['ti-device-mobile', 'Android & iOS'],
              ].map(([icon, label]) => (
                <div
                  key={label}
                  className="bg-surface-2 border border-edge rounded-md py-[5px] px-3 text-[11px] font-semibold text-ink-3 flex items-center gap-[5px]"
                >
                  <i className={`ti ${icon} text-[13px]`} aria-hidden="true" /> {label}
                </div>
              ))}
            </div>
          </div>

          <div>
            <h5 className="font-heading text-[13px] font-bold text-white mb-4 tracking-[0.3px]">Navigate</h5>
            <ul className="flex flex-col gap-2.5">
              {NAV_LINKS.map((l) => (
                <li key={l.id}>
                  <a onClick={() => onNavigate(l.id)} className="text-[13.5px] text-ink-3 cursor-pointer hover:text-ink-1 transition-colors">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h5 className="font-heading text-[13px] font-bold text-white mb-4 tracking-[0.3px]">Legal</h5>
            <ul className="flex flex-col gap-2.5">
              {LEGAL_LINKS.map((l) => (
                <li key={l.slug}>
                  <a onClick={() => onNavigatePolicy(l.slug)} className="text-[13.5px] text-ink-3 cursor-pointer hover:text-ink-1 transition-colors">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h5 className="font-heading text-[13px] font-bold text-white mb-4 tracking-[0.3px]">Contact</h5>
            <ul className="flex flex-col gap-2.5">
              <li><a className="text-[13.5px] text-ink-3">support@bookmysport.in</a></li>
              <li><a className="text-[13.5px] text-ink-3">owners@bookmysport.in</a></li>
              <li><a className="text-[13.5px] text-ink-3">+91 98100 00001</a></li>
              <li><a className="text-[13.5px] text-ink-3">Malviya Nagar, Jaipur</a></li>
              <li><a className="text-[13.5px] text-ink-3">Rajasthan – 302017</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-edge pt-6 flex justify-between items-center flex-wrap gap-3">
          <p className="text-[13px] text-ink-4">© 2026 BookMySport · Infomagine Softwares Pvt. Ltd. · All rights reserved.</p>
          <div className="flex gap-5">
            <a onClick={() => onNavigatePolicy('terms')} className="text-[13px] text-ink-4 cursor-pointer hover:text-ink-2 transition-colors">
              Terms
            </a>
            <a onClick={() => onNavigatePolicy('privacy')} className="text-[13px] text-ink-4 cursor-pointer hover:text-ink-2 transition-colors">
              Privacy
            </a>
            <a onClick={() => onNavigatePolicy('refund')} className="text-[13px] text-ink-4 cursor-pointer hover:text-ink-2 transition-colors">
              Refunds
            </a>
            <a onClick={() => onNavigate('contact')} className="text-[13px] text-ink-4 cursor-pointer hover:text-ink-2 transition-colors">
              Contact
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
