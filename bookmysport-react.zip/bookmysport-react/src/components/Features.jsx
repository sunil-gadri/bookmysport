import { Pill, SectionTitle, SectionSub, Card } from './ui.jsx'

const FEATURES = [
  {
    icon: 'ti-bolt',
    bg: 'bg-brand-blue/10',
    color: 'text-brand-blue',
    title: 'Instant slot confirmation',
    text: 'Your booking is locked in seconds. No calls, no waiting for approval. A confirmation and QR code reach your phone immediately.',
  },
  {
    icon: 'ti-wallet',
    bg: 'bg-brand-green/10',
    color: 'text-brand-green',
    title: 'BMS Wallet with cashback',
    text: 'Top up your BMS Wallet and earn cashback on every booking. Weekend deals give up to 10% back — your loyalty is rewarded every game.',
  },
  {
    icon: 'ti-refresh',
    bg: 'bg-brand-amber/10',
    color: 'text-brand-amber',
    title: 'Easy cancellation & refunds',
    text: 'Cancel at least 2 hours before your slot and receive a full refund to your wallet. No hidden charges, no drama.',
  },
  {
    icon: 'ti-users',
    bg: 'bg-brand-purple/10',
    color: 'text-brand-purple',
    title: 'Refer friends, earn ₹50',
    text: 'Share your unique referral code. When a friend completes their first booking, you both earn ₹50 in wallet credits — instantly.',
  },
  {
    icon: 'ti-map-pin',
    bg: 'bg-brand-cyan/10',
    color: 'text-brand-cyan',
    title: 'Real-time turf discovery',
    text: 'GPS-powered search shows turfs within your chosen radius with live ratings, photos, facilities, and current availability.',
  },
  {
    icon: 'ti-shield-check',
    bg: 'bg-brand-red/10',
    color: 'text-brand-red',
    title: 'Secure payments, always',
    text: 'Every transaction is encrypted and protected. UPI, cards, net banking, and wallet — all methods are 100% safe and verified.',
  },
]

export default function Features() {
  return (
    <section id="features" className="py-24">
      <div className="max-w-[1120px] mx-auto px-6">
        <div className="text-center mx-auto">
          <Pill icon="ti-sparkles">Platform features</Pill>
          <SectionTitle className="mx-auto">Everything a player needs</SectionTitle>
          <SectionSub className="mx-auto">
            From finding the perfect turf to earning cashback — BookMySport is built around you.
          </SectionSub>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {FEATURES.map((f) => (
            <Card key={f.title} className="hover:-translate-y-0.5">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-[18px] ${f.bg}`}>
                <i className={`ti ${f.icon} text-[22px] ${f.color}`} aria-hidden="true" />
              </div>
              <h4 className="text-[17px] font-bold mb-2.5 font-heading">{f.title}</h4>
              <p className="text-sm text-ink-2 leading-[1.7]">{f.text}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
