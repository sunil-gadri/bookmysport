import { Button } from './ui.jsx'

const NAV_ITEMS = [
  { id: 'home', label: 'Home' },
  { id: 'how', label: 'How it Works' },
  { id: 'features', label: 'Features' },
  { id: 'sports', label: 'Sports' },
  { id: 'for-owners', label: 'For Turf Owners' },
  { id: 'testimonials', label: 'Reviews' },
  { id: 'contact', label: 'Contact Us' },
]

export default function Navbar({ activeSection, onNavigate, onOpenMobile }) {
  return (
    <nav className="fixed top-0 left-0 right-0 z-[100] bg-bg/85 backdrop-blur-2xl border-b border-edge h-[68px] flex items-center">
      <div className="flex items-center w-full max-w-[1120px] mx-auto px-6">
        <div
          className="flex items-center gap-2.5 font-heading font-extrabold text-lg text-white mr-10 flex-shrink-0 cursor-pointer"
          onClick={() => onNavigate('home')}
        >
          <div className="w-9 h-9 rounded-[9px] bg-brand-blue flex items-center justify-center shadow-[0_0_16px_rgba(41,121,255,0.4)]">
            <i className="ti ti-bolt text-[19px] text-white" aria-hidden="true" />
          </div>
          BookMySport
        </div>

        <div className="hidden md:flex gap-1 flex-1 overflow-x-auto no-scrollbar">
          {NAV_ITEMS.map((item) => (
            <div
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`px-3.5 py-[7px] rounded-[7px] text-[13.5px] font-medium cursor-pointer transition-all whitespace-nowrap ${
                activeSection === item.id ? 'text-white bg-surface-3' : 'text-ink-2 hover:text-white hover:bg-surface-2'
              }`}
            >
              {item.label}
            </div>
          ))}
        </div>

        <div className="hidden md:flex gap-2 ml-auto flex-shrink-0">
          <Button variant="outline" size="sm" icon="ti-download">
            Download App
          </Button>
          <Button variant="primary" size="sm" icon="ti-calendar">
            Book Now
          </Button>
        </div>

        <button
          className="md:hidden flex items-center justify-center w-9 h-9 rounded-[7px] border border-edge text-ink-2 text-lg"
          onClick={onOpenMobile}
          aria-label="Open menu"
        >
          <i className="ti ti-menu-2" aria-hidden="true" />
        </button>
      </div>
    </nav>
  )
}
