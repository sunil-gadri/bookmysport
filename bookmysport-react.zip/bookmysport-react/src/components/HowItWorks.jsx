import { Pill, SectionTitle, SectionSub } from './ui.jsx'

const STEPS = [
  {
    num: '01',
    icon: 'ti-map-search',
    iconBg: 'bg-brand-blue/10',
    iconColor: 'text-brand-blue',
    title: 'Find a turf near you',
    text: 'Browse 320+ verified turfs across 18 cities. Filter by sport, location, price, and facilities.',
  },
  {
    num: '02',
    icon: 'ti-calendar',
    iconBg: 'bg-brand-green/10',
    iconColor: 'text-brand-green',
    title: 'Choose your slot',
    text: 'Check live availability in real time. Pick any open slot — morning, afternoon, or evening.',
  },
  {
    num: '03',
    icon: 'ti-credit-card',
    iconBg: 'bg-brand-amber/10',
    iconColor: 'text-brand-amber',
    title: 'Pay securely online',
    text: 'UPI, cards, net banking, or your BMS wallet — your choice. Every transaction is fully secured.',
  },
  {
    num: '04',
    icon: 'ti-trophy',
    iconBg: 'bg-brand-cyan/10',
    iconColor: 'text-brand-cyan',
    title: 'Show up and play',
    text: 'Receive a QR code gate pass instantly. Walk in, scan, and start your game on time.',
  },
]

export default function HowItWorks() {
  return (
    <section id="how" className="py-24">
      <div className="max-w-[1120px] mx-auto px-6">
        <div className="text-center mx-auto">
          <Pill icon="ti-route">Simple process</Pill>
          <SectionTitle className="mx-auto">Book a turf in four simple steps</SectionTitle>
          <SectionSub className="mx-auto">
            No calls, no waiting. Find your turf, pick your slot, pay and play — it really is that straightforward.
          </SectionSub>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {STEPS.map((step) => (
            <div
              key={step.num}
              className="bg-surface-2 border border-edge rounded-r16 py-7 px-6 relative overflow-hidden transition-colors duration-200 hover:border-brand-blue/30"
            >
              <div className="font-heading text-[56px] font-black text-brand-blue/[0.06] absolute top-2 right-4 leading-none">
                {step.num}
              </div>
              <div className={`w-[46px] h-[46px] rounded-[11px] flex items-center justify-center mb-4 ${step.iconBg}`}>
                <i className={`ti ${step.icon} text-[22px] ${step.iconColor}`} aria-hidden="true" />
              </div>
              <h4 className="text-base font-bold mb-2 font-heading">{step.title}</h4>
              <p className="text-[13.5px] text-ink-2 leading-[1.65]">{step.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
