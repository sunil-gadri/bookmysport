import { useState } from 'react'
import { Pill, SectionTitle, SectionSub, Button } from './ui.jsx'

const CONTACT_INFO = [
  {
    icon: 'ti-message-circle',
    bg: 'bg-brand-blue/10',
    color: 'text-brand-blue',
    title: 'Live Chat Support',
    sub: 'Available 9 AM – 9 PM every day. Typically replies in under 2 minutes through the app.',
  },
  {
    icon: 'ti-mail',
    bg: 'bg-brand-green/10',
    color: 'text-brand-green',
    title: 'Email us',
    sub: (
      <>
        support@bookmysport.in
        <br />
        For general enquiries, refunds, and disputes.
      </>
    ),
  },
  {
    icon: 'ti-brand-whatsapp',
    bg: 'bg-[#25D366]/10',
    color: 'text-[#25D366]',
    title: 'WhatsApp',
    sub: (
      <>
        +91 98100 00001
        <br />
        Quick answers for booking and payment queries.
      </>
    ),
  },
  {
    icon: 'ti-building-store',
    bg: 'bg-brand-amber/10',
    color: 'text-brand-amber',
    title: 'Turf owner enquiries',
    sub: (
      <>
        owners@bookmysport.in
        <br />
        Interested in listing your turf? We'll set you up within 24 hours.
      </>
    ),
  },
  {
    icon: 'ti-map-pin',
    bg: 'bg-brand-purple/10',
    color: 'text-brand-purple',
    title: 'Head office',
    sub: (
      <>
        Infomagine Softwares Pvt. Ltd.
        <br />
        Malviya Nagar, Jaipur, Rajasthan – 302017
      </>
    ),
  },
]

const inputClass =
  'w-full bg-surface-3 border border-edge-strong rounded-lg py-[11px] px-3.5 text-ink-1 text-sm outline-none transition-colors focus:border-brand-blue placeholder:text-ink-4'

export default function Contact({ formTab, onSetFormTab, onNavigatePolicy, onSubmitted }) {
  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    city: '',
    turf: '',
    sport: '',
    subject: '',
    message: '',
  })

  const update = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }))

  const handleSubmit = (e) => {
    e.preventDefault()
    onSubmitted("Message sent! We'll get back to you within 2 hours.")
    setForm({ name: '', phone: '', email: '', city: '', turf: '', sport: '', subject: '', message: '' })
  }

  return (
    <section id="contact" className="py-24">
      <div className="max-w-[1120px] mx-auto px-6">
        <div className="text-center mx-auto">
          <Pill icon="ti-message">Get in touch</Pill>
          <SectionTitle className="mx-auto">We're here whenever you need us</SectionTitle>
          <SectionSub className="mx-auto mb-14">
            A question about booking? Want to list your turf? Or just curious? Drop us a message — our team responds
            within 2 hours.
          </SectionSub>
        </div>

        <div className="grid md:grid-cols-2 gap-[60px] items-start">
          <div className="flex flex-col gap-6">
            {CONTACT_INFO.map((c) => (
              <div key={c.title} className="flex gap-3.5 items-start">
                <div className={`w-[42px] h-[42px] rounded-[10px] flex items-center justify-center flex-shrink-0 ${c.bg}`}>
                  <i className={`ti ${c.icon} text-[19px] ${c.color}`} aria-hidden="true" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-white mb-[3px] font-heading">{c.title}</div>
                  <div className="text-[13px] text-ink-2">{c.sub}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-surface-2 border border-edge rounded-r16 p-9">
            <h3 className="text-lg font-bold mb-5 font-heading">Send us a message</h3>
            <div className="flex bg-surface-3 rounded-[9px] p-1 mb-6">
              <div
                onClick={() => onSetFormTab('user')}
                className={`flex-1 py-[9px] rounded-[7px] text-center text-[13px] font-semibold font-heading cursor-pointer transition-all ${
                  formTab === 'user' ? 'bg-brand-blue text-white' : 'text-ink-3'
                }`}
              >
                As a Player
              </div>
              <div
                onClick={() => onSetFormTab('owner')}
                className={`flex-1 py-[9px] rounded-[7px] text-center text-[13px] font-semibold font-heading cursor-pointer transition-all ${
                  formTab === 'owner' ? 'bg-brand-blue text-white' : 'text-ink-3'
                }`}
              >
                As a Turf Owner
              </div>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="grid sm:grid-cols-2 gap-3.5">
                <div className="mb-4">
                  <label className="block text-xs font-semibold text-ink-3 uppercase tracking-[0.6px] mb-1.5">
                    Full name *
                  </label>
                  <input className={inputClass} placeholder="Your full name" required value={form.name} onChange={update('name')} />
                </div>
                <div className="mb-4">
                  <label className="block text-xs font-semibold text-ink-3 uppercase tracking-[0.6px] mb-1.5">
                    Phone number *
                  </label>
                  <input
                    className={inputClass}
                    type="tel"
                    placeholder="+91 98xxx xxxxx"
                    required
                    value={form.phone}
                    onChange={update('phone')}
                  />
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-xs font-semibold text-ink-3 uppercase tracking-[0.6px] mb-1.5">Email address *</label>
                <input
                  className={inputClass}
                  type="email"
                  placeholder="you@email.com"
                  required
                  value={form.email}
                  onChange={update('email')}
                />
              </div>

              <div className="mb-4">
                <label className="block text-xs font-semibold text-ink-3 uppercase tracking-[0.6px] mb-1.5">City *</label>
                <input className={inputClass} placeholder="e.g. Jaipur" value={form.city} onChange={update('city')} />
              </div>

              {formTab === 'owner' && (
                <>
                  <div className="mb-4">
                    <label className="block text-xs font-semibold text-ink-3 uppercase tracking-[0.6px] mb-1.5">
                      Turf / venue name *
                    </label>
                    <input
                      className={inputClass}
                      placeholder="Name of your sports facility"
                      value={form.turf}
                      onChange={update('turf')}
                    />
                  </div>
                  <div className="mb-4">
                    <label className="block text-xs font-semibold text-ink-3 uppercase tracking-[0.6px] mb-1.5">
                      Sports offered
                    </label>
                    <input
                      className={inputClass}
                      placeholder="e.g. Football, Cricket, Badminton"
                      value={form.sport}
                      onChange={update('sport')}
                    />
                  </div>
                </>
              )}

              <div className="mb-4">
                <label className="block text-xs font-semibold text-ink-3 uppercase tracking-[0.6px] mb-1.5">Subject *</label>
                <select className={inputClass + ' cursor-pointer'} required value={form.subject} onChange={update('subject')}>
                  <option value="">-- Select subject --</option>
                  <option>Booking inquiry</option>
                  <option>Payment or refund issue</option>
                  <option>Cancellation request</option>
                  <option>List my turf</option>
                  <option>Technical issue</option>
                  <option>Partnership opportunity</option>
                  <option>Other</option>
                </select>
              </div>

              <div className="mb-4">
                <label className="block text-xs font-semibold text-ink-3 uppercase tracking-[0.6px] mb-1.5">Message *</label>
                <textarea
                  className={inputClass + ' resize-y min-h-[100px] leading-normal'}
                  placeholder="Tell us how we can help. Include any booking IDs or details if relevant."
                  required
                  value={form.message}
                  onChange={update('message')}
                />
              </div>

              <Button type="submit" variant="primary" icon="ti-send" className="w-full justify-center">
                Send message
              </Button>
              <p className="text-xs text-ink-3 mt-3.5 text-center leading-relaxed">
                By submitting this form you agree to our{' '}
                <a onClick={() => onNavigatePolicy('privacy')} className="text-brand-blue cursor-pointer">
                  Privacy Policy
                </a>
                . We typically respond within 2 hours during business hours.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
