const STATS = [
  { val: '50', accent: 'k+', label: 'Players booked' },
  { val: '320', accent: '+', label: 'Partner turfs' },
  { val: '1.2', accent: 'L+', label: 'Slots booked' },
  { val: '4.8', accent: '★', label: 'App store rating' },
]

export default function StatsBar() {
  return (
    <div className="bg-surface-1 border-y border-edge py-12">
      <div className="max-w-[1120px] mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4">
          {STATS.map((s, i) => (
            <div
              key={s.label}
              className={`text-center px-6 py-3 ${i !== STATS.length - 1 ? 'border-r border-edge' : ''}`}
            >
              <div className="font-heading text-4xl font-extrabold text-white mb-1">
                {s.val}
                <span className="text-brand-blue">{s.accent}</span>
              </div>
              <div className="text-[13px] text-ink-3">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
