import { Pill, SectionTitle, SectionSub } from './ui.jsx'

const TESTIMONIALS = [
  {
    stars: '★★★★★',
    text: '"Booked a football ground for Saturday evening in literally 40 seconds. The QR gate pass worked perfectly — staff just scanned and we were in. No calls, no delays."',
    initials: 'AS',
    gradient: 'linear-gradient(135deg,#2979FF,#00B0FF)',
    name: 'Arjun Sharma',
    role: 'Football player · Jaipur',
  },
  {
    stars: '★★★★★',
    text: '"I used to spend 20 minutes calling around to find a free badminton court. With BookMySport I can see exactly what\'s available and just book it. The wallet cashback is a bonus."',
    initials: 'PM',
    gradient: 'linear-gradient(135deg,#AB47BC,#8e24aa)',
    name: 'Priya Mehta',
    role: 'Badminton player · Pune',
  },
  {
    stars: '★★★★☆',
    text: '"Listed my cricket ground on BookMySport six months ago. Weekday occupancy jumped from 40% to 85%. The slot management dashboard is genuinely useful — especially the peak pricing."',
    initials: 'RV',
    gradient: 'linear-gradient(135deg,#00E676,#00897B)',
    name: 'Rahul Verma',
    role: 'Turf owner · Jaipur',
  },
]

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-24">
      <div className="max-w-[1120px] mx-auto px-6">
        <div className="text-center mx-auto">
          <Pill icon="ti-star">What players say</Pill>
          <SectionTitle className="mx-auto">Trusted by 50,000+ players across India</SectionTitle>
          <SectionSub className="mx-auto mb-12">Real reviews from real players — no fake stars here.</SectionSub>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {TESTIMONIALS.map((t) => (
            <div key={t.name} className="bg-surface-2 border border-edge rounded-r16 p-7">
              <div className="text-brand-amber text-sm mb-3.5 tracking-[2px]">{t.stars}</div>
              <p className="text-sm text-ink-2 leading-[1.75] mb-5 italic">{t.text}</p>
              <div className="flex items-center gap-[11px]">
                <div
                  className="w-[38px] h-[38px] rounded-full flex items-center justify-center font-heading font-bold text-[13px] text-white flex-shrink-0"
                  style={{ background: t.gradient }}
                >
                  {t.initials}
                </div>
                <div>
                  <div className="text-sm font-semibold text-white font-heading">{t.name}</div>
                  <div className="text-xs text-ink-3">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
