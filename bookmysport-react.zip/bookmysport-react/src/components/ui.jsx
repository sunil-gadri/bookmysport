export function Pill({ icon, children, className = '' }) {
  return (
    <div
      className={`inline-flex items-center gap-1.5 rounded-full border px-3.5 py-[5px] mb-[18px] font-heading text-xs font-semibold tracking-[0.4px] bg-brand-blue/10 border-brand-blue/25 text-brand-blue ${className}`}
    >
      {icon && <i className={`ti ${icon} text-[13px]`} aria-hidden="true" />}
      {children}
    </div>
  )
}

export function SectionLabel({ children }) {
  return (
    <div className="font-heading text-xs font-semibold text-brand-blue tracking-[1.5px] uppercase mb-2.5">
      {children}
    </div>
  )
}

export function SectionTitle({ children, className = '' }) {
  return (
    <h2 className={`font-heading text-[clamp(28px,4vw,40px)] font-extrabold text-ink-1 mb-4 max-w-[640px] ${className}`}>
      {children}
    </h2>
  )
}

export function SectionSub({ children, className = '' }) {
  return (
    <p className={`text-base text-ink-2 leading-[1.7] max-w-[560px] mb-12 ${className}`}>
      {children}
    </p>
  )
}

export function Button({ as = 'button', variant = 'primary', size = 'md', icon, className = '', children, ...props }) {
  const base =
    'inline-flex items-center justify-center gap-2 rounded-r8 font-heading font-semibold border-none transition-all duration-[180ms] whitespace-nowrap cursor-pointer hover:-translate-y-px'
  const sizes = size === 'sm' ? 'px-[18px] py-[9px] text-[13px]' : 'px-6 py-3 text-sm'
  const variants = {
    primary: 'bg-brand-blue text-white shadow-blueglow hover:bg-[#3D8BFF] hover:shadow-blueglowlg',
    outline: 'bg-transparent text-ink-1 border border-edge-strong hover:bg-surface-2 hover:border-brand-blue hover:text-brand-blue',
    green: 'bg-brand-green text-[#07070C] shadow-greenglow hover:shadow-greenglowlg',
  }
  const Comp = as
  return (
    <Comp className={`${base} ${sizes} ${variants[variant]} ${className}`} {...props}>
      {icon && <i className={`ti ${icon} text-base`} aria-hidden="true" />}
      {children}
    </Comp>
  )
}

export function Card({ children, className = '' }) {
  return (
    <div
      className={`bg-surface-2 border border-edge rounded-r16 p-7 transition-colors duration-200 hover:border-brand-blue/30 hover:shadow-[0_8px_32px_rgba(41,121,255,0.08)] ${className}`}
    >
      {children}
    </div>
  )
}
