import { Pill, SectionTitle, Button } from './ui.jsx'

const BENEFITS = [
  { icon: 'ti-chart-bar', text: 'Live dashboard — bookings, revenue, and ratings in one place' },
  { icon: 'ti-clock', text: 'Smart slot management with peak-hour pricing built in' },
  { icon: 'ti-cash', text: 'Weekly payouts directly to your bank account' },
  { icon: 'ti-star', text: 'Verified reviews build trust and bring in more players' },
  { icon: 'ti-headset', text: 'Dedicated owner support — 9 AM to 9 PM, seven days a week' },
]

const WEEK_BARS = [30, 42, 36, 48, 50, 32, 16]
const WEEK_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

const TOP_SLOTS = [
  { time: '5 PM – 6 PM', price: '₹1,200' },
  { time: '7 PM – 8 PM', price: '₹1,200' },
]

export default function ForOwners({ onSwitchToOwnerTab, onNavigate }) {
  return (
    <section id="for-owners" className="py-24 bg-surface-1">
      <div className="max-w-[1120px] mx-auto px-6">
        <div className="bg-[linear-gradient(135deg,rgba(0,230,118,0.06)_0%,transparent_60%)] border border-brand-green/[0.15] rounded-3xl p-8 md:p-14 grid md:grid-cols-2 gap-14 items-center">
          <div>
            <Pill icon="ti-building-store" className="bg-brand-green/[0.08] border-brand-green/20 text-brand-green">
              For turf owners
            </Pill>
            <SectionTitle className="text-[clamp(24px,3.5vw,36px)]">
              Turn empty slots into revenue — automatically
            </SectionTitle>
            <p className="text-base text-ink-2 leading-[1.7] max-w-[560px]">
              Join 320+ turf owners across India who use BookMySport to fill their calendars, manage bookings, and grow
              their business without lifting a finger.
            </p>
            <div className="flex flex-col gap-4 mt-7">
              {BENEFITS.map((b) => (
                <div key={b.text} className="flex items-center gap-3 text-[14.5px] text-ink-2">
                  <div className="w-8 h-8 rounded-lg bg-brand-green/10 flex items-center justify-center flex-shrink-0">
                    <i className={`ti ${b.icon} text-[15px] text-brand-green`} aria-hidden="true" />
                  </div>
                  {b.text}
                </div>
              ))}
            </div>
            <div className="mt-7 flex gap-3 flex-wrap">
              <Button
                variant="green"
                icon="ti-plus"
                onClick={() => {
                  onSwitchToOwnerTab()
                  onNavigate('contact')
                }}
              >
                List your turf — it's free
              </Button>
              <Button variant="outline" onClick={() => onNavigate('contact')}>
                Talk to our team
              </Button>
            </div>
          </div>

          <div className="bg-surface-2 border border-edge rounded-2xl p-5 overflow-hidden">
            <div className="font-heading text-xs font-bold text-ink-3 tracking-[0.8px] mb-3.5">OWNER DASHBOARD</div>
            <div className="grid grid-cols-2 gap-2 mb-3.5">
              <div className="bg-surface-3 rounded-[10px] p-3">
                <div className="text-[10px] text-ink-3 mb-1">Today's revenue</div>
                <div className="font-heading text-xl font-extrabold text-brand-green">₹9,600</div>
              </div>
              <div className="bg-surface-3 rounded-[10px] p-3">
                <div className="text-[10px] text-ink-3 mb-1">Slots booked</div>
                <div className="font-heading text-xl font-extrabold text-brand-blue">12/18</div>
              </div>
            </div>

            <div className="text-[10px] text-ink-4 mb-2">Weekly bookings</div>
            <div className="flex gap-[5px] items-end h-[50px]">
              {WEEK_BARS.map((h, i) => (
                <div
                  key={i}
                  className={`flex-1 rounded-t-[3px] ${i === 4 ? 'bg-brand-green' : 'bg-brand-green/30'}`}
                  style={{ height: `${h}px` }}
                />
              ))}
            </div>
            <div className="flex justify-between text-[8px] text-ink-4 mt-1">
              {WEEK_LABELS.map((d) => (
                <span key={d}>{d}</span>
              ))}
            </div>

            <div className="mt-3.5 flex flex-col gap-1.5">
              {TOP_SLOTS.map((slot) => (
                <div key={slot.time} className="flex items-center gap-[9px] bg-surface-3 rounded-lg py-2 px-2.5">
                  <span className="text-sm">🏟️</span>
                  <div className="flex-1">
                    <div className="text-[11px] font-semibold text-white">{slot.time}</div>
                    <div className="text-[9px] text-ink-3">Green Arena FC</div>
                  </div>
                  <span className="text-[10px] font-bold text-brand-green">{slot.price}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
