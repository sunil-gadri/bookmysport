export default function Toast({ message, show }) {
  return (
    <div
      role="alert"
      aria-live="polite"
      className={`fixed bottom-7 right-7 z-[999] bg-surface-2 border border-brand-green/30 rounded-xl py-3.5 px-5 flex items-center gap-[11px] shadow-[0_8px_32px_rgba(0,0,0,0.4)] max-w-[320px] transition-transform duration-300 ${
        show ? 'translate-x-0' : 'translate-x-[150%]'
      }`}
    >
      <i className="ti ti-check text-xl text-brand-green flex-shrink-0" aria-hidden="true" />
      <div className="text-[13.5px] text-ink-1 font-medium">{message}</div>
    </div>
  )
}
