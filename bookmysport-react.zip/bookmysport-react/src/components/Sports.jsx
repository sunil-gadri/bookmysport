import { Pill, SectionTitle } from './ui.jsx'

const SPORTS = [
  ['⚽', 'Football'],
  ['🏏', 'Cricket'],
  ['🏸', 'Badminton'],
  ['🎾', 'Tennis'],
  ['🏊', 'Swimming'],
  ['🥊', 'Boxing'],
  ['🏀', 'Basketball'],
  ['🏐', 'Volleyball'],
]

export default function Sports() {
  return (
    <div id="sports" className="bg-surface-1">
      <div className="max-w-[1120px] mx-auto px-6 py-16">
        <Pill icon="ti-ball-football">Sports available</Pill>
        <SectionTitle className="mb-8">8 sports, one platform</SectionTitle>
        <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
          {SPORTS.map(([emoji, name]) => (
            <div
              key={name}
              className="flex items-center gap-2.5 bg-surface-2 border border-edge rounded-full py-[11px] px-5 whitespace-nowrap flex-shrink-0 text-sm font-semibold text-ink-2 transition-all hover:bg-brand-blue/10 hover:border-brand-blue/30 hover:text-white"
            >
              <span className="text-xl">{emoji}</span> {name}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
