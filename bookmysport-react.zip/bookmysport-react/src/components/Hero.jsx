import { Button } from './ui.jsx'

export default function Hero({ onNavigate }) {
  return (
    <section id="home" className="min-h-screen flex items-center pt-[68px] relative overflow-hidden">
      {/* Background glow + grid */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -top-[200px] left-1/2 -translate-x-1/2 w-[900px] h-[900px] rounded-full bg-[radial-gradient(circle,rgba(41,121,255,0.12)_0%,transparent_65%)]" />
        <div
          className="absolute inset-0 [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_80%)]"
          style={{
            backgroundImage:
              'linear-gradient(rgba(41,121,255,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(41,121,255,0.04) 1px, transparent 1px)',
            backgroundSize: '60px 60px',
          }}
        />
      </div>

      <div className="max-w-[1120px] mx-auto px-6 w-full">
        <div className="grid md:grid-cols-2 gap-[60px] items-center relative z-[2] py-[60px] md:py-20 text-center md:text-left">
          <div>
            <div className="inline-flex items-center gap-2 bg-brand-green/[0.08] border border-brand-green/20 text-brand-green rounded-full px-4 py-[6px] font-heading text-xs font-semibold mb-[22px] tracking-[0.5px]">
              <span className="w-1.5 h-1.5 rounded-full bg-brand-green animate-pulse-dot" />
              India's Fastest Growing Sports Booking Platform
            </div>
            <h1 className="font-heading text-[clamp(32px,5vw,54px)] font-black leading-[1.1] mb-5">
              Book Your Game.
              <br />
              <span className="bg-gradient-to-r from-brand-blue to-brand-cyan bg-clip-text text-transparent">
                Own Your Field.
              </span>
            </h1>
            <p className="text-[17px] text-ink-2 leading-[1.75] max-w-[480px] mb-9 mx-auto md:mx-0">
              Find premium sports turfs near you, check live slot availability, and book in under 60 seconds. Football,
              cricket, badminton, tennis, and more — all in one app.
            </p>
            <div className="flex gap-3 flex-wrap mb-11 justify-center md:justify-start">
              <Button variant="primary" icon="ti-device-mobile">
                Download Free App
              </Button>
              <Button variant="outline" icon="ti-play" onClick={() => onNavigate('how')}>
                See how it works
              </Button>
            </div>
            <div className="flex gap-8 flex-wrap justify-center md:justify-start">
              {[
                ['50k', 'Active players'],
                ['320', 'Partner turfs'],
                ['18', 'Cities covered'],
              ].map(([val, label]) => (
                <div key={label}>
                  <div className="font-heading text-2xl font-extrabold text-white">
                    {val}
                    <span className="text-brand-blue">+</span>
                  </div>
                  <div className="text-xs text-ink-3 mt-0.5">{label}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="hidden md:flex justify-center items-center relative">
            <div className="relative">
              <div className="w-[260px] h-[520px] rounded-[36px] bg-surface-2 border-2 border-edge-strong shadow-[0_32px_80px_rgba(0,0,0,0.5),0_0_0_1px_rgba(255,255,255,0.03)] relative overflow-hidden">
                <div className="absolute inset-0 p-4 px-3 flex flex-col gap-2.5">
                  <div className="flex justify-between text-[10px] text-ink-3 px-1.5 py-1">
                    <span>9:41</span>
                    <span>BMS</span>
                  </div>

                  <div className="bg-gradient-to-br from-[#0a2a1a] to-[#1a4a2a] rounded-[14px] p-3.5 relative overflow-hidden">
                    <div className="absolute -top-5 -right-5 w-20 h-20 rounded-full bg-brand-green/[0.12]" />
                    <div className="text-[8px] text-white/40 mb-1 relative">NEARBY TURF</div>
                    <h5 className="text-[11px] text-brand-green font-bold font-heading mb-1 relative">Green Arena FC</h5>
                    <p className="text-[10px] text-white/60 relative">Vaishali Nagar · 1.2 km away</p>
                    <div className="text-base font-extrabold text-white font-heading mt-2 relative">
                      ₹800<span className="text-[11px] font-normal text-white/60">/hr</span>
                    </div>
                    <div className="mt-2 flex gap-1.5 relative">
                      <span className="text-[9px] text-brand-amber">⭐ 4.8</span>
                      <span className="text-[9px] text-white/30">·</span>
                      <span className="text-[9px] text-brand-green">Open Now</span>
                    </div>
                  </div>

                  <div className="text-[9px] text-ink-3 font-heading font-bold tracking-[0.5px]">SPORTS</div>
                  <div className="grid grid-cols-4 gap-1.5">
                    {[
                      ['⚽', 'Football'],
                      ['🏏', 'Cricket'],
                      ['🏸', 'Badminton'],
                      ['🎾', 'Tennis'],
                    ].map(([emoji, label]) => (
                      <div key={label} className="bg-surface-3 rounded-[9px] py-2 px-1 text-center border border-edge">
                        <span className="text-base block mb-0.5">{emoji}</span>
                        <small className="text-[8px] text-ink-3">{label}</small>
                      </div>
                    ))}
                  </div>

                  <div className="text-[9px] text-ink-3 font-heading font-bold tracking-[0.5px]">TODAY'S SLOTS</div>
                  <div className="flex gap-[5px]">
                    {[
                      ['6 AM', 'bk'],
                      ['7 AM', 'bk'],
                      ['8 AM ✓', 'av'],
                      ['9 AM ✓', 'av'],
                      ['12 PM', 'bl'],
                    ].map(([label, kind]) => (
                      <div
                        key={label}
                        className={`flex-1 rounded-[6px] py-[5px] px-1 text-center text-[8px] font-bold font-heading ${
                          kind === 'av'
                            ? 'bg-brand-green/10 text-brand-green border border-brand-green/25'
                            : kind === 'bk'
                            ? 'bg-brand-blue/10 text-brand-blue border border-brand-blue/25'
                            : 'bg-brand-red/[0.08] text-brand-red border border-brand-red/20 opacity-70'
                        }`}
                      >
                        {label}
                      </div>
                    ))}
                  </div>
                  <div className="bg-brand-blue rounded-lg py-[9px] text-center text-[10px] font-bold text-white font-heading cursor-pointer">
                    Book 8 AM Slot — ₹800
                  </div>
                </div>
              </div>

              <div className="absolute bg-surface-2 border border-edge-strong rounded-xl px-3.5 py-2.5 flex items-center gap-[9px] shadow-[0_8px_24px_rgba(0,0,0,0.4)] top-[30px] -right-[30px]">
                <div className="w-8 h-8 rounded-lg bg-brand-green/10 flex items-center justify-center">
                  <i className="ti ti-check text-brand-green text-[15px]" aria-hidden="true" />
                </div>
                <div>
                  <div className="font-heading text-[13px] font-bold text-white">Instant Booking</div>
                  <div className="text-[10px] text-ink-3">Confirmed in 5 sec</div>
                </div>
              </div>
              <div className="absolute bg-surface-2 border border-edge-strong rounded-xl px-3.5 py-2.5 flex items-center gap-[9px] shadow-[0_8px_24px_rgba(0,0,0,0.4)] bottom-[60px] -left-[30px]">
                <div className="w-8 h-8 rounded-lg bg-brand-amber/10 flex items-center justify-center">
                  <i className="ti ti-wallet text-brand-amber text-[15px]" aria-hidden="true" />
                </div>
                <div>
                  <div className="font-heading text-[13px] font-bold text-white">₹50 Cashback</div>
                  <div className="text-[10px] text-ink-3">First booking offer</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
