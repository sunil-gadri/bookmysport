import { Pill, SectionTitle } from './ui.jsx'

export default function AppDownload() {
  return (
    <section className="py-24 bg-surface-1">
      <div className="max-w-[1120px] mx-auto px-6">
        <div className="bg-[linear-gradient(135deg,rgba(41,121,255,0.1)_0%,rgba(0,230,118,0.05)_100%)] border border-brand-blue/20 rounded-3xl py-12 px-8 md:py-[72px] md:px-[60px] grid md:grid-cols-2 gap-12 items-center relative overflow-hidden text-center md:text-left">
          <div className="absolute -top-20 -right-20 w-[300px] h-[300px] rounded-full bg-[radial-gradient(circle,rgba(0,230,118,0.1)_0%,transparent_70%)] pointer-events-none" />

          <div className="relative z-[1]">
            <Pill icon="ti-device-mobile" className="bg-brand-green/[0.08] border-brand-green/20 text-brand-green">
              Mobile app
            </Pill>
            <SectionTitle className="text-[clamp(24px,3.5vw,36px)] mx-auto md:mx-0">
              Your turf. Your schedule. Your phone.
            </SectionTitle>
            <p className="text-base text-ink-2 leading-[1.7] max-w-[560px] mx-auto md:mx-0">
              Download the BookMySport app and get ₹50 cashback on your very first booking. Available on Android and
              iOS — free forever.
            </p>
            <div className="flex gap-3 flex-wrap mt-7 justify-center md:justify-start">
              <a
                href="#"
                aria-label="Download on Google Play"
                className="flex items-center gap-2.5 bg-white/[0.06] border border-white/[0.12] rounded-[10px] py-[11px] px-5 text-white transition-all hover:bg-white/10"
              >
                <i className="ti ti-brand-google-play text-[22px]" aria-hidden="true" />
                <div>
                  <div className="text-[10px] text-ink-2">Download on</div>
                  <div className="text-[15px] font-bold font-heading">Google Play</div>
                </div>
              </a>
              <a
                href="#"
                aria-label="Download on App Store"
                className="flex items-center gap-2.5 bg-white/[0.06] border border-white/[0.12] rounded-[10px] py-[11px] px-5 text-white transition-all hover:bg-white/10"
              >
                <i className="ti ti-brand-apple text-[22px]" aria-hidden="true" />
                <div>
                  <div className="text-[10px] text-ink-2">Download on</div>
                  <div className="text-[15px] font-bold font-heading">App Store</div>
                </div>
              </a>
            </div>
          </div>

          <div className="hidden md:flex justify-center gap-4 items-end relative z-[1]">
            <div
              className="w-[110px] rounded-[20px] bg-surface-2 border border-edge-strong overflow-hidden"
              style={{ height: 220, transform: 'rotate(-5deg) translateY(10px)' }}
            >
              <div className="p-2.5 px-2 flex flex-col gap-[7px]">
                <div className="h-2 rounded-full bg-brand-blue/40 w-4/5" />
                <div className="h-2 rounded-full bg-surface-3 w-3/5" />
                <div className="grid grid-cols-2 gap-[5px] mt-1">
                  <div className="h-10 bg-brand-blue/[0.15] rounded-md border border-brand-blue/25" />
                  <div className="h-10 bg-brand-green/10 rounded-md border border-brand-green/20" />
                </div>
                <div className="h-2 rounded-full bg-surface-3 w-4/5" />
                <div className="h-2 rounded-full bg-surface-3 w-3/5" />
                <div className="h-2 rounded-full bg-brand-blue/40 w-4/5" />
              </div>
            </div>
            <div className="w-[110px] rounded-[20px] bg-surface-2 border border-edge-strong overflow-hidden" style={{ height: 260 }}>
              <div className="p-2.5 px-2 flex flex-col gap-[7px]">
                <div className="h-2 rounded-full bg-brand-blue/40 w-4/5" />
                <div className="h-2 rounded-full bg-surface-3 w-3/5" />
                <div className="h-[60px] bg-gradient-to-br from-[#0a2a1a] to-[#1a4a2a] rounded-lg flex items-center justify-center text-2xl">
                  🏟️
                </div>
                <div className="h-2 rounded-full bg-surface-3 w-4/5" />
                <div className="h-2 rounded-full bg-surface-3 w-3/5" />
                <div className="flex gap-1">
                  <div className="flex-1 h-5 bg-brand-green/10 rounded border border-brand-green/25" />
                  <div className="flex-1 h-5 bg-brand-blue/10 rounded border border-brand-blue/20" />
                  <div className="flex-1 h-5 bg-brand-red/[0.07] rounded border border-brand-red/[0.15]" />
                </div>
                <div className="bg-brand-blue rounded h-[22px]" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
