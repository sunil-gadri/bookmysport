import { Button } from './ui.jsx'

const MM_ITEMS = [
  { id: 'home', label: 'Home' },
  { id: 'how', label: 'How it Works' },
  { id: 'features', label: 'Features' },
  { id: 'sports', label: 'Sports' },
  { id: 'for-owners', label: 'For Turf Owners' },
  { id: 'contact', label: 'Contact Us' },
]

export default function MobileMenu({ open, onNavigate, onClose }) {
  if (!open) return null
  return (
    <div className="md:hidden fixed inset-0 z-[200] bg-bg/97 backdrop-blur-md flex flex-col px-8 pt-20 pb-10 gap-1.5">
      <button
        className="absolute top-5 right-5 bg-surface-2 border border-edge rounded-lg w-[38px] h-[38px] flex items-center justify-center text-ink-2 text-lg"
        onClick={onClose}
        aria-label="Close menu"
      >
        <i className="ti ti-x" aria-hidden="true" />
      </button>
      {MM_ITEMS.map((item) => (
        <div
          key={item.id}
          className="py-3.5 text-lg font-semibold text-ink-2 border-b border-edge cursor-pointer font-heading hover:text-white"
          onClick={() => onNavigate(item.id)}
        >
          {item.label}
        </div>
      ))}
      <div className="mt-5 flex flex-col gap-2.5">
        <Button variant="outline" className="w-full justify-center">
          Download App
        </Button>
        <Button variant="primary" className="w-full justify-center">
          Book a Turf
        </Button>
      </div>
    </div>
  )
}
