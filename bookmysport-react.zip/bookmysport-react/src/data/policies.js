// Structured content for the five legal / policy pages.
// Each policy has: slug, icon, label, title, effective/updated meta, and sections.
// A section can contain: paragraphs (p), sub-headings (h3), and/or a list (ul) of
// either plain strings or {strong, text} objects (for a bold lead-in phrase).

export const policies = {
  privacy: {
    slug: 'privacy',
    icon: 'ti-shield',
    label: 'Legal',
    title: 'Privacy Policy',
    effective: '1 January 2024',
    updated: '20 June 2026',
    company: 'Infomagine Softwares Pvt. Ltd.',
    sections: [
      {
        h2: '1. Introduction',
        p: [
          'BookMySport ("we", "our", "us") is operated by Infomagine Softwares Pvt. Ltd., registered in India. We are committed to protecting your personal information and your right to privacy. This Privacy Policy explains what information we collect, how we use it, who we share it with, and your rights in relation to it.',
          'By using the BookMySport app or website, you consent to the practices described in this policy. If you do not agree, please discontinue use of our services.',
        ],
      },
      {
        h2: '2. Information we collect',
        blocks: [
          {
            h3: 'Information you provide directly',
            ul: [
              'Name, phone number, and email address when you register',
              'Profile information such as favourite sports and location preferences',
              'Payment details including UPI IDs and saved card information (stored securely via our payment partners)',
              'Messages sent through our support chat or contact form',
              'Reviews and ratings you submit for turfs',
            ],
          },
          {
            h3: 'Information collected automatically',
            ul: [
              'Device information — make, model, OS version, and unique device identifiers',
              'App usage data — screens visited, features used, search queries',
              'Location data — when you grant permission, to show nearby turfs',
              'Log data — IP address, browser type, access time, and referring URLs',
              'Transaction history — booking records, payment amounts, and refund status',
            ],
          },
        ],
      },
      {
        h2: '3. How we use your information',
        ul: [
          'To create and manage your BookMySport account',
          'To process bookings, payments, and refunds',
          'To send booking confirmations, QR gate passes, and reminders',
          'To personalise your turf and sport recommendations',
          'To deliver offers, cashback, and promotional content (you can opt out at any time)',
          'To resolve disputes, investigate fraud, and enforce our Terms and Conditions',
          'To improve the app through analytics and crash reporting',
          'To comply with applicable Indian laws and regulations',
        ],
      },
      {
        h2: '4. Sharing your information',
        p: ['We do not sell your personal data. We share it only in the following circumstances:'],
        ul: [
          { strong: 'Turf owners', text: 'Your name and booking details are shared with the venue you book so they can manage entry' },
          { strong: 'Payment processors', text: 'Razorpay and similar partners receive only what is necessary to complete transactions' },
          { strong: 'Analytics providers', text: 'Anonymised usage data is shared with analytics tools to improve our services' },
          { strong: 'Legal compliance', text: 'We may disclose data to law enforcement or regulatory authorities when legally required' },
        ],
      },
      {
        h2: '5. Data retention',
        p: [
          'We retain your personal data for as long as your account is active or as required by law. Transaction records are kept for a minimum of 7 years for accounting and legal purposes. You may request deletion of your account at any time — see Section 7.',
        ],
      },
      {
        h2: '6. Security',
        p: [
          'We use industry-standard encryption (TLS 1.2 and above) for data in transit, and AES-256 encryption for stored payment data. Our systems undergo regular security audits. However, no system is completely immune to breach — if a data incident affects you, we will notify you as required by Indian data protection law.',
        ],
      },
      {
        h2: '7. Your rights',
        ul: [
          'Access the personal data we hold about you',
          'Correct inaccurate or incomplete data',
          'Request deletion of your account and associated data',
          'Opt out of promotional communications at any time via app settings',
          'Withdraw consent for location tracking at any time via device settings',
        ],
        pAfter: ['To exercise any of these rights, write to us at privacy@bookmysport.in.'],
      },
      {
        h2: '8. Contact',
        p: ['Infomagine Softwares Pvt. Ltd.<br/>Malviya Nagar, Jaipur, Rajasthan – 302017<br/>privacy@bookmysport.in'],
      },
    ],
  },

  terms: {
    slug: 'terms',
    icon: 'ti-file-text',
    label: 'Legal',
    title: 'Terms & Conditions',
    effective: '1 January 2024',
    updated: '20 June 2026',
    company: 'Infomagine Softwares Pvt. Ltd.',
    sections: [
      {
        h2: '1. Agreement to terms',
        p: [
          'By downloading the BookMySport app, visiting bookmysport.in, or making any booking, you confirm that you have read, understood, and agree to be bound by these Terms and Conditions and our Privacy Policy. If you are under 18, you must have the consent of a parent or guardian.',
        ],
      },
      {
        h2: '2. Use of the platform',
        ul: [
          'BookMySport is a booking intermediary — we connect players with turf owners. We are not the turf owner or service provider.',
          'You must create an account with accurate information. One account per person.',
          'You may not use the platform for commercial resale of slots without prior written permission.',
          'You must not post false reviews, manipulate ratings, or misrepresent your identity.',
          'We reserve the right to suspend or terminate any account that violates these terms without notice.',
        ],
      },
      {
        h2: '3. Bookings and payments',
        ul: [
          'A booking is confirmed only when full payment is received and a booking confirmation is issued.',
          'Prices displayed are inclusive of platform fees unless stated otherwise.',
          'BookMySport is not responsible for service quality issues at the turf — disputes must first be raised with the turf owner.',
          'In cases of genuine provider failure, BookMySport may at its discretion offer a refund or rebooking assistance.',
        ],
      },
      {
        h2: '4. Prohibited conduct',
        ul: [
          'Making fraudulent bookings or initiating false chargebacks',
          'Using the platform for illegal activities of any kind',
          'Harassing, threatening, or abusing turf staff or other users',
          'Attempting to access accounts other than your own',
          'Scraping, reverse-engineering, or copying content from the platform',
          'Creating multiple accounts to abuse referral or cashback offers',
        ],
      },
      {
        h2: '5. Intellectual property',
        p: [
          'All content on the BookMySport platform — including the app design, logo, text, graphics, and code — is the exclusive property of Infomagine Softwares Pvt. Ltd. and protected by applicable intellectual property laws. You may not reproduce, distribute, or create derivative works without written consent.',
        ],
      },
      {
        h2: '6. Limitation of liability',
        p: [
          'BookMySport is provided "as is". To the fullest extent permitted by Indian law, Infomagine Softwares Pvt. Ltd. is not liable for indirect, incidental, or consequential damages arising from use of the platform, including but not limited to missed games, injuries at venues, or service disruptions.',
        ],
      },
      {
        h2: '7. Governing law',
        p: [
          'These Terms are governed by and construed in accordance with the laws of India. Any disputes shall be subject to the exclusive jurisdiction of the courts of Jaipur, Rajasthan.',
        ],
      },
      {
        h2: '8. Changes to these terms',
        p: [
          'We may update these Terms at any time. Continued use of the platform after changes constitutes acceptance. We will notify you of material changes via in-app notification or email.',
        ],
      },
    ],
  },

  refund: {
    slug: 'refund',
    icon: 'ti-refresh',
    label: 'Policy',
    title: 'Refund & Cancellation Policy',
    effective: '1 January 2024',
    updated: '20 June 2026',
    sections: [
      {
        h2: '1. Our cancellation policy',
        p: ['We understand that plans change. BookMySport offers a fair and transparent cancellation policy to protect both players and turf owners.'],
      },
      {
        h2: '2. Player cancellations',
        ul: [
          { strong: '100% refund', color: 'text-brand-green', text: 'cancelled 2 or more hours before the slot start time' },
          { strong: '50% refund', color: 'text-brand-amber', text: 'cancelled between 1 hour and 2 hours before the slot start time' },
          { strong: 'No refund', color: 'text-brand-red', text: 'cancelled less than 1 hour before the slot start time or no-show' },
          'Refunds are credited to your BMS Wallet within 2 hours. Bank refunds (where applicable) may take 3–7 business days.',
          'The platform fee (if any) is non-refundable.',
        ],
      },
      {
        h2: '3. Rescheduling',
        ul: [
          'You may reschedule a booking up to 2 hours before the slot, subject to availability at the same turf.',
          'Rescheduling is free of charge, once per booking.',
          'The new slot must be at the same turf and of equal or lesser value. Difference in price is not refunded if the new slot costs less.',
        ],
      },
      {
        h2: '4. Cancellation by turf owner',
        ul: [
          'If a turf owner cancels your confirmed booking, you receive a full 100% refund — no questions asked.',
          'You will also receive a ₹50 goodwill credit to your BMS Wallet for the inconvenience.',
          'BookMySport will assist you in finding an alternative slot at a comparable turf if available.',
        ],
      },
      {
        h2: '5. Special circumstances',
        ul: [
          { strong: 'Rain or weather', text: 'If a game is cancelled due to weather and the turf owner confirms this, a full refund is issued.' },
          { strong: 'Power failure or venue issue', text: 'If the turf is unusable on arrival for reasons outside your control, contact support within 30 minutes for a full refund.' },
          { strong: 'Medical emergency', text: 'With valid documentation, cancellations within the no-refund window may be reviewed on a case-by-case basis.' },
        ],
      },
      {
        h2: '6. How to cancel',
        p: ['Open the BookMySport app → My Bookings → Select the booking → Tap Cancel. You can also contact support at support@bookmysport.in or WhatsApp us at +91 98100 00001.'],
      },
      {
        h2: '7. Refund timeline',
        ul: [
          'BMS Wallet — within 2 hours of cancellation',
          'UPI — within 24 hours',
          'Debit / Credit card — within 3–7 business days (depending on your bank)',
          'Net banking — within 3–5 business days',
        ],
      },
    ],
  },

  cookie: {
    slug: 'cookie',
    icon: 'ti-cookie',
    label: 'Policy',
    title: 'Cookie Policy',
    effective: '1 January 2024',
    updated: '20 June 2026',
    sections: [
      {
        h2: '1. What are cookies?',
        p: ['Cookies are small text files placed on your device when you visit a website. They help websites remember your preferences and understand how you use the site.'],
      },
      {
        h2: '2. Cookies we use',
        ul: [
          { strong: 'Essential cookies', text: 'Required for login sessions, booking cart, and security. Cannot be disabled.' },
          { strong: 'Performance cookies', text: 'Help us understand how visitors interact with our site (anonymous analytics data).' },
          { strong: 'Preference cookies', text: 'Remember your city, sport preferences, and display settings.' },
          { strong: 'Marketing cookies', text: 'Used with your consent to show relevant offers on other platforms.' },
        ],
      },
      {
        h2: '3. Managing cookies',
        p: ['You can control cookies through your browser settings. Disabling essential cookies will affect your ability to log in and use core features of the site. Third-party cookies can be disabled without impacting core functionality.'],
      },
      {
        h2: '4. Third-party cookies',
        p: ['We use Google Analytics, Meta Pixel, and Razorpay. Each of these services may place their own cookies as described in their respective privacy policies. BookMySport does not control these third-party cookies.'],
      },
    ],
  },

  grievance: {
    slug: 'grievance',
    icon: 'ti-alert-triangle',
    label: 'Policy',
    title: 'Grievance Redressal Policy',
    effective: '1 January 2024',
    updated: '20 June 2026',
    company: 'Infomagine Softwares Pvt. Ltd.',
    sections: [
      {
        h2: '1. Our commitment',
        p: ['BookMySport is committed to resolving every complaint quickly, fairly, and transparently. In compliance with the Information Technology Act 2000 and Consumer Protection (E-Commerce) Rules 2020, we maintain a formal grievance redressal mechanism.'],
      },
      {
        h2: '2. How to raise a grievance',
        ul: [
          'In-app: Settings → Help & Support → Raise a ticket',
          'Email: grievance@bookmysport.in',
          'WhatsApp: +91 98100 00001',
          'Written: Grievance Officer, Infomagine Softwares Pvt. Ltd., Malviya Nagar, Jaipur – 302017',
        ],
      },
      {
        h2: '3. Grievance Officer',
        p: ['Name: Vikas Jain<br/>Designation: Grievance Officer / Project Manager<br/>Email: grievance@bookmysport.in<br/>Phone: +91 98100 00001<br/>Available: Monday – Friday, 10 AM – 6 PM IST'],
      },
      {
        h2: '4. Resolution timelines',
        ul: [
          'Acknowledgement of grievance — within 24 hours',
          'Initial response — within 48 hours',
          'Resolution or escalation — within 15 working days',
          'Refund processing (where applicable) — as per Refund Policy timelines',
        ],
      },
      {
        h2: '5. Escalation',
        p: ['If you are not satisfied with the resolution, you may escalate to the National Consumer Helpline at 1800-11-4000 or the Consumer Disputes Redressal Forum applicable to your jurisdiction.'],
      },
    ],
  },
}

export const policyOrder = ['terms', 'privacy', 'refund', 'cookie', 'grievance']
