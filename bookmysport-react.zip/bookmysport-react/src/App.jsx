import { useEffect, useRef, useState } from 'react'
import Navbar from './components/Navbar.jsx'
import MobileMenu from './components/MobileMenu.jsx'
import Hero from './components/Hero.jsx'
import StatsBar from './components/StatsBar.jsx'
import HowItWorks from './components/HowItWorks.jsx'
import Sports from './components/Sports.jsx'
import Features from './components/Features.jsx'
import ForOwners from './components/ForOwners.jsx'
import Testimonials from './components/Testimonials.jsx'
import AppDownload from './components/AppDownload.jsx'
import Contact from './components/Contact.jsx'
import Footer from './components/Footer.jsx'
import Toast from './components/Toast.jsx'
import PolicyPage from './pages/PolicyPage.jsx'
import { policies } from './data/policies.js'

const SECTION_IDS = ['home', 'how', 'features', 'sports', 'for-owners', 'testimonials', 'contact']

export default function App() {
  const [view, setView] = useState('main') // 'main' | policy slug
  const [mobileOpen, setMobileOpen] = useState(false)
  const [activeSection, setActiveSection] = useState('home')
  const [formTab, setFormTab] = useState('user')
  const [toast, setToast] = useState({ show: false, message: '' })
  const toastTimer = useRef(null)

  const showToast = (message) => {
    setToast({ show: true, message })
    clearTimeout(toastTimer.current)
    toastTimer.current = setTimeout(() => setToast((t) => ({ ...t, show: false })), 4000)
  }

  const goToMain = () => {
    setView('main')
    window.scrollTo({ top: 0 })
  }

  const goToPolicy = (slug) => {
    setView(slug)
    window.scrollTo({ top: 0 })
  }

  const scrollToSection = (id) => {
    if (view !== 'main') {
      setView('main')
      setTimeout(() => {
        const el = document.getElementById(id)
        if (el) window.scrollTo({ top: el.offsetTop - 70, behavior: 'smooth' })
      }, 60)
      return
    }
    const el = document.getElementById(id)
    if (el) window.scrollTo({ top: el.offsetTop - 70, behavior: 'smooth' })
  }

  const handleNavigate = (id) => {
    scrollToSection(id)
    setMobileOpen(false)
  }

  // Scroll-spy: highlight the nav item for the section currently in view.
  useEffect(() => {
    if (view !== 'main') return
    const onScroll = () => {
      const fromTop = window.scrollY + 100
      for (const id of SECTION_IDS) {
        const el = document.getElementById(id)
        if (el && el.offsetTop <= fromTop && el.offsetTop + el.offsetHeight > fromTop) {
          setActiveSection(id)
          break
        }
      }
    }
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [view])

  return (
    <>
      <MobileMenu open={mobileOpen} onNavigate={handleNavigate} onClose={() => setMobileOpen(false)} />
      <Navbar activeSection={activeSection} onNavigate={handleNavigate} onOpenMobile={() => setMobileOpen(true)} />

      {view === 'main' ? (
        <main>
          <Hero onNavigate={scrollToSection} />
          <StatsBar />
          <HowItWorks />
          <Sports />
          <Features />
          <ForOwners onSwitchToOwnerTab={() => setFormTab('owner')} onNavigate={scrollToSection} />
          <Testimonials />
          <AppDownload />
          <Contact
            formTab={formTab}
            onSetFormTab={setFormTab}
            onNavigatePolicy={goToPolicy}
            onSubmitted={showToast}
          />
        </main>
      ) : (
        <PolicyPage policy={policies[view]} />
      )}

      <Footer onNavigate={handleNavigate} onNavigatePolicy={goToPolicy} />
      <Toast show={toast.show} message={toast.message} />
    </>
  )
}
