<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\CartItem;

class ExpireCartHolds extends Command
{
    /**
     * php artisan cart:expire
     */
    protected $signature = 'cart:expire';

    protected $description = 'Delete cart items whose 10-minute hold has run out, freeing the slots for other users.';

    public function handle(): int
    {
        $expired = CartItem::where('expires_at', '<=', now())->get();

        if ($expired->isEmpty()) {
            $this->info('No expired cart holds.');
            return self::SUCCESS;
        }

        $count = $expired->count();

        // Deleting the CartItem also deletes its CartItemSlot rows
        // (cascadeOnDelete on the foreign key) — that's what actually
        // frees the slot up for everyone else.
        foreach ($expired as $cartItem) {
            $cartItem->delete();
        }

        $this->info("Expired and removed {$count} cart hold(s).");

        return self::SUCCESS;
    }
}