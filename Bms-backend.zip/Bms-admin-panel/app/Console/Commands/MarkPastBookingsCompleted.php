<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Booking;

class MarkPastBookingsCompleted extends Command
{
    /**
     * php artisan bookings:complete
     */
    protected $signature = 'bookings:complete';

    protected $description = 'Mark confirmed bookings whose last slot has already ended as completed.';

    public function handle(): int
    {
        $today = now()->toDateString();
        $currentTime = now()->format('H:i:s');

        $candidates = Booking::query()
            ->where('booking_status', 'confirmed')
            ->where(function ($q) use ($today) {
                $q->whereDate('booking_date', '<', $today)
                    ->orWhereDate('booking_date', $today);
            })
            ->with('bookingItems.slotMaster')
            ->get();

        $count = 0;

        foreach ($candidates as $booking) {

            $lastSlotEnd = $booking->bookingItems
                ->map(fn ($item) => $item->slotMaster)
                ->filter()
                ->max('end_time');

            if (!$lastSlotEnd) {
                continue;
            }

            $hasEnded = $booking->booking_date->toDateString() < $today
                || ($booking->booking_date->toDateString() === $today && $lastSlotEnd <= $currentTime);

            if ($hasEnded) {
                $booking->update(['booking_status' => 'completed']);
                $count++;
            }
        }

        $this->info("Marked {$count} booking(s) as completed.");

        return self::SUCCESS;
    }
}