<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\Sport;


class UserProfile extends Model
{

    protected $fillable = [
        'user_id',
        'full_name',
        'email',
        'profile_image',
        'gender',
        'date_of_birth',
        'country_id',
        'state_id',
        'city_id',
        'address',
        'pincode',
    ];



    public function favouriteSports()
    {
        return $this->belongsToMany(
            Sport::class,
            'user_profile_favourite_sports',
            'user_profile_id',
            'sport_id'
        )->withTimestamps();
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function country(): BelongsTo
    {
        return $this->belongsTo(Country::class);
    }

    public function state(): BelongsTo
    {
        return $this->belongsTo(State::class);
    }

    public function city(): BelongsTo
    {
        return $this->belongsTo(City::class);
    }

    
}