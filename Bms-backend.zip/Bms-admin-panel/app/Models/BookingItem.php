<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BookingItem extends Model
{
    protected $fillable = [

        'booking_id',

        'slot_master_id',

        'price',

    ];

     protected $casts = [
       'price' => 'decimal:2',
   ];

    /**
     * Booking Item belongs to Booking
     */
    public function booking()
    {
        return $this->belongsTo(Booking::class);
    }

    /**
     * Booking Item belongs to Slot Master
     */
    public function slotMaster()
    {
        return $this->belongsTo(SlotMaster::class);
    }
}