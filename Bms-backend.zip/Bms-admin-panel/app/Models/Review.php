<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    public const HIGHLIGHT_OPTIONS = [
        'great_surface',
        'flood_lights',
        'parking',
        'clean_rooms',
        'friendly_staff',
    ];

    protected $fillable = [
        'user_id',
        'turf_id',
        'booking_id',
        'rating',
        'what_went_well',
        'comment',
    ];

    protected $casts = [
        'rating' => 'integer',
        'what_went_well' => 'array',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function turf()
    {
        return $this->belongsTo(Turf::class);
    }

    public function booking()
    {
        return $this->belongsTo(Booking::class);
    }
}