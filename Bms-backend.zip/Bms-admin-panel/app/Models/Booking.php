<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    protected $fillable = [

        'booking_number',

        'user_id',

        'turf_id',

        'booking_type',

        'booking_type_id',

        'booking_date',

        'total_amount',

        'booking_status',

        'payment_status',

        'payment_reference',

        'check_in_token',

        'checked_in_at',

    ];

    protected $casts = [
        'booking_date' => 'date',
        'checked_in_at' => 'datetime',
        'total_amount' => 'decimal:2',
       'platform_fee' => 'decimal:2',
       'turf_owner_amount' => 'decimal:2',
    ];

    /**
     * Booking belongs to User
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Booking belongs to Turf
     */
    public function turf()
    {
        return $this->belongsTo(Turf::class);
    }

    /**
     * Booking has many Booking Items
     */
    public function bookingItems()
    {
        return $this->hasMany(BookingItem::class);
    }


}