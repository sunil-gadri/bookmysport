<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Sport extends Model
{
    protected $fillable = [
        'name',
        'slug',
        'selected_icon',
        'unselected_icon',
        'status',
        'sort_order',
    ];

    protected $casts = [
        'status' => 'integer',
        'sort_order' => 'integer',
    ];

    public function turfs()
    {
        return $this->belongsToMany(
            Turf::class,
            'turf_sports',
            'sport_id',
            'turf_id'
        )->withTimestamps();
    }

}