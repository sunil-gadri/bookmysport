<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;

class Turf extends Model
{
    
    protected $fillable = [
        'owner_id',
        'name',
        'slug',
        'description',
        'cover_image',
        'contact_number',
        'email',
        'address',
        'area',
        'landmark',
        'country_id',
        'state_id',
        'city_id',
        'pincode',
        'latitude',
        'longitude',
        'opening_time',
        'closing_time',
        'ground_type',
        'is_featured',
        'average_rating',
        'total_reviews',
        'status',
        'approval_status',
        'rejection_reason',
    ];

    protected function casts(): array
    {
        return [
            'status' => 'boolean',
            'is_featured' => 'boolean',
            'latitude' => 'decimal:7',
            'longitude' => 'decimal:7',
            'average_rating' => 'decimal:2',
            'opening_time' => 'datetime:H:i',
            'closing_time' => 'datetime:H:i',
        ];
    }

    public function owner()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    public function country()
    {
        return $this->belongsTo(Country::class);
    }

    public function state()
    {
        return $this->belongsTo(State::class);
    }

    public function city()
    {
        return $this->belongsTo(City::class);
    }

    public function sports()
    {
        return $this->belongsToMany(
            Sport::class,
            'turf_sports',
            'turf_id',
            'sport_id'
        )->withTimestamps();
    }

    public function amenities()
    {
        return $this->belongsToMany(
            Amenity::class,
            'turf_amenities',
            'turf_id',
            'amenity_id'
        )->withTimestamps();
    }


    public function events()
    {
        return $this->belongsToMany(
            Event::class,
            'turf_events',
            'turf_id',
            'event_id'
        )->withTimestamps();
    }


    public function images()
    {
        return $this->hasMany(TurfImage::class);
    }


    protected function coverImage(): Attribute
    {
        return Attribute::make(
            get: fn ($value) => $value
                ? Storage::disk('public')->url($value)
                : null,
        );
    }


    public function favouriteUsers()
    {
        return $this->belongsToMany(
            User::class,
            'user_favourite_turfs'
        )->withTimestamps();
    }


    public function slotMasters()
    {
        return $this->hasMany(SlotMaster::class, 'turf_id');
    }



    public function scopeWithDistance($query, float $latitude, float $longitude)
    {
        return $query->selectRaw("
            *,
            (
                6371 *
                ACOS(
                    COS(RADIANS(?))
                    *
                    COS(RADIANS(latitude))
                    *
                    COS(RADIANS(longitude) - RADIANS(?))
                    +
                    SIN(RADIANS(?))
                    *
                    SIN(RADIANS(latitude))
                )
            ) AS distance
        ", [
            $latitude,
            $longitude,
            $latitude,
        ]);
    }

    /**
     * Turf has many Bookings
     */
    public function bookings()
    {
        return $this->hasMany(Booking::class);
    }


    /**
     * Check whether the turf is currently open.
     */
    public function isOpen(): bool
    {
        if (!$this->opening_time || !$this->closing_time) {
            return false;
        }

        $currentTime = Carbon::now();

        $openingTime = Carbon::parse($this->opening_time);

        $closingTime = Carbon::parse($this->closing_time);

        // Same-day timing
        if ($openingTime->lessThan($closingTime)) {

            return $currentTime->between(
                $openingTime,
                $closingTime
            );
        }

        // Overnight timing
        return $currentTime->greaterThanOrEqualTo($openingTime)
            || $currentTime->lessThanOrEqualTo($closingTime);
    }


    public function reviews()
{
    return $this->hasMany(Review::class);
}

}