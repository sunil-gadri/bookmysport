<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Support\Facades\Storage;

class TurfImage extends Model
{
    protected $fillable = [
        'turf_id',
        'image',
        'sort_order',
    ];

    public function turf()
    {
        return $this->belongsTo(Turf::class);
    }

    protected function image(): Attribute
    {
        return Attribute::make(
            get: fn ($value) => $value
                ? Storage::disk('public')->url($value)
                : null,
        );
    }

}