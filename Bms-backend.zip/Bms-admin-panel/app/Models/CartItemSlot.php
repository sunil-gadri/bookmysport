<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CartItemSlot extends Model
{
    protected $fillable = [
        'cart_item_id',
        'slot_master_id',
        'price',
    ];

    protected $casts = [
        'price' => 'decimal:2',
    ];

    public function cartItem()
    {
        return $this->belongsTo(CartItem::class);
    }

    public function slotMaster()
    {
        return $this->belongsTo(SlotMaster::class);
    }
}