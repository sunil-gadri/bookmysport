<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TurfOwnerProfile extends Model
{   
    protected $fillable = [
        'user_id',
        'business_name',
        'business_email',
        'business_phone',
        'profile_image',
        'description',
        'address',
        'country_id',
        'state_id',
        'city_id',
        'pincode',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function country()
    {
        return $this->belongsTo(Country::class);
    }

    public function state()
    {
        return $this->belongsTo(State::class);
    }

    public function city()
    {
        return $this->belongsTo(City::class);
    }
}