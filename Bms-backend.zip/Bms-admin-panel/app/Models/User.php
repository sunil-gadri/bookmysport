<?php

namespace App\Models;

use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use App\Models\UserProfile;
use Illuminate\Database\Eloquent\Relations\HasOne;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'mobile',
        'password',
        'status',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'status' => 'boolean',
        ];
    }

    

    public function profile(): HasOne
    {
        return $this->hasOne(UserProfile::class);
    }

    public function roles()
    {
        return $this->belongsToMany(
            Role::class,
            'user_roles',
            'user_id',
            'role_id'
        )->withTimestamps();
    }

    public function turfOwnerProfile()
    {
        return $this->hasOne(TurfOwnerProfile::class, 'user_id');
    }

    public function turfs()
    {
        return $this->hasMany(Turf::class, 'owner_id');
    }


    public function favouriteTurfs()
    {
        return $this->belongsToMany(
            Turf::class,
            'user_favourite_turfs'
        )->withTimestamps();
    }


    /**
     * User has many Bookings
     */
    public function bookings()
    {
        return $this->hasMany(Booking::class);
    }

    public function cartItems()
    {
        return $this->hasMany(CartItem::class);
    }

}