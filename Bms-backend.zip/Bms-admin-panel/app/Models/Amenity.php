<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Amenity extends Model
{
    protected $fillable = [
        'name',
        'slug',
        'icon',
        'status',
        'sort_order',
    ];

    protected function casts(): array
    {
        return [
            'status' => 'boolean',
            'sort_order' => 'integer',
        ];
    }

    public function turfs()
    {
        return $this->belongsToMany(
            Turf::class,
            'turf_amenities',
            'amenity_id',
            'turf_id'
        )->withTimestamps();
    }

}