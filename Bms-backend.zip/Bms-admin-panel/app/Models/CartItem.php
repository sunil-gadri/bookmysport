<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Sport;
use App\Models\Event;

class CartItem extends Model
{
    protected $fillable = [
        'user_id',
        'turf_id',
        'booking_type',
        'booking_type_id',
        'booking_date',
        'expires_at',
    ];

    protected $casts = [
        'booking_date' => 'date',
        'expires_at' => 'datetime',
    ];

    protected $appends = [
        'booking_name',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function turf()
    {
        return $this->belongsTo(Turf::class);
    }

    public function cartItemSlots()
    {
        return $this->hasMany(CartItemSlot::class);
    }

    public function getBookingNameAttribute()
    {
        if ($this->booking_type === 'sport') {
            return Sport::where('id', $this->booking_type_id)->value('name');
        }

        return Event::where('id', $this->booking_type_id)->value('name');
    }
}