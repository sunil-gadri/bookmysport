<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserFavouriteTurf extends Model
{
    protected $fillable = [
        'user_id',
        'turf_id',
    ];

    /**
     * Favourite belongs to a User
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Favourite belongs to a Turf
     */
    public function turf()
    {
        return $this->belongsTo(Turf::class);
    }
}