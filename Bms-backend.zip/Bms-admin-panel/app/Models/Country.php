<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Country extends Model
{
    protected $fillable = [
        'id',
        'name',
        'iso2',
        'phone_code',
        'status',
    ];

    protected $casts = [
        'status' => 'boolean',
    ];

    public function states(): HasMany
    {
        return $this->hasMany(State::class);
    }
    
    public function userProfiles(): HasMany
    {
        return $this->hasMany(UserProfile::class);
    }

}