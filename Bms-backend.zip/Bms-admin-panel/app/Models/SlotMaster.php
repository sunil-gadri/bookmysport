<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Sport;
use App\Models\Event;

class SlotMaster extends Model
{
    protected $fillable = [
        'turf_id',
        'booking_type',
        'booking_type_id',
        'day',
        'start_time',
        'end_time',
        'price',
        'status',
    ];

    protected $casts = [
        'status' => 'boolean',
        'price' => 'decimal:2',
    ];

    protected $appends = [
        'booking_name',
    ];

    public function turf()
    {
        return $this->belongsTo(Turf::class);
    }

    public function getBookingNameAttribute()
    {
        if ($this->booking_type === 'sport') {
            return Sport::where('id', $this->booking_type_id)->value('name');
        }

        if ($this->booking_type === 'event') {
            return Event::where('id', $this->booking_type_id)->value('name');
        }

        return null;
    }

    /**
     * Slot has many Booking Items
     */
    public function bookingItems()
    {
        return $this->hasMany(BookingItem::class);
    }

}