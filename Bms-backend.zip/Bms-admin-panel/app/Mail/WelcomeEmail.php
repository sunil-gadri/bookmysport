<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class WelcomeEmail extends Mailable
{
    use Queueable, SerializesModels;

    public string $recipientName;
    public string $role; // 'user' or 'turf_owner'

    /**
     * @param string $recipientName  Person's name, for the greeting.
     * @param string $role           'user' or 'turf_owner' — slightly
     *                                different copy for each.
     */
    public function __construct(string $recipientName, string $role = 'user')
    {
        $this->recipientName = $recipientName;
        $this->role = $role;
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: $this->role === 'turf_owner'
                ? 'Welcome to BookMySport — List Your Turf & Start Earning!'
                : 'Welcome to BookMySport! 🏏⚽',
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.welcome',
            with: [
                'recipientName' => $this->recipientName,
                'role' => $this->role,
            ],
        );
    }
}