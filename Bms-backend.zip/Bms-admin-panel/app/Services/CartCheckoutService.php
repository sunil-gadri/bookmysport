<?php

namespace App\Services;

use App\Mail\BookingConfirmedEmail;
use App\Models\CartItem;
use App\Models\SlotMaster;
use App\Models\BookingItem;
use App\Models\Booking;
use App\Models\PaymentOrder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;

class CartCheckoutService
{
    public function finalize(PaymentOrder $order): array
    {
        Log::info('CHECKOUT: Finalize started', [
            'payment_order_id' => $order->id,
            'razorpay_order_id' => $order->razorpay_order_id,
            'razorpay_payment_id' => $order->razorpay_payment_id,
            'user_id' => $order->user_id,
            'status' => $order->status,
            'finalized_at' => $order->finalized_at,
        ]);

        /*
        |--------------------------------------------------------------------------
        | Already Finalized
        |--------------------------------------------------------------------------
        */

        if ($order->finalized_at !== null) {

            Log::warning('CHECKOUT: Order already finalized', [
                'payment_order_id' => $order->id,
                'user_id' => $order->user_id,
            ]);

            return [
                'already_finalized' => true,
                'bookings' => [],
            ];
        }

        /*
        |--------------------------------------------------------------------------
        | Get Cart Items
        |--------------------------------------------------------------------------
        */

        $cartItems = CartItem::with('cartItemSlots.slotMaster')
            ->where('user_id', $order->user_id)
            ->get();

        Log::info('CHECKOUT: Cart items loaded', [
            'payment_order_id' => $order->id,
            'user_id' => $order->user_id,
            'cart_item_count' => $cartItems->count(),
        ]);

        if ($cartItems->isEmpty()) {

            Log::error('CHECKOUT: Cart is empty', [
                'payment_order_id' => $order->id,
                'user_id' => $order->user_id,
            ]);

            throw new \RuntimeException(
                'Payment received but cart is empty — refund required for order '
                . $order->razorpay_order_id
            );
        }

        DB::beginTransaction();

        try {

            $createdBookings = [];

            /*
            |--------------------------------------------------------------------------
            | Create Bookings
            |--------------------------------------------------------------------------
            */

            foreach ($cartItems as $cartItem) {

                Log::info('CHECKOUT: Processing cart item', [
                    'cart_item_id' => $cartItem->id,
                    'user_id' => $order->user_id,
                    'turf_id' => $cartItem->turf_id,
                    'booking_type' => $cartItem->booking_type,
                    'booking_type_id' => $cartItem->booking_type_id,
                    'booking_date' => $cartItem->booking_date,
                ]);

                $slotIds = $cartItem->cartItemSlots
                    ->pluck('slot_master_id')
                    ->toArray();

                Log::info('CHECKOUT: Slot IDs loaded', [
                    'cart_item_id' => $cartItem->id,
                    'slot_ids' => $slotIds,
                ]);

                /*
                |--------------------------------------------------------------------------
                | Lock Slots
                |--------------------------------------------------------------------------
                */

                $slots = SlotMaster::query()
                    ->whereIn('id', $slotIds)
                    ->lockForUpdate()
                    ->get();

                Log::info('CHECKOUT: Slots locked', [
                    'cart_item_id' => $cartItem->id,
                    'slot_count' => $slots->count(),
                ]);

                /*
                |--------------------------------------------------------------------------
                | Check Slot Availability
                |--------------------------------------------------------------------------
                */

                $alreadyBooked = BookingItem::query()
                    ->whereIn('slot_master_id', $slotIds)
                    ->whereHas('booking', function ($query) use ($cartItem) {

                        $query->whereDate(
                            'booking_date',
                            $cartItem->booking_date
                        )->whereIn('booking_status', [
                            'pending',
                            'confirmed',
                            'completed',
                        ]);
                    })
                    ->exists();

                if ($alreadyBooked) {

                    Log::error('CHECKOUT: Slot already booked', [
                        'cart_item_id' => $cartItem->id,
                        'slot_ids' => $slotIds,
                        'booking_date' => $cartItem->booking_date,
                    ]);

                    DB::rollBack();

                    throw new \RuntimeException(
                        "Payment received but slot for cart item {$cartItem->id} "
                        . "is no longer available — refund required for order "
                        . $order->razorpay_order_id
                    );
                }

                /*
                |--------------------------------------------------------------------------
                | Calculate Amount
                |--------------------------------------------------------------------------
                */

                $totalAmount = $slots->sum('price');

                /*
                |--------------------------------------------------------------------------
                | Create Booking
                |--------------------------------------------------------------------------
                */

                $booking = Booking::create([
                    'booking_number' => '',
                    'user_id' => $order->user_id,
                    'turf_id' => $cartItem->turf_id,
                    'booking_type' => $cartItem->booking_type,
                    'booking_type_id' => $cartItem->booking_type_id,
                    'booking_date' => $cartItem->booking_date,
                    'total_amount' => $totalAmount,
                    'booking_status' => 'confirmed',
                    'payment_status' => 'paid',
                    'payment_reference' => $order->razorpay_payment_id,
                    'check_in_token' => bin2hex(random_bytes(32)),
                ]);

                /*
                |--------------------------------------------------------------------------
                | Booking Number
                |--------------------------------------------------------------------------
                */

                $booking->booking_number =
                    'BMS' . str_pad(
                        $booking->id,
                        6,
                        '0',
                        STR_PAD_LEFT
                    );

                $booking->save();

                /*
                |--------------------------------------------------------------------------
                | Booking Items
                |--------------------------------------------------------------------------
                */

                $items = [];

                foreach ($slots as $slot) {

                    $items[] = [
                        'booking_id' => $booking->id,
                        'slot_master_id' => $slot->id,
                        'price' => $slot->price,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ];
                }

                BookingItem::insert($items);

                Log::info('CHECKOUT: Booking created successfully', [
                    'booking_id' => $booking->id,
                    'booking_number' => $booking->booking_number,
                    'user_id' => $booking->user_id,
                    'turf_id' => $booking->turf_id,
                    'amount' => $booking->total_amount,
                ]);

                $createdBookings[] = [
                    'booking_id' => $booking->id,
                    'booking_number' => $booking->booking_number,
                    'booking_date' => $booking->booking_date->toDateString(),
                    'total_amount' => $booking->total_amount,
                    'booking_status' => $booking->booking_status,
                    'payment_status' => $booking->payment_status,
                ];
            }

            /*
            |--------------------------------------------------------------------------
            | Delete Cart
            |--------------------------------------------------------------------------
            */

            CartItem::where('user_id', $order->user_id)->delete();

            /*
            |--------------------------------------------------------------------------
            | Update Payment Order
            |--------------------------------------------------------------------------
            */

            $order->update([
                'status' => 'paid',
                'finalized_at' => now(),
            ]);

            /*
            |--------------------------------------------------------------------------
            | Commit
            |--------------------------------------------------------------------------
            */

            DB::commit();

            Log::info('CHECKOUT: Transaction committed', [
                'payment_order_id' => $order->id,
                'user_id' => $order->user_id,
                'booking_count' => count($createdBookings),
            ]);

            /*
            |--------------------------------------------------------------------------
            | BOOKING CONFIRMATION EMAIL
            |--------------------------------------------------------------------------
            |
            | IMPORTANT:
            | Email logged-in user ki email par jayegi.
            |
            */

            foreach ($createdBookings as $createdBooking) {

                try {

                    Log::info('BOOKING MAIL: Loading booking', [
                        'booking_id' => $createdBooking['booking_id'],
                        'user_id' => $order->user_id,
                    ]);

                    /*
                    |--------------------------------------------------------------------------
                    | Get Logged-in User
                    |--------------------------------------------------------------------------
                    |
                    | Booking ke user_id se same authenticated user
                    | database se retrieve kar rahe hain.
                    |
                    */

                    $booking = Booking::with([
                        'user',
                        'turf',
                        'bookingItems.slotMaster',
                    ])->find($createdBooking['booking_id']);

                    if (!$booking) {

                        Log::error('BOOKING MAIL: Booking not found', [
                            'booking_id' => $createdBooking['booking_id'],
                        ]);

                        continue;
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | Get User Email
                    |--------------------------------------------------------------------------
                    */

                    $user = $booking->user;

                    Log::info('BOOKING MAIL: User details', [
                        'booking_id' => $booking->id,
                        'booking_number' => $booking->booking_number,
                        'user_id' => $user?->id,
                        'user_name' => $user?->name,
                        'user_email' => $user?->email,
                    ]);

                    /*
                    |--------------------------------------------------------------------------
                    | Email Required
                    |--------------------------------------------------------------------------
                    */

                    if (!$user) {

                        Log::error('BOOKING MAIL: User not found', [
                            'booking_id' => $booking->id,
                            'user_id' => $booking->user_id,
                        ]);

                        continue;
                    }

                    if (empty($user->email)) {

                        Log::error('BOOKING MAIL: Logged-in user email is NULL', [
                            'booking_id' => $booking->id,
                            'user_id' => $user->id,
                            'user_name' => $user->name,
                        ]);

                        continue;
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | Send Mail
                    |--------------------------------------------------------------------------
                    */

                    Log::info('BOOKING MAIL: Sending confirmation email', [
                        'booking_id' => $booking->id,
                        'booking_number' => $booking->booking_number,
                        'user_id' => $user->id,
                        'recipient_email' => $user->email,
                    ]);

                    Mail::to($user->email)->send(
                        new BookingConfirmedEmail($booking)
                    );

                    /*
                    |--------------------------------------------------------------------------
                    | Mail Success
                    |--------------------------------------------------------------------------
                    */

                    Log::info('BOOKING MAIL: Confirmation email sent successfully', [
                        'booking_id' => $booking->id,
                        'booking_number' => $booking->booking_number,
                        'recipient_email' => $user->email,
                    ]);

                } catch (\Throwable $mailException) {

                    /*
                    |--------------------------------------------------------------------------
                    | Mail Error
                    |--------------------------------------------------------------------------
                    */

                    Log::error('BOOKING MAIL: Failed to send confirmation email', [
                        'booking_id' => $createdBooking['booking_id'],
                        'booking_number' => $createdBooking['booking_number'],
                        'user_id' => $order->user_id,
                        'error' => $mailException->getMessage(),
                        'exception' => get_class($mailException),
                        'file' => $mailException->getFile(),
                        'line' => $mailException->getLine(),
                    ]);
                }
            }

            /*
            |--------------------------------------------------------------------------
            | Final Success
            |--------------------------------------------------------------------------
            */

            Log::info('CHECKOUT: Finalize completed successfully', [
                'payment_order_id' => $order->id,
                'user_id' => $order->user_id,
                'booking_count' => count($createdBookings),
            ]);

            return [
                'already_finalized' => false,
                'bookings' => $createdBookings,
            ];

        } catch (\Throwable $e) {

            if (DB::transactionLevel() > 0) {
                DB::rollBack();
            }

            Log::error('CHECKOUT: Finalize failed', [
                'payment_order_id' => $order->id,
                'razorpay_order_id' => $order->razorpay_order_id,
                'user_id' => $order->user_id,
                'error' => $e->getMessage(),
                'exception' => get_class($e),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);

            throw $e;
        }
    }
}