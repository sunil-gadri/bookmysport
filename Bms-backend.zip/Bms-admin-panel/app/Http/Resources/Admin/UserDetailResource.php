<?php

namespace App\Http\Resources\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserDetailResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     */
    public function toArray(Request $request): array
    {
        return [

            'id' => $this->id,

            'full_name' => $this->profile?->full_name,

            'mobile' => $this->mobile,

            'email' => $this->profile?->email,

            'profile_image' => $this->profile?->profile_image
                ? asset('storage/' . $this->profile->profile_image)
                : null,

            'gender' => $this->profile?->gender,

            'date_of_birth' => $this->profile?->date_of_birth,

            'country' => [
                'id' => $this->profile?->country?->id,
                'name' => $this->profile?->country?->name,
            ],

            'state' => [
                'id' => $this->profile?->state?->id,
                'name' => $this->profile?->state?->name,
            ],

            'city' => [
                'id' => $this->profile?->city?->id,
                'name' => $this->profile?->city?->name,
            ],

            'address' => $this->profile?->address,

            'pincode' => $this->profile?->pincode,

            'status' => [
                'value' => (bool) $this->status,
                'label' => $this->status ? 'Active' : 'Inactive',
            ],

            'created_at' => $this->created_at ? $this->created_at->format('d M Y, h:i A') : null,

        ];
    }
}