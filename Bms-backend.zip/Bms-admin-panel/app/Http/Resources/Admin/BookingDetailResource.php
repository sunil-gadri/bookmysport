<?php

namespace App\Http\Resources\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Carbon\Carbon;

class BookingDetailResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [

            'id' => $this->id,

            'booking_number' => $this->booking_number,

            'customer' => [
                'id' => $this->user?->id,
                'name' => $this->user?->profile?->full_name ?: $this->user?->name,
                'mobile' => $this->user?->mobile,
                'email' => $this->user?->profile?->email,
            ],

            'turf' => [
                'id' => $this->turf?->id,
                'name' => $this->turf?->name,
                'address' => $this->turf?->address,
                'owner' => [
                    'id' => $this->turf?->owner?->id,
                    'name' => $this->turf?->owner?->profile?->full_name ?: $this->turf?->owner?->name,
                    'mobile' => $this->turf?->owner?->mobile,
                ],
            ],

            'booking_type' => $this->booking_type,

            'booking_name' => $this->booking_type === 'sport'
                ? optional($this->turf?->sports?->firstWhere('id', $this->booking_type_id))->name
                : optional($this->turf?->events?->firstWhere('id', $this->booking_type_id))->name,

            'booking_date' => Carbon::parse($this->booking_date)->format('d M Y'),

            'slots' => $this->bookingItems->map(function ($item) {
                return [
                    'id' => $item->slotMaster?->id,
                    'start_time' => $item->slotMaster
                        ? Carbon::parse($item->slotMaster->start_time)->format('h:i A')
                        : null,
                    'end_time' => $item->slotMaster
                        ? Carbon::parse($item->slotMaster->end_time)->format('h:i A')
                        : null,
                    'price' => $item->price,
                ];
            }),

            'total_amount' => $this->total_amount,

            'booking_status' => $this->booking_status,

            'payment_status' => $this->payment_status,

            'payment_reference' => $this->payment_reference,

            'check_in' => [
                'checked_in' => $this->checked_in_at !== null,
                'checked_in_at' => $this->checked_in_at?->format('d M Y, h:i A'),
            ],

            'created_at' => $this->created_at->format('d M Y, h:i A'),

        ];
    }
}