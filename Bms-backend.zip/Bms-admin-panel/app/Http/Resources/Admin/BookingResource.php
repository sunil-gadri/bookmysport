<?php

namespace App\Http\Resources\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Carbon\Carbon;

class BookingResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $slots = $this->bookingItems
            ->map(fn ($item) => $item->slotMaster)
            ->filter();

        $firstSlot = $slots->sortBy('start_time')->first();
        $lastSlot = $slots->sortByDesc('end_time')->first();

        return [

            'id' => $this->id,

            'booking_number' => $this->booking_number,

            'customer' => [
                'id' => $this->user?->id,
                'name' => $this->user?->profile?->full_name ?: $this->user?->name,
                'mobile' => $this->user?->mobile,
            ],

            'turf' => [
                'id' => $this->turf?->id,
                'name' => $this->turf?->name,
            ],

            'booking_type' => $this->booking_type,

            'booking_name' => $this->booking_type === 'sport'
                ? optional($this->turf?->sports?->firstWhere('id', $this->booking_type_id))->name
                : optional($this->turf?->events?->firstWhere('id', $this->booking_type_id))->name,

            'booking_date' => Carbon::parse($this->booking_date)->format('d M Y'),

            'time_range' => $firstSlot && $lastSlot
                ? Carbon::parse($firstSlot->start_time)->format('h:i A')
                    . ' - '
                    . Carbon::parse($lastSlot->end_time)->format('h:i A')
                : null,

            'total_amount' =>  $this->total_amount,

            'booking_status' => $this->booking_status,

            'payment_status' => $this->payment_status,

            'checked_in' => $this->checked_in_at !== null,

            'created_at' => $this->created_at->format('d M Y, h:i A'),

        ];
    }
}