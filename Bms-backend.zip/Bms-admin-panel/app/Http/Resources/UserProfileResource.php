<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserProfileResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,

            'full_name' => $this->full_name,

            'mobile' => $this->user?->mobile,

            'email' => $this->email,

            'profile_image' => $this->profile_image
                ? asset('storage/' . $this->profile_image)
                : null,

            'gender' => $this->gender,

            'date_of_birth' => $this->date_of_birth,

            'country' => [
                'id' => $this->country?->id,
                'name' => $this->country?->name,
            ],

            'state' => [
                'id' => $this->state?->id,
                'name' => $this->state?->name,
            ],

            'city' => [
                'id' => $this->city?->id,
                'name' => $this->city?->name,
            ],

            'address' => $this->address,

            'pincode' => $this->pincode,

            'favourite_sports' => $this->favouriteSports->map(function ($sport) {
                return [
                    'id' => $sport->id,
                    'name' => $sport->name,
                    'slug' => $sport->slug,

                    'selected_icon' => $sport->selected_icon
                        ? asset('storage/' . $sport->selected_icon)
                        : null,

                    'unselected_icon' => $sport->unselected_icon
                        ? asset('storage/' . $sport->unselected_icon)
                        : null,
                ];
            }),
        ];
    }
}