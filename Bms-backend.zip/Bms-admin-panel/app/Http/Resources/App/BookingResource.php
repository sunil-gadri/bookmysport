<?php

namespace App\Http\Resources\App;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Carbon\Carbon;

class BookingResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     */
    public function toArray(Request $request): array
    {
        return [

            'id' => $this->id,

            'booking_number' => $this->booking_number,

            'booking_date' => Carbon::parse(
                $this->booking_date
            )->format('d M Y'),

            'booking_type' => $this->booking_type,

            // Sport/Event id — same value used as booking_type_id when
            // hitting the slots API for this turf.
            'booking_type_id' => $this->booking_type_id,

            'booking_name' => $this->booking_type == 'sport'
                ? optional(
                    $this->turf
                        ->sports
                        ->firstWhere('id', $this->booking_type_id)
                )->name
                : optional(
                    $this->turf
                        ->events
                        ->firstWhere('id', $this->booking_type_id)
                )->name,

            'total_amount' => $this->total_amount,

            'booking_status' => $this->booking_status,

            'payment_status' => $this->payment_status,

            // e.g. "08:00 PM - 09:00 PM" — handy for a one-line summary
            // without recomputing it from the slots array.
            'time_range' => $this->bookingItems->isNotEmpty()
                ? Carbon::parse(
                    $this->bookingItems->sortBy(fn ($item) => $item->slotMaster->start_time)->first()->slotMaster->start_time
                )->format('h:i A')
                    . ' - '
                    . Carbon::parse(
                        $this->bookingItems->sortByDesc(fn ($item) => $item->slotMaster->end_time)->first()->slotMaster->end_time
                    )->format('h:i A')
                : null,

            'slot_count' => $this->bookingItems->count(),

            // Same rule as the list endpoint: confirmed AND the last slot
            // hasn't ended yet.
            'is_upcoming' => $this->booking_status === 'confirmed'
                && $this->bookingItems->isNotEmpty()
                && Carbon::parse(
                    $this->booking_date->toDateString() . ' ' . $this->bookingItems->sortByDesc(fn ($item) => $item->slotMaster->end_time)->first()->slotMaster->end_time
                )->isFuture(),

            'turf' => [

                'id' => $this->turf->id,

                'name' => $this->turf->name,

                 'cover_image' => $this->turf->cover_image
        ? (filter_var($this->turf->cover_image, FILTER_VALIDATE_URL)
            ? $this->turf->cover_image
            : asset('storage/' . ltrim($this->turf->cover_image, '/')))
        : null,

                'address' => $this->turf->address,

                'area' => $this->turf->area,

            ],

            'slots' => $this->bookingItems->map(function ($item) {
    return [
        'id' => $item->slotMaster->id,
        'start_time' => Carbon::parse($item->slotMaster->start_time)->format('h:i A'),
        'end_time' => Carbon::parse($item->slotMaster->end_time)->format('h:i A'),
        'price' =>  $item->price,
    ];
}),

            // Only relevant for confirmed, not-yet-checked-in bookings.
            // The app should render this string as a QR code — it is
            // intentionally NOT the booking_number, since that's short
            // enough to read aloud/share and would defeat verification.
            'check_in' => $this->booking_status === 'confirmed'
                ? [
                    'qr_value' => $this->checked_in_at ? null : $this->check_in_token,
                    'checked_in' => $this->checked_in_at !== null,
                    'checked_in_at' => $this->checked_in_at?->toIso8601String(),
                ]
                : null,

        ];
    }
}