<?php

namespace App\Http\Resources\App;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Carbon\Carbon;

class AppTurfResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     */

    public function toArray(Request $request): array
    {

        $openingTime = Carbon::parse($this->opening_time);

        $closingTime = Carbon::parse($this->closing_time);

        $currentTime = now()->format('H:i:s');

        $isOpen = $currentTime >= $openingTime->format('H:i:s')
            && $currentTime <= $closingTime->format('H:i:s');

        return [
            'id' => $this->id,

            'name' => $this->name,

            'cover_image' => $this->cover_image,

            'city' => optional($this->city)->name,

            'address' => $this->address,

            'area' => $this->area,

            'distance' => isset($this->distance)
                ? round($this->distance, 2)
                : null,

            'sports' => $this->sports->map(function ($sport) {
                return [
                    'id' => $sport->id,
                    'name' => $sport->name,
                ];
            })->values(),

            'events' => $this->events->map(function ($event) {
                return [
                    'id' => $event->id,
                    'name' => $event->name,
                ];
            })->values(),

            'average_rating' => round((float) $this->average_rating, 1),
            'total_reviews' => (int) $this->total_reviews,

            'opening_time' => $openingTime
                ? $openingTime->format('h:i A')
                : null,

            'closing_time' => $closingTime
                ? $closingTime->format('h:i A')
                : null,

            'is_open' => $isOpen,
        ];
    }
}
