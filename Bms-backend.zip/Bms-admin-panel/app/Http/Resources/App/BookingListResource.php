<?php

namespace App\Http\Resources\App;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Carbon\Carbon;

class BookingListResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     */
    public function toArray(Request $request): array
    {
        $slots = $this->bookingItems
            ->map(fn ($item) => $item->slotMaster)
            ->filter();

        $firstSlot = $slots->sortBy('start_time')->first();
        $lastSlot = $slots->sortByDesc('end_time')->first();

        return [

            'id' => $this->id,

            'booking_number' => $this->booking_number,

            'booking_date' => Carbon::parse(
                $this->booking_date
            )->format('d M Y'),

            'booking_type' => $this->booking_type,

            // Sport/Event id — same value used as booking_type_id when
            // hitting the slots API for this turf.
            'booking_type_id' => $this->booking_type_id,

            'booking_name' => $this->booking_type === 'sport'
                ? optional(
                    $this->turf
                        ->sports
                        ->firstWhere('id', $this->booking_type_id)
                )->name
                : optional(
                    $this->turf
                        ->events
                        ->firstWhere('id', $this->booking_type_id)
                )->name,

            // e.g. "08:00 PM - 09:00 PM" — handy for a one-line list card
            // without the app having to fetch full booking details.
            'time_range' => $firstSlot && $lastSlot
                ? Carbon::parse($firstSlot->start_time)->format('h:i A')
                    . ' - '
                    . Carbon::parse($lastSlot->end_time)->format('h:i A')
                : null,

            'slot_count' => $slots->count(),

            // Full itemised slot list, in case the app wants to show
            // each individual slot rather than just the combined range.
            'slots' => $slots->sortBy('start_time')->values()->map(function ($slot) {
                return [
                    'id' => $slot->id,
                    'start_time' => Carbon::parse($slot->start_time)->format('h:i A'),
                    'end_time' => Carbon::parse($slot->end_time)->format('h:i A'),
                ];
            }),

            'total_amount' =>  $this->total_amount,

            'booking_status' => $this->booking_status,

            'payment_status' => $this->payment_status,

            // Convenience flag so the app doesn't have to redo date/time
            // math to decide which tab a booking belongs in.
            'is_upcoming' => $this->booking_status === 'confirmed'
                && $lastSlot
                && Carbon::parse($this->booking_date->toDateString() . ' ' . $lastSlot->end_time)->isFuture(),

            // Same rule as the detail endpoint: only present for a
            // confirmed, not-yet-checked-in booking. Null once checked in
            // or if the booking isn't confirmed.
            'check_in' => $this->booking_status === 'confirmed'
                ? [
                    'qr_value' => $this->checked_in_at ? null : $this->check_in_token,
                    'checked_in' => $this->checked_in_at !== null,
                    'checked_in_at' => $this->checked_in_at?->toIso8601String(),
                ]
                : null,

            'turf' => [

                'id' => $this->turf->id,

                'name' => $this->turf->name,

                'cover_image' => $this->turf->cover_image,

                'area' => $this->turf->area,

                'address' => $this->turf->address,

                'latitude' => $this->turf->latitude,

                'longitude' => $this->turf->longitude,

            ],

        ];
    }
}