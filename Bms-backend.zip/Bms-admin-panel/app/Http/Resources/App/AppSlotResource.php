<?php

namespace App\Http\Resources\App;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Carbon\Carbon;

class AppSlotResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     */
    public function toArray(Request $request): array
    {
        $start = Carbon::parse($this->start_time);
        $end = Carbon::parse($this->end_time);

        $minutes = $start->diffInMinutes($end);

        $hours = floor($minutes / 60);

        $remainingMinutes = $minutes % 60;

        if ($hours > 0 && $remainingMinutes > 0) {

            $duration = "{$hours} Hour" .
                ($hours > 1 ? 's' : '') .
                " {$remainingMinutes} Minute" .
                ($remainingMinutes > 1 ? 's' : '');

        } elseif ($hours > 0) {

            $duration = "{$hours} Hour" .
                ($hours > 1 ? 's' : '');

        } else {

            $duration = "{$remainingMinutes} Minute" .
                ($remainingMinutes > 1 ? 's' : '');

        }

        return [

            'id' => $this->id,

            'booking_type' => $this->booking_type,

            'booking_type_id' => $this->booking_type_id,

            'booking_name' => $this->booking_name,

            'day' => ucfirst($this->day),

            'start_time' => $start->format('H:i'),

            'end_time' => $end->format('H:i'),

            'duration' => $duration,

            'price' =>  $this->price,

            'status' => (bool) $this->status,

            'is_available' => $this->is_available,

        ];
    }
}