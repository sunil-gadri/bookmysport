<?php

namespace App\Http\Resources\TurfOwner;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SlotMasterResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     */
    public function toArray(Request $request): array
    {
        return [

            'id' => $this->id,

            'turf_id' => $this->turf_id,

            'turf_name' => $this->turf?->name,

            'booking_type' => $this->booking_type,

            'booking_type_id' => $this->booking_type_id,

            'booking_name' => $this->booking_name,

            'day' => ucfirst($this->day),

            'start_time' => date('h:i A', strtotime($this->start_time)),

            'end_time' => date('h:i A', strtotime($this->end_time)),

            'price' => $this->price,

            'status' => $this->status,

            'created_at' => $this->created_at?->format('d M Y h:i A'),

        ];
    }
}