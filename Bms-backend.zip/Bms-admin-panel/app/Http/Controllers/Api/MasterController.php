<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\CountryResource;
use App\Http\Resources\StateResource;
use App\Http\Resources\CityResource;
use App\Models\Country;
use App\Models\State;
use App\Models\City;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class MasterController extends Controller
{
    /**
     * Get Countries
     */
    public function countries()
    {
        $countries = Country::where('status', true)
            ->orderBy('name')
            ->get();

        return response()->json([
            'status' => true,
            'message' => 'Countries fetched successfully.',
            'data' => CountryResource::collection($countries),
        ]);
    }

    /**
     * Get States
     */
    public function states(Request $request)
    {
        $request->validate([
            'country_id' => 'required|exists:countries,id',
        ]);

        $states = State::where('country_id', $request->country_id)
            ->where('status', true)
            ->orderBy('name')
            ->get();

        return response()->json([
            'status' => true,
            'message' => 'States fetched successfully.',
            'data' => StateResource::collection($states),
        ]);
    }

    /**
     * Get Cities
     */
    public function cities(Request $request)
    {
        $request->validate([
            'state_id' => 'required|exists:states,id',
        ]);

        $cities = City::where('state_id', $request->state_id)
            ->where('status', true)
            ->orderBy('name')
            ->get();

        return response()->json([
            'status' => true,
            'message' => 'Cities fetched successfully.',
            'data' => CityResource::collection($cities),
        ]);
    }

    /**
     * Get latitude and longitude using OpenStreetMap Nominatim.
     */
    private function getCoordinates(
        string $pincode,
        ?string $district,
        ?string $state
    ): ?array {
        try {
            $queryParts = array_filter([
                $pincode,
                $district,
                $state,
                'India',
            ]);

            $query = implode(', ', $queryParts);

            $http = Http::timeout(10)
                ->withHeaders([
                    'User-Agent' => 'BMS-Backend/1.0',
                    'Accept' => 'application/json',
                ]);

            // Only for local development
            if (app()->environment('local')) {
                $http = $http->withoutVerifying();
            }

            $response = $http->get(
                'https://nominatim.openstreetmap.org/search',
                [
                    'q' => $query,
                    'format' => 'json',
                    'limit' => 1,
                    'countrycodes' => 'in',
                ]
            );

            if (!$response->successful()) {
                Log::warning('Nominatim geocoding failed', [
                    'pincode' => $pincode,
                    'district' => $district,
                    'state' => $state,
                    'status' => $response->status(),
                ]);

                return null;
            }

            $results = $response->json();

            if (!is_array($results) || empty($results)) {
                return null;
            }

            $latitude = $results[0]['lat'] ?? null;
            $longitude = $results[0]['lon'] ?? null;

            if ($latitude === null || $longitude === null) {
                return null;
            }

            return [
                'latitude' => (float) $latitude,
                'longitude' => (float) $longitude,
            ];
        } catch (\Throwable $e) {
            Log::warning('Nominatim geocoding exception', [
                'pincode' => $pincode,
                'district' => $district,
                'state' => $state,
                'error' => $e->getMessage(),
            ]);

            return null;
        }
    }

    /**
     * Pincode Lookup
     */
    public function pincodeLookup(Request $request)
    {
        $request->validate([
            'pincode' => [
                'required',
                'digits:6',
            ],
        ]);

        $pincode = $request->input('pincode');

        try {
            /**
             * India Post API HTTP client
             */
            $http = Http::timeout(10)
                ->withHeaders([
                    'User-Agent' => 'Mozilla/5.0 (compatible; BMS-Backend/1.0)',
                    'Accept' => 'application/json',
                ]);

            // Local development SSL issue fix
            if (app()->environment('local')) {
                $http = $http->withoutVerifying();
            }

            /**
             * India Post API
             */
            $response = $http->get(
                "https://api.postalpincode.in/pincode/{$pincode}"
            );

            /**
             * Check HTTP response
             */
            if (!$response->successful()) {
                Log::error('Pincode lookup got non-success response', [
                    'pincode' => $pincode,
                    'status' => $response->status(),
                    'body' => $response->body(),
                ]);

                return response()->json([
                    'status' => false,
                    'message' => 'Could not look up this pincode right now. Please select manually.',
                ], 503);
            }

            /**
             * Decode response
             */
            $responseData = $response->json();

            $result = $responseData[0] ?? null;

            /**
             * Validate India Post response
             */
            if (
                !$result ||
                ($result['Status'] ?? null) !== 'Success' ||
                empty($result['PostOffice'])
            ) {
                return response()->json([
                    'status' => false,
                    'message' => 'No location found for this pincode. Please select manually.',
                ], 404);
            }

            /**
             * First Post Office
             */
            $postOffice = $result['PostOffice'][0];

            /**
             * Raw location information
             */
            $areaName = $postOffice['Name'] ?? null;
            $districtName = $postOffice['District'] ?? null;
            $stateName = $postOffice['State'] ?? null;
            $countryName = $postOffice['Country'] ?? 'India';

            /**
             * Get all areas covered by pincode
             */
            $areas = collect($result['PostOffice'])
                ->pluck('Name')
                ->filter()
                ->unique()
                ->values();

            /**
             * Match Country
             */
            $country = Country::whereRaw(
                'LOWER(name) = ?',
                [strtolower($countryName)]
            )
                ->where('status', true)
                ->first();

            /**
             * Match State
             */
            $state = null;

            if ($country && $stateName) {
                $state = State::where('country_id', $country->id)
                    ->whereRaw(
                        'LOWER(name) = ?',
                        [strtolower($stateName)]
                    )
                    ->where('status', true)
                    ->first();
            }

            /**
             * Match City
             */
            $city = null;

            if ($state && $districtName) {
                $city = City::where('state_id', $state->id)
                    ->whereRaw(
                        'LOWER(name) LIKE ?',
                        ['%' . strtolower($districtName) . '%']
                    )
                    ->where('status', true)
                    ->first();
            }

            /**
             * Get approximate coordinates
             */
            $coordinates = $this->getCoordinates(
                $pincode,
                $districtName,
                $stateName
            );

            /**
             * Final response
             */
            return response()->json([
                'status' => true,
                'message' => 'Location found.',
                'data' => [

                    /**
                     * Raw India Post data
                     */
                    'raw' => [
                        'area' => $areaName,
                        'district' => $districtName,
                        'state' => $stateName,
                        'country' => $countryName,
                    ],

                    /**
                     * All areas
                     */
                    'areas' => $areas,

                    /**
                     * Database IDs
                     */
                    'country_id' => $country ? $country->id : null,
                    'state_id' => $state ? $state->id : null,
                    'city_id' => $city ? $city->id : null,

                    /**
                     * Matched database names
                     */
                    'matched' => [
                        'country_name' => $country ? $country->name : null,
                        'state_name' => $state ? $state->name : null,
                        'city_name' => $city ? $city->name : null,
                    ],

                    /**
                     * Approximate coordinates
                     */
                    'latitude' => $coordinates['latitude'] ?? null,
                    'longitude' => $coordinates['longitude'] ?? null,
                ],
            ]);

        } catch (\Throwable $e) {

            Log::error('Pincode lookup failed', [
                'pincode' => $pincode,
                'error' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);

            return response()->json([
                'status' => false,
                'message' => 'Could not look up this pincode right now. Please select manually.',
            ], 503);
        }
    }
}