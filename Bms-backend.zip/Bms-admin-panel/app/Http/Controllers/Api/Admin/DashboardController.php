<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Booking;
use App\Models\Turf;
use App\Models\BookingItem;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $now = now();
        $startOfWeek = $now->copy()->startOfWeek();
        $startOfMonth = $now->copy()->startOfMonth();
        $startOfLastMonth = $now->copy()->subMonthNoOverflow()->startOfMonth();
        $endOfLastMonth = $now->copy()->subMonthNoOverflow()->endOfMonth();
        $today = $now->toDateString();

        /*
        |--------------------------------------------------------------------------
        | Top Stat Cards
        |--------------------------------------------------------------------------
        */

        $totalUsers = User::whereHas('roles', fn ($q) => $q->where('name', 'user'))->count();

        $newUsersThisWeek = User::whereHas('roles', fn ($q) => $q->where('name', 'user'))
            ->where('created_at', '>=', $startOfWeek)
            ->count();

        $totalBookings = Booking::count();

        $bookingsToday = Booking::whereDate('created_at', $today)->count();

        $revenueThisMonth = Booking::where('payment_status', 'paid')
            ->where('booking_date', '>=', $startOfMonth->toDateString())
            ->sum('total_amount');

        $revenueLastMonth = Booking::where('payment_status', 'paid')
            ->whereBetween('booking_date', [
                $startOfLastMonth->toDateString(),
                $endOfLastMonth->toDateString(),
            ])
            ->sum('total_amount');

        $revenueChangePercent = $revenueLastMonth > 0
            ? round((($revenueThisMonth - $revenueLastMonth) / $revenueLastMonth) * 100, 1)
            : null;

        $activeTurfs = Turf::where('status', true)
            ->where('approval_status', 'approved')
            ->count();

        $pendingTurfs = Turf::where('approval_status', 'pending')->count();

        $avgBookingValue = Booking::where('payment_status', 'paid')->avg('total_amount');

        $cancellationRate = $totalBookings > 0
            ? round((Booking::where('booking_status', 'cancelled')->count() / $totalBookings) * 100, 1)
            : 0;

        /*
        |--------------------------------------------------------------------------
        | Peak Hour — most commonly booked slot start hour, across all
        | confirmed/completed bookings
        |--------------------------------------------------------------------------
        */

        $peakHourRow = BookingItem::query()
            ->join('slot_masters', 'slot_masters.id', '=', 'booking_items.slot_master_id')
            ->join('bookings', 'bookings.id', '=', 'booking_items.booking_id')
            ->whereIn('bookings.booking_status', ['confirmed', 'completed'])
            ->select(DB::raw('HOUR(slot_masters.start_time) as hour'), DB::raw('count(*) as total'))
            ->groupBy('hour')
            ->orderByDesc('total')
            ->first();

        $peakHour = null;

        if ($peakHourRow) {
            $startHour = (int) $peakHourRow->hour;
            $endHour = ($startHour + 1) % 24;
            $peakHour = Carbon::createFromTime($startHour, 0)->format('g A')
                . ' – '
                . Carbon::createFromTime($endHour, 0)->format('g A');
        }

        /*
        |--------------------------------------------------------------------------
        | Revenue Trend — last 30 days (for line/bar chart)
        |--------------------------------------------------------------------------
        */

        $revenueTrendRaw = Booking::where('payment_status', 'paid')
            ->where('booking_date', '>=', $now->copy()->subDays(29)->toDateString())
            ->select(
                DB::raw('date(booking_date) as date'),
                DB::raw('sum(total_amount) as revenue')
            )
            ->groupBy('date')
            ->pluck('revenue', 'date');

        $revenueTrend = [];

        for ($i = 29; $i >= 0; $i--) {
            $date = $now->copy()->subDays($i)->toDateString();
            $revenueTrend[] = [
                'date' => $date,
                'label' => Carbon::parse($date)->format('d M'),
                'revenue' => (float) ($revenueTrendRaw[$date] ?? 0),
            ];
        }

        /*
        |--------------------------------------------------------------------------
        | Bookings Trend — last 14 days (for bar chart)
        |--------------------------------------------------------------------------
        */

        $bookingsTrendRaw = Booking::where('created_at', '>=', $now->copy()->subDays(13)->startOfDay())
            ->select(
                DB::raw('date(created_at) as date'),
                DB::raw('count(*) as total')
            )
            ->groupBy('date')
            ->pluck('total', 'date');

        $bookingsTrend = [];

        for ($i = 13; $i >= 0; $i--) {
            $date = $now->copy()->subDays($i)->toDateString();
            $bookingsTrend[] = [
                'date' => $date,
                'label' => Carbon::parse($date)->format('d M'),
                'bookings' => (int) ($bookingsTrendRaw[$date] ?? 0),
            ];
        }

        /*
        |--------------------------------------------------------------------------
        | Booking Status Breakdown — for donut/pie chart
        |--------------------------------------------------------------------------
        */

        $statusBreakdown = Booking::select('booking_status', DB::raw('count(*) as total'))
            ->groupBy('booking_status')
            ->pluck('total', 'booking_status');

        $bookingStatusBreakdown = [
            ['status' => 'confirmed', 'label' => 'Confirmed', 'total' => (int) ($statusBreakdown['confirmed'] ?? 0)],
            ['status' => 'completed', 'label' => 'Completed', 'total' => (int) ($statusBreakdown['completed'] ?? 0)],
            ['status' => 'cancelled', 'label' => 'Cancelled', 'total' => (int) ($statusBreakdown['cancelled'] ?? 0)],
        ];

        /*
        |--------------------------------------------------------------------------
        | Top 5 Turfs — by number of bookings (for bar chart)
        |--------------------------------------------------------------------------
        */

        $topTurfs = Booking::select('turf_id', DB::raw('count(*) as total_bookings'))
            ->groupBy('turf_id')
            ->orderByDesc('total_bookings')
            ->limit(5)
            ->with('turf:id,name')
            ->get()
            ->map(fn ($row) => [
                'turf_name' => $row->turf?->name ?? 'Unknown',
                'total_bookings' => $row->total_bookings,
            ]);

        return response()->json([

            'success' => true,

            'message' => 'Dashboard data fetched successfully.',

            'data' => [

                'stats' => [

                    'total_users' => $totalUsers,
                    'new_users_this_week' => $newUsersThisWeek,

                    'total_bookings' => $totalBookings,
                    'bookings_today' => $bookingsToday,

                    'revenue_this_month' => (float) $revenueThisMonth,
                    'revenue_change_percent' => $revenueChangePercent,

                    'active_turfs' => $activeTurfs,
                    'pending_turfs' => $pendingTurfs,

                    'avg_booking_value' => round((float) $avgBookingValue, 0),

                    'cancellation_rate' => $cancellationRate,

                    'peak_hour' => $peakHour,

                ],

                'charts' => [

                    'revenue_trend' => $revenueTrend,

                    'bookings_trend' => $bookingsTrend,

                    'booking_status_breakdown' => $bookingStatusBreakdown,

                    'top_turfs' => $topTurfs,

                ],

            ],

        ]);
    }
}