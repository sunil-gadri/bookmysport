<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\EventRequest;
use App\Models\Event;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;


class EventController extends Controller
{

    public function store(EventRequest $request)
    {
        $validated = $request->validated();

        $selectedIconPath = null;
        $unselectedIconPath = null;

        if ($request->hasFile('selected_icon')) {
            $selectedIconPath = $request->file('selected_icon')
                ->store('events', 'public');
        }

        if ($request->hasFile('unselected_icon')) {
            $unselectedIconPath = $request->file('unselected_icon')
                ->store('events', 'public');
        }

        $event = Event::create([
            'name' => $validated['name'],
            'slug' => Str::slug($validated['name']),
            'selected_icon' => $selectedIconPath,
            'unselected_icon' => $unselectedIconPath,
            'status' => $validated['status'] ?? 1,
            'sort_order' => $validated['sort_order'] ?? 0,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Event created successfully.',
            'data' => [
                'id' => $event->id,
                'name' => $event->name,
                'slug' => $event->slug,
                'selected_icon' => $event->selected_icon
                    ? asset('storage/' . $event->selected_icon)
                    : null,
                'unselected_icon' => $event->unselected_icon
                    ? asset('storage/' . $event->unselected_icon)
                    : null,
                'status' => $event->status,
                'sort_order' => $event->sort_order,
            ],
        ], 201);
    }


    public function index(Request $request)
    {
        $query = Event::query();

        // Search by event name
        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Counts
        $totalEvents = Event::count();
        $activeEvents = Event::where('status', 1)->count();
        $inactiveEvents = Event::where('status', 0)->count();

        // Dynamic pagination
        $perPage = $request->get('per_page', 10);

        $events = $query
            ->orderBy('id', 'desc')
            ->paginate($perPage);

        $data = $events->getCollection()->map(function ($event) {
            return [
                'id' => $event->id,
                'name' => $event->name,
                'slug' => $event->slug,

                'selected_icon' => $event->selected_icon
                    ? asset('storage/' . $event->selected_icon)
                    : null,

                'unselected_icon' => $event->unselected_icon
                    ? asset('storage/' . $event->unselected_icon)
                    : null,

                'status' => [
                    'value' => (bool) $event->status,
                    'label' => $event->status ? 'Active' : 'Inactive',
                ],

                'sort_order' => $event->sort_order,

                'created_at' => $event->created_at->format('d M Y, h:i A'),
            ];
        });

        return response()->json([
            'status' => true,
            'message' => 'Events fetched successfully.',

            'counts' => [
                'total_events' => $totalEvents,
                'active_events' => $activeEvents,
                'inactive_events' => $inactiveEvents,
            ],

            'data' => $data,

            'pagination' => [
                'current_page' => $events->currentPage(),
                'last_page' => $events->lastPage(),
                'per_page' => $events->perPage(),
                'total' => $events->total(),
            ],
        ]);
    }


    public function show($id)
    {
        $event = Event::find($id);

        if (!$event) {
            return response()->json([
                'status' => false,
                'message' => 'Event not found.',
            ], 404);
        }

        return response()->json([
            'status' => true,
            'message' => 'Event fetched successfully.',
            'data' => [
                'id' => $event->id,
                'name' => $event->name,
                'slug' => $event->slug,

                'selected_icon' => $event->selected_icon
                    ? asset('storage/' . $event->selected_icon)
                    : null,

                'unselected_icon' => $event->unselected_icon
                    ? asset('storage/' . $event->unselected_icon)
                    : null,

                'status' => [
                    'value' => (bool) $event->status,
                    'label' => $event->status ? 'Active' : 'Inactive',
                ],

                'sort_order' => $event->sort_order,

                'created_at' => $event->created_at->format('d M Y'),
                'updated_at' => $event->updated_at->format('d M Y'),
            ],
        ]);
    }


    public function update(EventRequest $request, $id)
    {
        $event = Event::find($id);

        if (!$event) {
            return response()->json([
                'status' => false,
                'message' => 'Event not found.',
            ], 404);
        }

        $validated = $request->validated();

        if ($request->hasFile('selected_icon')) {
            $validated['selected_icon'] = $request->file('selected_icon')
                ->store('events', 'public');
        }

        if ($request->hasFile('unselected_icon')) {
            $validated['unselected_icon'] = $request->file('unselected_icon')
                ->store('events', 'public');
        }

        $validated['slug'] = Str::slug($validated['name']);

        $event->update($validated);

        return response()->json([
            'status' => true,
            'message' => 'Event updated successfully.',
            'data' => [
                'id' => $event->id,
                'name' => $event->name,
                'slug' => $event->slug,
                'selected_icon' => $event->selected_icon
                    ? asset('storage/' . $event->selected_icon)
                    : null,
                'unselected_icon' => $event->unselected_icon
                    ? asset('storage/' . $event->unselected_icon)
                    : null,
                'status' => [
                    'value' => (bool) $event->status,
                    'label' => $event->status ? 'Active' : 'Inactive',
                ],
                'sort_order' => $event->sort_order,
            ],
        ]);
    }


    public function destroy($id)
    {
        $event = Event::find($id);

        if (!$event) {
            return response()->json([
                'status' => false,
                'message' => 'Event not found.',
            ], 404);
        }

        // Delete selected icon
        if ($event->selected_icon && Storage::disk('public')->exists($event->selected_icon)) {
            Storage::disk('public')->delete($event->selected_icon);
        }

        // Delete unselected icon
        if ($event->unselected_icon && Storage::disk('public')->exists($event->unselected_icon)) {
            Storage::disk('public')->delete($event->unselected_icon);
        }

        $event->delete();

        return response()->json([
            'status' => true,
            'message' => 'Event deleted successfully.',
        ]);
    }


    public function changeStatus(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|in:0,1',
        ]);

        $event = Event::find($id);

        if (!$event) {
            return response()->json([
                'status' => false,
                'message' => 'Event not found.',
            ], 404);
        }

        $event->update([
            'status' => $request->status,
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Event status updated successfully.',
            'data' => [
                'id' => $event->id,
                'name' => $event->name,
                'status' => [
                    'value' => (bool) $event->status,
                    'label' => $event->status ? 'Active' : 'Inactive',
                ],
            ],
        ]);
    }


}
