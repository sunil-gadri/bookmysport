<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\TurfListRequest;
use App\Models\Turf;
use App\Http\Requests\Admin\UpdateTurfApprovalRequest;
use App\Models\User;
use Illuminate\Http\Request;


class AdminTurfController  extends Controller
{
    /*** Turf List */

    public function index(TurfListRequest $request)
    {
        $validated = $request->validated();

        $perPage = $validated['per_page'] ?? 10;

        $sortBy = $validated['sort_by'] ?? 'created_at';

        $sortOrder = $validated['sort_order'] ?? 'desc';

        $turfs = Turf::query()

            ->with([
                'owner:id,name,mobile',
                'country:id,name',
                'state:id,name',
                'city:id,name',
                'sports:id,name',
                'amenities:id,name',
                'events:id,name',

            ])

            ->when(isset($validated['search']), function ($query) use ($validated) {

                $search = $validated['search'];

                $query->where(function ($q) use ($search) {

                    $q->where('name', 'LIKE', "%{$search}%")
                        ->orWhere('contact_number', 'LIKE', "%{$search}%")
                        ->orWhere('address', 'LIKE', "%{$search}%")

                        ->orWhereHas('owner', function ($owner) use ($search) {

                            $owner->where('name', 'LIKE', "%{$search}%")
                                ->orWhere('mobile', 'LIKE', "%{$search}%");

                        });

                });

            })

            ->when(isset($validated['status']), function ($query) use ($validated) {

                $query->where('status', $validated['status']);

            })

            ->when(isset($validated['approval_status']), function ($query) use ($validated) {

                $query->where('approval_status', $validated['approval_status']);

            })

            ->when(isset($validated['city_id']), function ($query) use ($validated) {

                $query->where('city_id', $validated['city_id']);

            })

            ->when(isset($validated['sport_id']), function ($query) use ($validated) {

                $query->whereHas('sports', function ($sport) use ($validated) {

                    $sport->where('sports.id', $validated['sport_id']);

                });

            })

            ->when(isset($validated['event_id']), function ($query) use ($validated) {

                $query->whereHas('events', function ($event) use ($validated) {

                    $event->where('events.id', $validated['event_id']);

                });

            })

            ->orderBy($sortBy, $sortOrder)

            ->paginate($perPage);

        return response()->json([

            'success' => true,

            'message' => 'Turfs fetched successfully.',

            'data' => $turfs->items(),

            'pagination' => [

                'current_page' => $turfs->currentPage(),

                'last_page' => $turfs->lastPage(),

                'per_page' => $turfs->perPage(),

                'total' => $turfs->total(),

                'from' => $turfs->firstItem(),

                'to' => $turfs->lastItem(),

            ],

        ]);
    }


    public function updateApprovalStatus(
    UpdateTurfApprovalRequest $request,
    Turf $turf
    ) {

        $validated = $request->validated();

        $turf->approval_status = $validated['approval_status'];

        if ($validated['approval_status'] === 'approved') {

            $turf->rejection_reason = null;

        } else {

            $turf->rejection_reason = $validated['rejection_reason'];

        }

        $turf->save();


        $turf->load([
            'owner:id,name,mobile',
            'country:id,name',
            'state:id,name',
            'city:id,name',
            'sports:id,name',
            'amenities:id,name',
            'events:id,name',
        ]);


        return response()->json([

            'success' => true,

            'message' => 'Turf approval status updated successfully.',

            'data' => $turf,

        ]);

    }


    /**
     * Approve a pending turf — matches the React admin panel's
     * POST /admin/turfs/{turf}/approve (no body needed).
     */
    public function approve(Turf $turf)
    {
        $turf->approval_status = 'approved';

        $turf->rejection_reason = null;

        // Once admin approves it, the turf goes live so customers can
        // actually book it — matches the frontend's optimistic update
        // which sets status: true locally after a successful approve.
        $turf->status = true;

        $turf->save();

        $turf->load([
            'owner:id,name,mobile',
            'country:id,name',
            'state:id,name',
            'city:id,name',
            'sports:id,name',
            'amenities:id,name',
            'events:id,name',
        ]);

        return response()->json([

            'success' => true,

            'message' => 'Turf approved successfully.',

            'data' => $turf,

        ]);
    }

    /**
     * Reject a pending turf with a reason — matches the React admin
     * panel's POST /admin/turfs/{turf}/reject, body: { reason }.
     */
    public function reject(Request $request, Turf $turf)
    {
        $request->validate([
            'reason' => ['required', 'string', 'max:500'],
        ]);

        $turf->approval_status = 'rejected';

        $turf->rejection_reason = $request->reason;

        $turf->save();

        $turf->load([
            'owner:id,name,mobile',
            'country:id,name',
            'state:id,name',
            'city:id,name',
            'sports:id,name',
            'amenities:id,name',
            'events:id,name',
        ]);

        return response()->json([

            'success' => true,

            'message' => 'Turf rejected successfully.',

            'data' => $turf,

        ]);
    }



    /**
     * Toggle a turf's active/inactive status.
     */
    public function updateStatus(Request $request, Turf $turf)
    {
        $request->validate([
            'status' => ['required', 'boolean'],
        ]);

        $turf->status = $request->boolean('status');

        $turf->save();

        return response()->json([

            'success' => true,

            'message' => 'Turf status updated successfully.',

            'data' => $turf,

        ]);
    }

    /**
     * Toggle whether a turf is featured on the app's home screen.
     */
    public function toggleFeatured(Turf $turf)
    {
        $turf->is_featured = !$turf->is_featured;

        $turf->save();

        return response()->json([

            'success' => true,

            'message' => $turf->is_featured
                ? 'Turf marked as featured.'
                : 'Turf removed from featured.',

            'data' => $turf,

        ]);
    }



    public function turfOwners()
    {
        $turfOwners = User::with([
            'turfOwnerProfile:id,user_id,business_name,business_email,business_phone,profile_image,address'
        ])
        ->select('id', 'name', 'mobile', 'email', 'status')
        ->whereHas('roles', function ($query) {
            $query->where('slug', 'turf_owner');
        })
        ->orderBy('name')
        ->get();

        return response()->json([
            'success' => true,
            'message' => 'Turf owners fetched successfully.',
            'data' => $turfOwners,
        ]);
    }


    public function turfOwnerDetails()
    {
        $turfOwners = User::select('id', 'name', 'mobile')
            ->with([
                'turfOwnerProfile:id,user_id,business_name,business_phone',
                'turfs:id,owner_id,name',
                'turfs.slotMasters:id,turf_id,day,start_time,end_time,price,status',
            ])
            ->whereHas('roles', function ($query) {
                $query->where('slug', 'turf_owner');
            })
            ->get();

        return response()->json([
            'success' => true,
            'message' => 'Turf owner details fetched successfully.',
            'data' => $turfOwners,
        ]);
    }

public function destroy(Turf $turf)
{
    // Active / upcoming bookings check
    $hasActiveBookings = $turf->bookings()
        ->whereIn('booking_status', ['pending', 'confirmed'])
        ->whereDate('booking_date', '>=', now()->toDateString())
        ->exists();

    if ($hasActiveBookings) {
        return response()->json([
            'success' => false,
            'message' => 'Cannot delete turf. It has active or upcoming bookings.',
        ], 422);
    }

    // Detach pivot relations
    $turf->sports()->detach();
    $turf->amenities()->detach();
    $turf->events()->detach();

    // Related data cleanup (names apne model ke hisaab se adjust karo)
    if (method_exists($turf, 'images')) {
        $turf->images()->delete();
    }
    if (method_exists($turf, 'slotMasters')) {
        $turf->slotMasters()->delete();
    }

    $turf->delete();

    return response()->json([
        'success' => true,
        'message' => 'Turf deleted successfully.',
    ]);
}
    
}