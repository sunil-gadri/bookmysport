<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use Illuminate\Http\Request;
use App\Http\Resources\Admin\BookingResource;
use App\Http\Resources\Admin\BookingDetailResource;

class BookingController extends Controller
{
    /*** List All Bookings (Admin) */

    public function index(Request $request)
    {
        $query = Booking::with([
            'user.profile',
            'turf',
            'turf.sports',
            'turf.events',
            'bookingItems.slotMaster',
        ]);

        /*
        |--------------------------------------------------------------------------
        | Search — booking number, customer name/mobile, turf name
        |--------------------------------------------------------------------------
        */

        if ($request->filled('search')) {

            $search = $request->search;

            $query->where(function ($q) use ($search) {

                $q->where('booking_number', 'like', "%{$search}%")

                ->orWhereHas('user', function ($user) use ($search) {
                    $user->where('mobile', 'like', "%{$search}%")
                        ->orWhereHas('profile', function ($profile) use ($search) {
                            $profile->where('full_name', 'like', "%{$search}%");
                        });
                })

                ->orWhereHas('turf', function ($turf) use ($search) {
                    $turf->where('name', 'like', "%{$search}%");
                });

            });

        }

        /*
        |--------------------------------------------------------------------------
        | Filters
        |--------------------------------------------------------------------------
        */

        if ($request->filled('booking_status')) {
            $query->where('booking_status', $request->booking_status);
        }

        if ($request->filled('payment_status')) {
            $query->where('payment_status', $request->payment_status);
        }

        if ($request->filled('turf_id')) {
            $query->where('turf_id', $request->turf_id);
        }

        if ($request->filled('from_date')) {
            $query->whereDate('booking_date', '>=', $request->from_date);
        }

        if ($request->filled('to_date')) {
            $query->whereDate('booking_date', '<=', $request->to_date);
        }

        /*
        |--------------------------------------------------------------------------
        | Sorting
        |--------------------------------------------------------------------------
        */

        $sortBy = in_array($request->sort_by, ['created_at', 'booking_date', 'total_amount'])
            ? $request->sort_by
            : 'created_at';

        $sortOrder = $request->sort_order === 'asc' ? 'asc' : 'desc';

        $query->orderBy($sortBy, $sortOrder);

        /*
        |--------------------------------------------------------------------------
        | Summary Counts (unaffected by pagination, respects other filters
        | except itself so the cards stay meaningful alongside the table)
        |--------------------------------------------------------------------------
        */

        $countsQuery = clone $query;

        $totalBookings = (clone $countsQuery)->count();

        $confirmedCount = (clone $countsQuery)->where('booking_status', 'confirmed')->count();

        $completedCount = (clone $countsQuery)->where('booking_status', 'completed')->count();

        $cancelledCount = (clone $countsQuery)->where('booking_status', 'cancelled')->count();

        $totalRevenue = (clone $countsQuery)->where('payment_status', 'paid')->sum('total_amount');

        /*
        |--------------------------------------------------------------------------
        | Pagination
        |--------------------------------------------------------------------------
        */

        $bookings = $query->paginate($request->per_page ?? 15);

        return response()->json([

            'status' => true,

            'message' => 'Bookings fetched successfully.',

            'counts' => [

                'total_bookings' => $totalBookings,

                'confirmed' => $confirmedCount,

                'completed' => $completedCount,

                'cancelled' => $cancelledCount,

                'total_revenue' => (float) $totalRevenue,

            ],

            'data' => BookingResource::collection($bookings),

            'pagination' => [

                'current_page' => $bookings->currentPage(),

                'last_page' => $bookings->lastPage(),

                'per_page' => $bookings->perPage(),

                'total' => $bookings->total(),

            ],

        ]);
    }

    /*** View Single Booking Detail (Admin) */

    public function show(Booking $booking)
    {
        $booking->load([
            'user.profile',
            'turf.owner.profile',
            'turf.sports',
            'turf.events',
            'bookingItems.slotMaster',
        ]);

        return response()->json([

            'status' => true,

            'message' => 'Booking details fetched successfully.',

            'data' => new BookingDetailResource($booking),

        ]);
    }
}