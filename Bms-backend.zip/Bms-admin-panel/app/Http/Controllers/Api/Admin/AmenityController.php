<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Amenity;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;



class AmenityController extends Controller
{

    public function index(Request $request)
    {
        $perPage = $request->input('per_page', 10);

        $query = Amenity::query();

        // Search
        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        // Status Filter
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Counts
        $totalAmenities = Amenity::count();
        $activeAmenities = Amenity::where('status', 1)->count();
        $inactiveAmenities = Amenity::where('status', 0)->count();

        // Pagination
        $amenities = $query
            ->orderBy('sort_order', 'asc')
            ->orderBy('id', 'desc')
            ->paginate($perPage);

        $amenities->getCollection()->transform(function ($amenity) {
            return [
                'id' => $amenity->id,
                'name' => $amenity->name,
                'slug' => $amenity->slug,

                'icon' => $amenity->icon
                    ? asset('storage/' . $amenity->icon)
                    : null,

                'status' => [
                    'value' => (bool) $amenity->status,
                    'label' => $amenity->status ? 'Active' : 'Inactive',
                ],

                'sort_order' => $amenity->sort_order,

                'created_at' => $amenity->created_at->format('d M Y, h:i A'),
            ];
        });

        return response()->json([
            'success' => true,
            'message' => 'Amenities fetched successfully.',

            'counts' => [
                'total_amenities' => $totalAmenities,
                'active_amenities' => $activeAmenities,
                'inactive_amenities' => $inactiveAmenities,
            ],

            'data' => $amenities->items(),

            'pagination' => [
                'current_page' => $amenities->currentPage(),
                'last_page' => $amenities->lastPage(),
                'per_page' => $amenities->perPage(),
                'total' => $amenities->total(),
            ],
        ]);
    }
    
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => [
                'required',
                'string',
                'max:100',
                'unique:amenities,name',
            ],

            'icon' => [
                'nullable',
                'image',
                'mimes:jpg,jpeg,png,webp',
                'max:2048',
            ],

            'sort_order' => [
                'nullable',
                'integer',
                'min:0',
            ],
        ]);

        $iconPath = null;

        if ($request->hasFile('icon')) {
            $iconPath = $request->file('icon')
                ->store('amenities/icons', 'public');
        }

        $amenity = Amenity::create([
            'name' => $validated['name'],
            'slug' => Str::slug($validated['name']),
            'icon' => $iconPath,
            'status' => true,
            'sort_order' => $validated['sort_order'] ?? 0,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Amenity added successfully.',
            'data' => [
                'id' => $amenity->id,
                'name' => $amenity->name,
                'slug' => $amenity->slug,
                'icon' => $amenity->icon
                    ? asset('storage/' . $amenity->icon)
                    : null,
                'status' => $amenity->status,
                'sort_order' => $amenity->sort_order,
            ],
        ], 201);
    }

    public function show($id)
    {
        $amenity = Amenity::find($id);

        if (!$amenity) {
            return response()->json([
                'success' => false,
                'message' => 'Amenity not found.',
            ], 404);
        }

        return response()->json([
            'success' => true,
            'message' => 'Amenity fetched successfully.',
            'data' => [
                'id' => $amenity->id,
                'name' => $amenity->name,
                'slug' => $amenity->slug,
                'icon' => $amenity->icon
                    ? asset('storage/' . $amenity->icon)
                    : null,
                'status' => $amenity->status,
                'sort_order' => $amenity->sort_order,
                'created_at' => $amenity->created_at,
                'updated_at' => $amenity->updated_at,
            ],
        ]);
    }

    public function update(Request $request, $id)
    {
        $amenity = Amenity::find($id);

        if (!$amenity) {
            return response()->json([
                'success' => false,
                'message' => 'Amenity not found.',
            ], 404);
        }

        $validated = $request->validate([
            'name' => [
                'required',
                'string',
                'max:100',
                'unique:amenities,name,' . $amenity->id,
            ],

            'icon' => [
                'nullable',
                'image',
                'mimes:jpg,jpeg,png,webp',
                'max:2048',
            ],

            'sort_order' => [
                'nullable',
                'integer',
                'min:0',
            ],
        ]);

        $iconPath = $amenity->icon;

        if ($request->hasFile('icon')) {

            if ($amenity->icon && Storage::disk('public')->exists($amenity->icon)) {
                Storage::disk('public')->delete($amenity->icon);
            }

            $iconPath = $request->file('icon')
                ->store('amenities/icons', 'public');
        }

        $amenity->update([
            'name' => $validated['name'],
            'slug' => Str::slug($validated['name']),
            'icon' => $iconPath,
            'sort_order' => $validated['sort_order'] ?? $amenity->sort_order,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Amenity updated successfully.',
            'data' => [
                'id' => $amenity->id,
                'name' => $amenity->name,
                'slug' => $amenity->slug,
                'icon' => $amenity->icon
                    ? asset('storage/' . $amenity->icon)
                    : null,
                'status' => $amenity->status,
                'sort_order' => $amenity->sort_order,
            ],
        ]);
    }


    public function updateStatus(Request $request, $id)
    {
        $amenity = Amenity::find($id);

        if (!$amenity) {
            return response()->json([
                'success' => false,
                'message' => 'Amenity not found.',
            ], 404);
        }

        $validated = $request->validate([
            'status' => [
                'required',
                'boolean',
            ],
        ]);

        $amenity->update([
            'status' => $validated['status'],
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Amenity status updated successfully.',
            'data' => [
                'id' => $amenity->id,
                'name' => $amenity->name,
                'status' => $amenity->status,
            ],
        ]);
    }


    public function destroy($id)
    {
        $amenity = Amenity::find($id);

        if (!$amenity) {
            return response()->json([
                'success' => false,
                'message' => 'Amenity not found.',
            ], 404);
        }

        if (
            $amenity->icon &&
            Storage::disk('public')->exists($amenity->icon)
        ) {
            Storage::disk('public')->delete($amenity->icon);
        }

        $amenity->delete();

        return response()->json([
            'success' => true,
            'message' => 'Amenity deleted successfully.',
        ]);
    }

}
