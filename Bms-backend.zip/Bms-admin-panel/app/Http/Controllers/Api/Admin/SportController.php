<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Sport;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class SportController extends Controller
{

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:100|unique:sports,name',
            'selected_icon' => 'required|image|mimes:jpg,jpeg,png,webp|max:2048',
            'unselected_icon' => 'required|image|mimes:jpg,jpeg,png,webp|max:2048',
            'status' => 'nullable|in:0,1',
            'sort_order' => 'nullable|integer|min:0',
        ]);

        $selectedIconPath = null;
        $unselectedIconPath = null;

        if ($request->hasFile('selected_icon')) {
            $selectedIconPath = $request->file('selected_icon')
                ->store('sports', 'public');
        }

        if ($request->hasFile('unselected_icon')) {
            $unselectedIconPath = $request->file('unselected_icon')
                ->store('sports', 'public');
        }

        $sport = Sport::create([
            'name' => $validated['name'],
            'slug' => Str::slug($validated['name']),
            'selected_icon' => $selectedIconPath,
            'unselected_icon' => $unselectedIconPath,
            'status' => $validated['status'] ?? 1,
            'sort_order' => $validated['sort_order'] ?? 0,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Sport created successfully.',
            'data' => [
                'id' => $sport->id,
                'name' => $sport->name,
                'slug' => $sport->slug,
                'selected_icon' => $sport->selected_icon
                    ? asset('storage/' . $sport->selected_icon)
                    : null,

                'unselected_icon' => $sport->unselected_icon
                    ? asset('storage/' . $sport->unselected_icon)
                    : null,
                'status' => $sport->status,
                'sort_order' => $sport->sort_order,
            ],
        ], 201);

    }

    public function index(Request $request)
    {
        $query = Sport::query();

        // Search by sport name
        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Counts
        $totalSports = Sport::count();
        $activeSports = Sport::where('status', 1)->count();
        $inactiveSports = Sport::where('status', 0)->count();

        // Dynamic pagination
        $perPage = $request->get('per_page', 10);

        $sports = $query
            ->orderBy('id', 'desc')
            ->paginate($perPage);

        $data = $sports->getCollection()->map(function ($sport) {
            return [
                'id' => $sport->id,
                'name' => $sport->name,
                'slug' => $sport->slug,

                'selected_icon' => $sport->selected_icon
                    ? asset('storage/' . $sport->selected_icon)
                    : null,

                'unselected_icon' => $sport->unselected_icon
                    ? asset('storage/' . $sport->unselected_icon)
                    : null,

                'status' => [
                    'value' => (bool) $sport->status,
                    'label' => $sport->status ? 'Active' : 'Inactive',
                ],

                'sort_order' => $sport->sort_order,

                'created_at' => $sport->created_at->format('d M Y, h:i A'),
            ];
        });

        return response()->json([
            'status' => true,
            'message' => 'Sports fetched successfully.',

            'counts' => [
                'total_sports' => $totalSports,
                'active_sports' => $activeSports,
                'inactive_sports' => $inactiveSports,
            ],

            'data' => $data,

            'pagination' => [
                'current_page' => $sports->currentPage(),
                'last_page' => $sports->lastPage(),
                'per_page' => $sports->perPage(),
                'total' => $sports->total(),
            ],
        ]);
    }

    public function show($id)
    {
        $sport = Sport::find($id);

        if (!$sport) {
            return response()->json([
                'status' => false,
                'message' => 'Sport not found.',
            ], 404);
        }

        $data = [
            'id' => $sport->id,
            'name' => $sport->name,
            'slug' => $sport->slug,

            'selected_icon' => $sport->selected_icon
                ? asset('storage/' . $sport->selected_icon)
                : null,

            'unselected_icon' => $sport->unselected_icon
                ? asset('storage/' . $sport->unselected_icon)
                : null,

            'status' => [
                'value' => (bool) $sport->status,
                'label' => $sport->status ? 'Active' : 'Inactive',
            ],

            'sort_order' => $sport->sort_order,

            'created_at' => $sport->created_at->format('d M Y'),
        ];

        return response()->json([
            'status' => true,
            'message' => 'Sport fetched successfully.',
            'data' => $data,
        ]);
    }

    public function update(Request $request, $id)
    {
        $sport = Sport::find($id);

        if (!$sport) {
            return response()->json([
                'status' => false,
                'message' => 'Sport not found.',
            ], 404);
        }

        $validated = $request->validate([
            'name' => 'required|string|max:100|unique:sports,name,' . $sport->id,
            'selected_icon' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'unselected_icon' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'status' => 'required|in:0,1',
        ]);

        $sport->name = $validated['name'];
        $sport->slug = Str::slug($validated['name']);
        $sport->status = $validated['status'];

        if ($request->hasFile('selected_icon')) {

            if (
                $sport->selected_icon &&
                Storage::disk('public')->exists($sport->selected_icon)
            ) {
                Storage::disk('public')->delete($sport->selected_icon);
            }

            $sport->selected_icon = $request
                ->file('selected_icon')
                ->store('sports/selected-icons', 'public');
        }

        if ($request->hasFile('unselected_icon')) {

            if (
                $sport->unselected_icon &&
                Storage::disk('public')->exists($sport->unselected_icon)
            ) {
                Storage::disk('public')->delete($sport->unselected_icon);
            }

            $sport->unselected_icon = $request
                ->file('unselected_icon')
                ->store('sports/unselected-icons', 'public');
        }

        $sport->save();

        return response()->json([
            'status' => true,
            'message' => 'Sport updated successfully.',
            'data' => [
                'id' => $sport->id,
                'name' => $sport->name,
                'slug' => $sport->slug,

                'selected_icon' => $sport->selected_icon
                    ? asset('storage/' . $sport->selected_icon)
                    : null,

                'unselected_icon' => $sport->unselected_icon
                    ? asset('storage/' . $sport->unselected_icon)
                    : null,

                'status' => [
                    'value' => (bool) $sport->status,
                    'label' => $sport->status ? 'Active' : 'Inactive',
                ],

                'sort_order' => $sport->sort_order,

                'created_at' => $sport->created_at->format('d M Y'),
            ],
        ]);
    }

    public function updateStatus(Request $request, $id)
    {

        $sport = Sport::find($id);

        if (!$sport) {
            return response()->json([
                'status' => false,
                'message' => 'Sport not found.',
            ], 404);
        }


        $validated = $request->validate([
            'status' => 'required|in:0,1',
        ]);


        $sport->status = $validated['status'];
        $sport->save();

        return response()->json([
            'status' => true,
            'message' => 'Sport status updated successfully.',
            'data' => [
                'id' => $sport->id,
                'status' => [
                    'value' => (bool) $sport->status,
                    'label' => $sport->status ? 'Active' : 'Inactive',
                ],
            ],
        ]);
    }

    public function destroy($id)
    {
        $sport = Sport::find($id);

        if (!$sport) {
            return response()->json([
                'status' => false,
                'message' => 'Sport not found.',
            ], 404);
        }

        // Delete selected icon from storage
        if (
            $sport->selected_icon &&
            Storage::disk('public')->exists($sport->selected_icon)
        ) {
            Storage::disk('public')->delete($sport->selected_icon);
        }

        // Delete unselected icon from storage
        if (
            $sport->unselected_icon &&
            Storage::disk('public')->exists($sport->unselected_icon)
        ) {
            Storage::disk('public')->delete($sport->unselected_icon);
        }

        // Delete sport from database
        $sport->delete();

        return response()->json([
            'status' => true,
            'message' => 'Sport deleted successfully.',
        ]);
    }

}