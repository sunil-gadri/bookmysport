<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\SlotMaster;
use Illuminate\Http\Request;
use App\Http\Resources\Admin\SlotMasterResource;

class SlotMasterController extends Controller
{
    /*** List All Slots (Across Every Turf) */

    public function index(Request $request)
    {
        $baseQuery = SlotMaster::query();

        /*
        |--------------------------------------------------------------------------
        | Stat Counts (unaffected by filters — overview numbers)
        |--------------------------------------------------------------------------
        */

        $counts = [
            'total_slots' => (clone $baseQuery)->count(),
            'active_slots' => (clone $baseQuery)->where('status', true)->count(),
            'inactive_slots' => (clone $baseQuery)->where('status', false)->count(),
        ];

        $query = (clone $baseQuery)->with(['turf', 'turf.owner']);

        /*
        |--------------------------------------------------------------------------
        | Search — turf name or owner name
        |--------------------------------------------------------------------------
        */

        if ($request->filled('search')) {

            $search = $request->search;

            $query->whereHas('turf', function ($turf) use ($search) {
                $turf->where('name', 'like', "%{$search}%")
                    ->orWhereHas('owner', function ($owner) use ($search) {
                        $owner->where('name', 'like', "%{$search}%");
                    });
            });

        }

        /*
        |--------------------------------------------------------------------------
        | Filters
        |--------------------------------------------------------------------------
        */

        if ($request->filled('turf_id')) {
            $query->where('turf_id', $request->turf_id);
        }

        if ($request->filled('booking_type')) {
            $query->where('booking_type', $request->booking_type);
        }

        if ($request->filled('day')) {
            $query->where('day', $request->day);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        /*
        |--------------------------------------------------------------------------
        | Sorting — Turf, Then Calendar-Order Day, Then Start Time
        |--------------------------------------------------------------------------
        */

        $query->orderBy('turf_id')
            ->orderByRaw("FIELD(day, 'monday','tuesday','wednesday','thursday','friday','saturday','sunday')")
            ->orderBy('start_time', 'asc');

        $slots = $query->paginate($request->per_page ?? 15);

        return response()->json([

            'success' => true,

            'message' => 'Slots fetched successfully.',

            'counts' => $counts,

            'data' => SlotMasterResource::collection($slots),

            'pagination' => [
                'current_page' => $slots->currentPage(),
                'last_page' => $slots->lastPage(),
                'per_page' => $slots->perPage(),
                'total' => $slots->total(),
            ],

        ]);
    }

    /*** Toggle Slot Active/Inactive (Moderation) */

    public function toggleStatus(SlotMaster $slotMaster)
    {
        $slotMaster->status = !$slotMaster->status;

        $slotMaster->save();

        $slotMaster->load('turf');

        return response()->json([

            'success' => true,

            'message' => $slotMaster->status
                ? 'Slot activated successfully.'
                : 'Slot deactivated successfully.',

            'data' => new SlotMasterResource($slotMaster),

        ]);
    }

    /*** Delete Slot (Moderation) */

    public function destroy(SlotMaster $slotMaster)
    {
        $slotMaster->delete();

        return response()->json([

            'success' => true,

            'message' => 'Slot deleted successfully.',

        ]);
    }
}