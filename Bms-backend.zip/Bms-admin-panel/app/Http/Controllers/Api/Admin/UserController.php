<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Http\Requests\Admin\UserListRequest;
use App\Http\Resources\Admin\UserResource;
use App\Http\Resources\Admin\UserDetailResource;
use App\Http\Requests\Admin\UpdateUserStatusRequest;

class UserController extends Controller
{

    /*** List User Details */

    public function index(UserListRequest $request)
    {
        $query = User::with([
            'profile.country',
            'profile.state',
            'profile.city',
        ])
        ->whereHas('roles', function ($query) {
            $query->where('slug', 'user');
        });


        /*
        |--------------------------------------------------------------------------
        | Search
        |--------------------------------------------------------------------------
        */

        if ($request->filled('search')) {

            $search = $request->search;

            $query->where(function ($q) use ($search) {

                // Search in users table
                $q->where('mobile', 'like', "%{$search}%")

                // Search in profile table
                ->orWhereHas('profile', function ($profile) use ($search) {

                    $profile->where('full_name', 'like', "%{$search}%")
                            ->orWhere('email', 'like', "%{$search}%")
                            ->orWhere('address', 'like', "%{$search}%");

                })

                // Search by Country
                ->orWhereHas('profile.country', function ($country) use ($search) {

                    $country->where('name', 'like', "%{$search}%");

                })

                // Search by State
                ->orWhereHas('profile.state', function ($state) use ($search) {

                    $state->where('name', 'like', "%{$search}%");

                })

                // Search by City
                ->orWhereHas('profile.city', function ($city) use ($search) {

                    $city->where('name', 'like', "%{$search}%");

                });

            });

        }

        /*
        |--------------------------------------------------------------------------
        | Status Filter
        |--------------------------------------------------------------------------
        */

        if ($request->filled('status')) {

            $query->where('status', $request->status);

        }

        /*
        |--------------------------------------------------------------------------
        | Sorting
        |--------------------------------------------------------------------------
        */

        $sortBy = $request->sort_by ?? 'created_at';

        $sortOrder = $request->sort_order ?? 'desc';

        $query->orderBy($sortBy, $sortOrder);



        /*
        |--------------------------------------------------------------------------
        | User Counts
        |--------------------------------------------------------------------------
        */

        $totalUsers = User::whereHas('roles', function ($query) {
            $query->where('slug', 'user');
        })->count();

        $activeUsers = User::whereHas('roles', function ($query) {
            $query->where('slug', 'user');
        })
        ->where('status', true)
        ->count();

        $inactiveUsers = User::whereHas('roles', function ($query) {
            $query->where('slug', 'user');
        })
        ->where('status', false)
        ->count();


        /*
        |--------------------------------------------------------------------------
        | Pagination
        |--------------------------------------------------------------------------
        */

        $users = $query->paginate(

            $request->per_page ?? 10

        );

        return response()->json([

            'status' => true,

            'message' => 'Users fetched successfully.',

            'counts' => [

                'total_users' => $totalUsers,

                'active_users' => $activeUsers,

                'inactive_users' => $inactiveUsers,

            ],

            'data' => UserResource::collection($users),

            'pagination' => [

                'current_page' => $users->currentPage(),

                'last_page' => $users->lastPage(),

                'per_page' => $users->perPage(),

                'total' => $users->total(),

            ]

        ]);

    }


    /*** View User Details */

    public function show(User $user)
    {
        // Allow only app users
        if (!$user->roles()->where('slug', 'user')->exists()) {
            return response()->json([
                'status' => false,
                'message' => 'User not found.',
            ], 404);
        }

        $user->load([
            'profile.country',
            'profile.state',
            'profile.city'
        ]);

        return response()->json([
            'status' => true,
            'message' => 'User details fetched successfully.',
            'data' => new UserDetailResource($user)
        ]);
    }



    /*** Update User Status */
    public function updateStatus( UpdateUserStatusRequest $request, User $user)
    {
        /*
        |--------------------------------------------------------------------------
        | Check Role
        |--------------------------------------------------------------------------
        */

        if (!$user->roles()->where('slug', 'user')->exists()) {
            return response()->json([
                'status' => false,
                'message' => 'User not found.',
            ], 404);
        }

        /*
        |--------------------------------------------------------------------------
        | Update Status
        |--------------------------------------------------------------------------
        */

        $user->update([

            'status' => $request->status

        ]);

        /*
        |--------------------------------------------------------------------------
        | Response
        |--------------------------------------------------------------------------
        */

        return response()->json([

            'status' => true,

            'message' => $user->status
                ? 'User activated successfully.'
                : 'User deactivated successfully.',

            'data' => [

                'id' => $user->id,

                'status' => [

                    'value' => (bool)$user->status,

                    'label' => $user->status
                        ? 'Active'
                        : 'Inactive'

                ]

            ]

        ]);

    }


}
