<?php

namespace App\Http\Controllers\Api\TurfOwner;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\Turf;
use App\Models\SlotMaster;
use App\Models\BookingItem;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $ownerId = auth()->id();

        $myTurfIds = Turf::where('owner_id', $ownerId)->pluck('id');

        $now = now();
        $startOfMonth = $now->copy()->startOfMonth();
        $startOfLastMonth = $now->copy()->subMonthNoOverflow()->startOfMonth();
        $endOfLastMonth = $now->copy()->subMonthNoOverflow()->endOfMonth();
        $today = $now->toDateString();
        $todayDayName = strtolower($now->format('l'));

        $bookingBase = Booking::whereIn('turf_id', $myTurfIds);

        /*
        |--------------------------------------------------------------------------
        | Top Stat Cards
        |--------------------------------------------------------------------------
        */

        $totalTurfs = $myTurfIds->count();

        $activeTurfs = Turf::whereIn('id', $myTurfIds)
            ->where('status', true)
            ->where('approval_status', 'approved')
            ->count();

        $pendingTurfs = Turf::whereIn('id', $myTurfIds)
            ->where('approval_status', 'pending')
            ->count();

        $totalBookings = (clone $bookingBase)->count();

        $bookingsToday = (clone $bookingBase)->whereDate('booking_date', $today)->count();

        $checkedInToday = (clone $bookingBase)
            ->whereDate('booking_date', $today)
            ->whereNotNull('checked_in_at')
            ->count();

        $revenueThisMonth = (clone $bookingBase)
            ->where('payment_status', 'paid')
            ->where('booking_date', '>=', $startOfMonth->toDateString())
            ->sum('total_amount');

        $revenueLastMonth = (clone $bookingBase)
            ->where('payment_status', 'paid')
            ->whereBetween('booking_date', [
                $startOfLastMonth->toDateString(),
                $endOfLastMonth->toDateString(),
            ])
            ->sum('total_amount');

        $revenueChangePercent = $revenueLastMonth > 0
            ? round((($revenueThisMonth - $revenueLastMonth) / $revenueLastMonth) * 100, 1)
            : null;

        $avgBookingValue = (clone $bookingBase)->where('payment_status', 'paid')->avg('total_amount');

        $cancellationRate = $totalBookings > 0
            ? round(((clone $bookingBase)->where('booking_status', 'cancelled')->count() / $totalBookings) * 100, 1)
            : 0;

        /*
        |--------------------------------------------------------------------------
        | Today's Occupancy — how many of today's active slots are booked
        |--------------------------------------------------------------------------
        */

        $todaysActiveSlots = SlotMaster::whereIn('turf_id', $myTurfIds)
            ->where('day', $todayDayName)
            ->where('status', true)
            ->count();

        $todaysBookedSlots = BookingItem::query()
            ->join('bookings', 'bookings.id', '=', 'booking_items.booking_id')
            ->whereIn('bookings.turf_id', $myTurfIds)
            ->whereDate('bookings.booking_date', $today)
            ->whereIn('bookings.booking_status', ['confirmed', 'completed'])
            ->count();

        $occupancyRate = $todaysActiveSlots > 0
            ? round(($todaysBookedSlots / $todaysActiveSlots) * 100, 1)
            : 0;

        /*
        |--------------------------------------------------------------------------
        | Revenue Trend — last 30 days
        |--------------------------------------------------------------------------
        */

        $revenueTrendRaw = (clone $bookingBase)
            ->where('payment_status', 'paid')
            ->where('booking_date', '>=', $now->copy()->subDays(29)->toDateString())
            ->select(
                DB::raw('DATE(booking_date) as date'),
                DB::raw('sum(total_amount) as revenue')
            )
            ->groupBy('date')
            ->pluck('revenue', 'date');

        $revenueTrend = [];

        for ($i = 29; $i >= 0; $i--) {
            $date = $now->copy()->subDays($i)->toDateString();
            $revenueTrend[] = [
                'date' => $date,
                'label' => Carbon::parse($date)->format('d M'),
                'revenue' => (float) ($revenueTrendRaw[$date] ?? 0),
            ];
        }

        /*
        |--------------------------------------------------------------------------
        | Bookings Trend — last 14 days
        |--------------------------------------------------------------------------
        */

        $bookingsTrendRaw = (clone $bookingBase)
            ->where('created_at', '>=', $now->copy()->subDays(13)->startOfDay())
            ->select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('count(*) as total')
            )
            ->groupBy('date')
            ->pluck('total', 'date');

        $bookingsTrend = [];

        for ($i = 13; $i >= 0; $i--) {
            $date = $now->copy()->subDays($i)->toDateString();
            $bookingsTrend[] = [
                'date' => $date,
                'label' => Carbon::parse($date)->format('d M'),
                'bookings' => (int) ($bookingsTrendRaw[$date] ?? 0),
            ];
        }

        /*
        |--------------------------------------------------------------------------
        | Booking Status Breakdown
        |--------------------------------------------------------------------------
        */

        $statusBreakdown = (clone $bookingBase)
            ->select('booking_status', DB::raw('count(*) as total'))
            ->groupBy('booking_status')
            ->pluck('total', 'booking_status');

        $bookingStatusBreakdown = [
            ['status' => 'confirmed', 'label' => 'Confirmed', 'total' => (int) ($statusBreakdown['confirmed'] ?? 0)],
            ['status' => 'completed', 'label' => 'Completed', 'total' => (int) ($statusBreakdown['completed'] ?? 0)],
            ['status' => 'cancelled', 'label' => 'Cancelled', 'total' => (int) ($statusBreakdown['cancelled'] ?? 0)],
        ];

        /*
        |--------------------------------------------------------------------------
        | Bookings By Turf — useful if the owner runs more than one turf
        |--------------------------------------------------------------------------
        */

        $bookingsByTurf = (clone $bookingBase)
            ->select('turf_id', DB::raw('count(*) as total_bookings'))
            ->groupBy('turf_id')
            ->orderByDesc('total_bookings')
            ->with('turf:id,name')
            ->get()
            ->map(fn ($row) => [
                'turf_name' => $row->turf?->name ?? 'Unknown',
                'total_bookings' => $row->total_bookings,
            ]);

        return response()->json([

            'success' => true,

            'message' => 'Dashboard data fetched successfully.',

            'data' => [

                'stats' => [

                    'total_turfs' => $totalTurfs,
                    'active_turfs' => $activeTurfs,
                    'pending_turfs' => $pendingTurfs,

                    'total_bookings' => $totalBookings,
                    'bookings_today' => $bookingsToday,

                    'checked_in_today' => $checkedInToday,

                    'revenue_this_month' => (float) $revenueThisMonth,
                    'revenue_change_percent' => $revenueChangePercent,

                    'avg_booking_value' => round((float) $avgBookingValue, 0),

                    'cancellation_rate' => $cancellationRate,

                    'occupancy_rate_today' => $occupancyRate,

                ],

                'charts' => [

                    'revenue_trend' => $revenueTrend,

                    'bookings_trend' => $bookingsTrend,

                    'booking_status_breakdown' => $bookingStatusBreakdown,

                    'bookings_by_turf' => $bookingsByTurf,

                ],

            ],

        ]);
    }
}