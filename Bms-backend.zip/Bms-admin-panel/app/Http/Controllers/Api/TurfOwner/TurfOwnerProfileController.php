<?php

namespace App\Http\Controllers\Api\TurfOwner;

use App\Http\Controllers\Controller;
use App\Models\TurfOwnerProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class TurfOwnerProfileController extends Controller
{
    

    public function completeProfile(Request $request)
    {
        $user = $request->user();

        if ($user->turfOwnerProfile) {
            return response()->json([
                'status' => false,
                'message' => 'Turf owner profile already exists.',
            ], 409);
        }

        $validated = $request->validate([

            'name' => [
                'required',
                'string',
                'max:255',
            ],

            'business_name' => [
                'required',
                'string',
                'max:150',
            ],

            'business_email' => [
                'required',
                'email',
                'max:255',
            ],

            'business_phone' => [
                'nullable',
                'string',
                'max:20',
            ],

            'profile_image' => [
                'nullable',
                'image',
                'mimes:jpg,jpeg,png,webp',
                'max:2048',
            ],

            'description' => [
                'nullable',
                'string',
            ],

            'address' => [
                'nullable',
                'string',
            ],

            'country_id' => [
                'nullable',
                'exists:countries,id',
            ],

            'state_id' => [
                'nullable',
                'exists:states,id',
            ],

            'city_id' => [
                'nullable',
                'exists:cities,id',
            ],

            'pincode' => [
                'nullable',
                'string',
                'max:10',
            ],
        ]);

        $profileImagePath = null;

        if ($request->hasFile('profile_image')) {
            $profileImagePath = $request
                ->file('profile_image')
                ->store('turf-owner/profile-images', 'public');
        }

        $user->update([
            'name' => $validated['name'],
        ]);

        $profile = $user->turfOwnerProfile()->create([
            'business_name' => $validated['business_name'],
            'business_email' => $validated['business_email'] ?? null,
            'business_phone' => $validated['business_phone'] ?? null,
            'profile_image' => $profileImagePath,
            'description' => $validated['description'] ?? null,
            'address' => $validated['address'] ?? null,
            'country_id' => $validated['country_id'] ?? null,
            'state_id' => $validated['state_id'] ?? null,
            'city_id' => $validated['city_id'] ?? null,
            'pincode' => $validated['pincode'] ?? null,
        ]);

        $profile->load([
            'country:id,name',
            'state:id,name',
            'city:id,name',
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Turf owner profile completed successfully.',
            'data' => [
                'id' => $profile->id,
                'user_id' => $profile->user_id,
                'full_name' => $user->name,
                'business_name' => $profile->business_name,
                'business_email' => $profile->business_email,
                'business_phone' => $profile->business_phone,
                'profile_image' => $profile->profile_image
                    ? asset('storage/' . $profile->profile_image)
                    : null,
                'description' => $profile->description,
                'address' => $profile->address,
                'country' => $profile->country,
                'state' => $profile->state,
                'city' => $profile->city,
                'pincode' => $profile->pincode,
            ],
        ], 201);
    }

    public function getProfile(Request $request)
    {
        $user = $request->user();

        $profile = TurfOwnerProfile::with([
            'country:id,name',
            'state:id,name',
            'city:id,name',
            'user:id,name',
        ])
            ->where('user_id', $user->id)
            ->first();

        if (!$profile) {
            return response()->json([
                'status' => false,
                'message' => 'Turf owner profile not found.',
            ], 404);
        }

        return response()->json([
            'status' => true,
            'message' => 'Turf owner profile fetched successfully.',
            'data' => [
                'id' => $profile->id,
                'user_id' => $profile->user_id,
                'full_name' => $profile->user->name,
                'business_name' => $profile->business_name,
                'business_email' => $profile->business_email,
                'business_phone' => $profile->business_phone,
                'profile_image' => $profile->profile_image
                    ? asset('storage/' . $profile->profile_image)
                    : null,
                'description' => $profile->description,
                'address' => $profile->address,
                'country' => $profile->country,
                'state' => $profile->state,
                'city' => $profile->city,
                'pincode' => $profile->pincode,
                'created_at' => $profile->created_at,
                'updated_at' => $profile->updated_at,
            ],
        ]);
    }

    public function updateProfile(Request $request)
    {
        $user = $request->user();

        $profile = TurfOwnerProfile::where('user_id', $user->id)->first();

        if (!$profile) {
            return response()->json([
                'status' => false,
                'message' => 'Turf owner profile not found.',
            ], 404);
        }

        $validated = $request->validate([
             'name' => [
                'required',
                'string',
                'max:255',
            ],

            'business_name' => [
                'required',
                'string',
                'max:150',
            ],

            'business_email' => [
                'nullable',
                'email',
                'max:255',
            ],

            'business_phone' => [
                'nullable',
                'string',
                'max:20',
            ],

            'profile_image' => [
                'nullable',
                'image',
                'mimes:jpg,jpeg,png,webp',
                'max:2048',
            ],

            'description' => [
                'nullable',
                'string',
            ],

            'address' => [
                'nullable',
                'string',
            ],

            'country_id' => [
                'nullable',
                'exists:countries,id',
            ],

            'state_id' => [
                'nullable',
                'exists:states,id',
            ],

            'city_id' => [
                'nullable',
                'exists:cities,id',
            ],

            'pincode' => [
                'nullable',
                'string',
                'max:10',
            ],
        ]);

        $profileImagePath = $profile->profile_image;

        if ($request->hasFile('profile_image')) {

            if (
                $profile->profile_image &&
                Storage::disk('public')->exists($profile->profile_image)
            ) {
                Storage::disk('public')->delete($profile->profile_image);
            }

            $profileImagePath = $request
                ->file('profile_image')
                ->store('turf-owner/profile-images', 'public');
        }

        $user->update([
            'name' => $validated['name'],
        ]);

        $profile->update([
            'business_name' => $validated['business_name'],
            'business_email' => $validated['business_email'] ?? null,
            'business_phone' => $validated['business_phone'] ?? null,
            'profile_image' => $profileImagePath,
            'description' => $validated['description'] ?? null,
            'address' => $validated['address'] ?? null,
            'country_id' => $validated['country_id'] ?? null,
            'state_id' => $validated['state_id'] ?? null,
            'city_id' => $validated['city_id'] ?? null,
            'pincode' => $validated['pincode'] ?? null,
        ]);

        $profile->load([
            'country:id,name',
            'state:id,name',
            'city:id,name',
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Turf owner profile updated successfully.',
            'data' => [
                'id' => $profile->id,
                'user_id' => $profile->user_id,
                'full_name' => $user->name,
                'business_name' => $profile->business_name,
                'business_email' => $profile->business_email,
                'business_phone' => $profile->business_phone,
                'profile_image' => $profile->profile_image
                    ? asset('storage/' . $profile->profile_image)
                    : null,
                'description' => $profile->description,
                'address' => $profile->address,
                'country' => $profile->country,
                'state' => $profile->state,
                'city' => $profile->city,
                'pincode' => $profile->pincode,
            ],
        ]);

    }


}