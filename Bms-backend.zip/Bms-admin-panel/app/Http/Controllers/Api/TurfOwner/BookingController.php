<?php

namespace App\Http\Controllers\Api\TurfOwner;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use Illuminate\Http\Request;
use App\Http\Resources\TurfOwner\BookingResource;

class BookingController extends Controller
{
    /*** List Bookings — only for turfs owned by the logged-in turf owner */

    public function index(Request $request)
    {
        $baseQuery = Booking::query()
            ->whereHas('turf', function ($q) {
                $q->where('owner_id', auth()->id());
            });

        /*
        |--------------------------------------------------------------------------
        | Stat Counts (respects turf/date filters, not search/status —
        | so the summary cards make sense next to the filtered table)
        |--------------------------------------------------------------------------
        */

        $countsQuery = clone $baseQuery;

        if ($request->filled('turf_id')) {
            $countsQuery->where('turf_id', $request->turf_id);
        }

        $today = now()->toDateString();

        $counts = [
            'total_bookings' => (clone $countsQuery)->count(),
            'today_bookings' => (clone $countsQuery)->whereDate('booking_date', $today)->count(),
            'confirmed' => (clone $countsQuery)->where('booking_status', 'confirmed')->count(),
            'completed' => (clone $countsQuery)->where('booking_status', 'completed')->count(),
            'cancelled' => (clone $countsQuery)->where('booking_status', 'cancelled')->count(),
            'checked_in' => (clone $countsQuery)->whereNotNull('checked_in_at')->count(),
            'total_revenue' => (float) (clone $countsQuery)->where('payment_status', 'paid')->sum('total_amount'),
        ];

        /*
        |--------------------------------------------------------------------------
        | Main Query
        |--------------------------------------------------------------------------
        */

        $query = (clone $baseQuery)->with([
            'user.profile',
            'turf',
            'turf.sports',
            'turf.events',
            'bookingItems.slotMaster',
        ]);

        /*
        |--------------------------------------------------------------------------
        | Search — booking number, customer name/mobile
        |--------------------------------------------------------------------------
        */

        if ($request->filled('search')) {

            $search = $request->search;

            $query->where(function ($q) use ($search) {

                $q->where('booking_number', 'like', "%{$search}%")

                ->orWhereHas('user', function ($user) use ($search) {
                    $user->where('mobile', 'like', "%{$search}%")
                        ->orWhereHas('profile', function ($profile) use ($search) {
                            $profile->where('full_name', 'like', "%{$search}%");
                        });
                });

            });

        }

        /*
        |--------------------------------------------------------------------------
        | Filters
        |--------------------------------------------------------------------------
        */

        if ($request->filled('turf_id')) {
            $query->where('turf_id', $request->turf_id);
        }

        if ($request->filled('booking_status')) {
            $query->where('booking_status', $request->booking_status);
        }

        if ($request->filled('payment_status')) {
            $query->where('payment_status', $request->payment_status);
        }

        if ($request->filled('from_date')) {
            $query->whereDate('booking_date', '>=', $request->from_date);
        }

        if ($request->filled('to_date')) {
            $query->whereDate('booking_date', '<=', $request->to_date);
        }

        // Today's bookings shortcut — handy for a turf owner's "front desk" view
        if ($request->boolean('today')) {
            $query->whereDate('booking_date', $today);
        }

        /*
        |--------------------------------------------------------------------------
        | Sorting
        |--------------------------------------------------------------------------
        */

        $sortBy = in_array($request->sort_by, ['created_at', 'booking_date', 'total_amount'])
            ? $request->sort_by
            : 'booking_date';

        $sortOrder = $request->sort_order === 'asc' ? 'asc' : 'desc';

        $query->orderBy($sortBy, $sortOrder);

        $bookings = $query->paginate($request->per_page ?? 15);

        return response()->json([

            'success' => true,

            'message' => 'Bookings fetched successfully.',

            'counts' => $counts,

            'data' => BookingResource::collection($bookings),

            'pagination' => [
                'current_page' => $bookings->currentPage(),
                'last_page' => $bookings->lastPage(),
                'per_page' => $bookings->perPage(),
                'total' => $bookings->total(),
            ],

        ]);
    }

    /*** View Single Booking Detail — only if it belongs to one of their turfs */

    public function show(Booking $booking)
    {
        if ($booking->turf->owner_id !== auth()->id()) {
            return response()->json([
                'success' => false,
                'message' => 'Booking not found.',
            ], 404);
        }

        $booking->load([
            'user.profile',
            'turf',
            'turf.sports',
            'turf.events',
            'bookingItems.slotMaster',
        ]);

        return response()->json([

            'success' => true,

            'message' => 'Booking details fetched successfully.',

            'data' => new BookingResource($booking),

        ]);
    }
}