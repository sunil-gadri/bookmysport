<?php

namespace App\Http\Controllers\Api\TurfOwner;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use Illuminate\Http\Request;
use Carbon\Carbon;

class BookingCheckInController extends Controller
{
    /**
     * Turf owner scans the customer's QR code. The scanned value is the
     * booking's check_in_token — NOT the booking_number — so someone who
     * only knows/overhears the booking number cannot fake a check-in.
     */
    public function checkIn(Request $request)
    {
        $request->validate([
            'check_in_token' => ['required', 'string'],
        ]);

        $booking = Booking::with([
                'turf',
                'user',
                'bookingItems.slotMaster',
            ])
            ->where('check_in_token', $request->check_in_token)
            ->first();

        if (!$booking) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid QR code. This booking does not exist.',
            ], 404);
        }

        // Only the owner of THIS turf can check in a booking made for it.
        if ($booking->turf->owner_id !== auth()->id()) {
            return response()->json([
                'success' => false,
                'message' => 'This booking is not for one of your turfs.',
            ], 403);
        }

        if ($booking->booking_status === 'cancelled') {
            return response()->json([
                'success' => false,
                'message' => 'This booking was cancelled.',
            ], 422);
        }

        if ($booking->booking_status !== 'confirmed') {
            return response()->json([
                'success' => false,
                'message' => 'This booking is not in a valid state for check-in.',
            ], 422);
        }

        $bookingDate = Carbon::parse($booking->booking_date)->toDateString();

        if ($bookingDate !== now()->toDateString()) {
            return response()->json([
                'success' => false,
                'message' => "This booking is for {$bookingDate}, not today.",
            ], 422);
        }

        if ($booking->checked_in_at !== null) {
            return response()->json([
                'success' => false,
                'message' => 'This booking was already checked in at ' . $booking->checked_in_at->format('h:i A') . '.',
                'data' => $this->formatCheckIn($booking),
            ], 409);
        }

        $booking->update(['checked_in_at' => now()]);

        return response()->json([
            'success' => true,
            'message' => 'Checked in successfully.',
            'data' => $this->formatCheckIn($booking->fresh(['turf', 'user', 'bookingItems.slotMaster'])),
        ]);
    }

    private function formatCheckIn(Booking $booking): array
    {
        return [
            'booking_number' => $booking->booking_number,
            'customer_name' => $booking->user->name,
            'customer_mobile' => $booking->user->mobile,
            'turf_name' => $booking->turf->name,
            'booking_date' => Carbon::parse($booking->booking_date)->format('d M Y'),
            'slots' => $booking->bookingItems->map(function ($item) {
                return [
                    'start_time' => Carbon::parse($item->slotMaster->start_time)->format('h:i A'),
                    'end_time' => Carbon::parse($item->slotMaster->end_time)->format('h:i A'),
                ];
            }),
            'checked_in_at' => $booking->checked_in_at?->format('h:i A'),
        ];
    }
}