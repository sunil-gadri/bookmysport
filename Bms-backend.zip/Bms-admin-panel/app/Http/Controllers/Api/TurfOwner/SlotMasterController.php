<?php

namespace App\Http\Controllers\Api\TurfOwner;

use App\Http\Controllers\Controller;
use App\Http\Requests\TurfOwner\StoreSlotMasterRequest;
use App\Models\SlotMaster;
use App\Models\Turf;
use Illuminate\Http\JsonResponse;
use App\Http\Requests\TurfOwner\SlotMasterListRequest;
use App\Http\Resources\TurfOwner\SlotMasterResource;
use Illuminate\Http\Request;
use App\Http\Requests\TurfOwner\UpdateSlotMasterRequest;
use App\Http\Requests\TurfOwner\ChangeSlotStatusRequest;
use App\Models\Sport;
use App\Models\Event;
use App\Http\Requests\TurfOwner\AutoGenerateSlotRequest;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;



class SlotMasterController extends Controller
{
    /*** Create Manual Slot */

    public function store(StoreSlotMasterRequest $request): JsonResponse
    {
        $validated = $request->validated();

        /*
        |--------------------------------------------------------------------------
        | Verify Turf Ownership
        |--------------------------------------------------------------------------
        */

        $turf = Turf::where('id', $validated['turf_id'])
            ->where('owner_id', $request->user()->id)
            ->first();

        if (!$turf) {
            return response()->json([
                'success' => false,
                'message' => 'Turf not found or unauthorized.',
            ], 404);
        }

        /*
        |--------------------------------------------------------------------------
        | Validate Slot Timing
        |--------------------------------------------------------------------------
        */

        $openingTime = Carbon::parse($turf->opening_time);
        $closingTime = Carbon::parse($turf->closing_time);

        $slotStart = Carbon::createFromFormat('H:i', $validated['start_time']);
        $slotEnd = Carbon::createFromFormat('H:i', $validated['end_time']);

        if ($slotStart->lt($openingTime) || $slotEnd->gt($closingTime)) {

            return response()->json([
                'success' => false,
                'message' => "Slot timing must be between {$openingTime->format('h:i A')} and {$closingTime->format('h:i A')}.",
            ], 422);

        }


        /*
        |--------------------------------------------------------------------------
        | Validate Sport / Event Belongs To Turf
        |--------------------------------------------------------------------------
        */

        if ($validated['booking_type'] === 'sport') {

            $exists = $turf->sports()
                ->where('sports.id', $validated['booking_type_id'])
                ->exists();

            if (!$exists) {

                return response()->json([
                    'success' => false,
                    'message' => 'Selected sport is not available for this turf.',
                ], 422);

            }

        } elseif ($validated['booking_type'] === 'event') {

            $exists = $turf->events()
                ->where('events.id', $validated['booking_type_id'])
                ->exists();

            if (!$exists) {

                return response()->json([
                    'success' => false,
                    'message' => 'Selected event is not available for this turf.',
                ], 422);

            }

        }

        /*
        |--------------------------------------------------------------------------
        | Check Duplicate Slot
        |--------------------------------------------------------------------------
        */

        $exists = SlotMaster::where('turf_id', $validated['turf_id'])
            ->where('booking_type', $validated['booking_type'])
            ->where('booking_type_id', $validated['booking_type_id'])
            ->where('day', $validated['day'])
            ->where('start_time', $validated['start_time'])
            ->where('end_time', $validated['end_time'])
            ->exists();

        if ($exists) {
            return response()->json([
                'success' => false,
                'message' => 'This slot already exists.',
            ], 422);
        }

        /*
        |--------------------------------------------------------------------------
        | Create Slot
        |--------------------------------------------------------------------------
        */

        $slot = SlotMaster::create([
            'turf_id' => $validated['turf_id'],
            'booking_type' => $validated['booking_type'],
            'booking_type_id' => $validated['booking_type_id'],
            'day' => $validated['day'],
            'start_time' => $validated['start_time'],
            'end_time' => $validated['end_time'],
            'price' => $validated['price'],
            'status' => true,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Slot created successfully.',
            'data' => $slot,
        ], 201);
    }

    /*** Slot List */
    
    public function index(SlotMasterListRequest $request): JsonResponse
    {
        /*
        |--------------------------------------------------------------------------
        | Base Query — Only Logged-in Owner's Turf Slots
        |--------------------------------------------------------------------------
        */
        $baseQuery = SlotMaster::whereHas('turf', function ($q) use ($request) {
            $q->where('owner_id', $request->user()->id);
        });

        /*
        |--------------------------------------------------------------------------
        | Stat Counts (unaffected by filters — overview numbers)
        |--------------------------------------------------------------------------
        */
        $counts = [
            'total_slots'    => (clone $baseQuery)->count(),
            'active_slots'   => (clone $baseQuery)->where('status', true)->count(),
            'inactive_slots' => (clone $baseQuery)->where('status', false)->count(),
        ];

        $query = (clone $baseQuery)->with('turf');

        /*
        |--------------------------------------------------------------------------
        | Search
        |--------------------------------------------------------------------------
        */
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->whereHas('turf', function ($turf) use ($search) {
                    $turf->where('name', 'like', "%{$search}%");
                });
            });
        }

        /*
        |--------------------------------------------------------------------------
        | Turf / Booking Type / Day / Status Filters
        |--------------------------------------------------------------------------
        */
        if ($request->filled('turf_id')) {
            $query->where('turf_id', $request->turf_id);
        }

        if ($request->filled('booking_type')) {
            $query->where('booking_type', $request->booking_type);
        }

        if ($request->filled('day')) {
            $query->where('day', $request->day);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        /*
        |--------------------------------------------------------------------------
        | Sorting — Turf, Then Calendar-Order Day (Mon → Sun), Then Start Time
        |--------------------------------------------------------------------------
        */
        $query->orderBy('turf_id')
            ->orderByRaw("FIELD(day, 'monday','tuesday','wednesday','thursday','friday','saturday','sunday')")
            ->orderBy('start_time', 'asc');

        /*
        |--------------------------------------------------------------------------
        | Pagination
        |--------------------------------------------------------------------------
        */
        $slots = $query->paginate($request->per_page ?? 10);

        return response()->json([
            'success' => true,
            'message' => 'Slot list fetched successfully.',
            'data' => SlotMasterResource::collection($slots),
            'counts' => $counts,
            'pagination' => [
                'current_page' => $slots->currentPage(),
                'last_page' => $slots->lastPage(),
                'per_page' => $slots->perPage(),
                'total' => $slots->total(),
            ]
        ]);
    }

    /*** Slot Details */

    public function show(SlotMaster $slotMaster, Request $request): JsonResponse
    {
        /*
        |--------------------------------------------------------------------------
        | Load Turf Relationship
        |--------------------------------------------------------------------------
        */
        $slotMaster->load('turf');

        /*
        |--------------------------------------------------------------------------
        | Verify Turf Ownership
        |--------------------------------------------------------------------------
        */
        if ($slotMaster->turf->owner_id != $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Slot not found or unauthorized.',
            ], 404);
        }

        /*
        |--------------------------------------------------------------------------
        | Return Slot Details
        |--------------------------------------------------------------------------
        */
        return response()->json([
            'success' => true,
            'message' => 'Slot details fetched successfully.',
            'data' => new SlotMasterResource($slotMaster),
        ]);
    }


    /*** Update Slot */

    public function update(
        UpdateSlotMasterRequest $request,
        SlotMaster $slotMaster
    ): JsonResponse {

        $validated = $request->validated();


        /*
        |--------------------------------------------------------------------------
        | Fetch Selected Turf
        |--------------------------------------------------------------------------
        */

        $turf = Turf::with(['sports', 'events'])
            ->where('id', $validated['turf_id'])
            ->where('owner_id', $request->user()->id)
            ->first();

        if (!$turf) {

            return response()->json([
                'success' => false,
                'message' => 'Turf not found or unauthorized.',
            ], 404);

        }


        /*
        |--------------------------------------------------------------------------
        | Validate Slot Timing
        |--------------------------------------------------------------------------
        */

        $openingTime = Carbon::parse($turf->opening_time);
        $closingTime = Carbon::parse($turf->closing_time);

        $slotStart = Carbon::createFromFormat('H:i', $validated['start_time']);
        $slotEnd = Carbon::createFromFormat('H:i', $validated['end_time']);

        if (
            $slotStart->lt($openingTime) ||
            $slotEnd->gt($closingTime)
        ) {

            return response()->json([
                'success' => false,
                'message' => "Slot timing must be between {$openingTime->format('h:i A')} and {$closingTime->format('h:i A')}.",
            ], 422);

        }


        /*
        |--------------------------------------------------------------------------
        | Validate Sport / Event Belongs To Turf
        |--------------------------------------------------------------------------
        */

        if ($validated['booking_type'] === 'sport') {

            $exists = $turf->sports()
                ->where('sports.id', $validated['booking_type_id'])
                ->exists();

            if (!$exists) {

                return response()->json([
                    'success' => false,
                    'message' => 'Selected sport is not available for this turf.',
                ], 422);

            }

        } elseif ($validated['booking_type'] === 'event') {

            $exists = $turf->events()
                ->where('events.id', $validated['booking_type_id'])
                ->exists();

            if (!$exists) {

                return response()->json([
                    'success' => false,
                    'message' => 'Selected event is not available for this turf.',
                ], 422);

            }

        }


        /*
        |--------------------------------------------------------------------------
        | Load Turf Relationship
        |--------------------------------------------------------------------------
        */
        $slotMaster->load('turf');

        /*
        |--------------------------------------------------------------------------
        | Verify Turf Ownership
        |--------------------------------------------------------------------------
        */
        if ($slotMaster->turf->owner_id != $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Slot not found or unauthorized.',
            ], 404);
        }

        /*
        |--------------------------------------------------------------------------
        | Check Duplicate Slot
        |--------------------------------------------------------------------------
        */
        $exists = SlotMaster::where('turf_id', $validated['turf_id'])
            ->where('booking_type', $validated['booking_type'])
            ->where('booking_type_id', $validated['booking_type_id'])
            ->where('day', $validated['day'])
            ->where('start_time', $validated['start_time'])
            ->where('end_time', $validated['end_time'])
            ->where('id', '!=', $slotMaster->id)
            ->exists();

        if ($exists) {
            return response()->json([
                'success' => false,
                'message' => 'This slot already exists.',
            ], 422);
        }

        /*
        |--------------------------------------------------------------------------
        | Update Slot
        |--------------------------------------------------------------------------
        */
        
        $slotMaster->update([
            'turf_id'          => $validated['turf_id'],
            'booking_type'     => $validated['booking_type'],
            'booking_type_id'  => $validated['booking_type_id'],
            'day'              => $validated['day'],
            'start_time'       => $validated['start_time'],
            'end_time'         => $validated['end_time'],
            'price'            => $validated['price'],
        ]);

        /*
        |--------------------------------------------------------------------------
        | Load Latest Turf Data
        |--------------------------------------------------------------------------
        */
        $slotMaster->load('turf');

        return response()->json([
            'success' => true,
            'message' => 'Slot updated successfully.',
            'data' => new SlotMasterResource($slotMaster),
        ]);
    }


    /*** Delete Slot */

    public function destroy(
        Request $request,
        SlotMaster $slotMaster
    ): JsonResponse {

        /*
        |--------------------------------------------------------------------------
        | Load Turf Relationship
        |--------------------------------------------------------------------------
        */
        $slotMaster->load('turf');

        /*
        |--------------------------------------------------------------------------
        | Verify Turf Ownership
        |--------------------------------------------------------------------------
        */
        if ($slotMaster->turf->owner_id != $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Slot not found or unauthorized.',
            ], 404);
        }

        /*
        |--------------------------------------------------------------------------
        | Delete Slot
        |--------------------------------------------------------------------------
        */
        $slotMaster->delete();

        /*
        |--------------------------------------------------------------------------
        | Return Response
        |--------------------------------------------------------------------------
        */
        return response()->json([
            'success' => true,
            'message' => 'Slot deleted successfully.',
        ]);
    }


    public function changeStatus(
    ChangeSlotStatusRequest $request,
    SlotMaster $slotMaster
    ): JsonResponse
    {
        $validated = $request->validated();

        /*
        |--------------------------------------------------------------------------
        | Load Turf Relationship
        |--------------------------------------------------------------------------
        */

        $slotMaster->load('turf');

        /*
        |--------------------------------------------------------------------------
        | Verify Turf Ownership
        |--------------------------------------------------------------------------
        */

        if ($slotMaster->turf->owner_id != $request->user()->id) {

            return response()->json([
                'success' => false,
                'message' => 'Slot not found or unauthorized.',
            ],404);

        }

        /*
        |--------------------------------------------------------------------------
        | Update Status
        |--------------------------------------------------------------------------
        */

        $slotMaster->update([
            'status' => $validated['status']
        ]);

        /*
        |--------------------------------------------------------------------------
        | Return Response
        |--------------------------------------------------------------------------
        */

        return response()->json([
            'success' => true,
            'message' => 'Slot status updated successfully.',
            'data' => new SlotMasterResource($slotMaster),
        ]);
    }


    // public function dropdownData(Request $request): JsonResponse
    // {
    //     /*
    //     |--------------------------------------------------------------------------
    //     | Fetch Logged-in Owner Turfs
    //     |--------------------------------------------------------------------------
    //     */

    //     $turfs = Turf::where('owner_id', $request->user()->id)
    //         ->where('status', true)
    //         ->select('id', 'name')
    //         ->get();

    //     /*
    //     |--------------------------------------------------------------------------
    //     | Fetch Active Sports
    //     |--------------------------------------------------------------------------
    //     */

    //     $sports = Sport::where('status', true)
    //         ->select('id', 'name')
    //         ->get();

    //     /*
    //     |--------------------------------------------------------------------------
    //     | Fetch Active Events
    //     |--------------------------------------------------------------------------
    //     */

    //     $events = Event::where('status', true)
    //         ->select('id', 'name')
    //         ->get();

    //     /*
    //     |--------------------------------------------------------------------------
    //     | Days
    //     |--------------------------------------------------------------------------
    //     */

    //     $days = [
    //         'monday',
    //         'tuesday',
    //         'wednesday',
    //         'thursday',
    //         'friday',
    //         'saturday',
    //         'sunday'
    //     ];

    //     return response()->json([
    //         'success' => true,
    //         'message' => 'Dropdown data fetched successfully.',
    //         'data' => [
    //             'turfs' => $turfs,
    //             'sports' => $sports,
    //             'events' => $events,
    //             'days' => $days,
    //         ]
    //     ]);
    // }



    public function autoGenerate(AutoGenerateSlotRequest $request): JsonResponse
    {
        $validated = $request->validated();

        DB::beginTransaction();

        try {

            $turf = Turf::with(['sports', 'events'])
                ->where('id', $validated['turf_id'])
                ->first();

            if (!$turf) {
                return response()->json([
                    'success' => false,
                    'message' => 'Turf not found.',
                ], 404);
            }

            if ($turf->owner_id != $request->user()->id) {
                return response()->json([
                    'success' => false,
                    'message' => 'You are not authorized to manage this turf.',
                ], 403);
            }

            if ($validated['booking_type'] === 'sport') {
                $exists = $turf->sports()->where('sports.id', $validated['booking_type_id'])->exists();
                if (!$exists) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Selected sport is not available for this turf.',
                    ], 422);
                }
            } elseif ($validated['booking_type'] === 'event') {
                $exists = $turf->events()->where('events.id', $validated['booking_type_id'])->exists();
                if (!$exists) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Selected event is not available for this turf.',
                    ], 422);
                }
            }

            /*
            |--------------------------------------------------------------------------
            | Validate Turf Operating Hours
            |--------------------------------------------------------------------------
            */
            $turfOpeningTime = Carbon::parse($turf->opening_time);
            $turfClosingTime = Carbon::parse($turf->closing_time);

            $requestOpeningTime = Carbon::createFromFormat('H:i', $validated['opening_time']);
            $requestClosingTime = Carbon::createFromFormat('H:i', $validated['closing_time']);

            if ($requestOpeningTime->lt($turfOpeningTime) || $requestClosingTime->gt($turfClosingTime)) {
                return response()->json([
                    'success' => false,
                    'message' => "Slot generation time must be between {$turfOpeningTime->format('h:i A')} and {$turfClosingTime->format('h:i A')}.",
                ], 422);
            }

            $savedSlots = [];

            /*
            |--------------------------------------------------------------------------
            | Generate Slots For Each Selected Day
            |--------------------------------------------------------------------------
            */
            foreach ($validated['days'] as $day) {

                $currentTime = Carbon::createFromFormat('H:i', $validated['opening_time']);
                $closingTime = Carbon::createFromFormat('H:i', $validated['closing_time']);

                while ($currentTime < $closingTime) {

                    $slotStart = $currentTime->copy();
                    $slotEnd = $currentTime->copy()->addMinutes($validated['slot_duration']);

                    if ($slotEnd > $closingTime) {
                        break;
                    }

                    $duplicate = SlotMaster::where('turf_id', $validated['turf_id'])
                        ->where('booking_type', $validated['booking_type'])
                        ->where('booking_type_id', $validated['booking_type_id'])
                        ->where('day', strtolower($day))
                        ->where('start_time', $slotStart->format('H:i:s'))
                        ->where('end_time', $slotEnd->format('H:i:s'))
                        ->exists();

                    if (!$duplicate) {
                        $savedSlots[] = SlotMaster::create([
                            'turf_id'         => $validated['turf_id'],
                            'booking_type'    => $validated['booking_type'],
                            'booking_type_id' => $validated['booking_type_id'],
                            'day'             => strtolower($day),
                            'start_time'      => $slotStart->format('H:i:s'),
                            'end_time'        => $slotEnd->format('H:i:s'),
                            'price'           => $validated['price'],
                            'status'          => true,
                        ]);
                    }

                    $currentTime->addMinutes($validated['slot_duration']);
                }
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Slots generated successfully.',
                'data' => $savedSlots,
            ]);

        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    public function dropdownData(Request $request): JsonResponse
    {
        $turfs = Turf::where('owner_id', $request->user()->id)
            ->where('status', true)
            ->select('id', 'name')
            ->get();

        $days = [
            'monday',
            'tuesday',
            'wednesday',
            'thursday',
            'friday',
            'saturday',
            'sunday'
        ];

        return response()->json([
            'success' => true,
            'message' => 'Dropdown data fetched successfully.',
            'data' => [
                'turfs' => $turfs,
                'days' => $days,
            ]
        ]);
    }


    public function turfDetails(Turf $turf, Request $request): JsonResponse
    {
        if ($turf->owner_id != $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Turf not found or unauthorized.',
            ], 404);
        }

        $turf->load(['sports:id,name', 'events:id,name']);

        return response()->json([
            'success' => true,
            'message' => 'Turf details fetched successfully.',
            'data' => [
                'sports' => $turf->sports,
                'events' => $turf->events,
                'opening_time' => Carbon::parse($turf->opening_time)->format('H:i'),
                'closing_time' => Carbon::parse($turf->closing_time)->format('H:i'),
            ]
        ]);
    }

    

}