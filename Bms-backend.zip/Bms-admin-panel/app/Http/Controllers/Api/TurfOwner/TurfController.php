<?php

namespace App\Http\Controllers\Api\TurfOwner;

use App\Http\Controllers\Controller;
use App\Models\Turf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use App\Http\Requests\TurfOwner\StoreTurfRequest;
use App\Models\TurfImage;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\TurfOwner\UpdateTurfRequest;
use App\Mail\WelcomeEmail;
use Illuminate\Support\Facades\Mail;

class TurfController extends Controller
{


    public function store(StoreTurfRequest $request)
    {
        $validated = $request->validated();

        // Prevent duplicate turf for the same owner at the same address
        $exists = Turf::where('owner_id', $request->user()->id)
            ->where('name', trim($validated['name']))
            ->where('address', trim($validated['address']))
            ->exists();

        if ($exists) {
            return response()->json([
                'success' => false,
                'message' => 'A turf with the same name already exists at this address.',
            ], 422);
        }

        $turf = DB::transaction(function () use ($request, $validated) {

            $coverImage = null;

            if ($request->hasFile('cover_image')) {
                $coverImage = $request->file('cover_image')
                    ->store('turfs/cover', 'public');
            }

            $turf = Turf::create([
                'owner_id' => $request->user()->id,
                'name' => $validated['name'],
                'slug' => Str::slug($validated['name']) . '-' . Str::lower(Str::random(6)),
                'description' => $validated['description'] ?? null,
                'cover_image' => $coverImage,
                'contact_number' => $validated['contact_number'],
                'email' => $validated['email'] ?? null,
                'address' => $validated['address'],
                'area' => $validated['area'] ?? null,
                'landmark' => $validated['landmark'] ?? null,
                'country_id' => $validated['country_id'],
                'state_id' => $validated['state_id'],
                'city_id' => $validated['city_id'],
                'pincode' => $validated['pincode'],
                'latitude' => $validated['latitude'] ?? null,
                'longitude' => $validated['longitude'] ?? null,
                'opening_time' => $validated['opening_time'],
                'closing_time' => $validated['closing_time'],
                'ground_type' => $validated['ground_type'],
                'status' => true,
                'approval_status' => 'pending',
                'is_featured' => false,
                'average_rating' => 0,
                'total_reviews' => 0,
            ]);

            $turf->sports()->sync($validated['sport_ids']);

            $turf->amenities()->sync($validated['amenity_ids'] ?? []);

            $turf->events()->sync($validated['event_ids'] ?? []);

            if ($request->hasFile('gallery_images')) {

                foreach ($request->file('gallery_images') as $index => $image) {

                    $path = $image->store('turfs/gallery', 'public');

                    TurfImage::create([
                        'turf_id' => $turf->id,
                        'image' => $path,
                        'sort_order' => $index + 1,
                    ]);
                }
            }

            return $turf;
        });

        $turf->load([
            'country',
            'state',
            'city',
            'sports',
            'amenities',
            'events',
            'images',
        ]);


      Mail::to($turf->email)->send(
    new WelcomeEmail($turf->name, 'turf_owner')
);
        return response()->json([
            'success' => true,
            'message' => 'Turf created successfully.',
            'data' => $turf,
        ], 201);
    }

    public function index(Request $request)
    {
        $perPage = $request->input('per_page', 10);

        $allowedSortBy = [
            'name',
            'created_at',
            'status',
            'approval_status',
        ];

        $sortBy = in_array($request->sort_by, $allowedSortBy)
            ? $request->sort_by
            : 'created_at';

        $sortOrder = strtolower($request->sort_order) === 'asc'
            ? 'asc'
            : 'desc';

        $turfs = Turf::query()

            ->where('owner_id', $request->user()->id)

            ->with([
                'country:id,name',
                'state:id,name',
                'city:id,name',
                'sports:id,name,selected_icon,unselected_icon',
                'amenities:id,name,icon',
                'events:id,name,selected_icon,unselected_icon',
                'images:id,turf_id,image,sort_order',
            ])

            ->when($request->filled('search'), function ($query) use ($request) {

                $query->where(function ($q) use ($request) {

                    $q->where('name', 'like', '%' . $request->search . '%')
                        ->orWhere('contact_number', 'like', '%' . $request->search . '%')
                        ->orWhere('address', 'like', '%' . $request->search . '%');

                });

            })

            ->when($request->filled('approval_status'), function ($query) use ($request) {

                $query->where('approval_status', $request->approval_status);

            })

            ->when($request->filled('status'), function ($query) use ($request) {

                $query->where('status', $request->status);

            })

            ->when($request->filled('city_id'), function ($query) use ($request) {

                $query->where('city_id', $request->city_id);

            })

            ->when($request->filled('sport_id'), function ($query) use ($request) {

                $query->whereHas('sports', function ($q) use ($request) {

                    $q->where('sports.id', $request->sport_id);

                });

            })

            ->when($request->filled('event_id'), function ($query) use ($request) {

                $query->whereHas('events', function ($q) use ($request) {

                    $q->where('events.id', $request->event_id);

                });

            })

            ->orderBy($sortBy, $sortOrder)

            ->paginate($perPage);

        return response()->json([

            'success' => true,

            'message' => 'Turfs fetched successfully.',

            'data' => $turfs->items(),

            'pagination' => [

                'current_page' => $turfs->currentPage(),

                'last_page' => $turfs->lastPage(),

                'per_page' => $turfs->perPage(),

                'total' => $turfs->total(),

                'from' => $turfs->firstItem(),

                'to' => $turfs->lastItem(),

            ],

        ]);
    }
    
    public function show(Request $request, Turf $turf)
    {
        if ($turf->owner_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized.',
            ], 403);
        }

        $turf->load([
            'country:id,name',
            'state:id,name',
            'city:id,name',
            'sports:id,name,selected_icon,unselected_icon',
            'amenities:id,name,icon',
            'events:id,name,selected_icon,unselected_icon',
            'images:id,turf_id,image,sort_order',
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Turf details fetched successfully.',
            'data' => $turf,
        ]);
    }

    public function update(UpdateTurfRequest $request, Turf $turf)
    {
        // Check ownership
        if ($turf->owner_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized.',
            ], 403);
        }

        $validated = $request->validated();

        // Prevent duplicate turf with same name & address
        $exists = Turf::where('owner_id', $request->user()->id)
            ->where('name', trim($validated['name']))
            ->where('address', trim($validated['address']))
            ->where('id', '!=', $turf->id)
            ->exists();

        if ($exists) {
            return response()->json([
                'success' => false,
                'message' => 'A turf with the same name already exists at this address.',
            ], 422);
        }

        DB::transaction(function () use ($request, $validated, $turf) {

            /*
            |--------------------------------------------------------------------------
            | Cover Image
            |--------------------------------------------------------------------------
            */
            $coverImage = $turf->getRawOriginal('cover_image');

            if ($request->hasFile('cover_image')) {

                if ($coverImage && Storage::disk('public')->exists($coverImage)) {
                    Storage::disk('public')->delete($coverImage);
                }

                $coverImage = $request->file('cover_image')
                    ->store('turfs/cover', 'public');
            }

            /*
            |--------------------------------------------------------------------------
            | Update Turf
            |--------------------------------------------------------------------------
            */
            $turf->update([
                'name' => $validated['name'],
                'description' => $validated['description'] ?? null,
                'cover_image' => $coverImage,
                'contact_number' => $validated['contact_number'],
                'email' => $validated['email'] ?? null,
                'address' => $validated['address'],
                'area' => $validated['area'] ?? null,
                'landmark' => $validated['landmark'] ?? null,
                'country_id' => $validated['country_id'],
                'state_id' => $validated['state_id'],
                'city_id' => $validated['city_id'],
                'pincode' => $validated['pincode'],
                'latitude' => $validated['latitude'] ?? null,
                'longitude' => $validated['longitude'] ?? null,
                'opening_time' => $validated['opening_time'],
                'closing_time' => $validated['closing_time'],
                'ground_type' => $validated['ground_type'],
            ]);

            /*
            |--------------------------------------------------------------------------
            | Sync Sports
            |--------------------------------------------------------------------------
            */
            $turf->sports()->sync($validated['sport_ids']);

            /*
            |--------------------------------------------------------------------------
            | Sync Amenities
            |--------------------------------------------------------------------------
            */
            $turf->amenities()->sync($validated['amenity_ids'] ?? []);

            /*
            |--------------------------------------------------------------------------
            | Sync Events
            |--------------------------------------------------------------------------
            */

            $turf->events()->sync($validated['event_ids'] ?? []);

            /*
            |--------------------------------------------------------------------------
            | Remove Selected Gallery Images
            |--------------------------------------------------------------------------
            */

            if ($request->filled('remove_gallery_image_ids')) {

                $images = TurfImage::where('turf_id', $turf->id)
                    ->whereIn('id', $request->remove_gallery_image_ids)
                    ->get();

                foreach ($images as $image) {

                    if (Storage::disk('public')->exists($image->image)) {
                        Storage::disk('public')->delete($image->image);
                    }

                    $image->delete();
                }
            }


            /*
            |--------------------------------------------------------------------------
            | Add New Gallery Images
            |--------------------------------------------------------------------------
            */

            if ($request->hasFile('gallery_images')) {

                $lastSortOrder = TurfImage::where('turf_id', $turf->id)
                    ->max('sort_order') ?? 0;

                foreach ($request->file('gallery_images') as $image) {

                    $path = $image->store('turfs/gallery', 'public');

                    TurfImage::create([
                        'turf_id' => $turf->id,
                        'image' => $path,
                        'sort_order' => ++$lastSortOrder,
                    ]);
                }
            }

        });

        $turf->load([
            'country',
            'state',
            'city',
            'sports',
            'amenities',
            'events',
            'images',
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Turf updated successfully.',
            'data' => $turf,
        ]);
    }

    public function destroy(Turf $turf)
{
      $turf = Turf::find($turf->id);

    if (!$turf) {
        return response()->json([
            'success' => false,
            'message' => 'Turf not found.',
        ], 404);
    }
 
    $hasUpcomingBookings = \App\Models\Booking::where('turf_id', $turf->id)
        ->where('booking_status', 'confirmed')
        ->where(function ($query) {
            $query->whereDate('booking_date', '>', now()->toDateString())
                ->orWhereDate('booking_date', now()->toDateString());
            // Same-day bookings are included too, whether they've
            // technically started or not — safer to just block and let
            // the owner wait a day than accidentally orphan a booking
            // that's about to happen.
        })
        ->exists();
 
    if ($hasUpcomingBookings) {
        return response()->json([
            'success' => false,
            'message' => 'This turf has upcoming confirmed bookings. Please wait until they are completed, or contact support, before deleting this turf.',
        ], 422);
    }
 
    $turf->delete(); // soft delete — the row and its booking history stay intact
 
    return response()->json([
        'success' => true,
        'message' => 'Turf deleted successfully.',
    ]);
}


}
