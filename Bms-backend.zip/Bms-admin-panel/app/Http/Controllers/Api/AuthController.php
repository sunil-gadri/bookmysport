<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use App\Models\OtpVerification;

class AuthController extends Controller
{

    public function adminLogin(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        $user = User::where('email', $request->email)->first();

        if (!$user) {
            return response()->json([
                'status' => false,
                'message' => 'User not found',
            ], 404);
        }


        $loginRole = $user->roles()
            ->where('slug', 'admin')
            ->first();
            


         if (!$loginRole) {
            return response()->json([
                'status' => false,
                'message' => 'Unauthorized access',
            ], 403);
        }

        if (!Hash::check($request->password, $user->password)) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid password',
            ], 401);
        }

        $token = $user->createToken('admin-token', ['admin'])->plainTextToken;

        

        return response()->json([
            'status' => true,
            'message' => 'Login successful',
            'token' => $token,
            'login_role' => $loginRole->slug,
            'is_profile_completed' => true,
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'mobile' => $user->mobile,
                'status' => $user->status,
                'created_at' => $user->created_at,
                'updated_at' => $user->updated_at,
            ],
        ]);
    }

    public function profile(Request $request)
    {
        return response()->json([
            'status' => true,
            'user' => $request->user()->load('roles'),
        ]);
    }

    public function sendOtp(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'mobile' => 'required|digits:10',
            'role_id' => 'required|exists:roles,id',
        ]);

        $otp = "123456"; //rand(100000, 999999);

        OtpVerification::updateOrCreate(
            [
                'mobile' => $request->mobile
            ],
            [
                'name' => $request->name,
                'role_id' => $request->role_id,
                'otp' => $otp,
                'expires_at' => now()->addMinutes(1),
                'is_verified' => false,
            ]
        );

        return response()->json([
            'status' => true,
            'message' => 'OTP sent successfully',
           // 'otp' => $otp, 
        ]);
    }

    public function verifyOtp(Request $request)
    {
        $request->validate([
            'mobile' => 'required|digits:10',
            'otp' => 'required|digits:6',
        ]);

        // Find valid OTP
        $otpRecord = OtpVerification::where('mobile', $request->mobile)
            ->where('otp', $request->otp)
            ->where('expires_at', '>', now())
            ->first();

        if (!$otpRecord) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid or expired OTP'
            ], 400);
        }

        // Find existing user
        $user = User::where('mobile', $request->mobile)->first();

        // Create user if not exists
        if (!$user) {
            $user = User::create([
                'name' => $otpRecord->name,
                'mobile' => $otpRecord->mobile,
                'status' => true,
            ]);
        }

        // Attach requested role without removing existing roles
        $user->roles()->syncWithoutDetaching([
            $otpRecord->role_id
        ]);

        // Get the role used for this login
        $loginRole = $user->roles()
            ->where('roles.id', $otpRecord->role_id)
            ->first();

        // Check profile completion based on the current login role
        
        $isProfileCompleted = false;

        if ($loginRole) {
            if ($loginRole->slug === 'turf_owner') {
                $isProfileCompleted = $user->turfOwnerProfile()->exists();
            } elseif ($loginRole->slug === 'user') {
                $isProfileCompleted = $user->profile()->exists();
            }
        }

        // Mark OTP as verified
        $otpRecord->update([
            'is_verified' => true   
        ]);

        // Create token
        $token = $user->createToken('auth-token',[$loginRole->slug])->plainTextToken;

        return response()->json([
            'status' => true,
            'message' => 'Login successful',
            'token' => $token,
            'login_role' => $loginRole->slug,
            'is_profile_completed' => $isProfileCompleted,
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'mobile' => $user->mobile,  
                'status' => $user->status,
                'created_at' => $user->created_at,
                'updated_at' => $user->updated_at,
            ],
            'role' => [
                'id' => $loginRole->id,
                'name' => $loginRole->name,
                'slug' => $loginRole->slug,
            ]
        ]);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'status' => true,
            'message' => 'Logged out successfully'
        ]);
    }
    
}
