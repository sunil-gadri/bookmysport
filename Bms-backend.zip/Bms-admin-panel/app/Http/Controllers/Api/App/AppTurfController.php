<?php

namespace App\Http\Controllers\Api\App;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Turf;
use App\Http\Requests\App\TurfListRequest;
use App\Http\Requests\App\AppSlotRequest;
use Carbon\Carbon;
use App\Models\UserFavouriteTurf;
use App\Http\Resources\App\AppSlotResource;
use App\Models\BookingItem;

class AppTurfController extends Controller
{

    /*** Turf List API */

    public function index(TurfListRequest $request)
    {
        $validated = $request->validated();

        $perPage = $validated['per_page'] ?? 10;

        $sortBy = $validated['sort_by'] ?? 'created_at';

        $sortOrder = $validated['sort_order'] ?? 'desc';

        $latitude = $validated['latitude'] ?? null;
        $longitude = $validated['longitude'] ?? null;

        $hasLocation = !empty($latitude) && !empty($longitude);

        $turfs = Turf::query()
            ->when($hasLocation, function ($query) use ($latitude, $longitude) {
                $query->withDistance($latitude, $longitude);
            })

            ->where('status', true)
            ->where('approval_status', 'approved')

            ->with([
                'city:id,name',
                'sports:id,name',
                'events:id,name',
                'amenities:id,name,icon',
                'images:id,turf_id,image,sort_order',
            ])

            ->when(!empty($validated['search']), function ($query) use ($validated) {

                $search = $validated['search'];

                $query->where(function ($q) use ($search) {

                    $q->where('name', 'LIKE', "%{$search}%")
                        ->orWhere('address', 'LIKE', "%{$search}%")

                        ->orWhereHas('sports', function ($sportQuery) use ($search) {
                            $sportQuery->where('name', 'LIKE', "%{$search}%");
                        })

                        ->orWhereHas('events', function ($eventQuery) use ($search) {
                            $eventQuery->where('name', 'LIKE', "%{$search}%");
                        })

                        ->orWhereHas('amenities', function ($amenityQuery) use ($search) {
                            $amenityQuery->where('name', 'LIKE', "%{$search}%");
                        });
                });
            })

            ->when(!empty($validated['sport_id']), function ($query) use ($validated) {

                $sportIds = array_map('intval', explode(',', $validated['sport_id']));

                $query->whereHas('sports', function ($q) use ($sportIds) {

                    $q->whereIn('sports.id', $sportIds);
                });
            })

            ->when(!empty($validated['event_id']), function ($query) use ($validated) {

                $eventIds = array_map('intval', explode(',', $validated['event_id']));

                $query->whereHas('events', function ($q) use ($eventIds) {

                    $q->whereIn('events.id', $eventIds);
                });
            })

            ->when(!empty($validated['amenity_id']), function ($query) use ($validated) {

                $amenityIds = array_map('intval', explode(',', $validated['amenity_id']));

                $query->whereHas('amenities', function ($q) use ($amenityIds) {

                    $q->whereIn('amenities.id', $amenityIds);
                });
            })

            ->when(isset($validated['city_id']), function ($query) use ($validated) {

                $query->where('city_id', $validated['city_id']);
            })

            ->orderBy($sortBy, $sortOrder)

            ->paginate($perPage);

        $data = $turfs->getCollection()->map(function ($turf) {

            $coverImage = null;

            if ($turf->cover_image) {

                $coverImage = filter_var($turf->cover_image, FILTER_VALIDATE_URL)
                    ? $turf->cover_image
                    : asset('storage/' . $turf->cover_image);
            } elseif ($turf->images->isNotEmpty()) {

                $coverImage = asset('storage/' . $turf->images->first()->image);
            }

            $currentTime = Carbon::now();

            $openingTime = Carbon::parse($turf->opening_time);

            $closingTime = Carbon::parse($turf->closing_time);

            if ($openingTime->lessThan($closingTime)) {

                $isOpen = $currentTime->between(
                    $openingTime,
                    $closingTime
                );
            } else {

                $isOpen =
                    $currentTime->greaterThanOrEqualTo($openingTime)
                    ||
                    $currentTime->lessThanOrEqualTo($closingTime);
            }


            return [

                'id' => $turf->id,

                'name' => $turf->name,

                'cover_image' => $coverImage,

                'city' => $turf->city?->name,

                'address' => $turf->address,

                'distance' => isset($turf->distance)
                    ? round($turf->distance, 2)
                    : null,

                'area' => $turf->area,
                'sports' => $turf->sports->map(function ($sport) {

                    return [
                        'id' => $sport->id,
                        'name' => $sport->name,
                    ];
                }),

                'events' => $turf->events->map(function ($event) {

                    return [

                        'id' => $event->id,

                        'name' => $event->name,

                    ];
                }),

                'average_rating' => (float) $turf->average_rating,

                'total_reviews' => $turf->total_reviews,

                'opening_time' => $openingTime->format('h:i A'),

                'closing_time' => $closingTime->format('h:i A'),

                'is_open' => $isOpen,

            ];
        });

        return response()->json([

            'success' => true,

            'message' => 'Turfs fetched successfully.',

            'data' => $data,

            'pagination' => [

                'current_page' => $turfs->currentPage(),

                'last_page' => $turfs->lastPage(),

                'per_page' => $turfs->perPage(),

                'total' => $turfs->total(),

                'from' => $turfs->firstItem(),

                'to' => $turfs->lastItem(),

            ],

        ]);
    }


    public function show(Request $request, Turf $turf)
    {
        // Only approved and active turfs should be visible

        $latitude = $request->input('latitude');
        $longitude = $request->input('longitude');

        $hasLocation = $request->filled('latitude') &&
            $request->filled('longitude');

        if (!$turf->status || $turf->approval_status !== 'approved') {
            return response()->json([
                'success' => false,
                'message' => 'Turf not found.',
            ], 404);
        }

        if ($hasLocation) {

            $turf = Turf::query()
                ->withDistance($latitude, $longitude)
                ->whereKey($turf->id)
                ->where('status', true)
                ->where('approval_status', 'approved')
                ->firstOrFail();
        }

        $turf->load([
            'country:id,name',
            'state:id,name',
            'city:id,name',
            'sports:id,name,selected_icon,unselected_icon',
            'events:id,name,selected_icon,unselected_icon',
            'amenities:id,name,icon',
            'images:id,turf_id,image,sort_order',
        ]);

        $currentTime = Carbon::now();

        $openingTime = Carbon::parse($turf->opening_time);

        $closingTime = Carbon::parse($turf->closing_time);

        if ($openingTime->lessThan($closingTime)) {

            $isOpen = $currentTime->between(
                $openingTime,
                $closingTime
            );
        } else {

            $isOpen =
                $currentTime->greaterThanOrEqualTo($openingTime)
                ||
                $currentTime->lessThanOrEqualTo($closingTime);
        }
        $coverImage = null;

        if ($turf->cover_image) {

            $coverImage = filter_var($turf->cover_image, FILTER_VALIDATE_URL)
                ? $turf->cover_image
                : asset('storage/' . $turf->cover_image);
        } elseif ($turf->images->isNotEmpty()) {

            $coverImage = filter_var($turf->images->first()->image, FILTER_VALIDATE_URL)
                ? $turf->images->first()->image
                : asset('storage/' . $turf->images->first()->image);
        }

        $user = $request->user();

        $isFavourite = false;

        if ($user) {
            $isFavourite = UserFavouriteTurf::where('user_id', $user->id)
                ->where('turf_id', $turf->id)
                ->exists();
        }


        $data = [

            'id' => $turf->id,

            'name' => $turf->name,

            'description' => $turf->description,

            'cover_image' => $coverImage,

            'contact_number' => $turf->contact_number,

            'email' => $turf->email,

            'address' => $turf->address,

            'area' => $turf->area,

            'landmark' => $turf->landmark,

            'country' => $turf->country?->name,

            'state' => $turf->state?->name,

            'city' => $turf->city?->name,

            'pincode' => $turf->pincode,

            'latitude' => $turf->latitude,

            'longitude' => $turf->longitude,

            'opening_time' => $openingTime->format('h:i A'),

            'closing_time' => $closingTime->format('h:i A'),

            'distance' => $turf->distance !== null
                ? round($turf->distance, 2)
                : null,

            'is_open' => $isOpen,

            'average_rating' => (float) $turf->average_rating,

            'total_reviews' => $turf->total_reviews,

            'is_favourite' => $isFavourite,

            'sports' => $turf->sports->map(function ($sport) {

                return [

                    'id' => $sport->id,

                    'name' => $sport->name,

                    'selected_icon' => $sport->selected_icon
                        ? asset('storage/' . $sport->selected_icon)
                        : null,

                    'unselected_icon' => $sport->unselected_icon
                        ? asset('storage/' . $sport->unselected_icon)
                        : null,

                ];
            }),

            'events' => $turf->events->map(function ($event) {

                return [

                    'id' => $event->id,

                    'name' => $event->name,

                    'selected_icon' => $event->selected_icon
                        ? asset('storage/' . $event->selected_icon)
                        : null,

                    'unselected_icon' => $event->unselected_icon
                        ? asset('storage/' . $event->unselected_icon)
                        : null,

                ];
            }),

            'amenities' => $turf->amenities->map(function ($amenity) {

                return [

                    'id' => $amenity->id,

                    'name' => $amenity->name,

                    'icon' => $amenity->icon
                        ? asset('storage/' . $amenity->icon)
                        : null,

                ];
            }),

            'gallery_images' => $turf->images->map(function ($image) {

                return [

                    'id' => $image->id,

                    'image' => filter_var($image->image, FILTER_VALIDATE_URL)
                        ? $image->image
                        : asset('storage/' . $image->image),

                    'sort_order' => $image->sort_order,

                ];
            }),

        ];

        return response()->json([
            'success' => true,
            'message' => 'Turf details fetched successfully.',
            'data' => $data,
        ]);
    }


    public function slots(AppSlotRequest $request, $turfId)
    {
        // Check Turf Exists
        $turf = Turf::find($turfId);

        if (
            !$turf ||
            !$turf->status ||
            $turf->approval_status !== 'approved'
        ) {

            return response()->json([
                'status' => false,
                'message' => 'Turf not found.'
            ], 404);
        }

        $selectedDate = $request->date;
        $day = strtolower(
            Carbon::parse($selectedDate)->format('l')
        );


        /*
        |--------------------------------------------------------------------------
        | Check Selected Booking belongs to Turf
        |--------------------------------------------------------------------------
        */

        if ($request->booking_type == 'sport') {

            $exists = $turf->sports()
                ->where('sports.id', $request->booking_type_id)
                ->exists();

            if (!$exists) {
                return response()->json([
                    'status' => false,
                    'message' => 'Selected sport is not available for this turf.'
                ], 404);
            }
        } elseif ($request->booking_type == 'event') {

            $exists = $turf->events()
                ->where('events.id', $request->booking_type_id)
                ->exists();

            if (!$exists) {
                return response()->json([
                    'status' => false,
                    'message' => 'Selected event is not available for this turf.'
                ], 404);
            }
        } else {

            return response()->json([
                'status' => false,
                'message' => 'Invalid booking type.'
            ], 422);
        }

        /*
        |--------------------------------------------------------------------------
        | Get Slots
        |--------------------------------------------------------------------------
        */

        $slots = $turf->slotMasters()
            ->where('status', true)
            ->where('day', $day)
            ->where('booking_type', $request->booking_type)
            ->where('booking_type_id', $request->booking_type_id)
            ->orderBy('start_time')
            ->get();


        $bookedSlotIds = BookingItem::query()
            ->whereHas('booking', function ($query) use ($request, $turfId) {

                $query->where('turf_id', $turfId)
                    ->whereDate('booking_date', $request->date)
                    ->whereIn('booking_status', [
                        'pending',
                        'confirmed',
                        'completed',
                    ]);
            })
            ->pluck('slot_master_id')
            ->toArray();

        // Anyone (including other users) currently holding this slot
        // in their cart, within the 10-minute window, also blocks it.
        $heldSlotIds = \App\Models\CartItemSlot::query()
            ->whereHas('cartItem', function ($query) use ($request) {

                $query->whereDate('booking_date', $request->date)
                    ->where('expires_at', '>', now());
            })
            ->pluck('slot_master_id')
            ->toArray();

        $bookedSlotIds = array_unique(array_merge($bookedSlotIds, $heldSlotIds));


        $currentTime = Carbon::now()->format('H:i:s');

        if ($slots->isEmpty()) {

            return response()->json([
                'status' => false,
                'message' => 'No slots available for the selected date.'
            ], 404);
        }

        $slots->transform(function ($slot) use (
            $bookedSlotIds,
            $selectedDate,
            $currentTime
        ) {

            $slot->is_available = ! in_array(
                $slot->id,
                $bookedSlotIds
            );

            if (Carbon::parse($selectedDate)->isToday()) {

                $slot->is_available =
                    $slot->is_available &&
                    $slot->start_time > $currentTime;
            }

            return $slot;
        });

        return response()->json([
            'status' => true,
            'message' => 'Slots fetched successfully.',
            'date' => $selectedDate,
            'day' => $day,
            'booking_type' => $request->booking_type,
            'booking_type_id' => $request->booking_type_id,
            'data' => AppSlotResource::collection($slots),
        ]);
    }
}
