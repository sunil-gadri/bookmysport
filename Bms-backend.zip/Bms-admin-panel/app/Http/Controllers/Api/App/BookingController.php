<?php

namespace App\Http\Controllers\Api\App;

use App\Http\Controllers\Controller;
use App\Http\Requests\App\StoreBookingRequest;
use App\Http\Requests\App\RescheduleBookingRequest;
use App\Models\Booking;
use App\Models\BookingItem;
use App\Models\SlotMaster;
use Illuminate\Support\Facades\DB;
use App\Http\Resources\App\BookingResource;
use Illuminate\Http\Request;
use App\Http\Resources\App\BookingListResource;
use Carbon\Carbon;


class BookingController extends Controller
{
    /**
     * Create Booking
     */

    public function store(StoreBookingRequest $request)
    {
        DB::beginTransaction();

        try {

            $data = $request->validated();

            $slots = SlotMaster::query()
                ->whereIn('id', $data['slot_ids'])
                ->lockForUpdate()
                ->get();

            // Guard against a mismatched/stale turf_id: every selected slot
            // must actually belong to the turf_id sent in the request.
            // Without this, a booking could get saved against the wrong
            // turf, which later breaks the turf owner's check-in (they'd
            // see "This booking is not for one of your turfs.") because
            // the real slot owner never matches booking->turf->owner_id.
            $mismatchedSlot = $slots->first(
                fn ($slot) => (int) $slot->turf_id !== (int) $data['turf_id']
            );

            if ($mismatchedSlot) {

                DB::rollBack();

                return response()->json([
                    'success' => false,
                    'message' => 'One or more selected slots do not belong to the selected turf.',
                ], 422);
            }

            $alreadyBooked = BookingItem::query()
                ->whereIn('slot_master_id', $data['slot_ids'])
                ->whereHas('booking', function ($query) use ($data) {

                    $query->whereDate('booking_date', $data['booking_date'])
                        ->whereIn('booking_status', [
                            'pending',
                            'confirmed',
                            'completed',
                        ]);

                })
                ->exists();

            if ($alreadyBooked) {

                DB::rollBack();

                return response()->json([
                    'success' => false,
                    'message' => 'One or more selected slots have just been booked by another user. Please refresh and try again.'
                ], 422);
            }

            $totalAmount = $slots->sum('price');

            $booking = Booking::create([

                'booking_number' => '',

                'user_id' => $request->user()->id,
                
                'turf_id' => $data['turf_id'],

                'booking_type' => $data['booking_type'],

                'booking_type_id' => $data['booking_type_id'],

                'booking_date' => $data['booking_date'],

                'total_amount' => $totalAmount,

                'booking_status' => 'pending',

                'payment_status' => 'pending',

            ]);

            $booking->booking_number = 'BMS' . str_pad(
                $booking->id,
                6,
                '0',
                STR_PAD_LEFT
            );

            $booking->save();

            $items = [];

            foreach ($slots as $slot) {

                $items[] = [

                    'booking_id' => $booking->id,

                    'slot_master_id' => $slot->id,

                    'price' => $slot->price,

                    'created_at' => now(),

                    'updated_at' => now(),

                ];

            }

            BookingItem::insert($items);

            DB::commit();

            return response()->json([

                'success' => true,

                'message' => 'Booking created successfully.',

                'data' => [

                    'booking_id' => $booking->id,

                    'booking_number' => $booking->booking_number,

                    'booking_date' => $booking->booking_date->toDateString(),

                    'turf_id' => $booking->turf_id,

                    'booking_type' => $booking->booking_type,

                    'booking_type_id' => $booking->booking_type_id,

                    'total_amount' => $booking->total_amount,

                    'booking_status' => $booking->booking_status,

                    'payment_status' => $booking->payment_status,

                ],

            ], 201);

        } catch (\Throwable $e) {

            DB::rollBack();

            report($e);

            return response()->json([
                'success' => false,
                'message' => 'Something went wrong. Please try again.'
            ], 500);

        }
    }


    public function show(Request $request, Booking $booking)
    {
          if ($booking->user_id != $request->user()->id) {
        return response()->json([
            'success' => false,
            'message' => 'Booking not found.'
        ], 404);
    }


        $booking->load([

            'turf',

            'turf.sports',

            'turf.events',

            'bookingItems.slotMaster',

        ]);

        return response()->json([

            'success' => true,

            'message' => 'Booking details fetched successfully.',

            'data' => new BookingResource($booking),

        ]);
    }

    public function index(Request $request)
    {
        $query = Booking::query()
    ->where('user_id', $request->user()->id)
    ->with([

                'turf',

                'turf.sports',

                'turf.events',

                'bookingItems.slotMaster',

            ]);

        /*
        |--------------------------------------------------------------------------
        | Filter: Upcoming vs Completed (for the app's two tabs)
        |--------------------------------------------------------------------------
        |
        | Upcoming = confirmed AND the last slot hasn't ended yet.
        | Completed = everything else that isn't upcoming (played bookings,
        | cancelled bookings, and — once the scheduled job runs — bookings
        | explicitly marked booking_status = 'completed').
        */

        if ($request->filled('type')) {

            $today = now()->toDateString();
            $currentTime = now()->format('H:i:s');

            $isStillUpcoming = function ($q) use ($today, $currentTime) {
                $q->whereDate('booking_date', '>', $today)
                    ->orWhere(function ($q2) use ($today, $currentTime) {
                        $q2->whereDate('booking_date', $today)
                            ->whereHas('bookingItems.slotMaster', function ($q3) use ($currentTime) {
                                $q3->where('end_time', '>', $currentTime);
                            });
                    });
            };

            if ($request->type === 'upcoming') {

                $query->where('booking_status', 'confirmed')
                    ->where($isStillUpcoming);

            } elseif ($request->type === 'completed') {

                $query->where(function ($q) use ($isStillUpcoming) {
                    $q->where('booking_status', '!=', 'confirmed')
                        ->orWhere(function ($q2) use ($isStillUpcoming) {
                            $q2->where('booking_status', 'confirmed')
                                ->whereNot($isStillUpcoming);
                        });
                });

            }
        }

        /*
        |--------------------------------------------------------------------------
        | Filter Booking Status
        |--------------------------------------------------------------------------
        */

        if ($request->filled('booking_status')) {

            $query->where(
                'booking_status',
                $request->booking_status
            );

        }

        /*
        |--------------------------------------------------------------------------
        | Filter Payment Status
        |--------------------------------------------------------------------------
        */

        if ($request->filled('payment_status')) {

            $query->where(
                'payment_status',
                $request->payment_status
            );

        }

        /*
        |--------------------------------------------------------------------------
        | Sort Latest Booking First
        |--------------------------------------------------------------------------
        */

        $bookings = $query

            ->latest()

            ->paginate(
                $request->per_page ?? 10
            );

        return response()->json([

            'success' => true,

            'message' => 'Bookings fetched successfully.',

            'data' => BookingListResource::collection(
                $bookings->items()
            ),

            'pagination' => [

                'current_page' => $bookings->currentPage(),

                'last_page' => $bookings->lastPage(),

                'per_page' => $bookings->perPage(),

                'total' => $bookings->total(),

                'from' => $bookings->firstItem(),

                'to' => $bookings->lastItem(),

            ],

        ]);
    }


    /**
     * Cancel Booking
     */
    public function cancel(Request $request, Booking $booking)
    {
        /*
        |--------------------------------------------------------------------------
        | Check Booking Owner
        |--------------------------------------------------------------------------
        */

          if ($booking->user_id !== $request->user()->id) {
        return response()->json([
            'success' => false,
            'message' => 'Booking not found.',
        ], 404);
    }

        /*
        |--------------------------------------------------------------------------
        | Already Cancelled
        |--------------------------------------------------------------------------
        */

        if ($booking->booking_status === 'cancelled') {

            return response()->json([
                'success' => false,
                'message' => 'Booking is already cancelled.',
            ], 422);
        }

        /*
        |--------------------------------------------------------------------------
        | Already Completed
        |--------------------------------------------------------------------------
        */

        if ($booking->booking_status === 'completed') {

            return response()->json([
                'success' => false,
                'message' => 'Completed bookings cannot be cancelled.',
            ], 422);
        }

        /*
        |--------------------------------------------------------------------------
        | Get First Slot
        |--------------------------------------------------------------------------
        */

        $firstSlot = $booking->bookingItems()
            ->with('slotMaster')
            ->get()
            ->sortBy(function ($item) {
                return $item->slotMaster->start_time;
            })
            ->first();

        if (!$firstSlot) {
            return response()->json([
                'success' => false,
                'message' => 'No slots found for this booking.',
            ], 422);
        }

        /*
        |--------------------------------------------------------------------------
        | Booking Start DateTime
        |--------------------------------------------------------------------------
        */

        $bookingStart = Carbon::parse(
            $booking->booking_date->toDateString() . ' ' .
            $firstSlot->slotMaster->start_time
        );

        /*
        |--------------------------------------------------------------------------
        | Booking Already Started
        |--------------------------------------------------------------------------
        */

        if (now()->greaterThanOrEqualTo($bookingStart)) {

            return response()->json([
                'success' => false,
                'message' => 'Booking has already started.',
            ], 422);
        }

        /*
        |--------------------------------------------------------------------------
        | Cancellation Window (2 Hours)
        |--------------------------------------------------------------------------
        */

        $minutesRemaining = now()->diffInMinutes(
            $bookingStart,
            false
        );

        if ($minutesRemaining <= 120) {

            return response()->json([
                'success' => false,
                'message' => 'Booking cannot be cancelled within 2 hours of the booking start time.',
            ], 422);

        }

        /*
        |--------------------------------------------------------------------------
        | Cancel Booking
        |--------------------------------------------------------------------------
        */

        DB::beginTransaction();

        try {

            $booking->update([
                'booking_status' => 'cancelled',
            ]);

            /*
            |--------------------------------------------------------------------------
            | Future Payment Integration
            |--------------------------------------------------------------------------
            |
            | If payment_status == paid
            | Initiate refund here.
            |
            */

            DB::commit();

            return response()->json([

                'success' => true,

                'message' => 'Booking cancelled successfully.',

                'data' => [

                    'booking_id' => $booking->id,

                    'booking_number' => $booking->booking_number,

                    'booking_status' => $booking->booking_status,

                    'payment_status' => $booking->payment_status,

                ],

            ]);

        } catch (\Throwable $e) {

            DB::rollBack();

            report($e);

            return response()->json([

                'success' => false,

                'message' => 'Something went wrong. Please try again.',

            ], 500);

        }
    }


    /**
     * Reschedule an existing confirmed booking to a new date/slots —
     * same turf, same sport/event, just a different time.
     *
     * Rules: reschedule allowed up to 24 hours before the ORIGINAL slot
     * start, and only to new slots whose combined price exactly matches
     * the original total_amount — no partial payment/refund flow needed.
     */
   public function reschedule(RescheduleBookingRequest $request, Booking $booking)
{
    if ($booking->user_id !== $request->user()->id) {
        return response()->json([
            'success' => false,
            'message' => 'Booking not found.',
        ], 404);
    }
 
    if ($booking->booking_status !== 'confirmed') {
        return response()->json([
            'success' => false,
            'message' => "Only confirmed bookings can be rescheduled. This booking is \"{$booking->booking_status}\".",
        ], 422);
    }
 
    if ($booking->checked_in_at !== null) {
        return response()->json([
            'success' => false,
            'message' => 'This booking has already been checked in and cannot be rescheduled.',
        ], 422);
    }
 
    // Same "can't touch it once it's about to start" rule as cancel —
    // uses the booking's CURRENT (pre-reschedule) slot times.
    $currentFirstSlot = $booking->bookingItems->first()?->slotMaster;
 
    if ($currentFirstSlot) {
        $currentStart = \Carbon\Carbon::parse(
            $booking->booking_date->toDateString() . ' ' . $currentFirstSlot->start_time
        );
 
        if ($currentStart->isPast()) {
            return response()->json([
                'success' => false,
                'message' => 'This booking has already started and cannot be rescheduled.',
            ], 422);
        }
 
        if (now()->diffInHours($currentStart, false) < 24) {
            return response()->json([
                'success' => false,
                'message' => 'Bookings cannot be rescheduled within 24 hours of the start time.',
            ], 422);
        }
    }
 
    DB::beginTransaction();
 
    try {
 
        // Re-lock the new slots right now — someone else may have taken
        // one of them between validation and this exact moment.
        $newSlots = SlotMaster::whereIn('id', $request->slot_ids)
            ->lockForUpdate()
            ->get();
 
        $alreadyBooked = BookingItem::query()
            ->whereIn('slot_master_id', $request->slot_ids)
            ->where('booking_id', '!=', $booking->id)
            ->whereHas('booking', function ($query) use ($request) {
                $query->whereDate('booking_date', $request->booking_date)
                    ->whereIn('booking_status', ['pending', 'confirmed', 'completed']);
            })
            ->exists();
 
        if ($alreadyBooked) {
            DB::rollBack();
 
            return response()->json([
                'success' => false,
                'message' => 'One or more selected slots were just booked by someone else. Please choose different slots.',
            ], 422);
        }
 
        // Re-confirm the price match right here too (not just in the
        // request validation) — the DB lock above is the only truly
        // race-safe place to rely on numbers. Same 1-paisa tolerance
        // as the request validation, for the same floating-point
        // rounding reason.
        $newTotalAmount = (float) $newSlots->sum('price');
        $originalTotalAmount = (float) $booking->total_amount;
 
        if (abs($newTotalAmount - $originalTotalAmount) > 0.01) {
            DB::rollBack();
 
            return response()->json([
                'success' => false,
                'message' => 'Selected slots must total the same amount as the original booking.',
            ], 422);
        }
 
        // Swap the slots: drop the old booking_items, insert the new ones.
        // Price, platform_fee, and turf_owner_amount are unchanged since
        // the total is required to match exactly — only the date/time/
        // slot_master_id references change.
        $booking->bookingItems()->delete();
 
        $rows = [];
 
        foreach ($newSlots as $slot) {
            $rows[] = [
                'booking_id' => $booking->id,
                'slot_master_id' => $slot->id,
                'price' => $slot->price,
                'created_at' => now(),
                'updated_at' => now(),
            ];
        }
 
        BookingItem::insert($rows);
 
        $booking->update([
            'booking_date' => $request->booking_date,
        ]);
 
        DB::commit();
 
        return response()->json([
 
            'success' => true,
 
            'message' => 'Booking rescheduled successfully.',
 
            'data' => [
                'booking' => new BookingResource($booking->fresh('bookingItems.slotMaster', 'turf')),
            ],
 
        ]);
 
    } catch (\Throwable $e) {
 
        DB::rollBack();
        report($e);
 
        return response()->json([
            'success' => false,
            'message' => 'Something went wrong while rescheduling. Please try again.',
        ], 500);
    }
}

}