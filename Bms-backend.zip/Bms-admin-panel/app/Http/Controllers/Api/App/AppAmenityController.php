<?php

namespace App\Http\Controllers\Api\App;

use App\Http\Controllers\Controller;
use App\Models\Amenity;

class AppAmenityController extends Controller
{
    /**
     * Amenity List API
     */
    public function index()
    {
        $amenities = Amenity::where('status', 1)
            ->orderBy('sort_order', 'asc')
            ->get();

        $data = $amenities->map(function ($amenity) {

            return [

                'id' => $amenity->id,

                'name' => $amenity->name,

                'icon' => $amenity->icon
                    ? asset('storage/' . $amenity->icon)
                    : null,

            ];

        });

        return response()->json([

            'success' => true,

            'message' => 'Amenities fetched successfully.',

            'data' => $data,

        ]);
    }
}