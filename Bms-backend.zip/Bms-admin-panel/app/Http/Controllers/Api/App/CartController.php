<?php

namespace App\Http\Controllers\Api\App;

use App\Http\Controllers\Controller;
use App\Http\Requests\App\StoreCartItemRequest;
use App\Models\CartItem;
use App\Models\CartItemSlot;
use App\Models\SlotMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CartController extends Controller
{
    /**
     * Add slots to the cart for a given turf + sport/event + date.
     *
     * If the user already has an active (non-expired) cart group for the
     * exact same turf/sport-event/date, the new slots are MERGED into it
     * instead of creating a duplicate group:
     *   - slots already in that group are silently skipped (no error)
     *   - only genuinely new slots are inserted
     *   - the whole group's 10-minute hold is refreshed, since the user
     *     is actively still choosing
     *
     * This does NOT create a Booking. Nothing is blocked for other users
     * yet — that only happens at checkout time.
     */
    public function store(StoreCartItemRequest $request)
    {
        $data = $request->validated();

        try {

            DB::beginTransaction();

            $cartItem = CartItem::where('user_id', $request->user()->id)
                ->where('turf_id', $data['turf_id'])
                ->where('booking_type', $data['booking_type'])
                ->where('booking_type_id', $data['booking_type_id'])
                ->whereDate('booking_date', $data['booking_date'])
                ->where('expires_at', '>', now())
                ->first();

            if ($cartItem) {

                // Merge: only insert slots that aren't already in this
                // group. Re-selecting an already-held slot of your own
                // is a no-op, not an error.
                $existingSlotIds = $cartItem->cartItemSlots()
                    ->pluck('slot_master_id')
                    ->toArray();

                $newSlotIds = array_values(
                    array_diff($data['slot_ids'], $existingSlotIds)
                );

            } else {

                $cartItem = CartItem::create([
                    'user_id' => $request->user()->id,
                    'turf_id' => $data['turf_id'],
                    'booking_type' => $data['booking_type'],
                    'booking_type_id' => $data['booking_type_id'],
                    'booking_date' => $data['booking_date'],
                    'expires_at' => now()->addMinutes(10),
                ]);

                $newSlotIds = $data['slot_ids'];
            }

            if (!empty($newSlotIds)) {

                $slots = SlotMaster::whereIn('id', $newSlotIds)->get();

                $rows = [];

                foreach ($slots as $slot) {
                    $rows[] = [
                        'cart_item_id' => $cartItem->id,
                        'slot_master_id' => $slot->id,
                        'price' => $slot->price,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ];
                }

                CartItemSlot::insert($rows);
            }

            // Give the whole group a fresh 10-minute window — the user
            // is actively still picking slots, don't let an earlier
            // pick's timer run out from under a later addition.
            $cartItem->update([
                'expires_at' => now()->addMinutes(10),
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Added to cart successfully.',
                'data' => $this->formatCartItem(
                    $cartItem->fresh(
                        'cartItemSlots.slotMaster',
                        'turf'
                    )
                ),
            ], 201);

        } catch (\Throwable $e) {

            DB::rollBack();

            report($e);

            return response()->json([
                'success' => false,
                'message' => 'Something went wrong. Please try again.',
            ], 500);
        }
    }

    /**
     * View the full cart — grouped by sport/event + date,
     * with a grand total.
     */
    public function index(Request $request)
    {
        // Defensive: don't rely solely on the scheduled cart:expire job.
        // If someone views their cart between "hold expired" and "job
        // hasn't run yet", they should never see a stale/expired item.
        CartItem::where('user_id', $request->user()->id)
            ->where('expires_at', '<=', now())
            ->delete();

        $cartItems = CartItem::with([
                'cartItemSlots.slotMaster',
                'turf',
            ])
            ->where('user_id', $request->user()->id)
            ->latest()
            ->get();

        $grandTotal = $cartItems->sum(function ($item) {
            return $item->cartItemSlots->sum('price');
        });

        return response()->json([
            'success' => true,
            'message' => 'Cart fetched successfully.',
            'data' => [
                'items' => $cartItems->map(
                    fn ($item) => $this->formatCartItem($item)
                ),
                'grand_total' => $grandTotal,
            ],
        ]);
    }

    /**
     * Remove one group (e.g. one sport on one date) from the cart.
     */
    public function destroy(Request $request, CartItem $cartItem)
    {
        if ($cartItem->user_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Cart item not found.',
            ], 404);
        }

        $cartItem->delete();

        return response()->json([
            'success' => true,
            'message' => 'Removed from cart successfully.',
        ]);
    }

    /**
     * Remove just ONE slot from a cart group, keeping the rest of the
     * group (and its remaining slots) intact. If that was the last slot
     * in the group, the whole group is removed too — a group with zero
     * slots doesn't make sense to keep around.
     */
    public function destroySlot(
        Request $request,
        CartItem $cartItem,
        int $slotMasterId
    ) {
        if ($cartItem->user_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Cart item not found.',
            ], 404);
        }

        $deleted = $cartItem->cartItemSlots()
            ->where('slot_master_id', $slotMasterId)
            ->delete();

        if (!$deleted) {
            return response()->json([
                'success' => false,
                'message' => 'That slot is not in this cart item.',
            ], 404);
        }

        $remainingSlots = $cartItem->cartItemSlots()->count();

        if ($remainingSlots === 0) {
            $cartItem->delete();

            return response()->json([
                'success' => true,
                'message' => 'Slot removed. The cart group was emptied and removed as well.',
                'data' => null,
            ]);
        }

        return response()->json([
            'success' => true,
            'message' => 'Slot removed from cart.',
            'data' => $this->formatCartItem(
                $cartItem->fresh(
                    'cartItemSlots.slotMaster',
                    'turf'
                )
            ),
        ]);
    }

    /**
     * Clear the entire cart.
     */
    public function clear(Request $request)
    {
        CartItem::where('user_id', $request->user()->id)
            ->delete();

        return response()->json([
            'success' => true,
            'message' => 'Cart cleared successfully.',
        ]);
    }

    /**
     * Real checkout/payment now happens via RazorpayController
     * (createOrder + verify). See app/Services/CartCheckoutService.php
     * for the shared booking-creation logic used once payment is verified.
     */
    private function formatCartItem(CartItem $cartItem): array
    {
        return [
            'cart_item_id' => $cartItem->id,
            'turf_id' => $cartItem->turf_id,
            'turf_name' => $cartItem->turf?->name,
            'booking_type' => $cartItem->booking_type,
            'booking_type_id' => $cartItem->booking_type_id,
            'booking_name' => $cartItem->booking_name,
            'booking_date' => $cartItem->booking_date->toDateString(),
            'expires_at' => $cartItem->expires_at->toIso8601String(),
            'seconds_remaining' => max(
                0,
                $cartItem->expires_at->getTimestamp()
                - now()->getTimestamp()
            ),
            'total_amount' => $cartItem->cartItemSlots->sum('price'),

            'slots' => $cartItem->cartItemSlots->map(function ($cis) {
                return [
                    'slot_id' => $cis->slot_master_id,
                    'start_time' => $cis->slotMaster->start_time,
                    'end_time' => $cis->slotMaster->end_time,
                    'price' => $cis->price,
                ];
            }),
        ];
    }
}