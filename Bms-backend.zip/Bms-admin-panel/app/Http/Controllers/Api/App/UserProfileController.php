<?php

namespace App\Http\Controllers\Api\App;

use App\Http\Controllers\Controller;
use App\Http\Requests\App\CompleteProfileRequest;
use App\Http\Requests\App\UpdateProfileRequest;
use App\Http\Resources\UserProfileResource;
use App\Mail\WelcomeEmail;
use App\Models\UserProfile;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;


class UserProfileController extends Controller
{
    /*** Complete User Profile */

    public function completeProfile(CompleteProfileRequest $request)
    {
      $user = $request->user();

    if ($user->profile) {
        return response()->json([
            'status' => false,
            'message' => 'Profile already completed.'
        ], 422);
    }

        $profileImage = null;

        if ($request->hasFile('profile_image')) {
            $profileImage = $request->file('profile_image')
                ->store('profile-images', 'public');
        }

        $profile = UserProfile::create([
            'user_id' => $user->id,
            'full_name' => $request->full_name,
            'email' => $request->email,
            'profile_image' => $profileImage,
            'gender' => $request->gender,
            'date_of_birth' => $request->date_of_birth,
            'country_id' => $request->country_id,
            'state_id' => $request->state_id,
            'city_id' => $request->city_id,
            'address' => $request->address,
            'pincode' => $request->pincode,
        ]);

        if ($request->has('favourite_sports')) {
            $profile->favouriteSports()->sync(
                $request->favourite_sports
            );
        }

        $profile->load(
            'country',
            'state',
            'city',
            'favouriteSports'
        );

        Mail::to($profile->email)->send(
            new WelcomeEmail($profile->full_name, 'user')
        );

        return response()->json([
            'status' => true,
            'message' => 'Profile completed successfully.',
            'data' => new UserProfileResource($profile)
        ]);
    }

    /*** Get Logged In User Profile */

   public function getProfile(Request $request)
{
    $profile = $request->user()
        ->profile()
        ->with(
            'country',
            'state',
            'city',
            'favouriteSports'
        )
        ->first();

    if (!$profile) {
        return response()->json([
            'status' => false,
            'message' => 'Profile not found.'
        ], 404);
    }

    return response()->json([
        'status' => true,
        'message' => 'Profile fetched successfully.',
        'data' => new UserProfileResource($profile)
    ]);
}

    /*** Update User Profile */

    public function updateProfile(UpdateProfileRequest $request)
    {
        $profile = $request->user()->profile;

        if (!$profile) {
            return response()->json([
                'status' => false,
                'message' => 'Profile not found.'
            ], 404);
        }

        if ($request->hasFile('profile_image')) {

            if (
                $profile->profile_image &&
                Storage::disk('public')->exists($profile->profile_image)
            ) {
                Storage::disk('public')->delete(
                    $profile->profile_image
                );
            }

            $profile->profile_image = $request
                ->file('profile_image')
                ->store('profile-images', 'public');
        }

        $profile->fill(
            $request->except([
                'profile_image',
                'favourite_sports',
            ])
        );

        $profile->save();

        if ($request->has('favourite_sports')) {
            $profile->favouriteSports()->sync(
                $request->favourite_sports
            );
        }

        $profile->load(
            'country',
            'state',
            'city',
            'favouriteSports'
        );

        return response()->json([
            'status' => true,
            'message' => 'Profile updated successfully.',
            'data' => new UserProfileResource($profile)
        ]);
    }
}
