<?php

namespace App\Http\Controllers\Api\App;

use App\Http\Controllers\Controller;
use App\Models\Event;

class AppEventController extends Controller
{
    /**
     * Event List API
     */
    public function index()
    {
        $events = Event::where('status', 1)
            ->orderBy('sort_order', 'asc')
            ->get();

        $data = $events->map(function ($event) {

            return [

                'id' => $event->id,

                'name' => $event->name,

                'selected_icon' => $event->selected_icon
                    ? asset('storage/' . $event->selected_icon)
                    : null,

                'unselected_icon' => $event->unselected_icon
                    ? asset('storage/' . $event->unselected_icon)
                    : null,

            ];

        });

        return response()->json([

            'success' => true,

            'message' => 'Events fetched successfully.',

            'data' => $data,

        ]);
    }
}