<?php

namespace App\Http\Controllers\Api\App;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\App\FavouriteTurfRequest;
use App\Http\Resources\App\AppTurfResource;
use App\Models\UserFavouriteTurf;

class AppFavouriteController extends Controller
{
    /**
     * Add / Remove Favourite Turf
     */
    public function toggle(FavouriteTurfRequest $request)
    {
        $user = $request->user();

        $validated = $request->validated();

        // Check if already exists
        $favourite = UserFavouriteTurf::where('user_id', $user->id)
            ->where('turf_id', $validated['turf_id'])
            ->first();

        if ($favourite) {

            $favourite->delete();

            return response()->json([
                'success' => true,
                'message' => 'Turf removed from favourites.',
                'is_favourite' => false,
            ]);
        }

        UserFavouriteTurf::create([
            'user_id' => $user->id,
            'turf_id' => $validated['turf_id'],
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Turf added to favourites.',
            'is_favourite' => true,
        ]);
    }


    public function index(Request $request)
    {
        $user = $request->user();

        $latitude = $request->input('latitude');
        $longitude = $request->input('longitude');

        $hasLocation = $request->filled('latitude') &&
                    $request->filled('longitude');


        $query = UserFavouriteTurf::with([

            'turf' => function ($query) use ($hasLocation, $latitude, $longitude) {

                $query->where('status', true)
                    ->where('approval_status', 'approved');

                if ($hasLocation) {
                    $query->withDistance($latitude, $longitude);
                }

            },

            'turf.sports',
            'turf.events',
            'turf.city',
            'turf.images',

        ])
        ->where('user_id', $user->id);

        // Filter by multiple sports
        if ($request->filled('sports')) {

            // Convert comma separated string into array
            $sportIds = array_filter(explode(',', $request->sports));

            $query->whereHas('turf.sports', function ($q) use ($sportIds) {
                $q->whereIn('sports.id', $sportIds);
            });
        }

        $favourites = $query
            ->latest()
            ->paginate($request->per_page ?? 10);

        return response()->json([
            'success' => true,
            'message' => 'Favourite turfs fetched successfully.',
            'data' => AppTurfResource::collection(
                $favourites->getCollection()
                    ->pluck('turf')
                    ->filter() // drops any null (inactive/unapproved/deleted) turfs
                    ->values()
            ),
            'pagination' => [
                'current_page' => $favourites->currentPage(),
                'last_page'    => $favourites->lastPage(),
                'per_page'     => $favourites->perPage(),
                'total'        => $favourites->total(),
                'from'         => $favourites->firstItem(),
                'to'           => $favourites->lastItem(),
            ],
        ]);
    }


}