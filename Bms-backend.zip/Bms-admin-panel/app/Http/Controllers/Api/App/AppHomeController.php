<?php

namespace App\Http\Controllers\Api\App;

use App\Http\Controllers\Controller;
use App\Models\Sport;
use App\Models\Turf;
use Illuminate\Http\Request;
use Carbon\Carbon;


class AppHomeController extends Controller
{
    /*** Home API */

    public function index(Request $request)
    {
        // Active Sports
        $sports = Sport::where('status', 1)
            ->orderBy('sort_order')
            ->get() 
            ->map(function ($sport) {
                return [
                    'id' => $sport->id,
                    'name' => $sport->name,
                    'selected_icon' => $sport->selected_icon
                        ? asset('storage/' . $sport->selected_icon)
                        : null,
                    'unselected_icon' => $sport->unselected_icon
                        ? asset('storage/' . $sport->unselected_icon)
                        : null,
                ];
            });

        $latitude = $request->input('latitude');
        $longitude = $request->input('longitude');

        $hasLocation = $request->filled('latitude') &&
                       $request->filled('longitude');


        $baseQuery = Turf::query()
        ->where('status', true)
        ->where('approval_status', 'approved')
        ->with([
            'sports:id,name',
            'images:id,turf_id,image,sort_order',
        ]);

        if ($hasLocation) {

            // No radius cutoff — show all approved turfs, nearest first.
            // Turfs without lat/long can't have a distance calculated,
            // so they're excluded only from this location-based query
            // (not from the app in general).
            $baseQuery
                ->whereNotNull('latitude')
                ->whereNotNull('longitude')
                ->withDistance($latitude, $longitude)
                ->orderBy('distance');

        } else {

            // No location provided — fall back to newest approved turfs.
            $baseQuery->latest();

        }

        $turfs = $baseQuery
            ->take(5)
            ->get()
            ->map(function ($turf) use ($hasLocation) {

                $coverImage = null;

                if (!empty($turf->cover_image)) {

                    if (filter_var($turf->cover_image, FILTER_VALIDATE_URL)) {
                        $coverImage = $turf->cover_image;
                    } else {
                        $coverImage = asset('storage/' . $turf->cover_image);
                    }

                } elseif ($turf->images->isNotEmpty()) {

                    $image = $turf->images->first()->image;

                    $coverImage = filter_var($image, FILTER_VALIDATE_URL)
                        ? $image
                        : asset('storage/' . $image);
                }

                $currentTime = Carbon::now();

                $openingTime = Carbon::parse($turf->opening_time);

                $closingTime = Carbon::parse($turf->closing_time);

                if ($openingTime->lessThan($closingTime)) {

                    $isOpen = $currentTime->between(
                        $openingTime,
                        $closingTime
                    );

                } else {

                    $isOpen =
                        $currentTime->greaterThanOrEqualTo($openingTime)
                        ||
                        $currentTime->lessThanOrEqualTo($closingTime);

                }

                return [

                    'id' => $turf->id,

                    'name' => $turf->name,

                    'cover_image' => $coverImage,

                    'area' => $turf->area,

                    'sports' => $turf->sports->pluck('name'),

                    'average_rating' => (float) $turf->average_rating,

                    'total_reviews' => $turf->total_reviews,

                    'opening_time' => $turf->opening_time,

                    'closing_time' => $turf->closing_time,

                    // Only present when the request sent latitude/longitude.
                    'distance' => $hasLocation ? round($turf->distance, 2) : null,

                    'is_open' => $isOpen,

                ];
            });


        return response()->json([
            'success' => true,
            'message' => 'Home data fetched successfully.',
            'data' => [
                // 'banners' => [],
                'sports' => $sports,
                // 'latest_turfs' => $latestTurfs,
                'turfs' => $turfs,
            ]
        ]);
    }
}