<?php

namespace App\Http\Controllers\Api\App;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Sport;

class AppSportController extends Controller
{

    public function index(Request $request)
    {
        $sports = Sport::where('status', 1)
            ->when($request->search, function ($query, $search) {
                $query->where('name', 'like', '%' . $search . '%');
            })
            ->orderBy('sort_order', 'asc')
            ->get();

        $data = $sports->map(function ($sport) {
            return [
                'id' => $sport->id,
                'name' => $sport->name,
                'slug' => $sport->slug,

                'selected_icon' => $sport->selected_icon
                    ? asset('storage/' . $sport->selected_icon)
                    : null,

                'unselected_icon' => $sport->unselected_icon
                    ? asset('storage/' . $sport->unselected_icon)
                    : null,
            ];
        });

        return response()->json([
            'status' => true,
            'message' => 'Sports fetched successfully.',
            'data' => $data,
        ]);
    }
    
}