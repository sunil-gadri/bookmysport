<?php

namespace App\Http\Controllers\Api\App;

use App\Http\Controllers\Controller;
use App\Http\Requests\App\StoreReviewRequest;
use App\Models\Booking;
use App\Models\Review;
use App\Models\Turf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ReviewController extends Controller
{
    /**
     * Submit a review — only allowed for a booking that is completed
     * AND was actually checked in for (enforced in StoreReviewRequest).
     */
    public function store(StoreReviewRequest $request)
    {
        $booking = Booking::find($request->booking_id);

        $review = Review::create([
            'user_id' => Auth::id(),
            'turf_id' => $booking->turf_id,
            'booking_id' => $booking->id,
            'rating' => $request->rating,
            'what_went_well' => $request->what_went_well,
            'comment' => $request->comment,
        ]);

        $this->recalculateTurfRating($booking->turf_id);

        return response()->json([

            'success' => true,

            'message' => 'Review submitted successfully.',

            'data' => $this->formatReview($review->fresh('user')),

        ], 201);
    }

    /**
     * List the logged-in user's own reviews (across all turfs) —
     * used for a "My Reviews" screen in the app.
     */
    public function myReviews(Request $request)
    {
        $reviews = Review::where('user_id', Auth::id())
            ->with(['user.profile', 'turf:id,name'])
            ->latest()
            ->paginate($request->per_page ?? 10);

        return response()->json([

            'success' => true,

            'message' => 'Your reviews fetched successfully.',

            'data' => $reviews->through(function ($review) {
                $data = $this->formatReview($review);
                $data['turf'] = [
                    'id' => $review->turf_id,
                    'name' => $review->turf?->name,
                ];
                return $data;
            }),

            'pagination' => [
                'current_page' => $reviews->currentPage(),
                'last_page' => $reviews->lastPage(),
                'total' => $reviews->total(),
            ],

        ]);
    }

    /**
     * List reviews for a turf — public-facing (turf detail screen).
     */
    public function index(Request $request, Turf $turf)
    {
        $reviews = $turf->reviews()
            ->with('user.profile')
            ->latest()
            ->paginate($request->get('per_page', 10));

        $reviews->getCollection()->transform(function ($review) {
            return $this->formatReview($review);
        });

        return response()->json([
            'turfId' => $turf->id,
            'turfName' => $turf->name,
            'averageRating' => round($turf->reviews()->avg('rating'), 1),
            'totalReviews' => $turf->reviews()->count(),
            'reviews' => $reviews,
        ]);
    }

    /**
     * Update your own review (rating/comment/what_went_well only — can't
     * move it to a different booking).
     */
    public function update(Request $request, int $reviewId)
    {
        $review = Review::find($reviewId);

        if (!$review) {
            return response()->json([
                'message' => 'Review not found.',
            ], 404);
        }

        if ($review->user_id !== $request->user()->id) {
            return response()->json([
                'message' => 'You are not allowed to update this review.',
            ], 403);
        }

        $validated = $request->validate([
            'rating' => ['required', 'integer', 'min:1', 'max:5'],
            'what_went_well' => ['nullable', 'array'],
            'what_went_well.*' => [
                'string',
                'distinct',
                'in:' . implode(',', Review::HIGHLIGHT_OPTIONS),
            ],
            'comment' => ['nullable', 'string', 'max:1000'],
        ]);

        $review->update($validated);

        $this->recalculateTurfRating($review->turf_id);

        return response()->json([
            'message' => 'Review updated successfully.',
            'review' => $this->formatReview($review->fresh('user')),
        ]);
    }

    /**
     * Delete your own review.
     */
    public function destroy(Request $request, Review $review)
    {
        if ($review->user_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Review not found.',
            ], 404);
        }

        $turfId = $review->turf_id;

        $review->delete();

        $this->recalculateTurfRating($turfId);

        return response()->json([
            'success' => true,
            'message' => 'Review deleted successfully.',
        ]);
    }

    /**
     * Recompute and persist the turf's average_rating and total_reviews
     * columns so listing/search screens don't need a live aggregate
     * query every time they show a turf card.
     */
    private function recalculateTurfRating(int $turfId): void
    {
        $turf = Turf::find($turfId);

        if (!$turf) {
            return;
        }

        $turf->update([
            'average_rating' => round((float) $turf->reviews()->avg('rating'), 1),
            'total_reviews' => $turf->reviews()->count(),
        ]);
    }

    private function formatReview(Review $review): array
    {
        return [
            'id' => $review->id,
            'rating' => $review->rating,
            'what_went_well' => $review->what_went_well ?? [],
            'comment' => $review->comment,
            'user' => [
                'user_id' => $review->user?->id,
                'name' => $review->user?->profile?->full_name ?: $review->user?->name,
                'profile_image' => $review->user?->profile?->profile_image
                    ? asset('storage/' . $review->user->profile->profile_image) 
                    : null,
            ],
            'created_at' => $review->created_at->format('d M Y'),
        ];
    }
}