<?php

namespace App\Http\Controllers\Api\App;

use App\Http\Controllers\Controller;
use App\Models\CartItem;
use App\Models\PaymentOrder;
use App\Services\CartCheckoutService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Razorpay\Api\Api as RazorpayApi;
use Razorpay\Api\Errors\SignatureVerificationError;

class RazorpayController extends Controller
{
    /**
     * Step 1: App calls this right before opening the Razorpay checkout
     * screen. We total up whatever's currently in the user's cart and
     * ask Razorpay for an order id.
     */
    public function createOrder(Request $request)
    {
        $cartItems = CartItem::with('cartItemSlots')
            ->where('user_id', auth()->id())
            ->get();

        if ($cartItems->isEmpty()) {
            return response()->json([
                'success' => false,
                'message' => 'Your cart is empty.',
            ], 422);
        }

        $expired = $cartItems->filter(fn ($item) => $item->expires_at->isPast());

        if ($expired->isNotEmpty()) {
            $expired->each->delete();

            return response()->json([
                'success' => false,
                'message' => 'One or more items in your cart expired. Please add them again and pay within 10 minutes.',
            ], 422);
        }

        $amountInRupees = $cartItems->sum(
            fn ($item) => $item->cartItemSlots->sum('price')
        );

        try {

            $api = new RazorpayApi(
                config('services.razorpay.key'),
                config('services.razorpay.secret')
            );

            $razorpayOrder = $api->order->create([
                // Razorpay wants the amount in paise, not rupees.
                'amount' => (int) round($amountInRupees * 100),
                'currency' => 'INR',
                'receipt' => 'user_' . auth()->id() . '_' . now()->timestamp,
                'notes' => [
                    'user_id' => auth()->id(),
                ],
            ]);

            $paymentOrder = PaymentOrder::create([
                'user_id' => auth()->id(),
                'razorpay_order_id' => $razorpayOrder['id'],
                'amount' => $amountInRupees,
                'currency' => 'INR',
                'status' => 'created',
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Order created.',
                'data' => [
                    // Everything the Flutter app needs to open the
                    // Razorpay checkout widget.
                    'razorpay_key' => config('services.razorpay.key'),
                    'razorpay_order_id' => $razorpayOrder['id'],
                    'amount' => $amountInRupees,
                    'amount_in_paise' => (int) round($amountInRupees * 100),
                    'currency' => 'INR',
                ],
            ]);

        } catch (\Throwable $e) {

            Log::error('Razorpay order creation failed: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'Could not initiate payment. Please try again.',
            ], 500);
        }
    }

    /**
     * Step 2: App calls this after the Razorpay checkout widget closes
     * with a success result. We independently verify the signature with
     * Razorpay's secret before trusting anything the client says.
     */
    public function verify(Request $request)
    {
        $request->validate([
            'razorpay_order_id' => ['required', 'string'],
            'razorpay_payment_id' => ['required', 'string'],
            'razorpay_signature' => ['required', 'string'],
        ]);

        $order = PaymentOrder::where('razorpay_order_id', $request->razorpay_order_id)
            ->where('user_id', auth()->id())
            ->first();

        if (!$order) {
            return response()->json([
                'success' => false,
                'message' => 'Order not found.',
            ], 404);
        }

        try {

            $api = new RazorpayApi(
                config('services.razorpay.key'),
                config('services.razorpay.secret')
            );

            // This throws SignatureVerificationError if the payment
            // wasn't genuinely authorized by Razorpay for this exact order.
            $api->utility->verifyPaymentSignature([
                'razorpay_order_id' => $request->razorpay_order_id,
                'razorpay_payment_id' => $request->razorpay_payment_id,
                'razorpay_signature' => $request->razorpay_signature,
            ]);

        } catch (SignatureVerificationError $e) {

            $order->update(['status' => 'failed']);

            return response()->json([
                'success' => false,
                'message' => 'Payment verification failed.',
            ], 422);
        }

        $order->update(['razorpay_payment_id' => $request->razorpay_payment_id]);

        try {

            $result = app(CartCheckoutService::class)->finalize($order);

            return response()->json([
                'success' => true,
                'message' => 'Payment verified. Booking confirmed.',
                'data' => [
                    'bookings' => $result['bookings'],
                ],
            ], 201);

        } catch (\Throwable $e) {

            // Payment succeeded on Razorpay's side but we couldn't turn
            // it into a booking (e.g. slot vanished). This needs a human
            // to look at it and refund — never let this fail silently.
            Log::critical('Payment captured but booking finalization failed: ' . $e->getMessage(), [
                'razorpay_order_id' => $order->razorpay_order_id,
                'user_id' => $order->user_id,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Payment received but we could not confirm your booking. Our team has been notified — you will be refunded if this is not resolved shortly.',
            ], 500);
        }
    }

    /**
     * Optional but recommended for production: Razorpay calls this
     * server-to-server as a backup, in case the app never gets to call
     * verify() (network drop, app killed, etc). Configure this URL in
     * the Razorpay dashboard under Webhooks, subscribed to
     * "payment.captured".
     */
    public function webhook(Request $request)
    {
        $signature = $request->header('X-Razorpay-Signature');
        $payload = $request->getContent();

        try {
            \Razorpay\Api\Utility::verifyWebhookSignature(
                $payload,
                $signature,
                config('services.razorpay.webhook_secret')
            );
        } catch (SignatureVerificationError $e) {
            return response()->json(['status' => 'invalid signature'], 400);
        }

        $event = json_decode($payload, true);

        if (($event['event'] ?? null) === 'payment.captured') {

            $razorpayOrderId = $event['payload']['payment']['entity']['order_id'] ?? null;
            $razorpayPaymentId = $event['payload']['payment']['entity']['id'] ?? null;

            $order = PaymentOrder::where('razorpay_order_id', $razorpayOrderId)->first();

            if ($order && !$order->razorpay_payment_id) {
                $order->update(['razorpay_payment_id' => $razorpayPaymentId]);
            }

            if ($order) {
                try {
                    app(CartCheckoutService::class)->finalize($order);
                } catch (\Throwable $e) {
                    Log::critical('Webhook finalize failed: ' . $e->getMessage());
                }
            }
        }

        // Always respond 200 quickly so Razorpay doesn't keep retrying.
        return response()->json(['status' => 'ok']);
    }
}