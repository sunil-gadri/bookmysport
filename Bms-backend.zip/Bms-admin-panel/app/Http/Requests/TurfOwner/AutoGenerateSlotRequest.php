<?php

namespace App\Http\Requests\TurfOwner;

use Illuminate\Foundation\Http\FormRequest;

class AutoGenerateSlotRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [

            'turf_id' => 'required|exists:turfs,id',

            'booking_type' => 'required|in:sport,event',

            'booking_type_id' => 'required|integer',

            'days' => ['required', 'array', 'min:1'],

            'days.*' => ['required', 'string', 'in:monday,tuesday,wednesday,thursday,friday,saturday,sunday'],

            'opening_time' => 'required|date_format:H:i',

            'closing_time' => 'required|date_format:H:i|after:opening_time',

            'slot_duration' => 'required|integer|min:15',

            'price' => 'required|numeric|min:0',

        ];
    }
}