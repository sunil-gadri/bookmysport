<?php

namespace App\Http\Requests\TurfOwner;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class UpdateSlotMasterRequest extends FormRequest
{
    /*** Determine if the user is authorized to make this request.*/

    public function authorize(): bool
    {
        return true;
    }

    /*** Get the validation rules that apply to the request.*
    * @return array<string, ValidationRule|array<mixed>|string> */

    public function rules(): array
    {
        return [
            'turf_id' => 'required|exists:turfs,id',

            'booking_type' => 'required|in:sport,event',

            'booking_type_id' => 'required|integer',

            'day' => 'required|in:monday,tuesday,wednesday,thursday,friday,saturday,sunday',

            'start_time' => 'required|date_format:H:i',

            'end_time' => 'required|date_format:H:i|after:start_time',

            'price' => 'required|numeric|min:0',
        ];
    }

}
