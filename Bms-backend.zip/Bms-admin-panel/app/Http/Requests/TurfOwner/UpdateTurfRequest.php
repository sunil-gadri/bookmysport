<?php

namespace App\Http\Requests\TurfOwner;

use Illuminate\Foundation\Http\FormRequest;

class UpdateTurfRequest extends FormRequest
{
    /**
     * Determine if the user is authorized.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Validation Rules
     */
    public function rules(): array
    {
        return [

            'name' => [
                'required',
                'string',
                'max:150',
            ],

            'description' => [
                'nullable',
                'string',
            ],

            'cover_image' => [
                'nullable',
                'image',
                'mimes:jpg,jpeg,png,webp',
                'max:2048',
            ],

            'gallery_images' => [
                'nullable',
                'array',
            ],

            'gallery_images.*' => [
                'image',
                'mimes:jpg,jpeg,png,webp',
                'max:2048',
            ],

            'contact_number' => [
                'required',
                'string',
                'max:20',
            ],

            'email' => [
                'nullable',
                'email',
                'max:255',
            ],

            'address' => [
                'required',
                'string',
            ],

            'area' => [
                'nullable',
                'string',
                'max:150',
            ],


            'landmark' => [
                'nullable',
                'string',
                'max:255',
            ],

            'country_id' => [
                'required',
                'exists:countries,id',
            ],

            'state_id' => [
                'required',
                'exists:states,id',
            ],

            'city_id' => [
                'required',
                'exists:cities,id',
            ],

            'pincode' => [
                'required',
                'string',
                'max:10',
            ],

            'latitude' => [
                'nullable',
                'numeric',
                'between:-90,90',
            ],

            'longitude' => [
                'nullable',
                'numeric',
                'between:-180,180',
            ],

            'opening_time' => [
                'required',
                'date_format:H:i',
            ],

            'closing_time' => [
                'required',
                'date_format:H:i',
            ],

            'ground_type' => [
                'required',
                'in:single,multiple',
            ],

            'sport_ids' => [
                'required',
                'array',
                'min:1',
            ],

            'sport_ids.*' => [
                'integer',
                'distinct',
                'exists:sports,id',
            ],

            'amenity_ids' => [
                'nullable',
                'array',
            ],

            'amenity_ids.*' => [
                'integer',
                'distinct',
                'exists:amenities,id',
            ],

            'event_ids' => [
                'nullable',
                'array',
            ],

            'event_ids.*' => [
                'integer',
                'distinct',
                'exists:events,id',
            ],
        ];
    }

    public function withValidator($validator)
    {
        $validator->after(function ($validator) {

            $opening = $this->opening_time;
            $closing = $this->closing_time;

            if ($opening === $closing) {
                $validator->errors()->add(
                    'closing_time',
                    'Closing time cannot be the same as opening time.'
                );
            }
        });
    }

}