<?php

namespace App\Http\Requests\TurfOwner;

use App\Models\Event;
use App\Models\Sport;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Validator;

class StoreSlotMasterRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Validation Rules
     */
    public function rules(): array
    {
        return [
            'turf_id' => [
                'required',
                'exists:turfs,id',
            ],

            'booking_type' => [
                'required',
                'in:sport,event',
            ],

            'booking_type_id' => [
                'required',
                'integer',
            ],

            'day' => [
                'required',
                'in:monday,tuesday,wednesday,thursday,friday,saturday,sunday',
            ],

            'start_time' => [
                'required',
                'date_format:H:i',
            ],

            'end_time' => [
                'required',
                'date_format:H:i',
                'after:start_time',
            ],

            'price' => [
                'required',
                'numeric',
                'min:0',
            ],
        ];
    }

    /**
     * Additional Validation
     */
    public function after(): array
    {
        return [
            function (Validator $validator) {

                if ($this->booking_type === 'sport') {

                    if (!Sport::where('id', $this->booking_type_id)->exists()) {
                        $validator->errors()->add(
                            'booking_type_id',
                            'Selected sport does not exist.'
                        );
                    }

                } elseif ($this->booking_type === 'event') {

                    if (!Event::where('id', $this->booking_type_id)->exists()) {
                        $validator->errors()->add(
                            'booking_type_id',
                            'Selected event does not exist.'
                        );
                    }
                }
            }
        ];
    }
}