<?php

namespace App\Http\Requests\TurfOwner;

use Illuminate\Foundation\Http\FormRequest;

class SlotMasterListRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [

            'search' => 'nullable|string|max:255',

            'turf_id' => 'nullable|exists:turfs,id',

            'booking_type' => 'nullable|in:sport,event',

            'day' => 'nullable|in:monday,tuesday,wednesday,thursday,friday,saturday,sunday',

            'status' => 'nullable|boolean',

            'sort_by' => 'nullable|in:created_at,start_time,end_time,price',

            'sort_order' => 'nullable|in:asc,desc',

            'per_page' => 'nullable|integer|min:1|max:100',

        ];
    }
}