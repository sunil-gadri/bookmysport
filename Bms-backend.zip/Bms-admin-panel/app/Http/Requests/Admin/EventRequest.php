<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;


class EventRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }


    public function rules(): array
    {
        $eventId = $this->route('id');

        return [
            'name' => [
                'required',
                'string',
                'max:100',
                Rule::unique('events', 'name')->ignore($eventId),
            ],
            'selected_icon' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'unselected_icon' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'status' => 'nullable|in:0,1',
            'sort_order' => 'nullable|integer|min:0',
        ];
    }


}