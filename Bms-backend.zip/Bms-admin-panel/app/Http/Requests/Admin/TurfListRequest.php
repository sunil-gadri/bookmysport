<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class TurfListRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [

            'search' => [
                'nullable',
                'string',
                'max:100',
            ],

            'status' => [
                'nullable',
                'boolean',
            ],

            'approval_status' => [
                'nullable',
                'in:draft,pending,approved,rejected',
            ],

            'city_id' => [
                'nullable',
                'exists:cities,id',
            ],

            'sport_id' => [
                'nullable',
                'exists:sports,id',
            ],

            'page' => [
                'nullable',
                'integer',
                'min:1',
            ],

            'per_page' => [
                'nullable',
                'integer',
                'min:1',
                'max:100',
            ],

            'sort_by' => [
                'nullable',
                'in:name,created_at,status,approval_status',
            ],

            'sort_order' => [
                'nullable',
                'in:asc,desc',
            ],

        ];
    }
}