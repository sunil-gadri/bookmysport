<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UpdateTurfApprovalRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [

            'approval_status' => [
                'required',
                'in:approved,rejected',
            ],

            'rejection_reason' => [
                'nullable',
                'string',
                'max:500',
                'required_if:approval_status,rejected',
            ],

        ];
    }

    public function messages(): array
    {
        return [
            'rejection_reason.required_if' => 'Rejection reason is required when rejecting a turf.',
        ];
    }
}