<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UserListRequest extends FormRequest
{
    /**
     * Determine if the user is authorized.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Validation rules.
     */
    public function rules(): array
    {
        return [
            'search'     => 'nullable|string|max:100',

            'status'     => 'nullable|boolean',

            'sort_by'    => 'nullable|in:full_name,created_at',

            'sort_order' => 'nullable|in:asc,desc',

            'per_page'   => 'nullable|integer|min:5|max:100',
        ];
    }
}