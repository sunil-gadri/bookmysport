<?php

namespace App\Http\Requests\App;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\Turf;
use App\Models\SlotMaster;
use App\Models\BookingItem;
use App\Models\CartItemSlot;

class StoreBookingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [

            'turf_id' => [
                'required',
                'exists:turfs,id',
            ],

            'booking_type' => [
                'required',
                'in:sport,event',
            ],

            'booking_type_id' => [
                'required',
                'integer',
            ],

            'booking_date' => [
                'required',
                'date',
                'after_or_equal:today',
            ],

            'slot_ids' => [
                'required',
                'array',
                'min:1',
            ],

            'slot_ids.*' => [
                'required',
                'integer',
                'exists:slot_masters,id',
            ],

        ];
    }

    public function messages(): array
    {
        return [

            'booking_date.after_or_equal' =>
                'Booking date cannot be in the past.',

            'slot_ids.required' =>
                'Please select at least one slot.',

            'slot_ids.min' =>
                'Please select at least one slot.',

            'slot_ids.*.exists' =>
                'One or more selected slots are invalid.',

        ];
    }

    public function withValidator($validator): void
    {
        $validator->after(function ($validator) {

            $turf = Turf::with(['sports:id', 'events:id'])
                ->find($this->turf_id);

            if (!$turf) {
                return;
            }

            if (!$turf->status) {
                $validator->errors()->add(
                    'turf_id',
                    'This turf is currently unavailable.'
                );
                return;
            }

            if ($turf->approval_status !== 'approved') {
                $validator->errors()->add(
                    'turf_id',
                    'This turf is not approved for booking.'
                );
                return;
            }

            if ($this->booking_type === 'sport') {
                $exists = $turf->sports()
                    ->where('sports.id', $this->booking_type_id)
                    ->exists();

                if (!$exists) {
                    $validator->errors()->add(
                        'booking_type_id',
                        'Selected sport is not available for this turf.'
                    );
                    return;
                }
            }

            if ($this->booking_type === 'event') {
                $exists = $turf->events()
                    ->where('events.id', $this->booking_type_id)
                    ->exists();

                if (!$exists) {
                    $validator->errors()->add(
                        'booking_type_id',
                        'Selected event is not available for this turf.'
                    );
                    return;
                }
            }

            $slots = SlotMaster::whereIn('id', $this->slot_ids)
                ->where('status', true)
                ->get();

            if ($slots->count() !== count($this->slot_ids)) {
                $validator->errors()->add(
                    'slot_ids',
                    'One or more selected slots are invalid.'
                );
                return;
            }

            if (count($this->slot_ids) !== count(array_unique($this->slot_ids))) {
                $validator->errors()->add(
                    'slot_ids',
                    'Duplicate slots are not allowed.'
                );
                return;
            }

            $bookingDay = strtolower(
                \Carbon\Carbon::parse($this->booking_date)->format('l')
            );

            foreach ($slots as $slot) {

                if ((int) $slot->turf_id !== (int) $this->turf_id) {
                    $validator->errors()->add(
                        'slot_ids',
                        'Selected slot does not belong to the selected turf.'
                    );
                    return;
                }

                if ($slot->booking_type != $this->booking_type) {
                    $validator->errors()->add(
                        'slot_ids',
                        'Selected slot does not match the booking type.'
                    );
                    return;
                }

                if ((int) $slot->booking_type_id !== (int) $this->booking_type_id) {
                    $validator->errors()->add(
                        'slot_ids',
                        'Selected slot does not belong to the selected sport/event.'
                    );
                    return;
                }

                if ($slot->day !== $bookingDay) {
                    $validator->errors()->add(
                        'booking_date',
                        'Selected slot is not available on the chosen date.'
                    );
                    return;
                }

            }

            // Already part of a real (pending/confirmed/completed) booking?
            $alreadyBooked = BookingItem::query()
                ->whereIn('slot_master_id', $this->slot_ids)
                ->whereHas('booking', function ($query) {
                    $query->whereDate('booking_date', $this->booking_date)
                        ->whereIn('booking_status', [
                            'pending',
                            'confirmed',
                            'completed',
                        ]);
                })
                ->exists();

            if ($alreadyBooked) {
                $validator->errors()->add(
                    'slot_ids',
                    'One or more selected slots are already booked.'
                );
                return;
            }

            // Held by ANY user right now (their 10-minute window hasn't
            // expired yet)? Then it's not available to add to a new cart.
            $activelyHeld = CartItemSlot::query()
                ->whereIn('slot_master_id', $this->slot_ids)
                ->whereHas('cartItem', function ($query) {
                    $query->whereDate('booking_date', $this->booking_date)
                        ->where('expires_at', '>', now());
                })
                ->exists();

            if ($activelyHeld) {
                $validator->errors()->add(
                    'slot_ids',
                    'One or more selected slots are currently held by another user. Please try again in a few minutes.'
                );
                return;
            }

            if ($this->booking_date === now()->toDateString()) {

                $currentTime = now()->format('H:i:s');

                foreach ($slots as $slot) {
                    if ($slot->start_time <= $currentTime) {
                        $validator->errors()->add(
                            'slot_ids',
                            "The slot {$slot->start_time} - {$slot->end_time} has already started."
                        );
                        return;
                    }
                }
            }

        });
    }
}