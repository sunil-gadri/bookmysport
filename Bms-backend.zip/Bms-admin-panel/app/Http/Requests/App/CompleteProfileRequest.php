<?php

namespace App\Http\Requests\App;

use Illuminate\Foundation\Http\FormRequest;

class CompleteProfileRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Validation rules.
     */
    public function rules(): array
    {
        return [
            'full_name'     => 'required|string|max:100',
            'email'         => 'required|email|max:255|unique:user_profiles,email',
            'profile_image' => 'required|image|mimes:jpg,jpeg,png|max:2048',
            'gender'        => 'required|in:Male,Female,Other',
            'date_of_birth' => 'required|date',

            'country_id'    => 'required|exists:countries,id',
            'state_id'      => 'required|exists:states,id',
            'city_id'       => 'required|exists:cities,id',

            'address'       => 'required|string|max:255',
            'pincode'       => 'required|digits_between:4,10',

            'favourite_sports' => [
                'nullable',
                'array',
            ],

            'favourite_sports.*' => [
                'integer',
                'distinct',
                'exists:sports,id',
            ],

        ];
    }
}