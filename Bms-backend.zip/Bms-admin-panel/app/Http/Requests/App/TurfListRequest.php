<?php

namespace App\Http\Requests\App;

use Illuminate\Foundation\Http\FormRequest;

class TurfListRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [

            'search' => 'nullable|string|max:100',

            'sport_id' => 'nullable|string',

            'event_id' => 'nullable|string',

            'amenity_id' => 'nullable|string',

            'city_id' => 'nullable|exists:cities,id',

            'sort_by' => 'nullable|in:name,created_at,average_rating',

            'sort_order' => 'nullable|in:asc,desc',

            'per_page' => 'nullable|integer|min:1|max:50',

            'latitude' => [
                'nullable',
                'numeric',
                'between:-90,90',
            ],

            'longitude' => [
                'nullable',
                'numeric',
                'between:-180,180',
            ],

        ];
    }
}