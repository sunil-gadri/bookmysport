<?php

namespace App\Http\Requests\App;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;


class UpdateProfileRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'full_name'     => 'sometimes|required|string|max:100',
            'email' => [
                'sometimes',
                'nullable',
                'email',
                'max:255',
                Rule::unique('user_profiles', 'email')->ignore(auth()->user()->profile->id),
            ],
            'profile_image' => 'sometimes|nullable|image|mimes:jpg,jpeg,png|max:2048',
            'gender'        => 'sometimes|nullable|in:Male,Female,Other',
            'date_of_birth' => 'sometimes|nullable|date',

            'country_id'    => 'sometimes|required|exists:countries,id',
            'state_id'      => 'sometimes|required|exists:states,id',
            'city_id'       => 'sometimes|required|exists:cities,id',

            'address'       => 'sometimes|nullable|string|max:255',
            'pincode'       => 'sometimes|nullable|digits_between:4,10',

            'favourite_sports' => [
                'sometimes',
                'array',
            ],

            'favourite_sports.*' => [
                'integer',
                'distinct',
                'exists:sports,id',
            ],

        ];
    }
}