<?php

namespace App\Http\Requests\App;

use Illuminate\Foundation\Http\FormRequest;

class FavouriteTurfRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'turf_id' => [
                'required',
                'integer',
                'exists:turfs,id',
            ],
        ];
    }
}