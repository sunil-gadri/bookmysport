<?php

namespace App\Http\Requests\App;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\SlotMaster;
use App\Models\BookingItem;

class RescheduleBookingRequest extends FormRequest
{
    public function authorize(): bool
    {
        // The controller itself checks that the booking belongs to the
        // logged-in user (needed there anyway, to return a clean 404
        // instead of a 403 that leaks whether the booking id exists).
        return true;
    }

    public function rules(): array
    {
        return [

            'booking_date' => [
                'required',
                'date',
                'after_or_equal:today',
            ],

            'slot_ids' => [
                'required',
                'array',
                'min:1',
            ],

            'slot_ids.*' => [
                'required',
                'integer',
                'exists:slot_masters,id',
            ],

        ];
    }

    public function messages(): array
    {
        return [
            'booking_date.after_or_equal' => 'New date cannot be in the past.',
            'slot_ids.required' => 'Please select at least one slot.',
        ];
    }

    public function withValidator($validator): void
    {
        $validator->after(function ($validator) {

            /** @var \App\Models\Booking $booking */
            $booking = $this->route('booking');

            if (!$booking) {
                return;
            }

            $slots = SlotMaster::whereIn('id', $this->slot_ids)
                ->where('status', true)
                ->get();

            if ($slots->count() !== count($this->slot_ids)) {
                $validator->errors()->add('slot_ids', 'One or more selected slots are invalid.');
                return;
            }

            if (count($this->slot_ids) !== count(array_unique($this->slot_ids))) {
                $validator->errors()->add('slot_ids', 'Duplicate slots are not allowed.');
                return;
            }

            $bookingDay = strtolower(\Carbon\Carbon::parse($this->booking_date)->format('l'));

            foreach ($slots as $slot) {

                // Must stay on the same turf and same sport/event as the
                // original booking — changing the sport is a new booking,
                // not a reschedule.
                if ((int) $slot->turf_id !== (int) $booking->turf_id) {
                    $validator->errors()->add('slot_ids', 'Selected slot does not belong to this booking\'s turf.');
                    return;
                }

                if ($slot->booking_type !== $booking->booking_type
                    || (int) $slot->booking_type_id !== (int) $booking->booking_type_id) {
                    $validator->errors()->add('slot_ids', 'Selected slot does not match this booking\'s sport/event.');
                    return;
                }

                if ($slot->day !== $bookingDay) {
                    $validator->errors()->add('booking_date', 'Selected slot is not available on the chosen date.');
                    return;
                }
            }

            // Already booked by someone else (excluding this same booking,
            // in case the user re-selects one of their own current slots)?
            $alreadyBooked = BookingItem::query()
                ->whereIn('slot_master_id', $this->slot_ids)
                ->where('booking_id', '!=', $booking->id)
                ->whereHas('booking', function ($query) {
                    $query->whereDate('booking_date', $this->booking_date)
                        ->whereIn('booking_status', ['pending', 'confirmed', 'completed']);
                })
                ->exists();

            if ($alreadyBooked) {
                $validator->errors()->add('slot_ids', 'One or more selected slots are already booked.');
                return;
            }

            if ($this->booking_date === now()->toDateString()) {
                $currentTime = now()->format('H:i:s');
                foreach ($slots as $slot) {
                    if ($slot->start_time <= $currentTime) {
                        $validator->errors()->add('slot_ids', "The slot {$slot->start_time} has already started.");
                        return;
                    }
                }
            }

            // New slots must add up to EXACTLY the same price as the
            // original booking — no extra payment or refund flow exists,
            // so a price change simply isn't allowed here.
            //
            // NOTE: compared with a small tolerance (1 paisa) instead of
            // strict equality — floating point arithmetic can produce
            // tiny differences like 1100.0 vs 1099.9999999999998 even
            // when the "real" amounts are identical, which a strict !==
            // comparison would incorrectly reject.
            $newTotal = (float) $slots->sum('price');
            $originalTotal = (float) $booking->total_amount;

            if (abs($newTotal - $originalTotal) > 0.01) {
                $validator->errors()->add(
                    'slot_ids',
                    "Selected slots total ₹{$newTotal}, but this booking must be rescheduled to slots totalling the same amount as before (₹{$originalTotal})."
                );
                return;
            }
        });
    }
}