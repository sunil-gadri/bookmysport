<?php

namespace App\Http\Requests\App;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\Booking;
use App\Models\Review;

class StoreReviewRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [

            'booking_id' => [
                'required',
                'integer',
                'exists:bookings,id',
            ],

            'rating' => [
                'required',
                'integer',
                'min:1',
                'max:5',
            ],

            'what_went_well' => [
                'nullable',
                'array',
            ],

            'what_went_well.*' => [
                'string',
                'distinct',
                'in:' . implode(',', Review::HIGHLIGHT_OPTIONS),
            ],

            'comment' => [
                'nullable',
                'string',
                'max:1000',
            ],

        ];
    }

    public function withValidator($validator): void
    {
        $validator->after(function ($validator) {

            $booking = Booking::find($this->booking_id);

            if (!$booking) {
                return; // already caught by 'exists' rule above
            }

            if ($booking->user_id !== auth()->id()) {
                $validator->errors()->add(
                    'booking_id',
                    'This booking does not belong to you.'
                );
                return;
            }

            if ($booking->booking_status !== 'completed') {
                $validator->errors()->add(
                    'booking_id',
                    'You can only review a booking after it has been completed.'
                );
                return;
            }

            if ($booking->checked_in_at === null) {
                $validator->errors()->add(
                    'booking_id',
                    'You can only review a booking you actually checked in for.'
                );
                return;
            }

            $alreadyReviewed = Review::where('booking_id', $booking->id)->exists();

            if ($alreadyReviewed) {
                $validator->errors()->add(
                    'booking_id',
                    'You have already reviewed this booking.'
                );
                return;
            }
        });
    }
}