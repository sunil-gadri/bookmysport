<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Booking Confirmed - BookMySport</title>
</head>

<body style="
    margin: 0;
    padding: 0;
    background-color: #f4f6f8;
    font-family: Arial, Helvetica, sans-serif;
">

<table width="100%" cellpadding="0" cellspacing="0" style="padding: 30px 15px;">
    <tr>
        <td align="center">

            <table
                width="600"
                cellpadding="0"
                cellspacing="0"
                style="
                    max-width: 600px;
                    width: 100%;
                    background-color: #ffffff;
                    border-radius: 12px;
                    overflow: hidden;
                "
            >

                <!-- Header -->
                <tr>
                    <td style="
                        background-color: #111827;
                        padding: 25px;
                        text-align: center;
                    ">
                        <h1 style="
                            margin: 0;
                            color: #ffffff;
                            font-size: 28px;
                        ">
                            BookMySport
                        </h1>

                        <p style="
                            margin: 8px 0 0;
                            color: #d1d5db;
                            font-size: 14px;
                        ">
                            Your booking has been confirmed
                        </p>
                    </td>
                </tr>

                <!-- Success -->
                <tr>
                    <td style="padding: 30px;">

                        <h2 style="
                            margin-top: 0;
                            color: #111827;
                        ">
                            Booking Confirmed! 🎉
                        </h2>

                        <p style="
                            color: #4b5563;
                            font-size: 15px;
                            line-height: 1.6;
                        ">
                            Hi <?php echo e($booking->user->name ?? 'User'); ?>,
                        </p>

                        <p style="
                            color: #4b5563;
                            font-size: 15px;
                            line-height: 1.6;
                        ">
                            Your booking has been successfully confirmed.
                            Here are your booking details:
                        </p>

                        <!-- Booking Details -->
                        <table
                            width="100%"
                            cellpadding="10"
                            cellspacing="0"
                            style="
                                margin-top: 20px;
                                border: 1px solid #e5e7eb;
                                border-radius: 8px;
                            "
                        >

                            <tr>
                                <td style="color: #6b7280;">
                                    Booking ID
                                </td>

                                <td align="right" style="
                                    color: #111827;
                                    font-weight: bold;
                                ">
                                    <?php echo e($booking->booking_number); ?>

                                </td>
                            </tr>

                            <tr>
                                <td style="color: #6b7280;">
                                    Turf
                                </td>

                                <td align="right" style="
                                    color: #111827;
                                    font-weight: bold;
                                ">
                                    <?php echo e($booking->turf->name ?? 'N/A'); ?>

                                </td>
                            </tr>

                            <tr>
                                <td style="color: #6b7280;">
                                    Sport / Event
                                </td>

                                <td align="right" style="
                                    color: #111827;
                                    font-weight: bold;
                                ">
                                    <?php echo e($booking->booking_type === 'sport' ? 'Sport' : 'Event'); ?>

                                </td>
                            </tr>

                            <tr>
                                <td style="color: #6b7280;">
                                    Date
                                </td>

                                <td align="right" style="
                                    color: #111827;
                                    font-weight: bold;
                                ">
                                    <?php echo e($booking->booking_date->format('d M Y')); ?>

                                </td>
                            </tr>

                            <tr>
                                <td style="color: #6b7280;">
                                    Amount
                                </td>

                                <td align="right" style="
                                    color: #111827;
                                    font-weight: bold;
                                ">
                                    ₹<?php echo e(number_format((float) $booking->total_amount, 2)); ?>

                                </td>
                            </tr>

                            <tr>
                                <td style="color: #6b7280;">
                                    Payment Status
                                </td>

                                <td align="right" style="
                                    color: #16a34a;
                                    font-weight: bold;
                                ">
                                    Paid
                                </td>
                            </tr>

                            <tr>
                                <td style="color: #6b7280;">
                                    Booking Status
                                </td>

                                <td align="right" style="
                                    color: #16a34a;
                                    font-weight: bold;
                                ">
                                    Confirmed
                                </td>
                            </tr>

                        </table>

                        <p style="
                            margin-top: 25px;
                            color: #4b5563;
                            font-size: 14px;
                            line-height: 1.6;
                        ">
                            Please keep your booking details safe.
                            You can use your BookMySport app to view your booking
                            and check-in details.
                        </p>

                        <p style="
                            color: #4b5563;
                            font-size: 14px;
                        ">
                            Thank you for choosing
                            <strong>BookMySport</strong>.
                        </p>

                    </td>
                </tr>

                <!-- Footer -->
                <tr>
                    <td style="
                        background-color: #f9fafb;
                        padding: 20px;
                        text-align: center;
                    ">

                        <p style="
                            margin: 0;
                            color: #6b7280;
                            font-size: 12px;
                        ">
                            © <?php echo e(date('Y')); ?> BookMySport. All rights reserved.
                        </p>

                    </td>
                </tr>

            </table>

        </td>
    </tr>
</table>

</body>
</html><?php /**PATH C:\xampp_new\htdocs\Bms-admin-panel\resources\views/emails/booking-confirmed.blade.php ENDPATH**/ ?>