<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /*** Run the migrations. */

    public function up(): void
    {
        
        Schema::create('turf_owner_profiles', function (Blueprint $table) {
            $table->id();

            $table->foreignId('user_id')
                ->unique()
                ->constrained('users')
                ->cascadeOnDelete();

            $table->string('business_name', 150);

            $table->string('business_email')->nullable();

            $table->string('business_phone', 20)->nullable();

            $table->string('profile_image')->nullable();

            $table->text('description')->nullable();

            $table->text('address')->nullable();

            $table->foreignId('country_id')
                ->nullable()
                ->constrained('countries')
                ->nullOnDelete();

            $table->foreignId('state_id')
                ->nullable()
                ->constrained('states')
                ->nullOnDelete();

            $table->foreignId('city_id')
                ->nullable()
                ->constrained('cities')
                ->nullOnDelete();

            $table->string('pincode', 10)->nullable();

            $table->timestamps();
        });

    }

    /*** Reverse the migrations. */

    public function down(): void
    {
        Schema::dropIfExists('turf_owner_profiles');
    }

};
