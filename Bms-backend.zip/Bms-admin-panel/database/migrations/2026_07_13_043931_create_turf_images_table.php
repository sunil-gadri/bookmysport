<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('turf_images', function (Blueprint $table) {

            $table->id();

            $table->foreignId('turf_id')
                ->constrained('turfs')
                ->cascadeOnDelete();

            $table->string('image');

            $table->unsignedInteger('sort_order')->default(0);

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('turf_images');
    }
};