<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('reviews', function (Blueprint $table) {

            // User's overall experience for this booking — separate
            // from the numeric star rating, shown as a select on the
            // frontend (Very Bad / Bad / Good / Very Good).
            $table->enum('what_went_well', [
                'very_bad',
                'bad',
                'good',
                'very_good',
            ])->nullable()->after('rating');

        });
    }

    public function down(): void
    {
        Schema::table('reviews', function (Blueprint $table) {
            $table->dropColumn('what_went_well');
        });
    }
};