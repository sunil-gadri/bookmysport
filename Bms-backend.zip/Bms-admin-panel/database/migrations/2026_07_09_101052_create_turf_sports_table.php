<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('turf_sports', function (Blueprint $table) {

            $table->id();

            $table->foreignId('turf_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->foreignId('sport_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->timestamps();

            // Prevent the same sport being linked to the same turf twice.
            $table->unique(['turf_id', 'sport_id']);

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('turf_sports');
    }
};