<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('turfs', function (Blueprint $table) {

            $table->string('area', 150)
                ->nullable()
                ->after('address');

        });
    }

    public function down(): void
    {
        Schema::table('turfs', function (Blueprint $table) {

            $table->dropColumn('area');

        });
    }
};