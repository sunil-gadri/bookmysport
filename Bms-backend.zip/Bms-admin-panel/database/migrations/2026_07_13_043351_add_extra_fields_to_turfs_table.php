<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('turfs', function (Blueprint $table) {

            $table->string('cover_image')->nullable()->after('description');

            $table->string('landmark')->nullable()->after('address');

            $table->time('opening_time')->nullable()->after('longitude');

            $table->time('closing_time')->nullable()->after('opening_time');

            $table->boolean('is_featured')->default(false)->after('closing_time');

            $table->decimal('average_rating', 3, 2)
                  ->default(0.00)
                  ->after('is_featured');

            $table->unsignedInteger('total_reviews')
                  ->default(0)
                  ->after('average_rating');
        });
    }

    public function down(): void
    {
        Schema::table('turfs', function (Blueprint $table) {

            $table->dropColumn([
                'cover_image',
                'landmark',
                'opening_time',
                'closing_time',
                'is_featured',
                'average_rating',
                'total_reviews',
            ]);
        });
    }
};