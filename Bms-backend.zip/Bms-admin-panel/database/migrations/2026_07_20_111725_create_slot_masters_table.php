<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /*** Run the migrations.*/
    
    public function up(): void
    {
        Schema::create('slot_masters', function (Blueprint $table) {

            $table->id();

            $table->foreignId('turf_id')
                ->constrained('turfs')
                ->cascadeOnDelete();

            $table->enum('booking_type', ['sport', 'event']);

            $table->unsignedBigInteger('booking_type_id');

            $table->enum('day', [
                'monday',
                'tuesday',
                'wednesday',
                'thursday',
                'friday',
                'saturday',
                'sunday',
            ]);

            $table->time('start_time');

            $table->time('end_time');

            $table->decimal('price', 10, 2);

            $table->boolean('status')->default(true);

            $table->timestamps();

            $table->unique([
                'turf_id',
                'booking_type',
                'booking_type_id',
                'day',
                'start_time',
                'end_time'
            ], 'slot_unique');
        });

    }

    /*** Reverse the migrations.*/

    public function down(): void
    {
        Schema::dropIfExists('slot_masters');
    }
};
