<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payment_orders', function (Blueprint $table) {

            $table->id();

            $table->foreignId('user_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->string('razorpay_order_id')->unique();

            $table->string('razorpay_payment_id')->nullable();

            $table->decimal('amount', 10, 2);

            $table->string('currency')->default('INR');

            $table->enum('status', [
                'created',
                'paid',
                'failed',
            ])->default('created');

            // Set once bookings have actually been created from this
            // order — makes finalization safe to call twice (e.g. once
            // from the app's verify call, once from Razorpay's webhook)
            // without creating duplicate bookings.
            $table->timestamp('finalized_at')->nullable();

            $table->timestamps();

        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payment_orders');
    }
};