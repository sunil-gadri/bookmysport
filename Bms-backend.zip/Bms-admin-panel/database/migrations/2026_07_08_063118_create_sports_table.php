<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sports', function (Blueprint $table) {
            $table->id();

            $table->string('name', 100)->unique();

            $table->string('slug', 100)->unique();

            $table->string('icon')->nullable();

            $table->tinyInteger('status')
                ->default(1)
                ->comment('1 = Active, 0 = Inactive');

            $table->unsignedInteger('sort_order')->default(0);

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sports');
    }
};