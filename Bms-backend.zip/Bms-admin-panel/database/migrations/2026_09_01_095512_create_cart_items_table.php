<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * A cart_item represents ONE group: one turf + one sport/event + one date.
     * The actual slots picked inside that group live in cart_item_slots.
     * Adding to cart does NOT touch slot_masters / bookings at all —
     * a real Booking row is only created at checkout time.
     */
    public function up(): void
    {
        Schema::create('cart_items', function (Blueprint $table) {

            $table->id();

            $table->foreignId('user_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->foreignId('turf_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->enum('booking_type', [
                'sport',
                'event',
            ]);

            $table->unsignedBigInteger('booking_type_id');

            $table->date('booking_date');

            // The slot is "held" (blocked for everyone else) until this
            // moment. If payment isn't completed before this time, the
            // scheduled job below deletes the row and the slot frees up.
            $table->timestamp('expires_at');

            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cart_items');
    }
};