<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('sports', function (Blueprint $table) {
            $table->string('selected_icon')
                ->nullable()
                ->after('slug');

            $table->string('unselected_icon')
                ->nullable()
                ->after('selected_icon');
        });
    }

    public function down(): void
    {
        Schema::table('sports', function (Blueprint $table) {
            $table->dropColumn([
                'selected_icon',
                'unselected_icon',
            ]);
        });
    }
};