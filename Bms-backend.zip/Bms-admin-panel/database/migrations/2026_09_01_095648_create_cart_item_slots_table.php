<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('cart_item_slots', function (Blueprint $table) {

            $table->id();

            $table->foreignId('cart_item_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->foreignId('slot_master_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->decimal('price', 10, 2);

            $table->timestamps();

            // Same slot can't be added twice inside the same cart group
            $table->unique(['cart_item_id', 'slot_master_id']);

        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cart_item_slots');
    }
};