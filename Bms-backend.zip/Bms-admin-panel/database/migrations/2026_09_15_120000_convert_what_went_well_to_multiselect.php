<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    private string $tempColumn = 'what_went_well_multiselect_tmp';

    public function up(): void
    {
        if (!Schema::hasColumn('reviews', $this->tempColumn)) {
            Schema::table('reviews', function (Blueprint $table) {
                $table->json($this->tempColumn)->nullable()->after('rating');
            });
        }

        if (Schema::hasColumn('reviews', 'what_went_well')) {
            DB::table('reviews')
                ->whereNotNull('what_went_well')
                ->whereNull($this->tempColumn)
                ->orderBy('id')
                ->chunkById(200, function ($rows) {
                    foreach ($rows as $row) {
                        DB::table('reviews')
                            ->where('id', $row->id)
                            ->update([
                                $this->tempColumn => json_encode([$row->what_went_well]),
                            ]);
                    }
                });
        }

        if (Schema::hasColumn('reviews', 'what_went_well')) {
            Schema::table('reviews', function (Blueprint $table) {
                $table->dropColumn('what_went_well');
            });
        }

        if (!Schema::hasColumn('reviews', 'what_went_well') && Schema::hasColumn('reviews', $this->tempColumn)) {
            Schema::table('reviews', function (Blueprint $table) {
                $table->renameColumn($this->tempColumn, 'what_went_well');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('reviews', 'what_went_well')) {
            Schema::table('reviews', function (Blueprint $table) {
                $table->renameColumn('what_went_well', $this->tempColumn);
            });
        }

        if (!Schema::hasColumn('reviews', 'what_went_well')) {
            Schema::table('reviews', function (Blueprint $table) {
                $table->enum('what_went_well', [
                    'very_bad', 'bad', 'good', 'very_good',
                ])->nullable()->after('rating');
            });
        }

        DB::table('reviews')
            ->whereNotNull($this->tempColumn)
            ->orderBy('id')
            ->chunkById(200, function ($rows) {
                foreach ($rows as $row) {
                    $decoded = json_decode($row->{$this->tempColumn}, true);
                    DB::table('reviews')
                        ->where('id', $row->id)
                        ->update(['what_went_well' => $decoded[0] ?? null]);
                }
            });

        if (Schema::hasColumn('reviews', $this->tempColumn)) {
            Schema::table('reviews', function (Blueprint $table) {
                $table->dropColumn($this->tempColumn);
            });
        }
    }
};