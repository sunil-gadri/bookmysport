<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('turfs', function (Blueprint $table) {

            $table->enum('ground_type', [
                'single',
                'multiple'
            ])->default('single')->after('closing_time');

        });
    }

    public function down(): void
    {
        Schema::table('turfs', function (Blueprint $table) {

            $table->dropColumn('ground_type');

        });
    }
};