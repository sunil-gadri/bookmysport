<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('turfs', function (Blueprint $table) {
            $table->id();

            $table->foreignId('owner_id')
                ->constrained('users')
                ->cascadeOnDelete();

            $table->string('name', 150);

            $table->string('slug')->unique();

            $table->text('description')->nullable();

            $table->string('contact_number', 20);

            $table->string('email')->nullable();

            $table->text('address');

            $table->foreignId('country_id')
                ->constrained('countries');

            $table->foreignId('state_id')
                ->constrained('states');

            $table->foreignId('city_id')
                ->constrained('cities');

            $table->string('pincode', 10);

            $table->decimal('latitude', 10, 7)->nullable();

            $table->decimal('longitude', 10, 7)->nullable();

            $table->boolean('status')->default(true);

            $table->enum('approval_status', [
                'draft',
                'pending',
                'approved',
                'rejected'
            ])->default('draft');

            $table->text('rejection_reason')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('turfs');
    }
};
