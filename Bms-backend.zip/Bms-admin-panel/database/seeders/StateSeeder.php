<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;  // ← was missing

class StateSeeder extends Seeder
{
    public function run(): void
    {
        $json = file_get_contents(database_path('data/states.json'));
        $states = json_decode($json, true);

        $rows = array_map(fn($s) => [
            'id'         => $s['id'],
            'name'       => $s['name'],
            'country_id' => $s['country_id'],
            'status'     => 1,
        ], $states);

        foreach (array_chunk($rows, 100) as $chunk) {
            DB::table('states')->insert($chunk);
        }
    }
}