<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CitySeeder extends Seeder
{
    public function run(): void
    {
        // Disable FK checks so orphaned cities don't throw errors
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        $json = file_get_contents(database_path('data/cities.json'));
        $cities = json_decode($json, true);

        $rows = array_map(fn($c) => [
            'id'       => $c['id'],
            'name'     => $c['name'],
            'state_id' => $c['state_id'],
            'status'   => 1,
        ], $cities);

        foreach (array_chunk($rows, 500) as $chunk) {
            DB::table('cities')->insert($chunk);
        }

        // Re-enable FK checks
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}