<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;  // ← was missing

class CountrySeeder extends Seeder
{
    public function run(): void
    {
        $json = file_get_contents(database_path('data/countries.json'));
        $countries = json_decode($json, true);

        $rows = array_map(fn($c) => [
            'id'         => $c['id'],
            'iso2'       => $c['iso2'],
            'name'       => $c['name'],
            'phone_code' => $c['phone_code'],
            'status'     => 1,
        ], $countries);

        foreach (array_chunk($rows, 100) as $chunk) {
            DB::table('countries')->insert($chunk);
        }
    }
}