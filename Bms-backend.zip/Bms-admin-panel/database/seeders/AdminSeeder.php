<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Role;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    public function run(): void
    {
        $admin = User::updateOrCreate(
            [
                'email' => 'admin@bookmysport.com',
            ],
            [
                'name' => 'Admin',
                'password' => Hash::make('12345678'),
                'status' => true,
            ]
        );

        $adminRole = Role::where('slug', 'admin')->firstOrFail();

        $admin->roles()->syncWithoutDetaching([
            $adminRole->id
        ]);
    }
}