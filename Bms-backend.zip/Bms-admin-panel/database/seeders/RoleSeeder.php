<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Role;

class RoleSeeder extends Seeder
{
    public function run(): void
    {
        Role::updateOrCreate(
            ['slug' => 'admin'],
            ['name' => 'Admin']
        );

        Role::updateOrCreate(
            ['slug' => 'turf_owner'],
            ['name' => 'Turf Owner']
        );

        Role::updateOrCreate(
            ['slug' => 'user'],
            ['name' => 'User']
        );
    }
}