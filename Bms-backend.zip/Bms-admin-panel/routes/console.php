<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// Free up any slots whose 10-minute cart hold has run out.
Schedule::command('cart:expire')->everyMinute();

// Move past bookings from "confirmed" to "completed" once their slot has ended.
Schedule::command('bookings:complete')->everyFifteenMinutes();