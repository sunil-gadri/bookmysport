<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\MasterController;

use App\Http\Controllers\Api\Admin\UserController;
use App\Http\Controllers\Api\Admin\SportController;
use App\Http\Controllers\Api\Admin\AmenityController;
use App\Http\Controllers\Api\Admin\AdminTurfController;
use App\Http\Controllers\Api\Admin\BookingController as AdminBookingController;
use App\Http\Controllers\Api\Admin\SlotMasterController as AdminSlotMasterController;
use App\Http\Controllers\Api\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Api\Admin\EventController;

use App\Http\Controllers\Api\TurfOwner\TurfOwnerProfileController;
use App\Http\Controllers\Api\TurfOwner\SlotMasterController;
use App\Http\Controllers\Api\TurfOwner\TurfController as TurfOwnerTurfController;
use App\Http\Controllers\Api\TurfOwner\BookingCheckInController;
use App\Http\Controllers\Api\TurfOwner\BookingController as TurfOwnerBookingController;
use App\Http\Controllers\Api\TurfOwner\DashboardController as TurfOwnerDashboardController;

use App\Http\Controllers\Api\App\UserProfileController;
use App\Http\Controllers\Api\App\AppHomeController;
use App\Http\Controllers\Api\App\AppEventController;
use App\Http\Controllers\Api\App\AppAmenityController;
use App\Http\Controllers\Api\App\AppTurfController;
use App\Http\Controllers\Api\App\AppSportController;
use App\Http\Controllers\Api\App\AppFavouriteController;
use App\Http\Controllers\Api\App\CartController;
use App\Http\Controllers\Api\App\RazorpayController;
use App\Http\Controllers\Api\App\BookingController;
use App\Http\Controllers\Api\App\ReviewController;



Route::post('/admin/login', [AuthController::class, 'adminLogin']);
Route::post('/send-otp', [AuthController::class, 'sendOtp']);
Route::post('/verify-otp', [AuthController::class, 'verifyOtp']);
Route::get('/turfs/{turf}/reviews', [ReviewController::class, 'index']);



Route::prefix('masters')->group(function () {
    Route::get('/countries', [MasterController::class, 'countries']);
    Route::get('/states', [MasterController::class, 'states']);
    Route::get('/cities', [MasterController::class, 'cities']);
    Route::get('/pincode-lookup', [MasterController::class, 'pincodeLookup']);
});

// Public — Razorpay's server calls this directly, it has no user login
// token. Security here comes from the webhook signature check inside
// the controller, NOT from auth middleware.
Route::post('/webhooks/razorpay/payment', [RazorpayController::class, 'webhook']);

Route::middleware('auth:sanctum')->group(function () {

    // Route::get('/profile', [AuthController::class, 'profile']);
    Route::post('/logout', [AuthController::class, 'logout']);


    Route::get('/sports', [AppSportController::class, 'index']);
    Route::get('/events', [AppEventController::class, 'index']);
    Route::get('/amenities', [AppAmenityController::class, 'index']);



    Route::middleware('role:user')->group(function () {


        Route::get('/turfs', [AppTurfController::class, 'index']);
        Route::get('/turfs/{turf}', [AppTurfController::class, 'show']);
        Route::get('/home', [AppHomeController::class, 'index']);
        Route::post('/favourites/toggle', [AppFavouriteController::class, 'toggle']);
        Route::get('/favourites', [AppFavouriteController::class, 'index']);

        Route::get('/turfs/{turf}/slots', [AppTurfController::class, 'slots']);

        Route::prefix('bookings')->group(function () {

            Route::get('/', [BookingController::class, 'index']);
            Route::post('/', [BookingController::class, 'store']);
            Route::get('/{booking}', [BookingController::class, 'show']);
            Route::patch('/{booking}/cancel', [BookingController::class, 'cancel']);
            Route::patch('/{booking}/reschedule', [BookingController::class, 'reschedule']);
        });

        Route::prefix('cart')->group(function () {

            Route::get('/', [CartController::class, 'index']);
            Route::post('/items', [CartController::class, 'store']);
            Route::delete('/items/{cartItem}', [CartController::class, 'destroy']);
            Route::delete('/items/{cartItem}/slots/{slotMasterId}', [CartController::class, 'destroySlot']);
            Route::delete('/', [CartController::class, 'clear']);

            // Real payment flow — replaces the old plain "checkout".
            Route::post('/razorpay/order', [RazorpayController::class, 'createOrder']);
            Route::post('/razorpay/verify', [RazorpayController::class, 'verify']);
        });


        Route::prefix('profile')->group(function () {
            Route::post('/complete', [UserProfileController::class, 'completeProfile']);
            Route::get('/', [UserProfileController::class, 'getProfile']);
            Route::post('/update', [UserProfileController::class, 'updateProfile']);
        });

        Route::get('/my-reviews', [ReviewController::class, 'myReviews']);
        Route::post('/reviews', [ReviewController::class, 'store']);
        Route::patch('/reviews/{review}', [ReviewController::class, 'update']);
        Route::delete('/reviews/{review}', [ReviewController::class, 'destroy']);
    });


    Route::middleware('role:admin')->group(function () {

        Route::prefix('admin')->group(function () {

            Route::get('/dashboard', [AdminDashboardController::class, 'index']);

            Route::get('/users', [UserController::class, 'index']);
            Route::get('/users/{user}', [UserController::class, 'show']);
            Route::patch('/users/{user}/status', [UserController::class, 'updateStatus']);

            Route::post('/sports', [SportController::class, 'store']);
            Route::get('/sports', [SportController::class, 'index']);
            Route::get('/sports/{id}', [SportController::class, 'show']);
            Route::put('/sports/{id}', [SportController::class, 'update']);
            Route::patch('/sports/{id}/status', [SportController::class, 'updateStatus']);
            Route::delete('/sports/{id}', [SportController::class, 'destroy']);

            Route::get('/amenities', [AmenityController::class, 'index']);
            Route::post('/amenities', [AmenityController::class, 'store']);
            Route::get('/amenities/{id}', [AmenityController::class, 'show']);
            Route::post('/amenities/{id}', [AmenityController::class, 'update']);
            Route::patch('/amenities/{id}/status', [AmenityController::class, 'updateStatus']);
            Route::delete('/amenities/{id}', [AmenityController::class, 'destroy']);

            Route::post('/events', [EventController::class, 'store']);
            Route::get('/events', [EventController::class, 'index']);
            Route::get('/events/{id}', [EventController::class, 'show']);
            Route::post('/events/{id}', [EventController::class, 'update']);
            Route::delete('/events/{id}', [EventController::class, 'destroy']);
            Route::patch('/events/{id}/status', [EventController::class, 'changeStatus']);


            Route::get('/turfs', [AdminTurfController::class, 'index']);
            Route::get('/turfs/{turf}', [AdminTurfController::class, 'show']);
            Route::patch('/turfs/{turf}/approval-status', [AdminTurfController::class, 'updateApprovalStatus']);
            Route::post('/turfs/{turf}/approve', [AdminTurfController::class, 'approve']);
            Route::post('/turfs/{turf}/reject', [AdminTurfController::class, 'reject']);
            Route::patch('/turfs/{turf}/status', [AdminTurfController::class, 'updateStatus']);
            Route::patch('/turfs/{turf}/featured', [AdminTurfController::class, 'toggleFeatured']);

            Route::get('/turf-owners', [AdminTurfController::class, 'turfOwners']);
            Route::get('/turf-owner-details', [AdminTurfController::class, 'turfOwnerDetails']);

            Route::get('/bookings', [AdminBookingController::class, 'index']);
            Route::get('/bookings/{booking}', [AdminBookingController::class, 'show']);

            Route::get('/slots', [AdminSlotMasterController::class, 'index']);
            Route::patch('/slots/{slotMaster}/status', [AdminSlotMasterController::class, 'toggleStatus']);
            Route::delete('/slots/{slotMaster}', [AdminSlotMasterController::class, 'destroy']);
        });
    });


    Route::middleware('role:turf_owner')->prefix('turf-owner')->group(function () {

        Route::get('/dashboard', [TurfOwnerDashboardController::class, 'index']);

        Route::post('/profile/complete', [TurfOwnerProfileController::class, 'completeProfile']);
        Route::get('/profile', [TurfOwnerProfileController::class, 'getProfile']);
        Route::post('/profile/update', [TurfOwnerProfileController::class, 'updateProfile']);
        

        Route::post('/turfs', [TurfOwnerTurfController::class, 'store']);
        Route::get('/turfs', [TurfOwnerTurfController::class, 'index']);
        Route::get('/turfs/{turf}', [TurfOwnerTurfController::class, 'show']);
        Route::post('/turfs/{turf}', [TurfOwnerTurfController::class, 'update']);
        Route::delete('/turfs/{turf}', [TurfOwnerTurfController::class, 'destroy']);

        Route::get('/bookings', [TurfOwnerBookingController::class, 'index']);
        Route::get('/bookings/{booking}', [TurfOwnerBookingController::class, 'show']);
        Route::post('/bookings/check-in', [BookingCheckInController::class, 'checkIn']);

        Route::post('/slot-masters', [SlotMasterController::class, 'store']);
        Route::get('/slot-masters', [SlotMasterController::class, 'index']);
        Route::put('/slot-masters/{slotMaster}', [SlotMasterController::class, 'update']);
        Route::delete('/slot-masters/{slotMaster}', [SlotMasterController::class, 'destroy']);
        Route::patch('/slot-masters/{slotMaster}/status', [SlotMasterController::class, 'changeStatus']);
        Route::get('/slot-masters/dropdown-data', [SlotMasterController::class, 'dropdownData']);
        Route::get('/slot-masters/{slotMaster}', [SlotMasterController::class, 'show']);
        Route::post('/slot-masters/auto-generate', [SlotMasterController::class, 'autoGenerate']);
        Route::get('/slot-masters/turf-details/{turf}', [SlotMasterController::class, 'turfDetails']);
    });
});
