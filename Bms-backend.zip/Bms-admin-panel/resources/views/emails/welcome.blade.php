<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Welcome to BookMySport</title>
</head>

<body style="margin:0; padding:0; background-color:#0f0f14; font-family:Arial, Helvetica, sans-serif;">

<table role="presentation"
       width="100%"
       cellpadding="0"
       cellspacing="0"
       style="background-color:#0f0f14; padding:30px 0;">

    <tr>
        <td align="center">

            <table role="presentation"
                   width="480"
                   cellpadding="0"
                   cellspacing="0"
                   style="background-color:#16161f; border-radius:12px; overflow:hidden;">

                {{-- Header --}}
                <tr>
                    <td style="background-color:#2979FF; padding:32px 24px; text-align:center;">

                        <h1 style="color:#ffffff; margin:0; font-size:22px;">
                            🏏 BookMySport
                        </h1>

                    </td>
                </tr>

                {{-- Body --}}
                <tr>
                    <td style="padding:32px 28px;">

                        <h2 style="color:#ffffff; font-size:20px; margin:0 0 16px 0;">
                            Hi {{ $recipientName }}, welcome to BookMySport! 👋
                        </h2>

                        @if ($role === 'turf_owner')

                            <p style="color:#b0b0bd; font-size:14px; line-height:22px; margin:0 0 16px 0;">
                                Thank you for joining BookMySport as a turf partner.
                                Your turf has been successfully submitted.
                            </p>

                            <p style="color:#b0b0bd; font-size:14px; line-height:22px; margin:0 0 16px 0;">
                                You can now manage your turf and provide players
                                with a convenient way to discover and book your
                                sports facilities.
                            </p>

                            <table role="presentation"
                                   width="100%"
                                   cellpadding="0"
                                   cellspacing="0"
                                   style="margin-bottom:20px;">

                                <tr>
                                    <td style="color:#e0e0e5; font-size:14px; padding:7px 0;">
                                        📍 &nbsp; Manage your turf details
                                    </td>
                                </tr>

                                <tr>
                                    <td style="color:#e0e0e5; font-size:14px; padding:7px 0;">
                                        🏟️ &nbsp; Add sports, amenities and events
                                    </td>
                                </tr>

                                <tr>
                                    <td style="color:#e0e0e5; font-size:14px; padding:7px 0;">
                                        🗓️ &nbsp; Create and manage available slots
                                    </td>
                                </tr>

                                <tr>
                                    <td style="color:#e0e0e5; font-size:14px; padding:7px 0;">
                                        📅 &nbsp; Receive and manage bookings
                                    </td>
                                </tr>

                                <tr>
                                    <td style="color:#e0e0e5; font-size:14px; padding:7px 0;">
                                        💰 &nbsp; Grow your turf business
                                    </td>
                                </tr>

                            </table>

                            <p style="color:#b0b0bd; font-size:13px; line-height:20px; margin:0 0 20px 0;">
                                Your turf will be available to players after the
                                required approval process is completed.
                            </p>

                        @else

                            <p style="color:#b0b0bd; font-size:14px; line-height:22px; margin:0 0 16px 0;">
                                Your BookMySport account is ready.
                                Here's what you can do now:
                            </p>

                            <table role="presentation"
                                   width="100%"
                                   cellpadding="0"
                                   cellspacing="0"
                                   style="margin-bottom:20px;">

                                <tr>
                                    <td style="color:#e0e0e5; font-size:14px; padding:7px 0;">
                                        🔍 &nbsp; Find turfs near you
                                    </td>
                                </tr>

                                <tr>
                                    <td style="color:#e0e0e5; font-size:14px; padding:7px 0;">
                                        📅 &nbsp; Book your favourite sport and time slot
                                    </td>
                                </tr>

                                <tr>
                                    <td style="color:#e0e0e5; font-size:14px; padding:7px 0;">
                                        ⭐ &nbsp; Rate your visits and help other players
                                    </td>
                                </tr>

                            </table>

                        @endif

                        {{-- Button --}}
                        <div style="text-align:center; margin-top:8px;">

                            <a href="#"
                               style="
                                    display:inline-block;
                                    background-color:#2979FF;
                                    color:#ffffff;
                                    text-decoration:none;
                                    padding:12px 28px;
                                    border-radius:8px;
                                    font-size:14px;
                                    font-weight:bold;
                               ">
                                Open BookMySport
                            </a>

                        </div>

                    </td>
                </tr>

                {{-- Footer --}}
                <tr>
                    <td style="
                        padding:20px 28px;
                        border-top:1px solid #262633;
                        text-align:center;
                    ">

                        <p style="color:#6a6a78; font-size:11px; margin:0; line-height:18px;">
                            You're receiving this email because you joined
                            BookMySport.<br>
                            Need help? Contact us at
                            support@bookmysport.com
                        </p>

                    </td>
                </tr>

            </table>

        </td>
    </tr>

</table>

</body>
</html>